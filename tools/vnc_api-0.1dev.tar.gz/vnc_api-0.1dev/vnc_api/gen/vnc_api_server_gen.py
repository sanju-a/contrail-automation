
# AUTO-GENERATED file from IFMapApiGenerator. Do Not Edit!

from bottle import route, abort, request, response

import json
import uuid
from pprint import pformat

import common
from common.rest import LinkObject, hdr_server_tenant
from common.exceptions import *
from gen.resource_xsd import *
from gen.resource_common import *
from gen.resource_server import *

class VncApiServerGen(object):
    def __new__(cls, *args, **kwargs):
        obj = super(VncApiServerGen, cls).__new__(cls, *args, **kwargs)
        # leaf resource
        route('/domain/<id>', 'GET', obj.domain_http_get)
        route('/domain/<id>', 'PUT', obj.domain_http_put)
        route('/domain/<id>', 'DELETE', obj.domain_http_delete)
        # collections
        route('/domains', 'POST', obj.domains_http_post)
        route('/domains', 'GET', obj.domains_http_get)
        # leaf resource
        route('/service-instance/<id>', 'GET', obj.service_instance_http_get)
        route('/service-instance/<id>', 'PUT', obj.service_instance_http_put)
        route('/service-instance/<id>', 'DELETE', obj.service_instance_http_delete)
        # collections
        route('/service-instances', 'POST', obj.service_instances_http_post)
        route('/service-instances', 'GET', obj.service_instances_http_get)
        # leaf resource
        route('/instance-ip/<id>', 'GET', obj.instance_ip_http_get)
        route('/instance-ip/<id>', 'PUT', obj.instance_ip_http_put)
        route('/instance-ip/<id>', 'DELETE', obj.instance_ip_http_delete)
        # collections
        route('/instance-ips', 'POST', obj.instance_ips_http_post)
        route('/instance-ips', 'GET', obj.instance_ips_http_get)
        # leaf resource
        route('/network-policy/<id>', 'GET', obj.network_policy_http_get)
        route('/network-policy/<id>', 'PUT', obj.network_policy_http_put)
        route('/network-policy/<id>', 'DELETE', obj.network_policy_http_delete)
        # collections
        route('/network-policys', 'POST', obj.network_policys_http_post)
        route('/network-policys', 'GET', obj.network_policys_http_get)
        # leaf resource
        route('/virtual-DNS-record/<id>', 'GET', obj.virtual_DNS_record_http_get)
        route('/virtual-DNS-record/<id>', 'PUT', obj.virtual_DNS_record_http_put)
        route('/virtual-DNS-record/<id>', 'DELETE', obj.virtual_DNS_record_http_delete)
        # collections
        route('/virtual-DNS-records', 'POST', obj.virtual_DNS_records_http_post)
        route('/virtual-DNS-records', 'GET', obj.virtual_DNS_records_http_get)
        # leaf resource
        route('/route-target/<id>', 'GET', obj.route_target_http_get)
        route('/route-target/<id>', 'PUT', obj.route_target_http_put)
        route('/route-target/<id>', 'DELETE', obj.route_target_http_delete)
        # collections
        route('/route-targets', 'POST', obj.route_targets_http_post)
        route('/route-targets', 'GET', obj.route_targets_http_get)
        # leaf resource
        route('/floating-ip/<id>', 'GET', obj.floating_ip_http_get)
        route('/floating-ip/<id>', 'PUT', obj.floating_ip_http_put)
        route('/floating-ip/<id>', 'DELETE', obj.floating_ip_http_delete)
        # collections
        route('/floating-ips', 'POST', obj.floating_ips_http_post)
        route('/floating-ips', 'GET', obj.floating_ips_http_get)
        # leaf resource
        route('/floating-ip-pool/<id>', 'GET', obj.floating_ip_pool_http_get)
        route('/floating-ip-pool/<id>', 'PUT', obj.floating_ip_pool_http_put)
        route('/floating-ip-pool/<id>', 'DELETE', obj.floating_ip_pool_http_delete)
        # collections
        route('/floating-ip-pools', 'POST', obj.floating_ip_pools_http_post)
        route('/floating-ip-pools', 'GET', obj.floating_ip_pools_http_get)
        # leaf resource
        route('/physical-router/<id>', 'GET', obj.physical_router_http_get)
        route('/physical-router/<id>', 'PUT', obj.physical_router_http_put)
        route('/physical-router/<id>', 'DELETE', obj.physical_router_http_delete)
        # collections
        route('/physical-routers', 'POST', obj.physical_routers_http_post)
        route('/physical-routers', 'GET', obj.physical_routers_http_get)
        # leaf resource
        route('/bgp-router/<id>', 'GET', obj.bgp_router_http_get)
        route('/bgp-router/<id>', 'PUT', obj.bgp_router_http_put)
        route('/bgp-router/<id>', 'DELETE', obj.bgp_router_http_delete)
        # collections
        route('/bgp-routers', 'POST', obj.bgp_routers_http_post)
        route('/bgp-routers', 'GET', obj.bgp_routers_http_get)
        # leaf resource
        route('/virtual-router/<id>', 'GET', obj.virtual_router_http_get)
        route('/virtual-router/<id>', 'PUT', obj.virtual_router_http_put)
        route('/virtual-router/<id>', 'DELETE', obj.virtual_router_http_delete)
        # collections
        route('/virtual-routers', 'POST', obj.virtual_routers_http_post)
        route('/virtual-routers', 'GET', obj.virtual_routers_http_get)
        # leaf resource
        route('/global-system-config/<id>', 'GET', obj.global_system_config_http_get)
        route('/global-system-config/<id>', 'PUT', obj.global_system_config_http_put)
        route('/global-system-config/<id>', 'DELETE', obj.global_system_config_http_delete)
        # collections
        route('/global-system-configs', 'POST', obj.global_system_configs_http_post)
        route('/global-system-configs', 'GET', obj.global_system_configs_http_get)
        # leaf resource
        route('/namespace/<id>', 'GET', obj.namespace_http_get)
        route('/namespace/<id>', 'PUT', obj.namespace_http_put)
        route('/namespace/<id>', 'DELETE', obj.namespace_http_delete)
        # collections
        route('/namespaces', 'POST', obj.namespaces_http_post)
        route('/namespaces', 'GET', obj.namespaces_http_get)
        # leaf resource
        route('/physical-interface/<id>', 'GET', obj.physical_interface_http_get)
        route('/physical-interface/<id>', 'PUT', obj.physical_interface_http_put)
        route('/physical-interface/<id>', 'DELETE', obj.physical_interface_http_delete)
        # collections
        route('/physical-interfaces', 'POST', obj.physical_interfaces_http_post)
        route('/physical-interfaces', 'GET', obj.physical_interfaces_http_get)
        # leaf resource
        route('/access-control-list/<id>', 'GET', obj.access_control_list_http_get)
        route('/access-control-list/<id>', 'PUT', obj.access_control_list_http_put)
        route('/access-control-list/<id>', 'DELETE', obj.access_control_list_http_delete)
        # collections
        route('/access-control-lists', 'POST', obj.access_control_lists_http_post)
        route('/access-control-lists', 'GET', obj.access_control_lists_http_get)
        # leaf resource
        route('/virtual-DNS/<id>', 'GET', obj.virtual_DNS_http_get)
        route('/virtual-DNS/<id>', 'PUT', obj.virtual_DNS_http_put)
        route('/virtual-DNS/<id>', 'DELETE', obj.virtual_DNS_http_delete)
        # collections
        route('/virtual-DNSs', 'POST', obj.virtual_DNSs_http_post)
        route('/virtual-DNSs', 'GET', obj.virtual_DNSs_http_get)
        # leaf resource
        route('/customer-attachment/<id>', 'GET', obj.customer_attachment_http_get)
        route('/customer-attachment/<id>', 'PUT', obj.customer_attachment_http_put)
        route('/customer-attachment/<id>', 'DELETE', obj.customer_attachment_http_delete)
        # collections
        route('/customer-attachments', 'POST', obj.customer_attachments_http_post)
        route('/customer-attachments', 'GET', obj.customer_attachments_http_get)
        # leaf resource
        route('/virtual-machine/<id>', 'GET', obj.virtual_machine_http_get)
        route('/virtual-machine/<id>', 'PUT', obj.virtual_machine_http_put)
        route('/virtual-machine/<id>', 'DELETE', obj.virtual_machine_http_delete)
        # collections
        route('/virtual-machines', 'POST', obj.virtual_machines_http_post)
        route('/virtual-machines', 'GET', obj.virtual_machines_http_get)
        # leaf resource
        route('/service-template/<id>', 'GET', obj.service_template_http_get)
        route('/service-template/<id>', 'PUT', obj.service_template_http_put)
        route('/service-template/<id>', 'DELETE', obj.service_template_http_delete)
        # collections
        route('/service-templates', 'POST', obj.service_templates_http_post)
        route('/service-templates', 'GET', obj.service_templates_http_get)
        # leaf resource
        route('/security-group/<id>', 'GET', obj.security_group_http_get)
        route('/security-group/<id>', 'PUT', obj.security_group_http_put)
        route('/security-group/<id>', 'DELETE', obj.security_group_http_delete)
        # collections
        route('/security-groups', 'POST', obj.security_groups_http_post)
        route('/security-groups', 'GET', obj.security_groups_http_get)
        # leaf resource
        route('/provider-attachment/<id>', 'GET', obj.provider_attachment_http_get)
        route('/provider-attachment/<id>', 'PUT', obj.provider_attachment_http_put)
        route('/provider-attachment/<id>', 'DELETE', obj.provider_attachment_http_delete)
        # collections
        route('/provider-attachments', 'POST', obj.provider_attachments_http_post)
        route('/provider-attachments', 'GET', obj.provider_attachments_http_get)
        # leaf resource
        route('/network-ipam/<id>', 'GET', obj.network_ipam_http_get)
        route('/network-ipam/<id>', 'PUT', obj.network_ipam_http_put)
        route('/network-ipam/<id>', 'DELETE', obj.network_ipam_http_delete)
        # collections
        route('/network-ipams', 'POST', obj.network_ipams_http_post)
        route('/network-ipams', 'GET', obj.network_ipams_http_get)
        # leaf resource
        route('/virtual-network/<id>', 'GET', obj.virtual_network_http_get)
        route('/virtual-network/<id>', 'PUT', obj.virtual_network_http_put)
        route('/virtual-network/<id>', 'DELETE', obj.virtual_network_http_delete)
        # collections
        route('/virtual-networks', 'POST', obj.virtual_networks_http_post)
        route('/virtual-networks', 'GET', obj.virtual_networks_http_get)
        # leaf resource
        route('/project/<id>', 'GET', obj.project_http_get)
        route('/project/<id>', 'PUT', obj.project_http_put)
        route('/project/<id>', 'DELETE', obj.project_http_delete)
        # collections
        route('/projects', 'POST', obj.projects_http_post)
        route('/projects', 'GET', obj.projects_http_get)
        # leaf resource
        route('/logical-interface/<id>', 'GET', obj.logical_interface_http_get)
        route('/logical-interface/<id>', 'PUT', obj.logical_interface_http_put)
        route('/logical-interface/<id>', 'DELETE', obj.logical_interface_http_delete)
        # collections
        route('/logical-interfaces', 'POST', obj.logical_interfaces_http_post)
        route('/logical-interfaces', 'GET', obj.logical_interfaces_http_get)
        # leaf resource
        route('/routing-instance/<id>', 'GET', obj.routing_instance_http_get)
        route('/routing-instance/<id>', 'PUT', obj.routing_instance_http_put)
        route('/routing-instance/<id>', 'DELETE', obj.routing_instance_http_delete)
        # collections
        route('/routing-instances', 'POST', obj.routing_instances_http_post)
        route('/routing-instances', 'GET', obj.routing_instances_http_get)
        # leaf resource
        route('/virtual-machine-interface/<id>', 'GET', obj.virtual_machine_interface_http_get)
        route('/virtual-machine-interface/<id>', 'PUT', obj.virtual_machine_interface_http_put)
        route('/virtual-machine-interface/<id>', 'DELETE', obj.virtual_machine_interface_http_delete)
        # collections
        route('/virtual-machine-interfaces', 'POST', obj.virtual_machine_interfaces_http_post)
        route('/virtual-machine-interfaces', 'GET', obj.virtual_machine_interfaces_http_get)
        return obj
    #end __new__

    def __init__(self):
        self._db_conn = None
        self._get_common = None
        self._post_common = None

        self._resource_classes = {}
        self._resource_classes['domain'] = DomainServerGen

        self._resource_classes['service-instance'] = ServiceInstanceServerGen

        self._resource_classes['instance-ip'] = InstanceIpServerGen

        self._resource_classes['network-policy'] = NetworkPolicyServerGen

        self._resource_classes['virtual-DNS-record'] = VirtualDnsRecordServerGen

        self._resource_classes['route-target'] = RouteTargetServerGen

        self._resource_classes['floating-ip'] = FloatingIpServerGen

        self._resource_classes['floating-ip-pool'] = FloatingIpPoolServerGen

        self._resource_classes['physical-router'] = PhysicalRouterServerGen

        self._resource_classes['bgp-router'] = BgpRouterServerGen

        self._resource_classes['virtual-router'] = VirtualRouterServerGen

        self._resource_classes['config-root'] = ConfigRootServerGen

        self._resource_classes['global-system-config'] = GlobalSystemConfigServerGen

        self._resource_classes['namespace'] = NamespaceServerGen

        self._resource_classes['physical-interface'] = PhysicalInterfaceServerGen

        self._resource_classes['access-control-list'] = AccessControlListServerGen

        self._resource_classes['virtual-DNS'] = VirtualDnsServerGen

        self._resource_classes['customer-attachment'] = CustomerAttachmentServerGen

        self._resource_classes['virtual-machine'] = VirtualMachineServerGen

        self._resource_classes['service-template'] = ServiceTemplateServerGen

        self._resource_classes['security-group'] = SecurityGroupServerGen

        self._resource_classes['provider-attachment'] = ProviderAttachmentServerGen

        self._resource_classes['network-ipam'] = NetworkIpamServerGen

        self._resource_classes['virtual-network'] = VirtualNetworkServerGen

        self._resource_classes['project'] = ProjectServerGen

        self._resource_classes['logical-interface'] = LogicalInterfaceServerGen

        self._resource_classes['routing-instance'] = RoutingInstanceServerGen

        self._resource_classes['virtual-machine-interface'] = VirtualMachineInterfaceServerGen


        # Generate LinkObjects for all entities
        links = []
        # Link for root
        links.append(LinkObject('root', self._base_url , '/config-root',
                                'config-root'))

        # Link for collections
        link = LinkObject('collection',
                       self._base_url , '/domains',
                       'domain')
        links.append(link)

        link = LinkObject('collection',
                       self._base_url , '/service-instances',
                       'service-instance')
        links.append(link)

        link = LinkObject('collection',
                       self._base_url , '/instance-ips',
                       'instance-ip')
        links.append(link)

        link = LinkObject('collection',
                       self._base_url , '/network-policys',
                       'network-policy')
        links.append(link)

        link = LinkObject('collection',
                       self._base_url , '/virtual-DNS-records',
                       'virtual-DNS-record')
        links.append(link)

        link = LinkObject('collection',
                       self._base_url , '/route-targets',
                       'route-target')
        links.append(link)

        link = LinkObject('collection',
                       self._base_url , '/floating-ips',
                       'floating-ip')
        links.append(link)

        link = LinkObject('collection',
                       self._base_url , '/floating-ip-pools',
                       'floating-ip-pool')
        links.append(link)

        link = LinkObject('collection',
                       self._base_url , '/physical-routers',
                       'physical-router')
        links.append(link)

        link = LinkObject('collection',
                       self._base_url , '/bgp-routers',
                       'bgp-router')
        links.append(link)

        link = LinkObject('collection',
                       self._base_url , '/virtual-routers',
                       'virtual-router')
        links.append(link)

        link = LinkObject('collection',
                       self._base_url , '/global-system-configs',
                       'global-system-config')
        links.append(link)

        link = LinkObject('collection',
                       self._base_url , '/namespaces',
                       'namespace')
        links.append(link)

        link = LinkObject('collection',
                       self._base_url , '/physical-interfaces',
                       'physical-interface')
        links.append(link)

        link = LinkObject('collection',
                       self._base_url , '/access-control-lists',
                       'access-control-list')
        links.append(link)

        link = LinkObject('collection',
                       self._base_url , '/virtual-DNSs',
                       'virtual-DNS')
        links.append(link)

        link = LinkObject('collection',
                       self._base_url , '/customer-attachments',
                       'customer-attachment')
        links.append(link)

        link = LinkObject('collection',
                       self._base_url , '/virtual-machines',
                       'virtual-machine')
        links.append(link)

        link = LinkObject('collection',
                       self._base_url , '/service-templates',
                       'service-template')
        links.append(link)

        link = LinkObject('collection',
                       self._base_url , '/security-groups',
                       'security-group')
        links.append(link)

        link = LinkObject('collection',
                       self._base_url , '/provider-attachments',
                       'provider-attachment')
        links.append(link)

        link = LinkObject('collection',
                       self._base_url , '/network-ipams',
                       'network-ipam')
        links.append(link)

        link = LinkObject('collection',
                       self._base_url , '/virtual-networks',
                       'virtual-network')
        links.append(link)

        link = LinkObject('collection',
                       self._base_url , '/projects',
                       'project')
        links.append(link)

        link = LinkObject('collection',
                       self._base_url , '/logical-interfaces',
                       'logical-interface')
        links.append(link)

        link = LinkObject('collection',
                       self._base_url , '/routing-instances',
                       'routing-instance')
        links.append(link)

        link = LinkObject('collection',
                       self._base_url , '/virtual-machine-interfaces',
                       'virtual-machine-interface')
        links.append(link)

        # Link for Resources Base
        link = LinkObject('resource-base',
                       self._base_url , '/domain',
                       'domain')
        links.append(link)
        link = LinkObject('resource-base',
                       self._base_url , '/service-instance',
                       'service-instance')
        links.append(link)
        link = LinkObject('resource-base',
                       self._base_url , '/instance-ip',
                       'instance-ip')
        links.append(link)
        link = LinkObject('resource-base',
                       self._base_url , '/network-policy',
                       'network-policy')
        links.append(link)
        link = LinkObject('resource-base',
                       self._base_url , '/virtual-DNS-record',
                       'virtual-DNS-record')
        links.append(link)
        link = LinkObject('resource-base',
                       self._base_url , '/route-target',
                       'route-target')
        links.append(link)
        link = LinkObject('resource-base',
                       self._base_url , '/floating-ip',
                       'floating-ip')
        links.append(link)
        link = LinkObject('resource-base',
                       self._base_url , '/floating-ip-pool',
                       'floating-ip-pool')
        links.append(link)
        link = LinkObject('resource-base',
                       self._base_url , '/physical-router',
                       'physical-router')
        links.append(link)
        link = LinkObject('resource-base',
                       self._base_url , '/bgp-router',
                       'bgp-router')
        links.append(link)
        link = LinkObject('resource-base',
                       self._base_url , '/virtual-router',
                       'virtual-router')
        links.append(link)
        link = LinkObject('resource-base',
                       self._base_url , '/config-root',
                       'config-root')
        links.append(link)
        link = LinkObject('resource-base',
                       self._base_url , '/global-system-config',
                       'global-system-config')
        links.append(link)
        link = LinkObject('resource-base',
                       self._base_url , '/namespace',
                       'namespace')
        links.append(link)
        link = LinkObject('resource-base',
                       self._base_url , '/physical-interface',
                       'physical-interface')
        links.append(link)
        link = LinkObject('resource-base',
                       self._base_url , '/access-control-list',
                       'access-control-list')
        links.append(link)
        link = LinkObject('resource-base',
                       self._base_url , '/virtual-DNS',
                       'virtual-DNS')
        links.append(link)
        link = LinkObject('resource-base',
                       self._base_url , '/customer-attachment',
                       'customer-attachment')
        links.append(link)
        link = LinkObject('resource-base',
                       self._base_url , '/virtual-machine',
                       'virtual-machine')
        links.append(link)
        link = LinkObject('resource-base',
                       self._base_url , '/service-template',
                       'service-template')
        links.append(link)
        link = LinkObject('resource-base',
                       self._base_url , '/security-group',
                       'security-group')
        links.append(link)
        link = LinkObject('resource-base',
                       self._base_url , '/provider-attachment',
                       'provider-attachment')
        links.append(link)
        link = LinkObject('resource-base',
                       self._base_url , '/network-ipam',
                       'network-ipam')
        links.append(link)
        link = LinkObject('resource-base',
                       self._base_url , '/virtual-network',
                       'virtual-network')
        links.append(link)
        link = LinkObject('resource-base',
                       self._base_url , '/project',
                       'project')
        links.append(link)
        link = LinkObject('resource-base',
                       self._base_url , '/logical-interface',
                       'logical-interface')
        links.append(link)
        link = LinkObject('resource-base',
                       self._base_url , '/routing-instance',
                       'routing-instance')
        links.append(link)
        link = LinkObject('resource-base',
                       self._base_url , '/virtual-machine-interface',
                       'virtual-machine-interface')
        links.append(link)
        self._homepage_links = links
    #end __init__

    def domain_http_get(self, id):
        # TODO get vals from request out of the global ASAP
        etag = request.headers.get('If-None-Match')
        # common handling for all resource get
        (ok, result) = self._get_common(request, id)
        if not ok:
            (code, msg) = result
            self.config_object_error(id, None, 'domain', 'http_get', msg)
            abort(code, msg)

        # type-specific hook
        r_class = self._resource_classes.get('domain', None)
        if r_class:
            r_class.http_get(id)

        db_conn = self._db_conn
        if etag:
            obj_ids = {'uuid': id}
            (ok, result) = db_conn.dbe_is_latest(obj_ids, etag.replace('"', ''))
            if not ok:
                # Not present in DB
                self.config_object_error(id, None, 'domain', 'http_get', result)
                abort(404, result)

            is_latest = result
            if is_latest:
                # send Not-Modified, caches use this for read optimization
                response.status = 304
                return
        #end if etag

        obj_ids = {'uuid': id}
        if 'fields' in request.query:
            obj_fields = request.query.fields.split(',')
        else:
            obj_fields = None
        (ok, result) = db_conn.dbe_read('domain', obj_ids, obj_fields)
        if not ok:
            # Not present in DB
            self.config_object_error(id, None, 'domain', 'http_get', result)
            abort(404, result)

        rsp_body = {}
        rsp_body['uuid'] = id
        rsp_body['href'] = self.generate_url('domain', id)
        rsp_body['name'] = result['fq_name'][-1]
        rsp_body.update(result)
        id_perms = result['id_perms']
        response.set_header('ETag', '"' + id_perms['last_modified'] + '"')
        return {'domain': rsp_body} 
    #end domain_http_get

    def domain_http_put(self, id):
        key = 'domain'
        obj_dict = request.json[key]
        # common handling for all resource put
        (ok, result) = self._put_common(request, 'domain', obj_dict, id)
        if not ok:
            (code, msg) = result
            self.config_object_error(id, None, 'domain', 'http_put', msg)
            abort(code, msg)

        # type-specific hook
        r_class = self._resource_classes.get('domain', None)
        if r_class:
            (ok, msg) = r_class.http_put(id, obj_dict)
            if not ok:
                self.config_object_error(id, None, 'domain', 'http_put', msg)
                abort(409, msg)

        db_conn = self._db_conn

        # Validate perms
        objtype_list = eval("[u'project', u'namespace', 'service_template', u'virtual_DNS']")
        for obj_type in objtype_list:
            refs = obj_dict.get('%s_refs'%(obj_type), None)
            if refs:
                for ref in refs:
                    ref_uuid = db_conn.fq_name_to_uuid(obj_type, ref['to'])
                    (ok, status) = self._permissions.check_perms_link(request, ref_uuid)
                    if not ok:
                        (code, err_msg) = status
                        abort(code, err_msg)

        obj_ids = {'uuid': id}
        (ok, result) = \
             db_conn.dbe_update('domain', obj_ids, obj_dict)
        if not ok:
            self.config_object_error(id, None, 'domain', 'http_put', result)
            abort(404, result)

        rsp_body = {}
        rsp_body['uuid'] = id
        rsp_body['href'] = self.generate_url('domain', id)
        return {'domain': rsp_body} 
    #end domain_http_put

    def domain_http_delete(self, id):
        db_conn = self._db_conn
        # read in obj from db (accepting error) to get details of it
        obj_ids = {'uuid': id}
        (read_ok, read_result) = db_conn.dbe_read('domain', obj_ids)
        if not read_ok:
            self.config_object_error(id, None, 'domain', 'http_delete', read_result)
            # proceed down to delete the resource

        # common handling for all resource delete
        parent_type = read_result.get('parent_type', None)
        (ok, del_result) = self._delete_common(request, 'domain', id, parent_type)
        if not ok:
            (code, msg) = del_result
            self.config_object_error(id, None, 'domain', 'http_delete', msg)
            abort(code, msg)

        fq_name = read_result['fq_name']
        ifmap_id = common.imid.get_ifmap_id_from_fq_name('domain', fq_name)
        obj_ids['imid'] = ifmap_id
        if parent_type:
            parent_imid = common.imid.get_ifmap_id_from_fq_name(parent_type, fq_name[:-1])
            obj_ids['parent_imid'] = parent_imid

        # type-specific hook
        r_class = self._resource_classes.get('domain', None)
        if r_class:
            if read_ok:
                # fail if non-default children or backrefs exist
                projects = read_result.get('projects', None)
                if projects:
                    has_infos = read_result['projects']
                    if ((len(has_infos) > 1) or 
                        (len(has_infos) == 1 and has_infos[0]['to'][-1] != 'default-project')):
                        has_urls = [has_info['href'] for has_info in has_infos]
                        has_str = ', '.join(has_urls)
                        err_msg = 'Children ' + has_str + ' still exist'
                        self.config_object_error(id, None, 'domain', 'http_delete', err_msg)
                        abort(409, err_msg)

                namespaces = read_result.get('namespaces', None)
                if namespaces:
                    has_infos = read_result['namespaces']
                    if ((len(has_infos) > 1) or 
                        (len(has_infos) == 1 and has_infos[0]['to'][-1] != 'default-namespace')):
                        has_urls = [has_info['href'] for has_info in has_infos]
                        has_str = ', '.join(has_urls)
                        err_msg = 'Children ' + has_str + ' still exist'
                        self.config_object_error(id, None, 'domain', 'http_delete', err_msg)
                        abort(409, err_msg)

                service_templates = read_result.get('service_templates', None)
                if service_templates:
                    has_infos = read_result['service_templates']
                    if ((len(has_infos) > 1) or 
                        (len(has_infos) == 1 and has_infos[0]['to'][-1] != 'default-service-template')):
                        has_urls = [has_info['href'] for has_info in has_infos]
                        has_str = ', '.join(has_urls)
                        err_msg = 'Children ' + has_str + ' still exist'
                        self.config_object_error(id, None, 'domain', 'http_delete', err_msg)
                        abort(409, err_msg)

                virtual_DNSs = read_result.get('virtual_DNSs', None)
                if virtual_DNSs:
                    has_infos = read_result['virtual_DNSs']
                    if ((len(has_infos) > 1) or 
                        (len(has_infos) == 1 and has_infos[0]['to'][-1] != 'default-virtual-DNS')):
                        has_urls = [has_info['href'] for has_info in has_infos]
                        has_str = ', '.join(has_urls)
                        err_msg = 'Children ' + has_str + ' still exist'
                        self.config_object_error(id, None, 'domain', 'http_delete', err_msg)
                        abort(409, err_msg)


                # Delete default children first
                parent_obj = Domain.factory(**read_result)
                self._domain_delete_default_children(parent_obj)

                r_class.http_delete(id, read_result)
            #end if read_ok

        (ok, del_result) = \
             db_conn.dbe_delete('domain', obj_ids)
        if not ok:
            self.config_object_error(id, None, 'domain', 'http_delete', del_result)
            abort(409, del_result)

    #end domain_http_delete
    def domains_http_post(self):
        key = 'domain'
        obj_dict = request.json[key]
        # common handling for all resource create
        (ok, result) = self._post_common(request, 'domain', obj_dict)
        if not ok:
            (code, msg) = result
            fq_name_str = ':'.join(obj_dict.get('fq_name', []))
            self.config_object_error(None, fq_name_str, 'domain', 'http_post', msg)
            abort(code, msg)

        # Alloc and Store id-mappings before creating entry on pubsub store.
        # Else a subscriber can ask for an id mapping before we have stored it
        uuid_requested = result
        db_conn = self._db_conn
        (ok, result) = db_conn.dbe_alloc('domain', obj_dict, uuid_requested)
        if not ok:
            fq_name_str = ':'.join(obj_dict['fq_name'])
            self.config_object_error(None, fq_name_str, 'domain', 'http_post', result)
            abort(code, result)

        obj_ids = result

        name = obj_dict['fq_name'][-1]
        fq_name = obj_dict['fq_name']


        if 'parent_type' in obj_dict:
            # non config-root child, verify parent exists
            parent_type = obj_dict['parent_type']
            parent_fq_name = obj_dict['fq_name'][:-1]
            try:
                parent_uuid = self._db_conn.fq_name_to_uuid(parent_type, parent_fq_name)
                (ok, status) = self._permissions.check_perms_write(request, parent_uuid)
                if not ok:
                    (code, err_msg) = status
                    abort(code, err_msg)
                self._permissions.set_user_role(request, obj_dict)
            except NoIdError:
                err_msg = 'Parent ' + pformat(parent_fq_name) + ' type ' + parent_type + ' does not exist'
                fq_name_str = ':'.join(parent_fq_name)
                self.config_object_error(None, fq_name_str, 'domain', 'http_post', err_msg)
                abort(400, err_msg)

        env = request.headers.environ
        tenant_name = env.get(hdr_server_tenant(), 'default-project')


        # type-specific hook
        r_class = self._resource_classes.get('domain', None)
        if r_class:
            (ok, result) = r_class.http_post_collection(tenant_name, obj_dict)
            if not ok:
                (code, msg) = result
                fq_name_str = ':'.join(fq_name)
                self.config_object_error(None, fq_name_str, 'domain', 'http_post', msg)
                abort(code, msg)

        # Validate perms
        objtype_list = eval("[u'project', u'namespace', 'service_template', u'virtual_DNS']")
        for obj_type in objtype_list:
            refs = obj_dict.get('%s_refs'%(obj_type), None)
            if refs:
                for ref in refs:
                    ref_uuid = db_conn.fq_name_to_uuid(obj_type, ref['to'])
                    (ok, status) = self._permissions.check_perms_link(request, ref_uuid)
                    if not ok:
                        (code, err_msg) = status
                        abort(code, err_msg)

        (ok, result) = \
             db_conn.dbe_create('domain', obj_ids, obj_dict)

        if not ok:
            fq_name_str = ':'.join(fq_name)
            self.config_object_error(None, fq_name_str, 'domain', 'http_post', result)
            abort(404, result)

        rsp_body = {}
        rsp_body['name'] = name
        rsp_body['fq_name'] = fq_name
        rsp_body['uuid'] = obj_ids['uuid']
        rsp_body['href'] = self.generate_url('domain', obj_ids['uuid'])
        if 'parent_type' in obj_dict:
            # non config-root child, send back parent uuid/href
            rsp_body['parent_uuid'] = parent_uuid
            rsp_body['parent_href'] = self.generate_url(parent_type, parent_uuid)

        parent_obj = Domain.factory(**rsp_body)
        self._domain_create_default_children(parent_obj)

        return {'domain': rsp_body} 
    #end domains_http_post

    def domains_http_get(self):
        env = request.headers.environ
        tenant_name = env.get(hdr_server_tenant(), 'default-project')
        parent_uuid = None
        resource_id = 'domains'
        if (('parent_fq_name_str' in request.query) and
            ('parent_type' in request.query)):
            parent_fq_name = request.query.parent_fq_name_str.split(':')
            parent_type = request.query.parent_type
            parent_uuid = self._db_conn.fq_name_to_uuid(parent_type, parent_fq_name)
        elif 'parent_id' in request.query:
            parent_uuid = str(uuid.UUID(request.query.parent_id))

        if parent_uuid:
            resource_id = parent_uuid

        # common handling for all resource get
        (ok, result) = self._get_common(request, parent_uuid)
        if not ok:
            (code, msg) = result
            self.config_object_error(None, None, 'domains', 'http_get_collection', msg)
            abort(code, msg)

        db_conn = self._db_conn
        (ok, result) = \
             db_conn.dbe_list('domain', parent_uuid)

        if not ok:
            self.config_object_error(None, None, 'domains', 'http_get_collection', result)
            abort(404, result)

        fq_names = result
        obj_dicts = []
        for fq_name in fq_names:
            obj_dict = {}
            id = db_conn.fq_name_to_uuid('domain', fq_name)
            obj_dict['uuid'] = id
            obj_dict['fq_name'] = fq_name
            obj_dict['href'] = self.generate_url('domain', id)
            obj_dicts.append(obj_dict)

        return {'domains': obj_dicts} 
    #end domains_http_get

    def _domain_create_default_children(self, parent_obj):
        # Create a default child only if provisioned for
        r_class = self._resource_classes.get('project', None)
        if r_class.generate_default_instance:
            child_obj = Project(parent_obj = parent_obj)
            child_dict = child_obj.__dict__
            fq_name = child_dict['fq_name']
            child_dict['id_perms'] = self._get_default_id_perms('project')

            db_conn = self._db_conn
            (ok, result) = db_conn.dbe_alloc('project', child_dict)
            if not ok:
                return (ok, result)

            obj_ids = result
            db_conn.dbe_create('project', obj_ids, child_dict)
            self._project_create_default_children(child_obj)

        # Create a default child only if provisioned for
        r_class = self._resource_classes.get('namespace', None)
        if r_class.generate_default_instance:
            child_obj = Namespace(parent_obj = parent_obj)
            child_dict = child_obj.__dict__
            fq_name = child_dict['fq_name']
            child_dict['id_perms'] = self._get_default_id_perms('namespace')

            db_conn = self._db_conn
            (ok, result) = db_conn.dbe_alloc('namespace', child_dict)
            if not ok:
                return (ok, result)

            obj_ids = result
            db_conn.dbe_create('namespace', obj_ids, child_dict)
            self._namespace_create_default_children(child_obj)

        # Create a default child only if provisioned for
        r_class = self._resource_classes.get('service-template', None)
        if r_class.generate_default_instance:
            child_obj = ServiceTemplate(parent_obj = parent_obj)
            child_dict = child_obj.__dict__
            fq_name = child_dict['fq_name']
            child_dict['id_perms'] = self._get_default_id_perms('service-template')

            db_conn = self._db_conn
            (ok, result) = db_conn.dbe_alloc('service-template', child_dict)
            if not ok:
                return (ok, result)

            obj_ids = result
            db_conn.dbe_create('service-template', obj_ids, child_dict)
            self._service_template_create_default_children(child_obj)

        # Create a default child only if provisioned for
        r_class = self._resource_classes.get('virtual-DNS', None)
        if r_class.generate_default_instance:
            child_obj = VirtualDns(parent_obj = parent_obj)
            child_dict = child_obj.__dict__
            fq_name = child_dict['fq_name']
            child_dict['id_perms'] = self._get_default_id_perms('virtual-DNS')

            db_conn = self._db_conn
            (ok, result) = db_conn.dbe_alloc('virtual-DNS', child_dict)
            if not ok:
                return (ok, result)

            obj_ids = result
            db_conn.dbe_create('virtual-DNS', obj_ids, child_dict)
            self._virtual_DNS_create_default_children(child_obj)

        pass
    #end _domain_create_default_children

    def _domain_delete_default_children(self, parent_obj):
        # Delete a default child only if provisioned for
        r_class = self._resource_classes.get('virtual-DNS', None)
        if r_class.generate_default_instance:
            # first locate default child then delete it
            has_infos = parent_obj.get_projects()
            if has_infos:
                for has_info in has_infos:
                    if has_info['to'][-1] == 'default-project':
                        default_child_id = has_info['href'].split('/')[-1]
                        self.project_http_delete(default_child_id)
                        break

        # Delete a default child only if provisioned for
        r_class = self._resource_classes.get('virtual-DNS', None)
        if r_class.generate_default_instance:
            # first locate default child then delete it
            has_infos = parent_obj.get_namespaces()
            if has_infos:
                for has_info in has_infos:
                    if has_info['to'][-1] == 'default-namespace':
                        default_child_id = has_info['href'].split('/')[-1]
                        self.namespace_http_delete(default_child_id)
                        break

        # Delete a default child only if provisioned for
        r_class = self._resource_classes.get('virtual-DNS', None)
        if r_class.generate_default_instance:
            # first locate default child then delete it
            has_infos = parent_obj.get_service_templates()
            if has_infos:
                for has_info in has_infos:
                    if has_info['to'][-1] == 'default-service-template':
                        default_child_id = has_info['href'].split('/')[-1]
                        self.service_template_http_delete(default_child_id)
                        break

        # Delete a default child only if provisioned for
        r_class = self._resource_classes.get('virtual-DNS', None)
        if r_class.generate_default_instance:
            # first locate default child then delete it
            has_infos = parent_obj.get_virtual_DNSs()
            if has_infos:
                for has_info in has_infos:
                    if has_info['to'][-1] == 'default-virtual-DNS':
                        default_child_id = has_info['href'].split('/')[-1]
                        self.virtual_DNS_http_delete(default_child_id)
                        break

        pass
    #end _domain_delete_default_children

    def service_instance_http_get(self, id):
        # TODO get vals from request out of the global ASAP
        etag = request.headers.get('If-None-Match')
        # common handling for all resource get
        (ok, result) = self._get_common(request, id)
        if not ok:
            (code, msg) = result
            self.config_object_error(id, None, 'service_instance', 'http_get', msg)
            abort(code, msg)

        # type-specific hook
        r_class = self._resource_classes.get('service-instance', None)
        if r_class:
            r_class.http_get(id)

        db_conn = self._db_conn
        if etag:
            obj_ids = {'uuid': id}
            (ok, result) = db_conn.dbe_is_latest(obj_ids, etag.replace('"', ''))
            if not ok:
                # Not present in DB
                self.config_object_error(id, None, 'service_instance', 'http_get', result)
                abort(404, result)

            is_latest = result
            if is_latest:
                # send Not-Modified, caches use this for read optimization
                response.status = 304
                return
        #end if etag

        obj_ids = {'uuid': id}
        if 'fields' in request.query:
            obj_fields = request.query.fields.split(',')
        else:
            obj_fields = None
        (ok, result) = db_conn.dbe_read('service-instance', obj_ids, obj_fields)
        if not ok:
            # Not present in DB
            self.config_object_error(id, None, 'service_instance', 'http_get', result)
            abort(404, result)

        rsp_body = {}
        rsp_body['uuid'] = id
        rsp_body['href'] = self.generate_url('service-instance', id)
        rsp_body['name'] = result['fq_name'][-1]
        rsp_body.update(result)
        id_perms = result['id_perms']
        response.set_header('ETag', '"' + id_perms['last_modified'] + '"')
        return {'service-instance': rsp_body} 
    #end service_instance_http_get

    def service_instance_http_put(self, id):
        key = 'service-instance'
        obj_dict = request.json[key]
        # common handling for all resource put
        (ok, result) = self._put_common(request, 'service_instance', obj_dict, id)
        if not ok:
            (code, msg) = result
            self.config_object_error(id, None, 'service_instance', 'http_put', msg)
            abort(code, msg)

        # type-specific hook
        r_class = self._resource_classes.get('service-instance', None)
        if r_class:
            (ok, msg) = r_class.http_put(id, obj_dict)
            if not ok:
                self.config_object_error(id, None, 'service_instance', 'http_put', msg)
                abort(409, msg)

        db_conn = self._db_conn

        # Validate perms
        objtype_list = eval("['service_template']")
        for obj_type in objtype_list:
            refs = obj_dict.get('%s_refs'%(obj_type), None)
            if refs:
                for ref in refs:
                    ref_uuid = db_conn.fq_name_to_uuid(obj_type, ref['to'])
                    (ok, status) = self._permissions.check_perms_link(request, ref_uuid)
                    if not ok:
                        (code, err_msg) = status
                        abort(code, err_msg)

        obj_ids = {'uuid': id}
        (ok, result) = \
             db_conn.dbe_update('service-instance', obj_ids, obj_dict)
        if not ok:
            self.config_object_error(id, None, 'service_instance', 'http_put', result)
            abort(404, result)

        rsp_body = {}
        rsp_body['uuid'] = id
        rsp_body['href'] = self.generate_url('service-instance', id)
        return {'service-instance': rsp_body} 
    #end service_instance_http_put

    def service_instance_http_delete(self, id):
        db_conn = self._db_conn
        # read in obj from db (accepting error) to get details of it
        obj_ids = {'uuid': id}
        (read_ok, read_result) = db_conn.dbe_read('service-instance', obj_ids)
        if not read_ok:
            self.config_object_error(id, None, 'service_instance', 'http_delete', read_result)
            # proceed down to delete the resource

        # common handling for all resource delete
        parent_type = read_result.get('parent_type', None)
        (ok, del_result) = self._delete_common(request, 'service_instance', id, parent_type)
        if not ok:
            (code, msg) = del_result
            self.config_object_error(id, None, 'service_instance', 'http_delete', msg)
            abort(code, msg)

        fq_name = read_result['fq_name']
        ifmap_id = common.imid.get_ifmap_id_from_fq_name('service-instance', fq_name)
        obj_ids['imid'] = ifmap_id
        if parent_type:
            parent_imid = common.imid.get_ifmap_id_from_fq_name(parent_type, fq_name[:-1])
            obj_ids['parent_imid'] = parent_imid

        # type-specific hook
        r_class = self._resource_classes.get('service-instance', None)
        if r_class:
            if read_ok:
                # fail if non-default children or backrefs exist

                # Delete default children first
                parent_obj = ServiceInstance.factory(**read_result)
                self._service_instance_delete_default_children(parent_obj)

                r_class.http_delete(id, read_result)
            #end if read_ok

        (ok, del_result) = \
             db_conn.dbe_delete('service-instance', obj_ids)
        if not ok:
            self.config_object_error(id, None, 'service_instance', 'http_delete', del_result)
            abort(409, del_result)

    #end service_instance_http_delete
    def service_instances_http_post(self):
        key = 'service-instance'
        obj_dict = request.json[key]
        # common handling for all resource create
        (ok, result) = self._post_common(request, 'service-instance', obj_dict)
        if not ok:
            (code, msg) = result
            fq_name_str = ':'.join(obj_dict.get('fq_name', []))
            self.config_object_error(None, fq_name_str, 'service_instance', 'http_post', msg)
            abort(code, msg)

        # Alloc and Store id-mappings before creating entry on pubsub store.
        # Else a subscriber can ask for an id mapping before we have stored it
        uuid_requested = result
        db_conn = self._db_conn
        (ok, result) = db_conn.dbe_alloc('service-instance', obj_dict, uuid_requested)
        if not ok:
            fq_name_str = ':'.join(obj_dict['fq_name'])
            self.config_object_error(None, fq_name_str, 'service_instance', 'http_post', result)
            abort(code, result)

        obj_ids = result

        name = obj_dict['fq_name'][-1]
        fq_name = obj_dict['fq_name']


        if 'parent_type' in obj_dict:
            # non config-root child, verify parent exists
            parent_type = obj_dict['parent_type']
            parent_fq_name = obj_dict['fq_name'][:-1]
            try:
                parent_uuid = self._db_conn.fq_name_to_uuid(parent_type, parent_fq_name)
                (ok, status) = self._permissions.check_perms_write(request, parent_uuid)
                if not ok:
                    (code, err_msg) = status
                    abort(code, err_msg)
                self._permissions.set_user_role(request, obj_dict)
            except NoIdError:
                err_msg = 'Parent ' + pformat(parent_fq_name) + ' type ' + parent_type + ' does not exist'
                fq_name_str = ':'.join(parent_fq_name)
                self.config_object_error(None, fq_name_str, 'service_instance', 'http_post', err_msg)
                abort(400, err_msg)

        env = request.headers.environ
        tenant_name = env.get(hdr_server_tenant(), 'default-project')


        # type-specific hook
        r_class = self._resource_classes.get('service-instance', None)
        if r_class:
            (ok, result) = r_class.http_post_collection(tenant_name, obj_dict)
            if not ok:
                (code, msg) = result
                fq_name_str = ':'.join(fq_name)
                self.config_object_error(None, fq_name_str, 'service_instance', 'http_post', msg)
                abort(code, msg)

        # Validate perms
        objtype_list = eval("['service_template']")
        for obj_type in objtype_list:
            refs = obj_dict.get('%s_refs'%(obj_type), None)
            if refs:
                for ref in refs:
                    ref_uuid = db_conn.fq_name_to_uuid(obj_type, ref['to'])
                    (ok, status) = self._permissions.check_perms_link(request, ref_uuid)
                    if not ok:
                        (code, err_msg) = status
                        abort(code, err_msg)

        (ok, result) = \
             db_conn.dbe_create('service-instance', obj_ids, obj_dict)

        if not ok:
            fq_name_str = ':'.join(fq_name)
            self.config_object_error(None, fq_name_str, 'service_instance', 'http_post', result)
            abort(404, result)

        rsp_body = {}
        rsp_body['name'] = name
        rsp_body['fq_name'] = fq_name
        rsp_body['uuid'] = obj_ids['uuid']
        rsp_body['href'] = self.generate_url('service-instance', obj_ids['uuid'])
        if 'parent_type' in obj_dict:
            # non config-root child, send back parent uuid/href
            rsp_body['parent_uuid'] = parent_uuid
            rsp_body['parent_href'] = self.generate_url(parent_type, parent_uuid)

        parent_obj = ServiceInstance.factory(**rsp_body)
        self._service_instance_create_default_children(parent_obj)

        return {'service-instance': rsp_body} 
    #end service_instances_http_post

    def service_instances_http_get(self):
        env = request.headers.environ
        tenant_name = env.get(hdr_server_tenant(), 'default-project')
        parent_uuid = None
        resource_id = 'service_instances'
        if (('parent_fq_name_str' in request.query) and
            ('parent_type' in request.query)):
            parent_fq_name = request.query.parent_fq_name_str.split(':')
            parent_type = request.query.parent_type
            parent_uuid = self._db_conn.fq_name_to_uuid(parent_type, parent_fq_name)
        elif 'parent_id' in request.query:
            parent_uuid = str(uuid.UUID(request.query.parent_id))

        if parent_uuid:
            resource_id = parent_uuid

        # common handling for all resource get
        (ok, result) = self._get_common(request, parent_uuid)
        if not ok:
            (code, msg) = result
            self.config_object_error(None, None, 'service_instances', 'http_get_collection', msg)
            abort(code, msg)

        db_conn = self._db_conn
        (ok, result) = \
             db_conn.dbe_list('service-instance', parent_uuid)

        if not ok:
            self.config_object_error(None, None, 'service_instances', 'http_get_collection', result)
            abort(404, result)

        fq_names = result
        obj_dicts = []
        for fq_name in fq_names:
            obj_dict = {}
            id = db_conn.fq_name_to_uuid('service_instance', fq_name)
            obj_dict['uuid'] = id
            obj_dict['fq_name'] = fq_name
            obj_dict['href'] = self.generate_url('service-instance', id)
            obj_dicts.append(obj_dict)

        return {'service-instances': obj_dicts} 
    #end service_instances_http_get

    def _service_instance_create_default_children(self, parent_obj):
        pass
    #end _service_instance_create_default_children

    def _service_instance_delete_default_children(self, parent_obj):
        pass
    #end _service_instance_delete_default_children

    def instance_ip_http_get(self, id):
        # TODO get vals from request out of the global ASAP
        etag = request.headers.get('If-None-Match')
        # common handling for all resource get
        (ok, result) = self._get_common(request, id)
        if not ok:
            (code, msg) = result
            self.config_object_error(id, None, 'instance_ip', 'http_get', msg)
            abort(code, msg)

        # type-specific hook
        r_class = self._resource_classes.get('instance-ip', None)
        if r_class:
            r_class.http_get(id)

        db_conn = self._db_conn
        if etag:
            obj_ids = {'uuid': id}
            (ok, result) = db_conn.dbe_is_latest(obj_ids, etag.replace('"', ''))
            if not ok:
                # Not present in DB
                self.config_object_error(id, None, 'instance_ip', 'http_get', result)
                abort(404, result)

            is_latest = result
            if is_latest:
                # send Not-Modified, caches use this for read optimization
                response.status = 304
                return
        #end if etag

        obj_ids = {'uuid': id}
        if 'fields' in request.query:
            obj_fields = request.query.fields.split(',')
        else:
            obj_fields = None
        (ok, result) = db_conn.dbe_read('instance-ip', obj_ids, obj_fields)
        if not ok:
            # Not present in DB
            self.config_object_error(id, None, 'instance_ip', 'http_get', result)
            abort(404, result)

        rsp_body = {}
        rsp_body['uuid'] = id
        rsp_body['href'] = self.generate_url('instance-ip', id)
        rsp_body['name'] = result['fq_name'][-1]
        rsp_body.update(result)
        id_perms = result['id_perms']
        response.set_header('ETag', '"' + id_perms['last_modified'] + '"')
        return {'instance-ip': rsp_body} 
    #end instance_ip_http_get

    def instance_ip_http_put(self, id):
        key = 'instance-ip'
        obj_dict = request.json[key]
        # common handling for all resource put
        (ok, result) = self._put_common(request, 'instance_ip', obj_dict, id)
        if not ok:
            (code, msg) = result
            self.config_object_error(id, None, 'instance_ip', 'http_put', msg)
            abort(code, msg)

        # type-specific hook
        r_class = self._resource_classes.get('instance-ip', None)
        if r_class:
            (ok, msg) = r_class.http_put(id, obj_dict)
            if not ok:
                self.config_object_error(id, None, 'instance_ip', 'http_put', msg)
                abort(409, msg)

        db_conn = self._db_conn

        # Validate perms
        objtype_list = eval("[u'virtual_network', u'virtual_machine_interface']")
        for obj_type in objtype_list:
            refs = obj_dict.get('%s_refs'%(obj_type), None)
            if refs:
                for ref in refs:
                    ref_uuid = db_conn.fq_name_to_uuid(obj_type, ref['to'])
                    (ok, status) = self._permissions.check_perms_link(request, ref_uuid)
                    if not ok:
                        (code, err_msg) = status
                        abort(code, err_msg)

        obj_ids = {'uuid': id}
        (ok, result) = \
             db_conn.dbe_update('instance-ip', obj_ids, obj_dict)
        if not ok:
            self.config_object_error(id, None, 'instance_ip', 'http_put', result)
            abort(404, result)

        rsp_body = {}
        rsp_body['uuid'] = id
        rsp_body['href'] = self.generate_url('instance-ip', id)
        return {'instance-ip': rsp_body} 
    #end instance_ip_http_put

    def instance_ip_http_delete(self, id):
        db_conn = self._db_conn
        # read in obj from db (accepting error) to get details of it
        obj_ids = {'uuid': id}
        (read_ok, read_result) = db_conn.dbe_read('instance-ip', obj_ids)
        if not read_ok:
            self.config_object_error(id, None, 'instance_ip', 'http_delete', read_result)
            # proceed down to delete the resource

        # common handling for all resource delete
        parent_type = read_result.get('parent_type', None)
        (ok, del_result) = self._delete_common(request, 'instance_ip', id, parent_type)
        if not ok:
            (code, msg) = del_result
            self.config_object_error(id, None, 'instance_ip', 'http_delete', msg)
            abort(code, msg)

        fq_name = read_result['fq_name']
        ifmap_id = common.imid.get_ifmap_id_from_fq_name('instance-ip', fq_name)
        obj_ids['imid'] = ifmap_id
        if parent_type:
            parent_imid = common.imid.get_ifmap_id_from_fq_name(parent_type, fq_name[:-1])
            obj_ids['parent_imid'] = parent_imid

        # type-specific hook
        r_class = self._resource_classes.get('instance-ip', None)
        if r_class:
            if read_ok:
                # fail if non-default children or backrefs exist

                # Delete default children first
                parent_obj = InstanceIp.factory(**read_result)
                self._instance_ip_delete_default_children(parent_obj)

                r_class.http_delete(id, read_result)
            #end if read_ok

        (ok, del_result) = \
             db_conn.dbe_delete('instance-ip', obj_ids)
        if not ok:
            self.config_object_error(id, None, 'instance_ip', 'http_delete', del_result)
            abort(409, del_result)

    #end instance_ip_http_delete
    def instance_ips_http_post(self):
        key = 'instance-ip'
        obj_dict = request.json[key]
        # common handling for all resource create
        (ok, result) = self._post_common(request, 'instance-ip', obj_dict)
        if not ok:
            (code, msg) = result
            fq_name_str = ':'.join(obj_dict.get('fq_name', []))
            self.config_object_error(None, fq_name_str, 'instance_ip', 'http_post', msg)
            abort(code, msg)

        # Alloc and Store id-mappings before creating entry on pubsub store.
        # Else a subscriber can ask for an id mapping before we have stored it
        uuid_requested = result
        db_conn = self._db_conn
        (ok, result) = db_conn.dbe_alloc('instance-ip', obj_dict, uuid_requested)
        if not ok:
            fq_name_str = ':'.join(obj_dict['fq_name'])
            self.config_object_error(None, fq_name_str, 'instance_ip', 'http_post', result)
            abort(code, result)

        obj_ids = result

        name = obj_dict['fq_name'][-1]
        fq_name = obj_dict['fq_name']


        env = request.headers.environ
        tenant_name = env.get(hdr_server_tenant(), 'default-project')


        # type-specific hook
        r_class = self._resource_classes.get('instance-ip', None)
        if r_class:
            (ok, result) = r_class.http_post_collection(tenant_name, obj_dict)
            if not ok:
                (code, msg) = result
                fq_name_str = ':'.join(fq_name)
                self.config_object_error(None, fq_name_str, 'instance_ip', 'http_post', msg)
                abort(code, msg)

        # Validate perms
        objtype_list = eval("[u'virtual_network', u'virtual_machine_interface']")
        for obj_type in objtype_list:
            refs = obj_dict.get('%s_refs'%(obj_type), None)
            if refs:
                for ref in refs:
                    ref_uuid = db_conn.fq_name_to_uuid(obj_type, ref['to'])
                    (ok, status) = self._permissions.check_perms_link(request, ref_uuid)
                    if not ok:
                        (code, err_msg) = status
                        abort(code, err_msg)

        (ok, result) = \
             db_conn.dbe_create('instance-ip', obj_ids, obj_dict)

        if not ok:
            fq_name_str = ':'.join(fq_name)
            self.config_object_error(None, fq_name_str, 'instance_ip', 'http_post', result)
            abort(404, result)

        rsp_body = {}
        rsp_body['name'] = name
        rsp_body['fq_name'] = fq_name
        rsp_body['uuid'] = obj_ids['uuid']
        rsp_body['href'] = self.generate_url('instance-ip', obj_ids['uuid'])

        parent_obj = InstanceIp.factory(**rsp_body)
        self._instance_ip_create_default_children(parent_obj)

        return {'instance-ip': rsp_body} 
    #end instance_ips_http_post

    def instance_ips_http_get(self):
        env = request.headers.environ
        tenant_name = env.get(hdr_server_tenant(), 'default-project')
        parent_uuid = None
        resource_id = 'instance_ips'
        if (('parent_fq_name_str' in request.query) and
            ('parent_type' in request.query)):
            parent_fq_name = request.query.parent_fq_name_str.split(':')
            parent_type = request.query.parent_type
            parent_uuid = self._db_conn.fq_name_to_uuid(parent_type, parent_fq_name)
        elif 'parent_id' in request.query:
            parent_uuid = str(uuid.UUID(request.query.parent_id))

        if parent_uuid:
            resource_id = parent_uuid

        # common handling for all resource get
        (ok, result) = self._get_common(request, parent_uuid)
        if not ok:
            (code, msg) = result
            self.config_object_error(None, None, 'instance_ips', 'http_get_collection', msg)
            abort(code, msg)

        db_conn = self._db_conn
        (ok, result) = \
             db_conn.dbe_list('instance-ip', parent_uuid)

        if not ok:
            self.config_object_error(None, None, 'instance_ips', 'http_get_collection', result)
            abort(404, result)

        fq_names = result
        obj_dicts = []
        for fq_name in fq_names:
            obj_dict = {}
            id = db_conn.fq_name_to_uuid('instance_ip', fq_name)
            obj_dict['uuid'] = id
            obj_dict['fq_name'] = fq_name
            obj_dict['href'] = self.generate_url('instance-ip', id)
            obj_dicts.append(obj_dict)

        return {'instance-ips': obj_dicts} 
    #end instance_ips_http_get

    def _instance_ip_create_default_children(self, parent_obj):
        pass
    #end _instance_ip_create_default_children

    def _instance_ip_delete_default_children(self, parent_obj):
        pass
    #end _instance_ip_delete_default_children

    def network_policy_http_get(self, id):
        # TODO get vals from request out of the global ASAP
        etag = request.headers.get('If-None-Match')
        # common handling for all resource get
        (ok, result) = self._get_common(request, id)
        if not ok:
            (code, msg) = result
            self.config_object_error(id, None, 'network_policy', 'http_get', msg)
            abort(code, msg)

        # type-specific hook
        r_class = self._resource_classes.get('network-policy', None)
        if r_class:
            r_class.http_get(id)

        db_conn = self._db_conn
        if etag:
            obj_ids = {'uuid': id}
            (ok, result) = db_conn.dbe_is_latest(obj_ids, etag.replace('"', ''))
            if not ok:
                # Not present in DB
                self.config_object_error(id, None, 'network_policy', 'http_get', result)
                abort(404, result)

            is_latest = result
            if is_latest:
                # send Not-Modified, caches use this for read optimization
                response.status = 304
                return
        #end if etag

        obj_ids = {'uuid': id}
        if 'fields' in request.query:
            obj_fields = request.query.fields.split(',')
        else:
            obj_fields = None
        (ok, result) = db_conn.dbe_read('network-policy', obj_ids, obj_fields)
        if not ok:
            # Not present in DB
            self.config_object_error(id, None, 'network_policy', 'http_get', result)
            abort(404, result)

        rsp_body = {}
        rsp_body['uuid'] = id
        rsp_body['href'] = self.generate_url('network-policy', id)
        rsp_body['name'] = result['fq_name'][-1]
        rsp_body.update(result)
        id_perms = result['id_perms']
        response.set_header('ETag', '"' + id_perms['last_modified'] + '"')
        return {'network-policy': rsp_body} 
    #end network_policy_http_get

    def network_policy_http_put(self, id):
        key = 'network-policy'
        obj_dict = request.json[key]
        # common handling for all resource put
        (ok, result) = self._put_common(request, 'network_policy', obj_dict, id)
        if not ok:
            (code, msg) = result
            self.config_object_error(id, None, 'network_policy', 'http_put', msg)
            abort(code, msg)

        # type-specific hook
        r_class = self._resource_classes.get('network-policy', None)
        if r_class:
            (ok, msg) = r_class.http_put(id, obj_dict)
            if not ok:
                self.config_object_error(id, None, 'network_policy', 'http_put', msg)
                abort(409, msg)

        db_conn = self._db_conn


        obj_ids = {'uuid': id}
        (ok, result) = \
             db_conn.dbe_update('network-policy', obj_ids, obj_dict)
        if not ok:
            self.config_object_error(id, None, 'network_policy', 'http_put', result)
            abort(404, result)

        rsp_body = {}
        rsp_body['uuid'] = id
        rsp_body['href'] = self.generate_url('network-policy', id)
        return {'network-policy': rsp_body} 
    #end network_policy_http_put

    def network_policy_http_delete(self, id):
        db_conn = self._db_conn
        # read in obj from db (accepting error) to get details of it
        obj_ids = {'uuid': id}
        (read_ok, read_result) = db_conn.dbe_read('network-policy', obj_ids)
        if not read_ok:
            self.config_object_error(id, None, 'network_policy', 'http_delete', read_result)
            # proceed down to delete the resource

        # common handling for all resource delete
        parent_type = read_result.get('parent_type', None)
        (ok, del_result) = self._delete_common(request, 'network_policy', id, parent_type)
        if not ok:
            (code, msg) = del_result
            self.config_object_error(id, None, 'network_policy', 'http_delete', msg)
            abort(code, msg)

        fq_name = read_result['fq_name']
        ifmap_id = common.imid.get_ifmap_id_from_fq_name('network-policy', fq_name)
        obj_ids['imid'] = ifmap_id
        if parent_type:
            parent_imid = common.imid.get_ifmap_id_from_fq_name(parent_type, fq_name[:-1])
            obj_ids['parent_imid'] = parent_imid

        # type-specific hook
        r_class = self._resource_classes.get('network-policy', None)
        if r_class:
            if read_ok:
                # fail if non-default children or backrefs exist
                virtual_network_back_refs = read_result.get('virtual_network_back_refs', None)
                if virtual_network_back_refs:
                    back_ref_urls = [back_ref_info['href'] for back_ref_info in read_result['virtual_network_back_refs']]
                    back_ref_str = ', '.join(back_ref_urls)
                    err_msg = 'Back-References from ' + back_ref_str + ' still exist'
                    self.config_object_error(id, None, 'network_policy', 'http_delete', err_msg)
                    abort(409, err_msg)


                # Delete default children first
                parent_obj = NetworkPolicy.factory(**read_result)
                self._network_policy_delete_default_children(parent_obj)

                r_class.http_delete(id, read_result)
            #end if read_ok

        (ok, del_result) = \
             db_conn.dbe_delete('network-policy', obj_ids)
        if not ok:
            self.config_object_error(id, None, 'network_policy', 'http_delete', del_result)
            abort(409, del_result)

    #end network_policy_http_delete
    def network_policys_http_post(self):
        key = 'network-policy'
        obj_dict = request.json[key]
        # common handling for all resource create
        (ok, result) = self._post_common(request, 'network-policy', obj_dict)
        if not ok:
            (code, msg) = result
            fq_name_str = ':'.join(obj_dict.get('fq_name', []))
            self.config_object_error(None, fq_name_str, 'network_policy', 'http_post', msg)
            abort(code, msg)

        # Alloc and Store id-mappings before creating entry on pubsub store.
        # Else a subscriber can ask for an id mapping before we have stored it
        uuid_requested = result
        db_conn = self._db_conn
        (ok, result) = db_conn.dbe_alloc('network-policy', obj_dict, uuid_requested)
        if not ok:
            fq_name_str = ':'.join(obj_dict['fq_name'])
            self.config_object_error(None, fq_name_str, 'network_policy', 'http_post', result)
            abort(code, result)

        obj_ids = result

        name = obj_dict['fq_name'][-1]
        fq_name = obj_dict['fq_name']


        if 'parent_type' in obj_dict:
            # non config-root child, verify parent exists
            parent_type = obj_dict['parent_type']
            parent_fq_name = obj_dict['fq_name'][:-1]
            try:
                parent_uuid = self._db_conn.fq_name_to_uuid(parent_type, parent_fq_name)
                (ok, status) = self._permissions.check_perms_write(request, parent_uuid)
                if not ok:
                    (code, err_msg) = status
                    abort(code, err_msg)
                self._permissions.set_user_role(request, obj_dict)
            except NoIdError:
                err_msg = 'Parent ' + pformat(parent_fq_name) + ' type ' + parent_type + ' does not exist'
                fq_name_str = ':'.join(parent_fq_name)
                self.config_object_error(None, fq_name_str, 'network_policy', 'http_post', err_msg)
                abort(400, err_msg)

        env = request.headers.environ
        tenant_name = env.get(hdr_server_tenant(), 'default-project')


        # type-specific hook
        r_class = self._resource_classes.get('network-policy', None)
        if r_class:
            (ok, result) = r_class.http_post_collection(tenant_name, obj_dict)
            if not ok:
                (code, msg) = result
                fq_name_str = ':'.join(fq_name)
                self.config_object_error(None, fq_name_str, 'network_policy', 'http_post', msg)
                abort(code, msg)


        (ok, result) = \
             db_conn.dbe_create('network-policy', obj_ids, obj_dict)

        if not ok:
            fq_name_str = ':'.join(fq_name)
            self.config_object_error(None, fq_name_str, 'network_policy', 'http_post', result)
            abort(404, result)

        rsp_body = {}
        rsp_body['name'] = name
        rsp_body['fq_name'] = fq_name
        rsp_body['uuid'] = obj_ids['uuid']
        rsp_body['href'] = self.generate_url('network-policy', obj_ids['uuid'])
        if 'parent_type' in obj_dict:
            # non config-root child, send back parent uuid/href
            rsp_body['parent_uuid'] = parent_uuid
            rsp_body['parent_href'] = self.generate_url(parent_type, parent_uuid)

        parent_obj = NetworkPolicy.factory(**rsp_body)
        self._network_policy_create_default_children(parent_obj)

        return {'network-policy': rsp_body} 
    #end network_policys_http_post

    def network_policys_http_get(self):
        env = request.headers.environ
        tenant_name = env.get(hdr_server_tenant(), 'default-project')
        parent_uuid = None
        resource_id = 'network_policys'
        if (('parent_fq_name_str' in request.query) and
            ('parent_type' in request.query)):
            parent_fq_name = request.query.parent_fq_name_str.split(':')
            parent_type = request.query.parent_type
            parent_uuid = self._db_conn.fq_name_to_uuid(parent_type, parent_fq_name)
        elif 'parent_id' in request.query:
            parent_uuid = str(uuid.UUID(request.query.parent_id))

        if parent_uuid:
            resource_id = parent_uuid

        # common handling for all resource get
        (ok, result) = self._get_common(request, parent_uuid)
        if not ok:
            (code, msg) = result
            self.config_object_error(None, None, 'network_policys', 'http_get_collection', msg)
            abort(code, msg)

        db_conn = self._db_conn
        (ok, result) = \
             db_conn.dbe_list('network-policy', parent_uuid)

        if not ok:
            self.config_object_error(None, None, 'network_policys', 'http_get_collection', result)
            abort(404, result)

        fq_names = result
        obj_dicts = []
        for fq_name in fq_names:
            obj_dict = {}
            id = db_conn.fq_name_to_uuid('network_policy', fq_name)
            obj_dict['uuid'] = id
            obj_dict['fq_name'] = fq_name
            obj_dict['href'] = self.generate_url('network-policy', id)
            obj_dicts.append(obj_dict)

        return {'network-policys': obj_dicts} 
    #end network_policys_http_get

    def _network_policy_create_default_children(self, parent_obj):
        pass
    #end _network_policy_create_default_children

    def _network_policy_delete_default_children(self, parent_obj):
        pass
    #end _network_policy_delete_default_children

    def virtual_DNS_record_http_get(self, id):
        # TODO get vals from request out of the global ASAP
        etag = request.headers.get('If-None-Match')
        # common handling for all resource get
        (ok, result) = self._get_common(request, id)
        if not ok:
            (code, msg) = result
            self.config_object_error(id, None, 'virtual_DNS_record', 'http_get', msg)
            abort(code, msg)

        # type-specific hook
        r_class = self._resource_classes.get('virtual-DNS-record', None)
        if r_class:
            r_class.http_get(id)

        db_conn = self._db_conn
        if etag:
            obj_ids = {'uuid': id}
            (ok, result) = db_conn.dbe_is_latest(obj_ids, etag.replace('"', ''))
            if not ok:
                # Not present in DB
                self.config_object_error(id, None, 'virtual_DNS_record', 'http_get', result)
                abort(404, result)

            is_latest = result
            if is_latest:
                # send Not-Modified, caches use this for read optimization
                response.status = 304
                return
        #end if etag

        obj_ids = {'uuid': id}
        if 'fields' in request.query:
            obj_fields = request.query.fields.split(',')
        else:
            obj_fields = None
        (ok, result) = db_conn.dbe_read('virtual-DNS-record', obj_ids, obj_fields)
        if not ok:
            # Not present in DB
            self.config_object_error(id, None, 'virtual_DNS_record', 'http_get', result)
            abort(404, result)

        rsp_body = {}
        rsp_body['uuid'] = id
        rsp_body['href'] = self.generate_url('virtual-DNS-record', id)
        rsp_body['name'] = result['fq_name'][-1]
        rsp_body.update(result)
        id_perms = result['id_perms']
        response.set_header('ETag', '"' + id_perms['last_modified'] + '"')
        return {'virtual-DNS-record': rsp_body} 
    #end virtual_DNS_record_http_get

    def virtual_DNS_record_http_put(self, id):
        key = 'virtual-DNS-record'
        obj_dict = request.json[key]
        # common handling for all resource put
        (ok, result) = self._put_common(request, 'virtual_DNS_record', obj_dict, id)
        if not ok:
            (code, msg) = result
            self.config_object_error(id, None, 'virtual_DNS_record', 'http_put', msg)
            abort(code, msg)

        # type-specific hook
        r_class = self._resource_classes.get('virtual-DNS-record', None)
        if r_class:
            (ok, msg) = r_class.http_put(id, obj_dict)
            if not ok:
                self.config_object_error(id, None, 'virtual_DNS_record', 'http_put', msg)
                abort(409, msg)

        db_conn = self._db_conn


        obj_ids = {'uuid': id}
        (ok, result) = \
             db_conn.dbe_update('virtual-DNS-record', obj_ids, obj_dict)
        if not ok:
            self.config_object_error(id, None, 'virtual_DNS_record', 'http_put', result)
            abort(404, result)

        rsp_body = {}
        rsp_body['uuid'] = id
        rsp_body['href'] = self.generate_url('virtual-DNS-record', id)
        return {'virtual-DNS-record': rsp_body} 
    #end virtual_DNS_record_http_put

    def virtual_DNS_record_http_delete(self, id):
        db_conn = self._db_conn
        # read in obj from db (accepting error) to get details of it
        obj_ids = {'uuid': id}
        (read_ok, read_result) = db_conn.dbe_read('virtual-DNS-record', obj_ids)
        if not read_ok:
            self.config_object_error(id, None, 'virtual_DNS_record', 'http_delete', read_result)
            # proceed down to delete the resource

        # common handling for all resource delete
        parent_type = read_result.get('parent_type', None)
        (ok, del_result) = self._delete_common(request, 'virtual_DNS_record', id, parent_type)
        if not ok:
            (code, msg) = del_result
            self.config_object_error(id, None, 'virtual_DNS_record', 'http_delete', msg)
            abort(code, msg)

        fq_name = read_result['fq_name']
        ifmap_id = common.imid.get_ifmap_id_from_fq_name('virtual-DNS-record', fq_name)
        obj_ids['imid'] = ifmap_id
        if parent_type:
            parent_imid = common.imid.get_ifmap_id_from_fq_name(parent_type, fq_name[:-1])
            obj_ids['parent_imid'] = parent_imid

        # type-specific hook
        r_class = self._resource_classes.get('virtual-DNS-record', None)
        if r_class:
            if read_ok:
                # fail if non-default children or backrefs exist

                # Delete default children first
                parent_obj = VirtualDnsRecord.factory(**read_result)
                self._virtual_DNS_record_delete_default_children(parent_obj)

                r_class.http_delete(id, read_result)
            #end if read_ok

        (ok, del_result) = \
             db_conn.dbe_delete('virtual-DNS-record', obj_ids)
        if not ok:
            self.config_object_error(id, None, 'virtual_DNS_record', 'http_delete', del_result)
            abort(409, del_result)

    #end virtual_DNS_record_http_delete
    def virtual_DNS_records_http_post(self):
        key = 'virtual-DNS-record'
        obj_dict = request.json[key]
        # common handling for all resource create
        (ok, result) = self._post_common(request, 'virtual-DNS-record', obj_dict)
        if not ok:
            (code, msg) = result
            fq_name_str = ':'.join(obj_dict.get('fq_name', []))
            self.config_object_error(None, fq_name_str, 'virtual_DNS_record', 'http_post', msg)
            abort(code, msg)

        # Alloc and Store id-mappings before creating entry on pubsub store.
        # Else a subscriber can ask for an id mapping before we have stored it
        uuid_requested = result
        db_conn = self._db_conn
        (ok, result) = db_conn.dbe_alloc('virtual-DNS-record', obj_dict, uuid_requested)
        if not ok:
            fq_name_str = ':'.join(obj_dict['fq_name'])
            self.config_object_error(None, fq_name_str, 'virtual_DNS_record', 'http_post', result)
            abort(code, result)

        obj_ids = result

        name = obj_dict['fq_name'][-1]
        fq_name = obj_dict['fq_name']


        if 'parent_type' in obj_dict:
            # non config-root child, verify parent exists
            parent_type = obj_dict['parent_type']
            parent_fq_name = obj_dict['fq_name'][:-1]
            try:
                parent_uuid = self._db_conn.fq_name_to_uuid(parent_type, parent_fq_name)
                (ok, status) = self._permissions.check_perms_write(request, parent_uuid)
                if not ok:
                    (code, err_msg) = status
                    abort(code, err_msg)
                self._permissions.set_user_role(request, obj_dict)
            except NoIdError:
                err_msg = 'Parent ' + pformat(parent_fq_name) + ' type ' + parent_type + ' does not exist'
                fq_name_str = ':'.join(parent_fq_name)
                self.config_object_error(None, fq_name_str, 'virtual_DNS_record', 'http_post', err_msg)
                abort(400, err_msg)

        env = request.headers.environ
        tenant_name = env.get(hdr_server_tenant(), 'default-project')


        # type-specific hook
        r_class = self._resource_classes.get('virtual-DNS-record', None)
        if r_class:
            (ok, result) = r_class.http_post_collection(tenant_name, obj_dict)
            if not ok:
                (code, msg) = result
                fq_name_str = ':'.join(fq_name)
                self.config_object_error(None, fq_name_str, 'virtual_DNS_record', 'http_post', msg)
                abort(code, msg)


        (ok, result) = \
             db_conn.dbe_create('virtual-DNS-record', obj_ids, obj_dict)

        if not ok:
            fq_name_str = ':'.join(fq_name)
            self.config_object_error(None, fq_name_str, 'virtual_DNS_record', 'http_post', result)
            abort(404, result)

        rsp_body = {}
        rsp_body['name'] = name
        rsp_body['fq_name'] = fq_name
        rsp_body['uuid'] = obj_ids['uuid']
        rsp_body['href'] = self.generate_url('virtual-DNS-record', obj_ids['uuid'])
        if 'parent_type' in obj_dict:
            # non config-root child, send back parent uuid/href
            rsp_body['parent_uuid'] = parent_uuid
            rsp_body['parent_href'] = self.generate_url(parent_type, parent_uuid)

        parent_obj = VirtualDnsRecord.factory(**rsp_body)
        self._virtual_DNS_record_create_default_children(parent_obj)

        return {'virtual-DNS-record': rsp_body} 
    #end virtual_DNS_records_http_post

    def virtual_DNS_records_http_get(self):
        env = request.headers.environ
        tenant_name = env.get(hdr_server_tenant(), 'default-project')
        parent_uuid = None
        resource_id = 'virtual_DNS_records'
        if (('parent_fq_name_str' in request.query) and
            ('parent_type' in request.query)):
            parent_fq_name = request.query.parent_fq_name_str.split(':')
            parent_type = request.query.parent_type
            parent_uuid = self._db_conn.fq_name_to_uuid(parent_type, parent_fq_name)
        elif 'parent_id' in request.query:
            parent_uuid = str(uuid.UUID(request.query.parent_id))

        if parent_uuid:
            resource_id = parent_uuid

        # common handling for all resource get
        (ok, result) = self._get_common(request, parent_uuid)
        if not ok:
            (code, msg) = result
            self.config_object_error(None, None, 'virtual_DNS_records', 'http_get_collection', msg)
            abort(code, msg)

        db_conn = self._db_conn
        (ok, result) = \
             db_conn.dbe_list('virtual-DNS-record', parent_uuid)

        if not ok:
            self.config_object_error(None, None, 'virtual_DNS_records', 'http_get_collection', result)
            abort(404, result)

        fq_names = result
        obj_dicts = []
        for fq_name in fq_names:
            obj_dict = {}
            id = db_conn.fq_name_to_uuid('virtual_DNS_record', fq_name)
            obj_dict['uuid'] = id
            obj_dict['fq_name'] = fq_name
            obj_dict['href'] = self.generate_url('virtual-DNS-record', id)
            obj_dicts.append(obj_dict)

        return {'virtual-DNS-records': obj_dicts} 
    #end virtual_DNS_records_http_get

    def _virtual_DNS_record_create_default_children(self, parent_obj):
        pass
    #end _virtual_DNS_record_create_default_children

    def _virtual_DNS_record_delete_default_children(self, parent_obj):
        pass
    #end _virtual_DNS_record_delete_default_children

    def route_target_http_get(self, id):
        # TODO get vals from request out of the global ASAP
        etag = request.headers.get('If-None-Match')
        # common handling for all resource get
        (ok, result) = self._get_common(request, id)
        if not ok:
            (code, msg) = result
            self.config_object_error(id, None, 'route_target', 'http_get', msg)
            abort(code, msg)

        # type-specific hook
        r_class = self._resource_classes.get('route-target', None)
        if r_class:
            r_class.http_get(id)

        db_conn = self._db_conn
        if etag:
            obj_ids = {'uuid': id}
            (ok, result) = db_conn.dbe_is_latest(obj_ids, etag.replace('"', ''))
            if not ok:
                # Not present in DB
                self.config_object_error(id, None, 'route_target', 'http_get', result)
                abort(404, result)

            is_latest = result
            if is_latest:
                # send Not-Modified, caches use this for read optimization
                response.status = 304
                return
        #end if etag

        obj_ids = {'uuid': id}
        if 'fields' in request.query:
            obj_fields = request.query.fields.split(',')
        else:
            obj_fields = None
        (ok, result) = db_conn.dbe_read('route-target', obj_ids, obj_fields)
        if not ok:
            # Not present in DB
            self.config_object_error(id, None, 'route_target', 'http_get', result)
            abort(404, result)

        rsp_body = {}
        rsp_body['uuid'] = id
        rsp_body['href'] = self.generate_url('route-target', id)
        rsp_body['name'] = result['fq_name'][-1]
        rsp_body.update(result)
        id_perms = result['id_perms']
        response.set_header('ETag', '"' + id_perms['last_modified'] + '"')
        return {'route-target': rsp_body} 
    #end route_target_http_get

    def route_target_http_put(self, id):
        key = 'route-target'
        obj_dict = request.json[key]
        # common handling for all resource put
        (ok, result) = self._put_common(request, 'route_target', obj_dict, id)
        if not ok:
            (code, msg) = result
            self.config_object_error(id, None, 'route_target', 'http_put', msg)
            abort(code, msg)

        # type-specific hook
        r_class = self._resource_classes.get('route-target', None)
        if r_class:
            (ok, msg) = r_class.http_put(id, obj_dict)
            if not ok:
                self.config_object_error(id, None, 'route_target', 'http_put', msg)
                abort(409, msg)

        db_conn = self._db_conn


        obj_ids = {'uuid': id}
        (ok, result) = \
             db_conn.dbe_update('route-target', obj_ids, obj_dict)
        if not ok:
            self.config_object_error(id, None, 'route_target', 'http_put', result)
            abort(404, result)

        rsp_body = {}
        rsp_body['uuid'] = id
        rsp_body['href'] = self.generate_url('route-target', id)
        return {'route-target': rsp_body} 
    #end route_target_http_put

    def route_target_http_delete(self, id):
        db_conn = self._db_conn
        # read in obj from db (accepting error) to get details of it
        obj_ids = {'uuid': id}
        (read_ok, read_result) = db_conn.dbe_read('route-target', obj_ids)
        if not read_ok:
            self.config_object_error(id, None, 'route_target', 'http_delete', read_result)
            # proceed down to delete the resource

        # common handling for all resource delete
        parent_type = read_result.get('parent_type', None)
        (ok, del_result) = self._delete_common(request, 'route_target', id, parent_type)
        if not ok:
            (code, msg) = del_result
            self.config_object_error(id, None, 'route_target', 'http_delete', msg)
            abort(code, msg)

        fq_name = read_result['fq_name']
        ifmap_id = common.imid.get_ifmap_id_from_fq_name('route-target', fq_name)
        obj_ids['imid'] = ifmap_id
        if parent_type:
            parent_imid = common.imid.get_ifmap_id_from_fq_name(parent_type, fq_name[:-1])
            obj_ids['parent_imid'] = parent_imid

        # type-specific hook
        r_class = self._resource_classes.get('route-target', None)
        if r_class:
            if read_ok:
                # fail if non-default children or backrefs exist
                routing_instance_back_refs = read_result.get('routing_instance_back_refs', None)
                if routing_instance_back_refs:
                    back_ref_urls = [back_ref_info['href'] for back_ref_info in read_result['routing_instance_back_refs']]
                    back_ref_str = ', '.join(back_ref_urls)
                    err_msg = 'Back-References from ' + back_ref_str + ' still exist'
                    self.config_object_error(id, None, 'route_target', 'http_delete', err_msg)
                    abort(409, err_msg)


                # Delete default children first
                parent_obj = RouteTarget.factory(**read_result)
                self._route_target_delete_default_children(parent_obj)

                r_class.http_delete(id, read_result)
            #end if read_ok

        (ok, del_result) = \
             db_conn.dbe_delete('route-target', obj_ids)
        if not ok:
            self.config_object_error(id, None, 'route_target', 'http_delete', del_result)
            abort(409, del_result)

    #end route_target_http_delete
    def route_targets_http_post(self):
        key = 'route-target'
        obj_dict = request.json[key]
        # common handling for all resource create
        (ok, result) = self._post_common(request, 'route-target', obj_dict)
        if not ok:
            (code, msg) = result
            fq_name_str = ':'.join(obj_dict.get('fq_name', []))
            self.config_object_error(None, fq_name_str, 'route_target', 'http_post', msg)
            abort(code, msg)

        # Alloc and Store id-mappings before creating entry on pubsub store.
        # Else a subscriber can ask for an id mapping before we have stored it
        uuid_requested = result
        db_conn = self._db_conn
        (ok, result) = db_conn.dbe_alloc('route-target', obj_dict, uuid_requested)
        if not ok:
            fq_name_str = ':'.join(obj_dict['fq_name'])
            self.config_object_error(None, fq_name_str, 'route_target', 'http_post', result)
            abort(code, result)

        obj_ids = result

        name = obj_dict['fq_name'][-1]
        fq_name = obj_dict['fq_name']


        env = request.headers.environ
        tenant_name = env.get(hdr_server_tenant(), 'default-project')


        # type-specific hook
        r_class = self._resource_classes.get('route-target', None)
        if r_class:
            (ok, result) = r_class.http_post_collection(tenant_name, obj_dict)
            if not ok:
                (code, msg) = result
                fq_name_str = ':'.join(fq_name)
                self.config_object_error(None, fq_name_str, 'route_target', 'http_post', msg)
                abort(code, msg)


        (ok, result) = \
             db_conn.dbe_create('route-target', obj_ids, obj_dict)

        if not ok:
            fq_name_str = ':'.join(fq_name)
            self.config_object_error(None, fq_name_str, 'route_target', 'http_post', result)
            abort(404, result)

        rsp_body = {}
        rsp_body['name'] = name
        rsp_body['fq_name'] = fq_name
        rsp_body['uuid'] = obj_ids['uuid']
        rsp_body['href'] = self.generate_url('route-target', obj_ids['uuid'])

        parent_obj = RouteTarget.factory(**rsp_body)
        self._route_target_create_default_children(parent_obj)

        return {'route-target': rsp_body} 
    #end route_targets_http_post

    def route_targets_http_get(self):
        env = request.headers.environ
        tenant_name = env.get(hdr_server_tenant(), 'default-project')
        parent_uuid = None
        resource_id = 'route_targets'
        if (('parent_fq_name_str' in request.query) and
            ('parent_type' in request.query)):
            parent_fq_name = request.query.parent_fq_name_str.split(':')
            parent_type = request.query.parent_type
            parent_uuid = self._db_conn.fq_name_to_uuid(parent_type, parent_fq_name)
        elif 'parent_id' in request.query:
            parent_uuid = str(uuid.UUID(request.query.parent_id))

        if parent_uuid:
            resource_id = parent_uuid

        # common handling for all resource get
        (ok, result) = self._get_common(request, parent_uuid)
        if not ok:
            (code, msg) = result
            self.config_object_error(None, None, 'route_targets', 'http_get_collection', msg)
            abort(code, msg)

        db_conn = self._db_conn
        (ok, result) = \
             db_conn.dbe_list('route-target', parent_uuid)

        if not ok:
            self.config_object_error(None, None, 'route_targets', 'http_get_collection', result)
            abort(404, result)

        fq_names = result
        obj_dicts = []
        for fq_name in fq_names:
            obj_dict = {}
            id = db_conn.fq_name_to_uuid('route_target', fq_name)
            obj_dict['uuid'] = id
            obj_dict['fq_name'] = fq_name
            obj_dict['href'] = self.generate_url('route-target', id)
            obj_dicts.append(obj_dict)

        return {'route-targets': obj_dicts} 
    #end route_targets_http_get

    def _route_target_create_default_children(self, parent_obj):
        pass
    #end _route_target_create_default_children

    def _route_target_delete_default_children(self, parent_obj):
        pass
    #end _route_target_delete_default_children

    def floating_ip_http_get(self, id):
        # TODO get vals from request out of the global ASAP
        etag = request.headers.get('If-None-Match')
        # common handling for all resource get
        (ok, result) = self._get_common(request, id)
        if not ok:
            (code, msg) = result
            self.config_object_error(id, None, 'floating_ip', 'http_get', msg)
            abort(code, msg)

        # type-specific hook
        r_class = self._resource_classes.get('floating-ip', None)
        if r_class:
            r_class.http_get(id)

        db_conn = self._db_conn
        if etag:
            obj_ids = {'uuid': id}
            (ok, result) = db_conn.dbe_is_latest(obj_ids, etag.replace('"', ''))
            if not ok:
                # Not present in DB
                self.config_object_error(id, None, 'floating_ip', 'http_get', result)
                abort(404, result)

            is_latest = result
            if is_latest:
                # send Not-Modified, caches use this for read optimization
                response.status = 304
                return
        #end if etag

        obj_ids = {'uuid': id}
        if 'fields' in request.query:
            obj_fields = request.query.fields.split(',')
        else:
            obj_fields = None
        (ok, result) = db_conn.dbe_read('floating-ip', obj_ids, obj_fields)
        if not ok:
            # Not present in DB
            self.config_object_error(id, None, 'floating_ip', 'http_get', result)
            abort(404, result)

        rsp_body = {}
        rsp_body['uuid'] = id
        rsp_body['href'] = self.generate_url('floating-ip', id)
        rsp_body['name'] = result['fq_name'][-1]
        rsp_body.update(result)
        id_perms = result['id_perms']
        response.set_header('ETag', '"' + id_perms['last_modified'] + '"')
        return {'floating-ip': rsp_body} 
    #end floating_ip_http_get

    def floating_ip_http_put(self, id):
        key = 'floating-ip'
        obj_dict = request.json[key]
        # common handling for all resource put
        (ok, result) = self._put_common(request, 'floating_ip', obj_dict, id)
        if not ok:
            (code, msg) = result
            self.config_object_error(id, None, 'floating_ip', 'http_put', msg)
            abort(code, msg)

        # type-specific hook
        r_class = self._resource_classes.get('floating-ip', None)
        if r_class:
            (ok, msg) = r_class.http_put(id, obj_dict)
            if not ok:
                self.config_object_error(id, None, 'floating_ip', 'http_put', msg)
                abort(409, msg)

        db_conn = self._db_conn

        # Validate perms
        objtype_list = eval("[u'project', u'virtual_machine_interface']")
        for obj_type in objtype_list:
            refs = obj_dict.get('%s_refs'%(obj_type), None)
            if refs:
                for ref in refs:
                    ref_uuid = db_conn.fq_name_to_uuid(obj_type, ref['to'])
                    (ok, status) = self._permissions.check_perms_link(request, ref_uuid)
                    if not ok:
                        (code, err_msg) = status
                        abort(code, err_msg)

        obj_ids = {'uuid': id}
        (ok, result) = \
             db_conn.dbe_update('floating-ip', obj_ids, obj_dict)
        if not ok:
            self.config_object_error(id, None, 'floating_ip', 'http_put', result)
            abort(404, result)

        rsp_body = {}
        rsp_body['uuid'] = id
        rsp_body['href'] = self.generate_url('floating-ip', id)
        return {'floating-ip': rsp_body} 
    #end floating_ip_http_put

    def floating_ip_http_delete(self, id):
        db_conn = self._db_conn
        # read in obj from db (accepting error) to get details of it
        obj_ids = {'uuid': id}
        (read_ok, read_result) = db_conn.dbe_read('floating-ip', obj_ids)
        if not read_ok:
            self.config_object_error(id, None, 'floating_ip', 'http_delete', read_result)
            # proceed down to delete the resource

        # common handling for all resource delete
        parent_type = read_result.get('parent_type', None)
        (ok, del_result) = self._delete_common(request, 'floating_ip', id, parent_type)
        if not ok:
            (code, msg) = del_result
            self.config_object_error(id, None, 'floating_ip', 'http_delete', msg)
            abort(code, msg)

        fq_name = read_result['fq_name']
        ifmap_id = common.imid.get_ifmap_id_from_fq_name('floating-ip', fq_name)
        obj_ids['imid'] = ifmap_id
        if parent_type:
            parent_imid = common.imid.get_ifmap_id_from_fq_name(parent_type, fq_name[:-1])
            obj_ids['parent_imid'] = parent_imid

        # type-specific hook
        r_class = self._resource_classes.get('floating-ip', None)
        if r_class:
            if read_ok:
                # fail if non-default children or backrefs exist
                customer_attachment_back_refs = read_result.get('customer_attachment_back_refs', None)
                if customer_attachment_back_refs:
                    back_ref_urls = [back_ref_info['href'] for back_ref_info in read_result['customer_attachment_back_refs']]
                    back_ref_str = ', '.join(back_ref_urls)
                    err_msg = 'Back-References from ' + back_ref_str + ' still exist'
                    self.config_object_error(id, None, 'floating_ip', 'http_delete', err_msg)
                    abort(409, err_msg)


                # Delete default children first
                parent_obj = FloatingIp.factory(**read_result)
                self._floating_ip_delete_default_children(parent_obj)

                r_class.http_delete(id, read_result)
            #end if read_ok

        (ok, del_result) = \
             db_conn.dbe_delete('floating-ip', obj_ids)
        if not ok:
            self.config_object_error(id, None, 'floating_ip', 'http_delete', del_result)
            abort(409, del_result)

    #end floating_ip_http_delete
    def floating_ips_http_post(self):
        key = 'floating-ip'
        obj_dict = request.json[key]
        # common handling for all resource create
        (ok, result) = self._post_common(request, 'floating-ip', obj_dict)
        if not ok:
            (code, msg) = result
            fq_name_str = ':'.join(obj_dict.get('fq_name', []))
            self.config_object_error(None, fq_name_str, 'floating_ip', 'http_post', msg)
            abort(code, msg)

        # Alloc and Store id-mappings before creating entry on pubsub store.
        # Else a subscriber can ask for an id mapping before we have stored it
        uuid_requested = result
        db_conn = self._db_conn
        (ok, result) = db_conn.dbe_alloc('floating-ip', obj_dict, uuid_requested)
        if not ok:
            fq_name_str = ':'.join(obj_dict['fq_name'])
            self.config_object_error(None, fq_name_str, 'floating_ip', 'http_post', result)
            abort(code, result)

        obj_ids = result

        name = obj_dict['fq_name'][-1]
        fq_name = obj_dict['fq_name']


        if 'parent_type' in obj_dict:
            # non config-root child, verify parent exists
            parent_type = obj_dict['parent_type']
            parent_fq_name = obj_dict['fq_name'][:-1]
            try:
                parent_uuid = self._db_conn.fq_name_to_uuid(parent_type, parent_fq_name)
                (ok, status) = self._permissions.check_perms_write(request, parent_uuid)
                if not ok:
                    (code, err_msg) = status
                    abort(code, err_msg)
                self._permissions.set_user_role(request, obj_dict)
            except NoIdError:
                err_msg = 'Parent ' + pformat(parent_fq_name) + ' type ' + parent_type + ' does not exist'
                fq_name_str = ':'.join(parent_fq_name)
                self.config_object_error(None, fq_name_str, 'floating_ip', 'http_post', err_msg)
                abort(400, err_msg)

        env = request.headers.environ
        tenant_name = env.get(hdr_server_tenant(), 'default-project')


        # type-specific hook
        r_class = self._resource_classes.get('floating-ip', None)
        if r_class:
            (ok, result) = r_class.http_post_collection(tenant_name, obj_dict)
            if not ok:
                (code, msg) = result
                fq_name_str = ':'.join(fq_name)
                self.config_object_error(None, fq_name_str, 'floating_ip', 'http_post', msg)
                abort(code, msg)

        # Validate perms
        objtype_list = eval("[u'project', u'virtual_machine_interface']")
        for obj_type in objtype_list:
            refs = obj_dict.get('%s_refs'%(obj_type), None)
            if refs:
                for ref in refs:
                    ref_uuid = db_conn.fq_name_to_uuid(obj_type, ref['to'])
                    (ok, status) = self._permissions.check_perms_link(request, ref_uuid)
                    if not ok:
                        (code, err_msg) = status
                        abort(code, err_msg)

        (ok, result) = \
             db_conn.dbe_create('floating-ip', obj_ids, obj_dict)

        if not ok:
            fq_name_str = ':'.join(fq_name)
            self.config_object_error(None, fq_name_str, 'floating_ip', 'http_post', result)
            abort(404, result)

        rsp_body = {}
        rsp_body['name'] = name
        rsp_body['fq_name'] = fq_name
        rsp_body['uuid'] = obj_ids['uuid']
        rsp_body['href'] = self.generate_url('floating-ip', obj_ids['uuid'])
        if 'parent_type' in obj_dict:
            # non config-root child, send back parent uuid/href
            rsp_body['parent_uuid'] = parent_uuid
            rsp_body['parent_href'] = self.generate_url(parent_type, parent_uuid)

        parent_obj = FloatingIp.factory(**rsp_body)
        self._floating_ip_create_default_children(parent_obj)

        return {'floating-ip': rsp_body} 
    #end floating_ips_http_post

    def floating_ips_http_get(self):
        env = request.headers.environ
        tenant_name = env.get(hdr_server_tenant(), 'default-project')
        parent_uuid = None
        resource_id = 'floating_ips'
        if (('parent_fq_name_str' in request.query) and
            ('parent_type' in request.query)):
            parent_fq_name = request.query.parent_fq_name_str.split(':')
            parent_type = request.query.parent_type
            parent_uuid = self._db_conn.fq_name_to_uuid(parent_type, parent_fq_name)
        elif 'parent_id' in request.query:
            parent_uuid = str(uuid.UUID(request.query.parent_id))

        if parent_uuid:
            resource_id = parent_uuid

        # common handling for all resource get
        (ok, result) = self._get_common(request, parent_uuid)
        if not ok:
            (code, msg) = result
            self.config_object_error(None, None, 'floating_ips', 'http_get_collection', msg)
            abort(code, msg)

        db_conn = self._db_conn
        (ok, result) = \
             db_conn.dbe_list('floating-ip', parent_uuid)

        if not ok:
            self.config_object_error(None, None, 'floating_ips', 'http_get_collection', result)
            abort(404, result)

        fq_names = result
        obj_dicts = []
        for fq_name in fq_names:
            obj_dict = {}
            id = db_conn.fq_name_to_uuid('floating_ip', fq_name)
            obj_dict['uuid'] = id
            obj_dict['fq_name'] = fq_name
            obj_dict['href'] = self.generate_url('floating-ip', id)
            obj_dicts.append(obj_dict)

        return {'floating-ips': obj_dicts} 
    #end floating_ips_http_get

    def _floating_ip_create_default_children(self, parent_obj):
        pass
    #end _floating_ip_create_default_children

    def _floating_ip_delete_default_children(self, parent_obj):
        pass
    #end _floating_ip_delete_default_children

    def floating_ip_pool_http_get(self, id):
        # TODO get vals from request out of the global ASAP
        etag = request.headers.get('If-None-Match')
        # common handling for all resource get
        (ok, result) = self._get_common(request, id)
        if not ok:
            (code, msg) = result
            self.config_object_error(id, None, 'floating_ip_pool', 'http_get', msg)
            abort(code, msg)

        # type-specific hook
        r_class = self._resource_classes.get('floating-ip-pool', None)
        if r_class:
            r_class.http_get(id)

        db_conn = self._db_conn
        if etag:
            obj_ids = {'uuid': id}
            (ok, result) = db_conn.dbe_is_latest(obj_ids, etag.replace('"', ''))
            if not ok:
                # Not present in DB
                self.config_object_error(id, None, 'floating_ip_pool', 'http_get', result)
                abort(404, result)

            is_latest = result
            if is_latest:
                # send Not-Modified, caches use this for read optimization
                response.status = 304
                return
        #end if etag

        obj_ids = {'uuid': id}
        if 'fields' in request.query:
            obj_fields = request.query.fields.split(',')
        else:
            obj_fields = None
        (ok, result) = db_conn.dbe_read('floating-ip-pool', obj_ids, obj_fields)
        if not ok:
            # Not present in DB
            self.config_object_error(id, None, 'floating_ip_pool', 'http_get', result)
            abort(404, result)

        rsp_body = {}
        rsp_body['uuid'] = id
        rsp_body['href'] = self.generate_url('floating-ip-pool', id)
        rsp_body['name'] = result['fq_name'][-1]
        rsp_body.update(result)
        id_perms = result['id_perms']
        response.set_header('ETag', '"' + id_perms['last_modified'] + '"')
        return {'floating-ip-pool': rsp_body} 
    #end floating_ip_pool_http_get

    def floating_ip_pool_http_put(self, id):
        key = 'floating-ip-pool'
        obj_dict = request.json[key]
        # common handling for all resource put
        (ok, result) = self._put_common(request, 'floating_ip_pool', obj_dict, id)
        if not ok:
            (code, msg) = result
            self.config_object_error(id, None, 'floating_ip_pool', 'http_put', msg)
            abort(code, msg)

        # type-specific hook
        r_class = self._resource_classes.get('floating-ip-pool', None)
        if r_class:
            (ok, msg) = r_class.http_put(id, obj_dict)
            if not ok:
                self.config_object_error(id, None, 'floating_ip_pool', 'http_put', msg)
                abort(409, msg)

        db_conn = self._db_conn

        # Validate perms
        objtype_list = eval("[u'floating_ip']")
        for obj_type in objtype_list:
            refs = obj_dict.get('%s_refs'%(obj_type), None)
            if refs:
                for ref in refs:
                    ref_uuid = db_conn.fq_name_to_uuid(obj_type, ref['to'])
                    (ok, status) = self._permissions.check_perms_link(request, ref_uuid)
                    if not ok:
                        (code, err_msg) = status
                        abort(code, err_msg)

        obj_ids = {'uuid': id}
        (ok, result) = \
             db_conn.dbe_update('floating-ip-pool', obj_ids, obj_dict)
        if not ok:
            self.config_object_error(id, None, 'floating_ip_pool', 'http_put', result)
            abort(404, result)

        rsp_body = {}
        rsp_body['uuid'] = id
        rsp_body['href'] = self.generate_url('floating-ip-pool', id)
        return {'floating-ip-pool': rsp_body} 
    #end floating_ip_pool_http_put

    def floating_ip_pool_http_delete(self, id):
        db_conn = self._db_conn
        # read in obj from db (accepting error) to get details of it
        obj_ids = {'uuid': id}
        (read_ok, read_result) = db_conn.dbe_read('floating-ip-pool', obj_ids)
        if not read_ok:
            self.config_object_error(id, None, 'floating_ip_pool', 'http_delete', read_result)
            # proceed down to delete the resource

        # common handling for all resource delete
        parent_type = read_result.get('parent_type', None)
        (ok, del_result) = self._delete_common(request, 'floating_ip_pool', id, parent_type)
        if not ok:
            (code, msg) = del_result
            self.config_object_error(id, None, 'floating_ip_pool', 'http_delete', msg)
            abort(code, msg)

        fq_name = read_result['fq_name']
        ifmap_id = common.imid.get_ifmap_id_from_fq_name('floating-ip-pool', fq_name)
        obj_ids['imid'] = ifmap_id
        if parent_type:
            parent_imid = common.imid.get_ifmap_id_from_fq_name(parent_type, fq_name[:-1])
            obj_ids['parent_imid'] = parent_imid

        # type-specific hook
        r_class = self._resource_classes.get('floating-ip-pool', None)
        if r_class:
            if read_ok:
                # fail if non-default children or backrefs exist
                floating_ips = read_result.get('floating_ips', None)
                if floating_ips:
                    has_infos = read_result['floating_ips']
                    if ((len(has_infos) > 1) or 
                        (len(has_infos) == 1 and has_infos[0]['to'][-1] != 'default-floating-ip')):
                        has_urls = [has_info['href'] for has_info in has_infos]
                        has_str = ', '.join(has_urls)
                        err_msg = 'Children ' + has_str + ' still exist'
                        self.config_object_error(id, None, 'floating_ip_pool', 'http_delete', err_msg)
                        abort(409, err_msg)

                project_back_refs = read_result.get('project_back_refs', None)
                if project_back_refs:
                    back_ref_urls = [back_ref_info['href'] for back_ref_info in read_result['project_back_refs']]
                    back_ref_str = ', '.join(back_ref_urls)
                    err_msg = 'Back-References from ' + back_ref_str + ' still exist'
                    self.config_object_error(id, None, 'floating_ip_pool', 'http_delete', err_msg)
                    abort(409, err_msg)


                # Delete default children first
                parent_obj = FloatingIpPool.factory(**read_result)
                self._floating_ip_pool_delete_default_children(parent_obj)

                r_class.http_delete(id, read_result)
            #end if read_ok

        (ok, del_result) = \
             db_conn.dbe_delete('floating-ip-pool', obj_ids)
        if not ok:
            self.config_object_error(id, None, 'floating_ip_pool', 'http_delete', del_result)
            abort(409, del_result)

    #end floating_ip_pool_http_delete
    def floating_ip_pools_http_post(self):
        key = 'floating-ip-pool'
        obj_dict = request.json[key]
        # common handling for all resource create
        (ok, result) = self._post_common(request, 'floating-ip-pool', obj_dict)
        if not ok:
            (code, msg) = result
            fq_name_str = ':'.join(obj_dict.get('fq_name', []))
            self.config_object_error(None, fq_name_str, 'floating_ip_pool', 'http_post', msg)
            abort(code, msg)

        # Alloc and Store id-mappings before creating entry on pubsub store.
        # Else a subscriber can ask for an id mapping before we have stored it
        uuid_requested = result
        db_conn = self._db_conn
        (ok, result) = db_conn.dbe_alloc('floating-ip-pool', obj_dict, uuid_requested)
        if not ok:
            fq_name_str = ':'.join(obj_dict['fq_name'])
            self.config_object_error(None, fq_name_str, 'floating_ip_pool', 'http_post', result)
            abort(code, result)

        obj_ids = result

        name = obj_dict['fq_name'][-1]
        fq_name = obj_dict['fq_name']


        if 'parent_type' in obj_dict:
            # non config-root child, verify parent exists
            parent_type = obj_dict['parent_type']
            parent_fq_name = obj_dict['fq_name'][:-1]
            try:
                parent_uuid = self._db_conn.fq_name_to_uuid(parent_type, parent_fq_name)
                (ok, status) = self._permissions.check_perms_write(request, parent_uuid)
                if not ok:
                    (code, err_msg) = status
                    abort(code, err_msg)
                self._permissions.set_user_role(request, obj_dict)
            except NoIdError:
                err_msg = 'Parent ' + pformat(parent_fq_name) + ' type ' + parent_type + ' does not exist'
                fq_name_str = ':'.join(parent_fq_name)
                self.config_object_error(None, fq_name_str, 'floating_ip_pool', 'http_post', err_msg)
                abort(400, err_msg)

        env = request.headers.environ
        tenant_name = env.get(hdr_server_tenant(), 'default-project')


        # type-specific hook
        r_class = self._resource_classes.get('floating-ip-pool', None)
        if r_class:
            (ok, result) = r_class.http_post_collection(tenant_name, obj_dict)
            if not ok:
                (code, msg) = result
                fq_name_str = ':'.join(fq_name)
                self.config_object_error(None, fq_name_str, 'floating_ip_pool', 'http_post', msg)
                abort(code, msg)

        # Validate perms
        objtype_list = eval("[u'floating_ip']")
        for obj_type in objtype_list:
            refs = obj_dict.get('%s_refs'%(obj_type), None)
            if refs:
                for ref in refs:
                    ref_uuid = db_conn.fq_name_to_uuid(obj_type, ref['to'])
                    (ok, status) = self._permissions.check_perms_link(request, ref_uuid)
                    if not ok:
                        (code, err_msg) = status
                        abort(code, err_msg)

        (ok, result) = \
             db_conn.dbe_create('floating-ip-pool', obj_ids, obj_dict)

        if not ok:
            fq_name_str = ':'.join(fq_name)
            self.config_object_error(None, fq_name_str, 'floating_ip_pool', 'http_post', result)
            abort(404, result)

        rsp_body = {}
        rsp_body['name'] = name
        rsp_body['fq_name'] = fq_name
        rsp_body['uuid'] = obj_ids['uuid']
        rsp_body['href'] = self.generate_url('floating-ip-pool', obj_ids['uuid'])
        if 'parent_type' in obj_dict:
            # non config-root child, send back parent uuid/href
            rsp_body['parent_uuid'] = parent_uuid
            rsp_body['parent_href'] = self.generate_url(parent_type, parent_uuid)

        parent_obj = FloatingIpPool.factory(**rsp_body)
        self._floating_ip_pool_create_default_children(parent_obj)

        return {'floating-ip-pool': rsp_body} 
    #end floating_ip_pools_http_post

    def floating_ip_pools_http_get(self):
        env = request.headers.environ
        tenant_name = env.get(hdr_server_tenant(), 'default-project')
        parent_uuid = None
        resource_id = 'floating_ip_pools'
        if (('parent_fq_name_str' in request.query) and
            ('parent_type' in request.query)):
            parent_fq_name = request.query.parent_fq_name_str.split(':')
            parent_type = request.query.parent_type
            parent_uuid = self._db_conn.fq_name_to_uuid(parent_type, parent_fq_name)
        elif 'parent_id' in request.query:
            parent_uuid = str(uuid.UUID(request.query.parent_id))

        if parent_uuid:
            resource_id = parent_uuid

        # common handling for all resource get
        (ok, result) = self._get_common(request, parent_uuid)
        if not ok:
            (code, msg) = result
            self.config_object_error(None, None, 'floating_ip_pools', 'http_get_collection', msg)
            abort(code, msg)

        db_conn = self._db_conn
        (ok, result) = \
             db_conn.dbe_list('floating-ip-pool', parent_uuid)

        if not ok:
            self.config_object_error(None, None, 'floating_ip_pools', 'http_get_collection', result)
            abort(404, result)

        fq_names = result
        obj_dicts = []
        for fq_name in fq_names:
            obj_dict = {}
            id = db_conn.fq_name_to_uuid('floating_ip_pool', fq_name)
            obj_dict['uuid'] = id
            obj_dict['fq_name'] = fq_name
            obj_dict['href'] = self.generate_url('floating-ip-pool', id)
            obj_dicts.append(obj_dict)

        return {'floating-ip-pools': obj_dicts} 
    #end floating_ip_pools_http_get

    def _floating_ip_pool_create_default_children(self, parent_obj):
        # Create a default child only if provisioned for
        r_class = self._resource_classes.get('floating-ip', None)
        if r_class.generate_default_instance:
            child_obj = FloatingIp(parent_obj = parent_obj)
            child_dict = child_obj.__dict__
            fq_name = child_dict['fq_name']
            child_dict['id_perms'] = self._get_default_id_perms('floating-ip')

            db_conn = self._db_conn
            (ok, result) = db_conn.dbe_alloc('floating-ip', child_dict)
            if not ok:
                return (ok, result)

            obj_ids = result
            db_conn.dbe_create('floating-ip', obj_ids, child_dict)
            self._floating_ip_create_default_children(child_obj)

        pass
    #end _floating_ip_pool_create_default_children

    def _floating_ip_pool_delete_default_children(self, parent_obj):
        # Delete a default child only if provisioned for
        r_class = self._resource_classes.get('floating-ip', None)
        if r_class.generate_default_instance:
            # first locate default child then delete it
            has_infos = parent_obj.get_floating_ips()
            if has_infos:
                for has_info in has_infos:
                    if has_info['to'][-1] == 'default-floating-ip':
                        default_child_id = has_info['href'].split('/')[-1]
                        self.floating_ip_http_delete(default_child_id)
                        break

        pass
    #end _floating_ip_pool_delete_default_children

    def physical_router_http_get(self, id):
        # TODO get vals from request out of the global ASAP
        etag = request.headers.get('If-None-Match')
        # common handling for all resource get
        (ok, result) = self._get_common(request, id)
        if not ok:
            (code, msg) = result
            self.config_object_error(id, None, 'physical_router', 'http_get', msg)
            abort(code, msg)

        # type-specific hook
        r_class = self._resource_classes.get('physical-router', None)
        if r_class:
            r_class.http_get(id)

        db_conn = self._db_conn
        if etag:
            obj_ids = {'uuid': id}
            (ok, result) = db_conn.dbe_is_latest(obj_ids, etag.replace('"', ''))
            if not ok:
                # Not present in DB
                self.config_object_error(id, None, 'physical_router', 'http_get', result)
                abort(404, result)

            is_latest = result
            if is_latest:
                # send Not-Modified, caches use this for read optimization
                response.status = 304
                return
        #end if etag

        obj_ids = {'uuid': id}
        if 'fields' in request.query:
            obj_fields = request.query.fields.split(',')
        else:
            obj_fields = None
        (ok, result) = db_conn.dbe_read('physical-router', obj_ids, obj_fields)
        if not ok:
            # Not present in DB
            self.config_object_error(id, None, 'physical_router', 'http_get', result)
            abort(404, result)

        rsp_body = {}
        rsp_body['uuid'] = id
        rsp_body['href'] = self.generate_url('physical-router', id)
        rsp_body['name'] = result['fq_name'][-1]
        rsp_body.update(result)
        id_perms = result['id_perms']
        response.set_header('ETag', '"' + id_perms['last_modified'] + '"')
        return {'physical-router': rsp_body} 
    #end physical_router_http_get

    def physical_router_http_put(self, id):
        key = 'physical-router'
        obj_dict = request.json[key]
        # common handling for all resource put
        (ok, result) = self._put_common(request, 'physical_router', obj_dict, id)
        if not ok:
            (code, msg) = result
            self.config_object_error(id, None, 'physical_router', 'http_put', msg)
            abort(code, msg)

        # type-specific hook
        r_class = self._resource_classes.get('physical-router', None)
        if r_class:
            (ok, msg) = r_class.http_put(id, obj_dict)
            if not ok:
                self.config_object_error(id, None, 'physical_router', 'http_put', msg)
                abort(409, msg)

        db_conn = self._db_conn

        # Validate perms
        objtype_list = eval("['bgp_router', u'physical_interface']")
        for obj_type in objtype_list:
            refs = obj_dict.get('%s_refs'%(obj_type), None)
            if refs:
                for ref in refs:
                    ref_uuid = db_conn.fq_name_to_uuid(obj_type, ref['to'])
                    (ok, status) = self._permissions.check_perms_link(request, ref_uuid)
                    if not ok:
                        (code, err_msg) = status
                        abort(code, err_msg)

        obj_ids = {'uuid': id}
        (ok, result) = \
             db_conn.dbe_update('physical-router', obj_ids, obj_dict)
        if not ok:
            self.config_object_error(id, None, 'physical_router', 'http_put', result)
            abort(404, result)

        rsp_body = {}
        rsp_body['uuid'] = id
        rsp_body['href'] = self.generate_url('physical-router', id)
        return {'physical-router': rsp_body} 
    #end physical_router_http_put

    def physical_router_http_delete(self, id):
        db_conn = self._db_conn
        # read in obj from db (accepting error) to get details of it
        obj_ids = {'uuid': id}
        (read_ok, read_result) = db_conn.dbe_read('physical-router', obj_ids)
        if not read_ok:
            self.config_object_error(id, None, 'physical_router', 'http_delete', read_result)
            # proceed down to delete the resource

        # common handling for all resource delete
        parent_type = read_result.get('parent_type', None)
        (ok, del_result) = self._delete_common(request, 'physical_router', id, parent_type)
        if not ok:
            (code, msg) = del_result
            self.config_object_error(id, None, 'physical_router', 'http_delete', msg)
            abort(code, msg)

        fq_name = read_result['fq_name']
        ifmap_id = common.imid.get_ifmap_id_from_fq_name('physical-router', fq_name)
        obj_ids['imid'] = ifmap_id
        if parent_type:
            parent_imid = common.imid.get_ifmap_id_from_fq_name(parent_type, fq_name[:-1])
            obj_ids['parent_imid'] = parent_imid

        # type-specific hook
        r_class = self._resource_classes.get('physical-router', None)
        if r_class:
            if read_ok:
                # fail if non-default children or backrefs exist
                physical_interfaces = read_result.get('physical_interfaces', None)
                if physical_interfaces:
                    has_infos = read_result['physical_interfaces']
                    if ((len(has_infos) > 1) or 
                        (len(has_infos) == 1 and has_infos[0]['to'][-1] != 'default-physical-interface')):
                        has_urls = [has_info['href'] for has_info in has_infos]
                        has_str = ', '.join(has_urls)
                        err_msg = 'Children ' + has_str + ' still exist'
                        self.config_object_error(id, None, 'physical_router', 'http_delete', err_msg)
                        abort(409, err_msg)


                # Delete default children first
                parent_obj = PhysicalRouter.factory(**read_result)
                self._physical_router_delete_default_children(parent_obj)

                r_class.http_delete(id, read_result)
            #end if read_ok

        (ok, del_result) = \
             db_conn.dbe_delete('physical-router', obj_ids)
        if not ok:
            self.config_object_error(id, None, 'physical_router', 'http_delete', del_result)
            abort(409, del_result)

    #end physical_router_http_delete
    def physical_routers_http_post(self):
        key = 'physical-router'
        obj_dict = request.json[key]
        # common handling for all resource create
        (ok, result) = self._post_common(request, 'physical-router', obj_dict)
        if not ok:
            (code, msg) = result
            fq_name_str = ':'.join(obj_dict.get('fq_name', []))
            self.config_object_error(None, fq_name_str, 'physical_router', 'http_post', msg)
            abort(code, msg)

        # Alloc and Store id-mappings before creating entry on pubsub store.
        # Else a subscriber can ask for an id mapping before we have stored it
        uuid_requested = result
        db_conn = self._db_conn
        (ok, result) = db_conn.dbe_alloc('physical-router', obj_dict, uuid_requested)
        if not ok:
            fq_name_str = ':'.join(obj_dict['fq_name'])
            self.config_object_error(None, fq_name_str, 'physical_router', 'http_post', result)
            abort(code, result)

        obj_ids = result

        name = obj_dict['fq_name'][-1]
        fq_name = obj_dict['fq_name']


        if 'parent_type' in obj_dict:
            # non config-root child, verify parent exists
            parent_type = obj_dict['parent_type']
            parent_fq_name = obj_dict['fq_name'][:-1]
            try:
                parent_uuid = self._db_conn.fq_name_to_uuid(parent_type, parent_fq_name)
                (ok, status) = self._permissions.check_perms_write(request, parent_uuid)
                if not ok:
                    (code, err_msg) = status
                    abort(code, err_msg)
                self._permissions.set_user_role(request, obj_dict)
            except NoIdError:
                err_msg = 'Parent ' + pformat(parent_fq_name) + ' type ' + parent_type + ' does not exist'
                fq_name_str = ':'.join(parent_fq_name)
                self.config_object_error(None, fq_name_str, 'physical_router', 'http_post', err_msg)
                abort(400, err_msg)

        env = request.headers.environ
        tenant_name = env.get(hdr_server_tenant(), 'default-project')


        # type-specific hook
        r_class = self._resource_classes.get('physical-router', None)
        if r_class:
            (ok, result) = r_class.http_post_collection(tenant_name, obj_dict)
            if not ok:
                (code, msg) = result
                fq_name_str = ':'.join(fq_name)
                self.config_object_error(None, fq_name_str, 'physical_router', 'http_post', msg)
                abort(code, msg)

        # Validate perms
        objtype_list = eval("['bgp_router', u'physical_interface']")
        for obj_type in objtype_list:
            refs = obj_dict.get('%s_refs'%(obj_type), None)
            if refs:
                for ref in refs:
                    ref_uuid = db_conn.fq_name_to_uuid(obj_type, ref['to'])
                    (ok, status) = self._permissions.check_perms_link(request, ref_uuid)
                    if not ok:
                        (code, err_msg) = status
                        abort(code, err_msg)

        (ok, result) = \
             db_conn.dbe_create('physical-router', obj_ids, obj_dict)

        if not ok:
            fq_name_str = ':'.join(fq_name)
            self.config_object_error(None, fq_name_str, 'physical_router', 'http_post', result)
            abort(404, result)

        rsp_body = {}
        rsp_body['name'] = name
        rsp_body['fq_name'] = fq_name
        rsp_body['uuid'] = obj_ids['uuid']
        rsp_body['href'] = self.generate_url('physical-router', obj_ids['uuid'])
        if 'parent_type' in obj_dict:
            # non config-root child, send back parent uuid/href
            rsp_body['parent_uuid'] = parent_uuid
            rsp_body['parent_href'] = self.generate_url(parent_type, parent_uuid)

        parent_obj = PhysicalRouter.factory(**rsp_body)
        self._physical_router_create_default_children(parent_obj)

        return {'physical-router': rsp_body} 
    #end physical_routers_http_post

    def physical_routers_http_get(self):
        env = request.headers.environ
        tenant_name = env.get(hdr_server_tenant(), 'default-project')
        parent_uuid = None
        resource_id = 'physical_routers'
        if (('parent_fq_name_str' in request.query) and
            ('parent_type' in request.query)):
            parent_fq_name = request.query.parent_fq_name_str.split(':')
            parent_type = request.query.parent_type
            parent_uuid = self._db_conn.fq_name_to_uuid(parent_type, parent_fq_name)
        elif 'parent_id' in request.query:
            parent_uuid = str(uuid.UUID(request.query.parent_id))

        if parent_uuid:
            resource_id = parent_uuid

        # common handling for all resource get
        (ok, result) = self._get_common(request, parent_uuid)
        if not ok:
            (code, msg) = result
            self.config_object_error(None, None, 'physical_routers', 'http_get_collection', msg)
            abort(code, msg)

        db_conn = self._db_conn
        (ok, result) = \
             db_conn.dbe_list('physical-router', parent_uuid)

        if not ok:
            self.config_object_error(None, None, 'physical_routers', 'http_get_collection', result)
            abort(404, result)

        fq_names = result
        obj_dicts = []
        for fq_name in fq_names:
            obj_dict = {}
            id = db_conn.fq_name_to_uuid('physical_router', fq_name)
            obj_dict['uuid'] = id
            obj_dict['fq_name'] = fq_name
            obj_dict['href'] = self.generate_url('physical-router', id)
            obj_dicts.append(obj_dict)

        return {'physical-routers': obj_dicts} 
    #end physical_routers_http_get

    def _physical_router_create_default_children(self, parent_obj):
        # Create a default child only if provisioned for
        r_class = self._resource_classes.get('physical-interface', None)
        if r_class.generate_default_instance:
            child_obj = PhysicalInterface(parent_obj = parent_obj)
            child_dict = child_obj.__dict__
            fq_name = child_dict['fq_name']
            child_dict['id_perms'] = self._get_default_id_perms('physical-interface')

            db_conn = self._db_conn
            (ok, result) = db_conn.dbe_alloc('physical-interface', child_dict)
            if not ok:
                return (ok, result)

            obj_ids = result
            db_conn.dbe_create('physical-interface', obj_ids, child_dict)
            self._physical_interface_create_default_children(child_obj)

        pass
    #end _physical_router_create_default_children

    def _physical_router_delete_default_children(self, parent_obj):
        # Delete a default child only if provisioned for
        r_class = self._resource_classes.get('physical-interface', None)
        if r_class.generate_default_instance:
            # first locate default child then delete it
            has_infos = parent_obj.get_physical_interfaces()
            if has_infos:
                for has_info in has_infos:
                    if has_info['to'][-1] == 'default-physical-interface':
                        default_child_id = has_info['href'].split('/')[-1]
                        self.physical_interface_http_delete(default_child_id)
                        break

        pass
    #end _physical_router_delete_default_children

    def bgp_router_http_get(self, id):
        # TODO get vals from request out of the global ASAP
        etag = request.headers.get('If-None-Match')
        # common handling for all resource get
        (ok, result) = self._get_common(request, id)
        if not ok:
            (code, msg) = result
            self.config_object_error(id, None, 'bgp_router', 'http_get', msg)
            abort(code, msg)

        # type-specific hook
        r_class = self._resource_classes.get('bgp-router', None)
        if r_class:
            r_class.http_get(id)

        db_conn = self._db_conn
        if etag:
            obj_ids = {'uuid': id}
            (ok, result) = db_conn.dbe_is_latest(obj_ids, etag.replace('"', ''))
            if not ok:
                # Not present in DB
                self.config_object_error(id, None, 'bgp_router', 'http_get', result)
                abort(404, result)

            is_latest = result
            if is_latest:
                # send Not-Modified, caches use this for read optimization
                response.status = 304
                return
        #end if etag

        obj_ids = {'uuid': id}
        if 'fields' in request.query:
            obj_fields = request.query.fields.split(',')
        else:
            obj_fields = None
        (ok, result) = db_conn.dbe_read('bgp-router', obj_ids, obj_fields)
        if not ok:
            # Not present in DB
            self.config_object_error(id, None, 'bgp_router', 'http_get', result)
            abort(404, result)

        rsp_body = {}
        rsp_body['uuid'] = id
        rsp_body['href'] = self.generate_url('bgp-router', id)
        rsp_body['name'] = result['fq_name'][-1]
        rsp_body.update(result)
        id_perms = result['id_perms']
        response.set_header('ETag', '"' + id_perms['last_modified'] + '"')
        return {'bgp-router': rsp_body} 
    #end bgp_router_http_get

    def bgp_router_http_put(self, id):
        key = 'bgp-router'
        obj_dict = request.json[key]
        # common handling for all resource put
        (ok, result) = self._put_common(request, 'bgp_router', obj_dict, id)
        if not ok:
            (code, msg) = result
            self.config_object_error(id, None, 'bgp_router', 'http_put', msg)
            abort(code, msg)

        # type-specific hook
        r_class = self._resource_classes.get('bgp-router', None)
        if r_class:
            (ok, msg) = r_class.http_put(id, obj_dict)
            if not ok:
                self.config_object_error(id, None, 'bgp_router', 'http_put', msg)
                abort(409, msg)

        db_conn = self._db_conn

        # Validate perms
        objtype_list = eval("['bgp_router']")
        for obj_type in objtype_list:
            refs = obj_dict.get('%s_refs'%(obj_type), None)
            if refs:
                for ref in refs:
                    ref_uuid = db_conn.fq_name_to_uuid(obj_type, ref['to'])
                    (ok, status) = self._permissions.check_perms_link(request, ref_uuid)
                    if not ok:
                        (code, err_msg) = status
                        abort(code, err_msg)

        obj_ids = {'uuid': id}
        (ok, result) = \
             db_conn.dbe_update('bgp-router', obj_ids, obj_dict)
        if not ok:
            self.config_object_error(id, None, 'bgp_router', 'http_put', result)
            abort(404, result)

        rsp_body = {}
        rsp_body['uuid'] = id
        rsp_body['href'] = self.generate_url('bgp-router', id)
        return {'bgp-router': rsp_body} 
    #end bgp_router_http_put

    def bgp_router_http_delete(self, id):
        db_conn = self._db_conn
        # read in obj from db (accepting error) to get details of it
        obj_ids = {'uuid': id}
        (read_ok, read_result) = db_conn.dbe_read('bgp-router', obj_ids)
        if not read_ok:
            self.config_object_error(id, None, 'bgp_router', 'http_delete', read_result)
            # proceed down to delete the resource

        # common handling for all resource delete
        parent_type = read_result.get('parent_type', None)
        (ok, del_result) = self._delete_common(request, 'bgp_router', id, parent_type)
        if not ok:
            (code, msg) = del_result
            self.config_object_error(id, None, 'bgp_router', 'http_delete', msg)
            abort(code, msg)

        fq_name = read_result['fq_name']
        ifmap_id = common.imid.get_ifmap_id_from_fq_name('bgp-router', fq_name)
        obj_ids['imid'] = ifmap_id
        if parent_type:
            parent_imid = common.imid.get_ifmap_id_from_fq_name(parent_type, fq_name[:-1])
            obj_ids['parent_imid'] = parent_imid

        # type-specific hook
        r_class = self._resource_classes.get('bgp-router', None)
        if r_class:
            if read_ok:
                # fail if non-default children or backrefs exist
                global_system_config_back_refs = read_result.get('global_system_config_back_refs', None)
                if global_system_config_back_refs:
                    back_ref_urls = [back_ref_info['href'] for back_ref_info in read_result['global_system_config_back_refs']]
                    back_ref_str = ', '.join(back_ref_urls)
                    err_msg = 'Back-References from ' + back_ref_str + ' still exist'
                    self.config_object_error(id, None, 'bgp_router', 'http_delete', err_msg)
                    abort(409, err_msg)

                physical_router_back_refs = read_result.get('physical_router_back_refs', None)
                if physical_router_back_refs:
                    back_ref_urls = [back_ref_info['href'] for back_ref_info in read_result['physical_router_back_refs']]
                    back_ref_str = ', '.join(back_ref_urls)
                    err_msg = 'Back-References from ' + back_ref_str + ' still exist'
                    self.config_object_error(id, None, 'bgp_router', 'http_delete', err_msg)
                    abort(409, err_msg)

                virtual_router_back_refs = read_result.get('virtual_router_back_refs', None)
                if virtual_router_back_refs:
                    back_ref_urls = [back_ref_info['href'] for back_ref_info in read_result['virtual_router_back_refs']]
                    back_ref_str = ', '.join(back_ref_urls)
                    err_msg = 'Back-References from ' + back_ref_str + ' still exist'
                    self.config_object_error(id, None, 'bgp_router', 'http_delete', err_msg)
                    abort(409, err_msg)

                bgp_router_back_refs = read_result.get('bgp_router_back_refs', None)
                if bgp_router_back_refs:
                    back_ref_urls = [back_ref_info['href'] for back_ref_info in read_result['bgp_router_back_refs']]
                    back_ref_str = ', '.join(back_ref_urls)
                    err_msg = 'Back-References from ' + back_ref_str + ' still exist'
                    self.config_object_error(id, None, 'bgp_router', 'http_delete', err_msg)
                    abort(409, err_msg)


                # Delete default children first
                parent_obj = BgpRouter.factory(**read_result)
                self._bgp_router_delete_default_children(parent_obj)

                r_class.http_delete(id, read_result)
            #end if read_ok

        (ok, del_result) = \
             db_conn.dbe_delete('bgp-router', obj_ids)
        if not ok:
            self.config_object_error(id, None, 'bgp_router', 'http_delete', del_result)
            abort(409, del_result)

    #end bgp_router_http_delete
    def bgp_routers_http_post(self):
        key = 'bgp-router'
        obj_dict = request.json[key]
        # common handling for all resource create
        (ok, result) = self._post_common(request, 'bgp-router', obj_dict)
        if not ok:
            (code, msg) = result
            fq_name_str = ':'.join(obj_dict.get('fq_name', []))
            self.config_object_error(None, fq_name_str, 'bgp_router', 'http_post', msg)
            abort(code, msg)

        # Alloc and Store id-mappings before creating entry on pubsub store.
        # Else a subscriber can ask for an id mapping before we have stored it
        uuid_requested = result
        db_conn = self._db_conn
        (ok, result) = db_conn.dbe_alloc('bgp-router', obj_dict, uuid_requested)
        if not ok:
            fq_name_str = ':'.join(obj_dict['fq_name'])
            self.config_object_error(None, fq_name_str, 'bgp_router', 'http_post', result)
            abort(code, result)

        obj_ids = result

        name = obj_dict['fq_name'][-1]
        fq_name = obj_dict['fq_name']


        if 'parent_type' in obj_dict:
            # non config-root child, verify parent exists
            parent_type = obj_dict['parent_type']
            parent_fq_name = obj_dict['fq_name'][:-1]
            try:
                parent_uuid = self._db_conn.fq_name_to_uuid(parent_type, parent_fq_name)
                (ok, status) = self._permissions.check_perms_write(request, parent_uuid)
                if not ok:
                    (code, err_msg) = status
                    abort(code, err_msg)
                self._permissions.set_user_role(request, obj_dict)
            except NoIdError:
                err_msg = 'Parent ' + pformat(parent_fq_name) + ' type ' + parent_type + ' does not exist'
                fq_name_str = ':'.join(parent_fq_name)
                self.config_object_error(None, fq_name_str, 'bgp_router', 'http_post', err_msg)
                abort(400, err_msg)

        env = request.headers.environ
        tenant_name = env.get(hdr_server_tenant(), 'default-project')


        # type-specific hook
        r_class = self._resource_classes.get('bgp-router', None)
        if r_class:
            (ok, result) = r_class.http_post_collection(tenant_name, obj_dict)
            if not ok:
                (code, msg) = result
                fq_name_str = ':'.join(fq_name)
                self.config_object_error(None, fq_name_str, 'bgp_router', 'http_post', msg)
                abort(code, msg)

        # Validate perms
        objtype_list = eval("['bgp_router']")
        for obj_type in objtype_list:
            refs = obj_dict.get('%s_refs'%(obj_type), None)
            if refs:
                for ref in refs:
                    ref_uuid = db_conn.fq_name_to_uuid(obj_type, ref['to'])
                    (ok, status) = self._permissions.check_perms_link(request, ref_uuid)
                    if not ok:
                        (code, err_msg) = status
                        abort(code, err_msg)

        (ok, result) = \
             db_conn.dbe_create('bgp-router', obj_ids, obj_dict)

        if not ok:
            fq_name_str = ':'.join(fq_name)
            self.config_object_error(None, fq_name_str, 'bgp_router', 'http_post', result)
            abort(404, result)

        rsp_body = {}
        rsp_body['name'] = name
        rsp_body['fq_name'] = fq_name
        rsp_body['uuid'] = obj_ids['uuid']
        rsp_body['href'] = self.generate_url('bgp-router', obj_ids['uuid'])
        if 'parent_type' in obj_dict:
            # non config-root child, send back parent uuid/href
            rsp_body['parent_uuid'] = parent_uuid
            rsp_body['parent_href'] = self.generate_url(parent_type, parent_uuid)

        parent_obj = BgpRouter.factory(**rsp_body)
        self._bgp_router_create_default_children(parent_obj)

        return {'bgp-router': rsp_body} 
    #end bgp_routers_http_post

    def bgp_routers_http_get(self):
        env = request.headers.environ
        tenant_name = env.get(hdr_server_tenant(), 'default-project')
        parent_uuid = None
        resource_id = 'bgp_routers'
        if (('parent_fq_name_str' in request.query) and
            ('parent_type' in request.query)):
            parent_fq_name = request.query.parent_fq_name_str.split(':')
            parent_type = request.query.parent_type
            parent_uuid = self._db_conn.fq_name_to_uuid(parent_type, parent_fq_name)
        elif 'parent_id' in request.query:
            parent_uuid = str(uuid.UUID(request.query.parent_id))

        if parent_uuid:
            resource_id = parent_uuid

        # common handling for all resource get
        (ok, result) = self._get_common(request, parent_uuid)
        if not ok:
            (code, msg) = result
            self.config_object_error(None, None, 'bgp_routers', 'http_get_collection', msg)
            abort(code, msg)

        db_conn = self._db_conn
        (ok, result) = \
             db_conn.dbe_list('bgp-router', parent_uuid)

        if not ok:
            self.config_object_error(None, None, 'bgp_routers', 'http_get_collection', result)
            abort(404, result)

        fq_names = result
        obj_dicts = []
        for fq_name in fq_names:
            obj_dict = {}
            id = db_conn.fq_name_to_uuid('bgp_router', fq_name)
            obj_dict['uuid'] = id
            obj_dict['fq_name'] = fq_name
            obj_dict['href'] = self.generate_url('bgp-router', id)
            obj_dicts.append(obj_dict)

        return {'bgp-routers': obj_dicts} 
    #end bgp_routers_http_get

    def _bgp_router_create_default_children(self, parent_obj):
        pass
    #end _bgp_router_create_default_children

    def _bgp_router_delete_default_children(self, parent_obj):
        pass
    #end _bgp_router_delete_default_children

    def virtual_router_http_get(self, id):
        # TODO get vals from request out of the global ASAP
        etag = request.headers.get('If-None-Match')
        # common handling for all resource get
        (ok, result) = self._get_common(request, id)
        if not ok:
            (code, msg) = result
            self.config_object_error(id, None, 'virtual_router', 'http_get', msg)
            abort(code, msg)

        # type-specific hook
        r_class = self._resource_classes.get('virtual-router', None)
        if r_class:
            r_class.http_get(id)

        db_conn = self._db_conn
        if etag:
            obj_ids = {'uuid': id}
            (ok, result) = db_conn.dbe_is_latest(obj_ids, etag.replace('"', ''))
            if not ok:
                # Not present in DB
                self.config_object_error(id, None, 'virtual_router', 'http_get', result)
                abort(404, result)

            is_latest = result
            if is_latest:
                # send Not-Modified, caches use this for read optimization
                response.status = 304
                return
        #end if etag

        obj_ids = {'uuid': id}
        if 'fields' in request.query:
            obj_fields = request.query.fields.split(',')
        else:
            obj_fields = None
        (ok, result) = db_conn.dbe_read('virtual-router', obj_ids, obj_fields)
        if not ok:
            # Not present in DB
            self.config_object_error(id, None, 'virtual_router', 'http_get', result)
            abort(404, result)

        rsp_body = {}
        rsp_body['uuid'] = id
        rsp_body['href'] = self.generate_url('virtual-router', id)
        rsp_body['name'] = result['fq_name'][-1]
        rsp_body.update(result)
        id_perms = result['id_perms']
        response.set_header('ETag', '"' + id_perms['last_modified'] + '"')
        return {'virtual-router': rsp_body} 
    #end virtual_router_http_get

    def virtual_router_http_put(self, id):
        key = 'virtual-router'
        obj_dict = request.json[key]
        # common handling for all resource put
        (ok, result) = self._put_common(request, 'virtual_router', obj_dict, id)
        if not ok:
            (code, msg) = result
            self.config_object_error(id, None, 'virtual_router', 'http_put', msg)
            abort(code, msg)

        # type-specific hook
        r_class = self._resource_classes.get('virtual-router', None)
        if r_class:
            (ok, msg) = r_class.http_put(id, obj_dict)
            if not ok:
                self.config_object_error(id, None, 'virtual_router', 'http_put', msg)
                abort(409, msg)

        db_conn = self._db_conn

        # Validate perms
        objtype_list = eval("['bgp_router', u'virtual_machine']")
        for obj_type in objtype_list:
            refs = obj_dict.get('%s_refs'%(obj_type), None)
            if refs:
                for ref in refs:
                    ref_uuid = db_conn.fq_name_to_uuid(obj_type, ref['to'])
                    (ok, status) = self._permissions.check_perms_link(request, ref_uuid)
                    if not ok:
                        (code, err_msg) = status
                        abort(code, err_msg)

        obj_ids = {'uuid': id}
        (ok, result) = \
             db_conn.dbe_update('virtual-router', obj_ids, obj_dict)
        if not ok:
            self.config_object_error(id, None, 'virtual_router', 'http_put', result)
            abort(404, result)

        rsp_body = {}
        rsp_body['uuid'] = id
        rsp_body['href'] = self.generate_url('virtual-router', id)
        return {'virtual-router': rsp_body} 
    #end virtual_router_http_put

    def virtual_router_http_delete(self, id):
        db_conn = self._db_conn
        # read in obj from db (accepting error) to get details of it
        obj_ids = {'uuid': id}
        (read_ok, read_result) = db_conn.dbe_read('virtual-router', obj_ids)
        if not read_ok:
            self.config_object_error(id, None, 'virtual_router', 'http_delete', read_result)
            # proceed down to delete the resource

        # common handling for all resource delete
        parent_type = read_result.get('parent_type', None)
        (ok, del_result) = self._delete_common(request, 'virtual_router', id, parent_type)
        if not ok:
            (code, msg) = del_result
            self.config_object_error(id, None, 'virtual_router', 'http_delete', msg)
            abort(code, msg)

        fq_name = read_result['fq_name']
        ifmap_id = common.imid.get_ifmap_id_from_fq_name('virtual-router', fq_name)
        obj_ids['imid'] = ifmap_id
        if parent_type:
            parent_imid = common.imid.get_ifmap_id_from_fq_name(parent_type, fq_name[:-1])
            obj_ids['parent_imid'] = parent_imid

        # type-specific hook
        r_class = self._resource_classes.get('virtual-router', None)
        if r_class:
            if read_ok:
                # fail if non-default children or backrefs exist
                provider_attachment_back_refs = read_result.get('provider_attachment_back_refs', None)
                if provider_attachment_back_refs:
                    back_ref_urls = [back_ref_info['href'] for back_ref_info in read_result['provider_attachment_back_refs']]
                    back_ref_str = ', '.join(back_ref_urls)
                    err_msg = 'Back-References from ' + back_ref_str + ' still exist'
                    self.config_object_error(id, None, 'virtual_router', 'http_delete', err_msg)
                    abort(409, err_msg)


                # Delete default children first
                parent_obj = VirtualRouter.factory(**read_result)
                self._virtual_router_delete_default_children(parent_obj)

                r_class.http_delete(id, read_result)
            #end if read_ok

        (ok, del_result) = \
             db_conn.dbe_delete('virtual-router', obj_ids)
        if not ok:
            self.config_object_error(id, None, 'virtual_router', 'http_delete', del_result)
            abort(409, del_result)

    #end virtual_router_http_delete
    def virtual_routers_http_post(self):
        key = 'virtual-router'
        obj_dict = request.json[key]
        # common handling for all resource create
        (ok, result) = self._post_common(request, 'virtual-router', obj_dict)
        if not ok:
            (code, msg) = result
            fq_name_str = ':'.join(obj_dict.get('fq_name', []))
            self.config_object_error(None, fq_name_str, 'virtual_router', 'http_post', msg)
            abort(code, msg)

        # Alloc and Store id-mappings before creating entry on pubsub store.
        # Else a subscriber can ask for an id mapping before we have stored it
        uuid_requested = result
        db_conn = self._db_conn
        (ok, result) = db_conn.dbe_alloc('virtual-router', obj_dict, uuid_requested)
        if not ok:
            fq_name_str = ':'.join(obj_dict['fq_name'])
            self.config_object_error(None, fq_name_str, 'virtual_router', 'http_post', result)
            abort(code, result)

        obj_ids = result

        name = obj_dict['fq_name'][-1]
        fq_name = obj_dict['fq_name']


        if 'parent_type' in obj_dict:
            # non config-root child, verify parent exists
            parent_type = obj_dict['parent_type']
            parent_fq_name = obj_dict['fq_name'][:-1]
            try:
                parent_uuid = self._db_conn.fq_name_to_uuid(parent_type, parent_fq_name)
                (ok, status) = self._permissions.check_perms_write(request, parent_uuid)
                if not ok:
                    (code, err_msg) = status
                    abort(code, err_msg)
                self._permissions.set_user_role(request, obj_dict)
            except NoIdError:
                err_msg = 'Parent ' + pformat(parent_fq_name) + ' type ' + parent_type + ' does not exist'
                fq_name_str = ':'.join(parent_fq_name)
                self.config_object_error(None, fq_name_str, 'virtual_router', 'http_post', err_msg)
                abort(400, err_msg)

        env = request.headers.environ
        tenant_name = env.get(hdr_server_tenant(), 'default-project')


        # type-specific hook
        r_class = self._resource_classes.get('virtual-router', None)
        if r_class:
            (ok, result) = r_class.http_post_collection(tenant_name, obj_dict)
            if not ok:
                (code, msg) = result
                fq_name_str = ':'.join(fq_name)
                self.config_object_error(None, fq_name_str, 'virtual_router', 'http_post', msg)
                abort(code, msg)

        # Validate perms
        objtype_list = eval("['bgp_router', u'virtual_machine']")
        for obj_type in objtype_list:
            refs = obj_dict.get('%s_refs'%(obj_type), None)
            if refs:
                for ref in refs:
                    ref_uuid = db_conn.fq_name_to_uuid(obj_type, ref['to'])
                    (ok, status) = self._permissions.check_perms_link(request, ref_uuid)
                    if not ok:
                        (code, err_msg) = status
                        abort(code, err_msg)

        (ok, result) = \
             db_conn.dbe_create('virtual-router', obj_ids, obj_dict)

        if not ok:
            fq_name_str = ':'.join(fq_name)
            self.config_object_error(None, fq_name_str, 'virtual_router', 'http_post', result)
            abort(404, result)

        rsp_body = {}
        rsp_body['name'] = name
        rsp_body['fq_name'] = fq_name
        rsp_body['uuid'] = obj_ids['uuid']
        rsp_body['href'] = self.generate_url('virtual-router', obj_ids['uuid'])
        if 'parent_type' in obj_dict:
            # non config-root child, send back parent uuid/href
            rsp_body['parent_uuid'] = parent_uuid
            rsp_body['parent_href'] = self.generate_url(parent_type, parent_uuid)

        parent_obj = VirtualRouter.factory(**rsp_body)
        self._virtual_router_create_default_children(parent_obj)

        return {'virtual-router': rsp_body} 
    #end virtual_routers_http_post

    def virtual_routers_http_get(self):
        env = request.headers.environ
        tenant_name = env.get(hdr_server_tenant(), 'default-project')
        parent_uuid = None
        resource_id = 'virtual_routers'
        if (('parent_fq_name_str' in request.query) and
            ('parent_type' in request.query)):
            parent_fq_name = request.query.parent_fq_name_str.split(':')
            parent_type = request.query.parent_type
            parent_uuid = self._db_conn.fq_name_to_uuid(parent_type, parent_fq_name)
        elif 'parent_id' in request.query:
            parent_uuid = str(uuid.UUID(request.query.parent_id))

        if parent_uuid:
            resource_id = parent_uuid

        # common handling for all resource get
        (ok, result) = self._get_common(request, parent_uuid)
        if not ok:
            (code, msg) = result
            self.config_object_error(None, None, 'virtual_routers', 'http_get_collection', msg)
            abort(code, msg)

        db_conn = self._db_conn
        (ok, result) = \
             db_conn.dbe_list('virtual-router', parent_uuid)

        if not ok:
            self.config_object_error(None, None, 'virtual_routers', 'http_get_collection', result)
            abort(404, result)

        fq_names = result
        obj_dicts = []
        for fq_name in fq_names:
            obj_dict = {}
            id = db_conn.fq_name_to_uuid('virtual_router', fq_name)
            obj_dict['uuid'] = id
            obj_dict['fq_name'] = fq_name
            obj_dict['href'] = self.generate_url('virtual-router', id)
            obj_dicts.append(obj_dict)

        return {'virtual-routers': obj_dicts} 
    #end virtual_routers_http_get

    def _virtual_router_create_default_children(self, parent_obj):
        pass
    #end _virtual_router_create_default_children

    def _virtual_router_delete_default_children(self, parent_obj):
        pass
    #end _virtual_router_delete_default_children

    def config_root_http_get(self, id):
        # TODO get vals from request out of the global ASAP
        etag = request.headers.get('If-None-Match')
        # common handling for all resource get
        (ok, result) = self._get_common(request, id)
        if not ok:
            (code, msg) = result
            self.config_object_error(id, None, 'config_root', 'http_get', msg)
            abort(code, msg)

        # type-specific hook
        r_class = self._resource_classes.get('config-root', None)
        if r_class:
            r_class.http_get(id)

        db_conn = self._db_conn
        if etag:
            obj_ids = {'uuid': id}
            (ok, result) = db_conn.dbe_is_latest(obj_ids, etag.replace('"', ''))
            if not ok:
                # Not present in DB
                self.config_object_error(id, None, 'config_root', 'http_get', result)
                abort(404, result)

            is_latest = result
            if is_latest:
                # send Not-Modified, caches use this for read optimization
                response.status = 304
                return
        #end if etag

        obj_ids = {'uuid': id}
        if 'fields' in request.query:
            obj_fields = request.query.fields.split(',')
        else:
            obj_fields = None
        (ok, result) = db_conn.dbe_read('config-root', obj_ids, obj_fields)
        if not ok:
            # Not present in DB
            self.config_object_error(id, None, 'config_root', 'http_get', result)
            abort(404, result)

        rsp_body = {}
        rsp_body['uuid'] = id
        rsp_body['href'] = self.generate_url('config-root', id)
        rsp_body['name'] = result['fq_name'][-1]
        rsp_body.update(result)
        id_perms = result['id_perms']
        response.set_header('ETag', '"' + id_perms['last_modified'] + '"')
        return {'config-root': rsp_body} 
    #end config_root_http_get

    def config_root_http_put(self, id):
        key = 'config-root'
        obj_dict = request.json[key]
        # common handling for all resource put
        (ok, result) = self._put_common(request, 'config_root', obj_dict, id)
        if not ok:
            (code, msg) = result
            self.config_object_error(id, None, 'config_root', 'http_put', msg)
            abort(code, msg)

        # type-specific hook
        r_class = self._resource_classes.get('config-root', None)
        if r_class:
            (ok, msg) = r_class.http_put(id, obj_dict)
            if not ok:
                self.config_object_error(id, None, 'config_root', 'http_put', msg)
                abort(409, msg)

        db_conn = self._db_conn

        # Validate perms
        objtype_list = eval("[u'global_system_config', u'domain']")
        for obj_type in objtype_list:
            refs = obj_dict.get('%s_refs'%(obj_type), None)
            if refs:
                for ref in refs:
                    ref_uuid = db_conn.fq_name_to_uuid(obj_type, ref['to'])
                    (ok, status) = self._permissions.check_perms_link(request, ref_uuid)
                    if not ok:
                        (code, err_msg) = status
                        abort(code, err_msg)

        obj_ids = {'uuid': id}
        (ok, result) = \
             db_conn.dbe_update('config-root', obj_ids, obj_dict)
        if not ok:
            self.config_object_error(id, None, 'config_root', 'http_put', result)
            abort(404, result)

        rsp_body = {}
        rsp_body['uuid'] = id
        rsp_body['href'] = self.generate_url('config-root', id)
        return {'config-root': rsp_body} 
    #end config_root_http_put

    def config_root_http_delete(self, id):
        db_conn = self._db_conn
        # read in obj from db (accepting error) to get details of it
        obj_ids = {'uuid': id}
        (read_ok, read_result) = db_conn.dbe_read('config-root', obj_ids)
        if not read_ok:
            self.config_object_error(id, None, 'config_root', 'http_delete', read_result)
            # proceed down to delete the resource

        # common handling for all resource delete
        parent_type = read_result.get('parent_type', None)
        (ok, del_result) = self._delete_common(request, 'config_root', id, parent_type)
        if not ok:
            (code, msg) = del_result
            self.config_object_error(id, None, 'config_root', 'http_delete', msg)
            abort(code, msg)

        fq_name = read_result['fq_name']
        ifmap_id = common.imid.get_ifmap_id_from_fq_name('config-root', fq_name)
        obj_ids['imid'] = ifmap_id
        if parent_type:
            parent_imid = common.imid.get_ifmap_id_from_fq_name(parent_type, fq_name[:-1])
            obj_ids['parent_imid'] = parent_imid

        # type-specific hook
        r_class = self._resource_classes.get('config-root', None)
        if r_class:
            if read_ok:
                # fail if non-default children or backrefs exist
                global_system_configs = read_result.get('global_system_configs', None)
                if global_system_configs:
                    has_infos = read_result['global_system_configs']
                    if ((len(has_infos) > 1) or 
                        (len(has_infos) == 1 and has_infos[0]['to'][-1] != 'default-global-system-config')):
                        has_urls = [has_info['href'] for has_info in has_infos]
                        has_str = ', '.join(has_urls)
                        err_msg = 'Children ' + has_str + ' still exist'
                        self.config_object_error(id, None, 'config_root', 'http_delete', err_msg)
                        abort(409, err_msg)

                domains = read_result.get('domains', None)
                if domains:
                    has_infos = read_result['domains']
                    if ((len(has_infos) > 1) or 
                        (len(has_infos) == 1 and has_infos[0]['to'][-1] != 'default-domain')):
                        has_urls = [has_info['href'] for has_info in has_infos]
                        has_str = ', '.join(has_urls)
                        err_msg = 'Children ' + has_str + ' still exist'
                        self.config_object_error(id, None, 'config_root', 'http_delete', err_msg)
                        abort(409, err_msg)


                # Delete default children first
                parent_obj = ConfigRoot.factory(**read_result)
                self._config_root_delete_default_children(parent_obj)

                r_class.http_delete(id, read_result)
            #end if read_ok

        (ok, del_result) = \
             db_conn.dbe_delete('config-root', obj_ids)
        if not ok:
            self.config_object_error(id, None, 'config_root', 'http_delete', del_result)
            abort(409, del_result)

    #end config_root_http_delete
    def config_roots_http_post(self):
        key = 'config-root'
        obj_dict = request.json[key]
        # common handling for all resource create
        (ok, result) = self._post_common(request, 'config-root', obj_dict)
        if not ok:
            (code, msg) = result
            fq_name_str = ':'.join(obj_dict.get('fq_name', []))
            self.config_object_error(None, fq_name_str, 'config_root', 'http_post', msg)
            abort(code, msg)

        # Alloc and Store id-mappings before creating entry on pubsub store.
        # Else a subscriber can ask for an id mapping before we have stored it
        uuid_requested = result
        db_conn = self._db_conn
        (ok, result) = db_conn.dbe_alloc('config-root', obj_dict, uuid_requested)
        if not ok:
            fq_name_str = ':'.join(obj_dict['fq_name'])
            self.config_object_error(None, fq_name_str, 'config_root', 'http_post', result)
            abort(code, result)

        obj_ids = result

        name = obj_dict['fq_name'][-1]
        fq_name = obj_dict['fq_name']


        env = request.headers.environ
        tenant_name = env.get(hdr_server_tenant(), 'default-project')


        # type-specific hook
        r_class = self._resource_classes.get('config-root', None)
        if r_class:
            (ok, result) = r_class.http_post_collection(tenant_name, obj_dict)
            if not ok:
                (code, msg) = result
                fq_name_str = ':'.join(fq_name)
                self.config_object_error(None, fq_name_str, 'config_root', 'http_post', msg)
                abort(code, msg)

        # Validate perms
        objtype_list = eval("[u'global_system_config', u'domain']")
        for obj_type in objtype_list:
            refs = obj_dict.get('%s_refs'%(obj_type), None)
            if refs:
                for ref in refs:
                    ref_uuid = db_conn.fq_name_to_uuid(obj_type, ref['to'])
                    (ok, status) = self._permissions.check_perms_link(request, ref_uuid)
                    if not ok:
                        (code, err_msg) = status
                        abort(code, err_msg)

        (ok, result) = \
             db_conn.dbe_create('config-root', obj_ids, obj_dict)

        if not ok:
            fq_name_str = ':'.join(fq_name)
            self.config_object_error(None, fq_name_str, 'config_root', 'http_post', result)
            abort(404, result)

        rsp_body = {}
        rsp_body['name'] = name
        rsp_body['fq_name'] = fq_name
        rsp_body['uuid'] = obj_ids['uuid']
        rsp_body['href'] = self.generate_url('config-root', obj_ids['uuid'])

        parent_obj = ConfigRoot.factory(**rsp_body)
        self._config_root_create_default_children(parent_obj)

        return {'config-root': rsp_body} 
    #end config_roots_http_post

    def config_roots_http_get(self):
        env = request.headers.environ
        tenant_name = env.get(hdr_server_tenant(), 'default-project')
        parent_uuid = None
        resource_id = 'config_roots'
        if (('parent_fq_name_str' in request.query) and
            ('parent_type' in request.query)):
            parent_fq_name = request.query.parent_fq_name_str.split(':')
            parent_type = request.query.parent_type
            parent_uuid = self._db_conn.fq_name_to_uuid(parent_type, parent_fq_name)
        elif 'parent_id' in request.query:
            parent_uuid = str(uuid.UUID(request.query.parent_id))

        if parent_uuid:
            resource_id = parent_uuid

        # common handling for all resource get
        (ok, result) = self._get_common(request, parent_uuid)
        if not ok:
            (code, msg) = result
            self.config_object_error(None, None, 'config_roots', 'http_get_collection', msg)
            abort(code, msg)

        db_conn = self._db_conn
        (ok, result) = \
             db_conn.dbe_list('config-root', parent_uuid)

        if not ok:
            self.config_object_error(None, None, 'config_roots', 'http_get_collection', result)
            abort(404, result)

        fq_names = result
        obj_dicts = []
        for fq_name in fq_names:
            obj_dict = {}
            id = db_conn.fq_name_to_uuid('config_root', fq_name)
            obj_dict['uuid'] = id
            obj_dict['fq_name'] = fq_name
            obj_dict['href'] = self.generate_url('config-root', id)
            obj_dicts.append(obj_dict)

        return {'config-roots': obj_dicts} 
    #end config_roots_http_get

    def _config_root_create_default_children(self, parent_obj):
        # Create a default child only if provisioned for
        r_class = self._resource_classes.get('global-system-config', None)
        if r_class.generate_default_instance:
            child_obj = GlobalSystemConfig(parent_obj = parent_obj)
            child_dict = child_obj.__dict__
            fq_name = child_dict['fq_name']
            child_dict['id_perms'] = self._get_default_id_perms('global-system-config')

            db_conn = self._db_conn
            (ok, result) = db_conn.dbe_alloc('global-system-config', child_dict)
            if not ok:
                return (ok, result)

            obj_ids = result
            db_conn.dbe_create('global-system-config', obj_ids, child_dict)
            self._global_system_config_create_default_children(child_obj)

        # Create a default child only if provisioned for
        r_class = self._resource_classes.get('domain', None)
        if r_class.generate_default_instance:
            child_obj = Domain(parent_obj = parent_obj)
            child_dict = child_obj.__dict__
            fq_name = child_dict['fq_name']
            child_dict['id_perms'] = self._get_default_id_perms('domain')

            db_conn = self._db_conn
            (ok, result) = db_conn.dbe_alloc('domain', child_dict)
            if not ok:
                return (ok, result)

            obj_ids = result
            db_conn.dbe_create('domain', obj_ids, child_dict)
            self._domain_create_default_children(child_obj)

        pass
    #end _config_root_create_default_children

    def _config_root_delete_default_children(self, parent_obj):
        # Delete a default child only if provisioned for
        r_class = self._resource_classes.get('domain', None)
        if r_class.generate_default_instance:
            # first locate default child then delete it
            has_infos = parent_obj.get_global_system_configs()
            if has_infos:
                for has_info in has_infos:
                    if has_info['to'][-1] == 'default-global-system-config':
                        default_child_id = has_info['href'].split('/')[-1]
                        self.global_system_config_http_delete(default_child_id)
                        break

        # Delete a default child only if provisioned for
        r_class = self._resource_classes.get('domain', None)
        if r_class.generate_default_instance:
            # first locate default child then delete it
            has_infos = parent_obj.get_domains()
            if has_infos:
                for has_info in has_infos:
                    if has_info['to'][-1] == 'default-domain':
                        default_child_id = has_info['href'].split('/')[-1]
                        self.domain_http_delete(default_child_id)
                        break

        pass
    #end _config_root_delete_default_children

    def global_system_config_http_get(self, id):
        # TODO get vals from request out of the global ASAP
        etag = request.headers.get('If-None-Match')
        # common handling for all resource get
        (ok, result) = self._get_common(request, id)
        if not ok:
            (code, msg) = result
            self.config_object_error(id, None, 'global_system_config', 'http_get', msg)
            abort(code, msg)

        # type-specific hook
        r_class = self._resource_classes.get('global-system-config', None)
        if r_class:
            r_class.http_get(id)

        db_conn = self._db_conn
        if etag:
            obj_ids = {'uuid': id}
            (ok, result) = db_conn.dbe_is_latest(obj_ids, etag.replace('"', ''))
            if not ok:
                # Not present in DB
                self.config_object_error(id, None, 'global_system_config', 'http_get', result)
                abort(404, result)

            is_latest = result
            if is_latest:
                # send Not-Modified, caches use this for read optimization
                response.status = 304
                return
        #end if etag

        obj_ids = {'uuid': id}
        if 'fields' in request.query:
            obj_fields = request.query.fields.split(',')
        else:
            obj_fields = None
        (ok, result) = db_conn.dbe_read('global-system-config', obj_ids, obj_fields)
        if not ok:
            # Not present in DB
            self.config_object_error(id, None, 'global_system_config', 'http_get', result)
            abort(404, result)

        rsp_body = {}
        rsp_body['uuid'] = id
        rsp_body['href'] = self.generate_url('global-system-config', id)
        rsp_body['name'] = result['fq_name'][-1]
        rsp_body.update(result)
        id_perms = result['id_perms']
        response.set_header('ETag', '"' + id_perms['last_modified'] + '"')
        return {'global-system-config': rsp_body} 
    #end global_system_config_http_get

    def global_system_config_http_put(self, id):
        key = 'global-system-config'
        obj_dict = request.json[key]
        # common handling for all resource put
        (ok, result) = self._put_common(request, 'global_system_config', obj_dict, id)
        if not ok:
            (code, msg) = result
            self.config_object_error(id, None, 'global_system_config', 'http_put', msg)
            abort(code, msg)

        # type-specific hook
        r_class = self._resource_classes.get('global-system-config', None)
        if r_class:
            (ok, msg) = r_class.http_put(id, obj_dict)
            if not ok:
                self.config_object_error(id, None, 'global_system_config', 'http_put', msg)
                abort(409, msg)

        db_conn = self._db_conn

        # Validate perms
        objtype_list = eval("['bgp_router', u'physical_router', u'virtual_router']")
        for obj_type in objtype_list:
            refs = obj_dict.get('%s_refs'%(obj_type), None)
            if refs:
                for ref in refs:
                    ref_uuid = db_conn.fq_name_to_uuid(obj_type, ref['to'])
                    (ok, status) = self._permissions.check_perms_link(request, ref_uuid)
                    if not ok:
                        (code, err_msg) = status
                        abort(code, err_msg)

        obj_ids = {'uuid': id}
        (ok, result) = \
             db_conn.dbe_update('global-system-config', obj_ids, obj_dict)
        if not ok:
            self.config_object_error(id, None, 'global_system_config', 'http_put', result)
            abort(404, result)

        rsp_body = {}
        rsp_body['uuid'] = id
        rsp_body['href'] = self.generate_url('global-system-config', id)
        return {'global-system-config': rsp_body} 
    #end global_system_config_http_put

    def global_system_config_http_delete(self, id):
        db_conn = self._db_conn
        # read in obj from db (accepting error) to get details of it
        obj_ids = {'uuid': id}
        (read_ok, read_result) = db_conn.dbe_read('global-system-config', obj_ids)
        if not read_ok:
            self.config_object_error(id, None, 'global_system_config', 'http_delete', read_result)
            # proceed down to delete the resource

        # common handling for all resource delete
        parent_type = read_result.get('parent_type', None)
        (ok, del_result) = self._delete_common(request, 'global_system_config', id, parent_type)
        if not ok:
            (code, msg) = del_result
            self.config_object_error(id, None, 'global_system_config', 'http_delete', msg)
            abort(code, msg)

        fq_name = read_result['fq_name']
        ifmap_id = common.imid.get_ifmap_id_from_fq_name('global-system-config', fq_name)
        obj_ids['imid'] = ifmap_id
        if parent_type:
            parent_imid = common.imid.get_ifmap_id_from_fq_name(parent_type, fq_name[:-1])
            obj_ids['parent_imid'] = parent_imid

        # type-specific hook
        r_class = self._resource_classes.get('global-system-config', None)
        if r_class:
            if read_ok:
                # fail if non-default children or backrefs exist
                physical_routers = read_result.get('physical_routers', None)
                if physical_routers:
                    has_infos = read_result['physical_routers']
                    if ((len(has_infos) > 1) or 
                        (len(has_infos) == 1 and has_infos[0]['to'][-1] != 'default-physical-router')):
                        has_urls = [has_info['href'] for has_info in has_infos]
                        has_str = ', '.join(has_urls)
                        err_msg = 'Children ' + has_str + ' still exist'
                        self.config_object_error(id, None, 'global_system_config', 'http_delete', err_msg)
                        abort(409, err_msg)

                virtual_routers = read_result.get('virtual_routers', None)
                if virtual_routers:
                    has_infos = read_result['virtual_routers']
                    if ((len(has_infos) > 1) or 
                        (len(has_infos) == 1 and has_infos[0]['to'][-1] != 'default-virtual-router')):
                        has_urls = [has_info['href'] for has_info in has_infos]
                        has_str = ', '.join(has_urls)
                        err_msg = 'Children ' + has_str + ' still exist'
                        self.config_object_error(id, None, 'global_system_config', 'http_delete', err_msg)
                        abort(409, err_msg)


                # Delete default children first
                parent_obj = GlobalSystemConfig.factory(**read_result)
                self._global_system_config_delete_default_children(parent_obj)

                r_class.http_delete(id, read_result)
            #end if read_ok

        (ok, del_result) = \
             db_conn.dbe_delete('global-system-config', obj_ids)
        if not ok:
            self.config_object_error(id, None, 'global_system_config', 'http_delete', del_result)
            abort(409, del_result)

    #end global_system_config_http_delete
    def global_system_configs_http_post(self):
        key = 'global-system-config'
        obj_dict = request.json[key]
        # common handling for all resource create
        (ok, result) = self._post_common(request, 'global-system-config', obj_dict)
        if not ok:
            (code, msg) = result
            fq_name_str = ':'.join(obj_dict.get('fq_name', []))
            self.config_object_error(None, fq_name_str, 'global_system_config', 'http_post', msg)
            abort(code, msg)

        # Alloc and Store id-mappings before creating entry on pubsub store.
        # Else a subscriber can ask for an id mapping before we have stored it
        uuid_requested = result
        db_conn = self._db_conn
        (ok, result) = db_conn.dbe_alloc('global-system-config', obj_dict, uuid_requested)
        if not ok:
            fq_name_str = ':'.join(obj_dict['fq_name'])
            self.config_object_error(None, fq_name_str, 'global_system_config', 'http_post', result)
            abort(code, result)

        obj_ids = result

        name = obj_dict['fq_name'][-1]
        fq_name = obj_dict['fq_name']


        if 'parent_type' in obj_dict:
            # non config-root child, verify parent exists
            parent_type = obj_dict['parent_type']
            parent_fq_name = obj_dict['fq_name'][:-1]
            try:
                parent_uuid = self._db_conn.fq_name_to_uuid(parent_type, parent_fq_name)
                (ok, status) = self._permissions.check_perms_write(request, parent_uuid)
                if not ok:
                    (code, err_msg) = status
                    abort(code, err_msg)
                self._permissions.set_user_role(request, obj_dict)
            except NoIdError:
                err_msg = 'Parent ' + pformat(parent_fq_name) + ' type ' + parent_type + ' does not exist'
                fq_name_str = ':'.join(parent_fq_name)
                self.config_object_error(None, fq_name_str, 'global_system_config', 'http_post', err_msg)
                abort(400, err_msg)

        env = request.headers.environ
        tenant_name = env.get(hdr_server_tenant(), 'default-project')


        # type-specific hook
        r_class = self._resource_classes.get('global-system-config', None)
        if r_class:
            (ok, result) = r_class.http_post_collection(tenant_name, obj_dict)
            if not ok:
                (code, msg) = result
                fq_name_str = ':'.join(fq_name)
                self.config_object_error(None, fq_name_str, 'global_system_config', 'http_post', msg)
                abort(code, msg)

        # Validate perms
        objtype_list = eval("['bgp_router', u'physical_router', u'virtual_router']")
        for obj_type in objtype_list:
            refs = obj_dict.get('%s_refs'%(obj_type), None)
            if refs:
                for ref in refs:
                    ref_uuid = db_conn.fq_name_to_uuid(obj_type, ref['to'])
                    (ok, status) = self._permissions.check_perms_link(request, ref_uuid)
                    if not ok:
                        (code, err_msg) = status
                        abort(code, err_msg)

        (ok, result) = \
             db_conn.dbe_create('global-system-config', obj_ids, obj_dict)

        if not ok:
            fq_name_str = ':'.join(fq_name)
            self.config_object_error(None, fq_name_str, 'global_system_config', 'http_post', result)
            abort(404, result)

        rsp_body = {}
        rsp_body['name'] = name
        rsp_body['fq_name'] = fq_name
        rsp_body['uuid'] = obj_ids['uuid']
        rsp_body['href'] = self.generate_url('global-system-config', obj_ids['uuid'])
        if 'parent_type' in obj_dict:
            # non config-root child, send back parent uuid/href
            rsp_body['parent_uuid'] = parent_uuid
            rsp_body['parent_href'] = self.generate_url(parent_type, parent_uuid)

        parent_obj = GlobalSystemConfig.factory(**rsp_body)
        self._global_system_config_create_default_children(parent_obj)

        return {'global-system-config': rsp_body} 
    #end global_system_configs_http_post

    def global_system_configs_http_get(self):
        env = request.headers.environ
        tenant_name = env.get(hdr_server_tenant(), 'default-project')
        parent_uuid = None
        resource_id = 'global_system_configs'
        if (('parent_fq_name_str' in request.query) and
            ('parent_type' in request.query)):
            parent_fq_name = request.query.parent_fq_name_str.split(':')
            parent_type = request.query.parent_type
            parent_uuid = self._db_conn.fq_name_to_uuid(parent_type, parent_fq_name)
        elif 'parent_id' in request.query:
            parent_uuid = str(uuid.UUID(request.query.parent_id))

        if parent_uuid:
            resource_id = parent_uuid

        # common handling for all resource get
        (ok, result) = self._get_common(request, parent_uuid)
        if not ok:
            (code, msg) = result
            self.config_object_error(None, None, 'global_system_configs', 'http_get_collection', msg)
            abort(code, msg)

        db_conn = self._db_conn
        (ok, result) = \
             db_conn.dbe_list('global-system-config', parent_uuid)

        if not ok:
            self.config_object_error(None, None, 'global_system_configs', 'http_get_collection', result)
            abort(404, result)

        fq_names = result
        obj_dicts = []
        for fq_name in fq_names:
            obj_dict = {}
            id = db_conn.fq_name_to_uuid('global_system_config', fq_name)
            obj_dict['uuid'] = id
            obj_dict['fq_name'] = fq_name
            obj_dict['href'] = self.generate_url('global-system-config', id)
            obj_dicts.append(obj_dict)

        return {'global-system-configs': obj_dicts} 
    #end global_system_configs_http_get

    def _global_system_config_create_default_children(self, parent_obj):
        # Create a default child only if provisioned for
        r_class = self._resource_classes.get('physical-router', None)
        if r_class.generate_default_instance:
            child_obj = PhysicalRouter(parent_obj = parent_obj)
            child_dict = child_obj.__dict__
            fq_name = child_dict['fq_name']
            child_dict['id_perms'] = self._get_default_id_perms('physical-router')

            db_conn = self._db_conn
            (ok, result) = db_conn.dbe_alloc('physical-router', child_dict)
            if not ok:
                return (ok, result)

            obj_ids = result
            db_conn.dbe_create('physical-router', obj_ids, child_dict)
            self._physical_router_create_default_children(child_obj)

        # Create a default child only if provisioned for
        r_class = self._resource_classes.get('virtual-router', None)
        if r_class.generate_default_instance:
            child_obj = VirtualRouter(parent_obj = parent_obj)
            child_dict = child_obj.__dict__
            fq_name = child_dict['fq_name']
            child_dict['id_perms'] = self._get_default_id_perms('virtual-router')

            db_conn = self._db_conn
            (ok, result) = db_conn.dbe_alloc('virtual-router', child_dict)
            if not ok:
                return (ok, result)

            obj_ids = result
            db_conn.dbe_create('virtual-router', obj_ids, child_dict)
            self._virtual_router_create_default_children(child_obj)

        pass
    #end _global_system_config_create_default_children

    def _global_system_config_delete_default_children(self, parent_obj):
        # Delete a default child only if provisioned for
        r_class = self._resource_classes.get('virtual-router', None)
        if r_class.generate_default_instance:
            # first locate default child then delete it
            has_infos = parent_obj.get_physical_routers()
            if has_infos:
                for has_info in has_infos:
                    if has_info['to'][-1] == 'default-physical-router':
                        default_child_id = has_info['href'].split('/')[-1]
                        self.physical_router_http_delete(default_child_id)
                        break

        # Delete a default child only if provisioned for
        r_class = self._resource_classes.get('virtual-router', None)
        if r_class.generate_default_instance:
            # first locate default child then delete it
            has_infos = parent_obj.get_virtual_routers()
            if has_infos:
                for has_info in has_infos:
                    if has_info['to'][-1] == 'default-virtual-router':
                        default_child_id = has_info['href'].split('/')[-1]
                        self.virtual_router_http_delete(default_child_id)
                        break

        pass
    #end _global_system_config_delete_default_children

    def namespace_http_get(self, id):
        # TODO get vals from request out of the global ASAP
        etag = request.headers.get('If-None-Match')
        # common handling for all resource get
        (ok, result) = self._get_common(request, id)
        if not ok:
            (code, msg) = result
            self.config_object_error(id, None, 'namespace', 'http_get', msg)
            abort(code, msg)

        # type-specific hook
        r_class = self._resource_classes.get('namespace', None)
        if r_class:
            r_class.http_get(id)

        db_conn = self._db_conn
        if etag:
            obj_ids = {'uuid': id}
            (ok, result) = db_conn.dbe_is_latest(obj_ids, etag.replace('"', ''))
            if not ok:
                # Not present in DB
                self.config_object_error(id, None, 'namespace', 'http_get', result)
                abort(404, result)

            is_latest = result
            if is_latest:
                # send Not-Modified, caches use this for read optimization
                response.status = 304
                return
        #end if etag

        obj_ids = {'uuid': id}
        if 'fields' in request.query:
            obj_fields = request.query.fields.split(',')
        else:
            obj_fields = None
        (ok, result) = db_conn.dbe_read('namespace', obj_ids, obj_fields)
        if not ok:
            # Not present in DB
            self.config_object_error(id, None, 'namespace', 'http_get', result)
            abort(404, result)

        rsp_body = {}
        rsp_body['uuid'] = id
        rsp_body['href'] = self.generate_url('namespace', id)
        rsp_body['name'] = result['fq_name'][-1]
        rsp_body.update(result)
        id_perms = result['id_perms']
        response.set_header('ETag', '"' + id_perms['last_modified'] + '"')
        return {'namespace': rsp_body} 
    #end namespace_http_get

    def namespace_http_put(self, id):
        key = 'namespace'
        obj_dict = request.json[key]
        # common handling for all resource put
        (ok, result) = self._put_common(request, 'namespace', obj_dict, id)
        if not ok:
            (code, msg) = result
            self.config_object_error(id, None, 'namespace', 'http_put', msg)
            abort(code, msg)

        # type-specific hook
        r_class = self._resource_classes.get('namespace', None)
        if r_class:
            (ok, msg) = r_class.http_put(id, obj_dict)
            if not ok:
                self.config_object_error(id, None, 'namespace', 'http_put', msg)
                abort(409, msg)

        db_conn = self._db_conn


        obj_ids = {'uuid': id}
        (ok, result) = \
             db_conn.dbe_update('namespace', obj_ids, obj_dict)
        if not ok:
            self.config_object_error(id, None, 'namespace', 'http_put', result)
            abort(404, result)

        rsp_body = {}
        rsp_body['uuid'] = id
        rsp_body['href'] = self.generate_url('namespace', id)
        return {'namespace': rsp_body} 
    #end namespace_http_put

    def namespace_http_delete(self, id):
        db_conn = self._db_conn
        # read in obj from db (accepting error) to get details of it
        obj_ids = {'uuid': id}
        (read_ok, read_result) = db_conn.dbe_read('namespace', obj_ids)
        if not read_ok:
            self.config_object_error(id, None, 'namespace', 'http_delete', read_result)
            # proceed down to delete the resource

        # common handling for all resource delete
        parent_type = read_result.get('parent_type', None)
        (ok, del_result) = self._delete_common(request, 'namespace', id, parent_type)
        if not ok:
            (code, msg) = del_result
            self.config_object_error(id, None, 'namespace', 'http_delete', msg)
            abort(code, msg)

        fq_name = read_result['fq_name']
        ifmap_id = common.imid.get_ifmap_id_from_fq_name('namespace', fq_name)
        obj_ids['imid'] = ifmap_id
        if parent_type:
            parent_imid = common.imid.get_ifmap_id_from_fq_name(parent_type, fq_name[:-1])
            obj_ids['parent_imid'] = parent_imid

        # type-specific hook
        r_class = self._resource_classes.get('namespace', None)
        if r_class:
            if read_ok:
                # fail if non-default children or backrefs exist
                project_back_refs = read_result.get('project_back_refs', None)
                if project_back_refs:
                    back_ref_urls = [back_ref_info['href'] for back_ref_info in read_result['project_back_refs']]
                    back_ref_str = ', '.join(back_ref_urls)
                    err_msg = 'Back-References from ' + back_ref_str + ' still exist'
                    self.config_object_error(id, None, 'namespace', 'http_delete', err_msg)
                    abort(409, err_msg)


                # Delete default children first
                parent_obj = Namespace.factory(**read_result)
                self._namespace_delete_default_children(parent_obj)

                r_class.http_delete(id, read_result)
            #end if read_ok

        (ok, del_result) = \
             db_conn.dbe_delete('namespace', obj_ids)
        if not ok:
            self.config_object_error(id, None, 'namespace', 'http_delete', del_result)
            abort(409, del_result)

    #end namespace_http_delete
    def namespaces_http_post(self):
        key = 'namespace'
        obj_dict = request.json[key]
        # common handling for all resource create
        (ok, result) = self._post_common(request, 'namespace', obj_dict)
        if not ok:
            (code, msg) = result
            fq_name_str = ':'.join(obj_dict.get('fq_name', []))
            self.config_object_error(None, fq_name_str, 'namespace', 'http_post', msg)
            abort(code, msg)

        # Alloc and Store id-mappings before creating entry on pubsub store.
        # Else a subscriber can ask for an id mapping before we have stored it
        uuid_requested = result
        db_conn = self._db_conn
        (ok, result) = db_conn.dbe_alloc('namespace', obj_dict, uuid_requested)
        if not ok:
            fq_name_str = ':'.join(obj_dict['fq_name'])
            self.config_object_error(None, fq_name_str, 'namespace', 'http_post', result)
            abort(code, result)

        obj_ids = result

        name = obj_dict['fq_name'][-1]
        fq_name = obj_dict['fq_name']


        if 'parent_type' in obj_dict:
            # non config-root child, verify parent exists
            parent_type = obj_dict['parent_type']
            parent_fq_name = obj_dict['fq_name'][:-1]
            try:
                parent_uuid = self._db_conn.fq_name_to_uuid(parent_type, parent_fq_name)
                (ok, status) = self._permissions.check_perms_write(request, parent_uuid)
                if not ok:
                    (code, err_msg) = status
                    abort(code, err_msg)
                self._permissions.set_user_role(request, obj_dict)
            except NoIdError:
                err_msg = 'Parent ' + pformat(parent_fq_name) + ' type ' + parent_type + ' does not exist'
                fq_name_str = ':'.join(parent_fq_name)
                self.config_object_error(None, fq_name_str, 'namespace', 'http_post', err_msg)
                abort(400, err_msg)

        env = request.headers.environ
        tenant_name = env.get(hdr_server_tenant(), 'default-project')


        # type-specific hook
        r_class = self._resource_classes.get('namespace', None)
        if r_class:
            (ok, result) = r_class.http_post_collection(tenant_name, obj_dict)
            if not ok:
                (code, msg) = result
                fq_name_str = ':'.join(fq_name)
                self.config_object_error(None, fq_name_str, 'namespace', 'http_post', msg)
                abort(code, msg)


        (ok, result) = \
             db_conn.dbe_create('namespace', obj_ids, obj_dict)

        if not ok:
            fq_name_str = ':'.join(fq_name)
            self.config_object_error(None, fq_name_str, 'namespace', 'http_post', result)
            abort(404, result)

        rsp_body = {}
        rsp_body['name'] = name
        rsp_body['fq_name'] = fq_name
        rsp_body['uuid'] = obj_ids['uuid']
        rsp_body['href'] = self.generate_url('namespace', obj_ids['uuid'])
        if 'parent_type' in obj_dict:
            # non config-root child, send back parent uuid/href
            rsp_body['parent_uuid'] = parent_uuid
            rsp_body['parent_href'] = self.generate_url(parent_type, parent_uuid)

        parent_obj = Namespace.factory(**rsp_body)
        self._namespace_create_default_children(parent_obj)

        return {'namespace': rsp_body} 
    #end namespaces_http_post

    def namespaces_http_get(self):
        env = request.headers.environ
        tenant_name = env.get(hdr_server_tenant(), 'default-project')
        parent_uuid = None
        resource_id = 'namespaces'
        if (('parent_fq_name_str' in request.query) and
            ('parent_type' in request.query)):
            parent_fq_name = request.query.parent_fq_name_str.split(':')
            parent_type = request.query.parent_type
            parent_uuid = self._db_conn.fq_name_to_uuid(parent_type, parent_fq_name)
        elif 'parent_id' in request.query:
            parent_uuid = str(uuid.UUID(request.query.parent_id))

        if parent_uuid:
            resource_id = parent_uuid

        # common handling for all resource get
        (ok, result) = self._get_common(request, parent_uuid)
        if not ok:
            (code, msg) = result
            self.config_object_error(None, None, 'namespaces', 'http_get_collection', msg)
            abort(code, msg)

        db_conn = self._db_conn
        (ok, result) = \
             db_conn.dbe_list('namespace', parent_uuid)

        if not ok:
            self.config_object_error(None, None, 'namespaces', 'http_get_collection', result)
            abort(404, result)

        fq_names = result
        obj_dicts = []
        for fq_name in fq_names:
            obj_dict = {}
            id = db_conn.fq_name_to_uuid('namespace', fq_name)
            obj_dict['uuid'] = id
            obj_dict['fq_name'] = fq_name
            obj_dict['href'] = self.generate_url('namespace', id)
            obj_dicts.append(obj_dict)

        return {'namespaces': obj_dicts} 
    #end namespaces_http_get

    def _namespace_create_default_children(self, parent_obj):
        pass
    #end _namespace_create_default_children

    def _namespace_delete_default_children(self, parent_obj):
        pass
    #end _namespace_delete_default_children

    def physical_interface_http_get(self, id):
        # TODO get vals from request out of the global ASAP
        etag = request.headers.get('If-None-Match')
        # common handling for all resource get
        (ok, result) = self._get_common(request, id)
        if not ok:
            (code, msg) = result
            self.config_object_error(id, None, 'physical_interface', 'http_get', msg)
            abort(code, msg)

        # type-specific hook
        r_class = self._resource_classes.get('physical-interface', None)
        if r_class:
            r_class.http_get(id)

        db_conn = self._db_conn
        if etag:
            obj_ids = {'uuid': id}
            (ok, result) = db_conn.dbe_is_latest(obj_ids, etag.replace('"', ''))
            if not ok:
                # Not present in DB
                self.config_object_error(id, None, 'physical_interface', 'http_get', result)
                abort(404, result)

            is_latest = result
            if is_latest:
                # send Not-Modified, caches use this for read optimization
                response.status = 304
                return
        #end if etag

        obj_ids = {'uuid': id}
        if 'fields' in request.query:
            obj_fields = request.query.fields.split(',')
        else:
            obj_fields = None
        (ok, result) = db_conn.dbe_read('physical-interface', obj_ids, obj_fields)
        if not ok:
            # Not present in DB
            self.config_object_error(id, None, 'physical_interface', 'http_get', result)
            abort(404, result)

        rsp_body = {}
        rsp_body['uuid'] = id
        rsp_body['href'] = self.generate_url('physical-interface', id)
        rsp_body['name'] = result['fq_name'][-1]
        rsp_body.update(result)
        id_perms = result['id_perms']
        response.set_header('ETag', '"' + id_perms['last_modified'] + '"')
        return {'physical-interface': rsp_body} 
    #end physical_interface_http_get

    def physical_interface_http_put(self, id):
        key = 'physical-interface'
        obj_dict = request.json[key]
        # common handling for all resource put
        (ok, result) = self._put_common(request, 'physical_interface', obj_dict, id)
        if not ok:
            (code, msg) = result
            self.config_object_error(id, None, 'physical_interface', 'http_put', msg)
            abort(code, msg)

        # type-specific hook
        r_class = self._resource_classes.get('physical-interface', None)
        if r_class:
            (ok, msg) = r_class.http_put(id, obj_dict)
            if not ok:
                self.config_object_error(id, None, 'physical_interface', 'http_put', msg)
                abort(409, msg)

        db_conn = self._db_conn

        # Validate perms
        objtype_list = eval("[u'logical_interface']")
        for obj_type in objtype_list:
            refs = obj_dict.get('%s_refs'%(obj_type), None)
            if refs:
                for ref in refs:
                    ref_uuid = db_conn.fq_name_to_uuid(obj_type, ref['to'])
                    (ok, status) = self._permissions.check_perms_link(request, ref_uuid)
                    if not ok:
                        (code, err_msg) = status
                        abort(code, err_msg)

        obj_ids = {'uuid': id}
        (ok, result) = \
             db_conn.dbe_update('physical-interface', obj_ids, obj_dict)
        if not ok:
            self.config_object_error(id, None, 'physical_interface', 'http_put', result)
            abort(404, result)

        rsp_body = {}
        rsp_body['uuid'] = id
        rsp_body['href'] = self.generate_url('physical-interface', id)
        return {'physical-interface': rsp_body} 
    #end physical_interface_http_put

    def physical_interface_http_delete(self, id):
        db_conn = self._db_conn
        # read in obj from db (accepting error) to get details of it
        obj_ids = {'uuid': id}
        (read_ok, read_result) = db_conn.dbe_read('physical-interface', obj_ids)
        if not read_ok:
            self.config_object_error(id, None, 'physical_interface', 'http_delete', read_result)
            # proceed down to delete the resource

        # common handling for all resource delete
        parent_type = read_result.get('parent_type', None)
        (ok, del_result) = self._delete_common(request, 'physical_interface', id, parent_type)
        if not ok:
            (code, msg) = del_result
            self.config_object_error(id, None, 'physical_interface', 'http_delete', msg)
            abort(code, msg)

        fq_name = read_result['fq_name']
        ifmap_id = common.imid.get_ifmap_id_from_fq_name('physical-interface', fq_name)
        obj_ids['imid'] = ifmap_id
        if parent_type:
            parent_imid = common.imid.get_ifmap_id_from_fq_name(parent_type, fq_name[:-1])
            obj_ids['parent_imid'] = parent_imid

        # type-specific hook
        r_class = self._resource_classes.get('physical-interface', None)
        if r_class:
            if read_ok:
                # fail if non-default children or backrefs exist
                logical_interfaces = read_result.get('logical_interfaces', None)
                if logical_interfaces:
                    has_infos = read_result['logical_interfaces']
                    if ((len(has_infos) > 1) or 
                        (len(has_infos) == 1 and has_infos[0]['to'][-1] != 'default-logical-interface')):
                        has_urls = [has_info['href'] for has_info in has_infos]
                        has_str = ', '.join(has_urls)
                        err_msg = 'Children ' + has_str + ' still exist'
                        self.config_object_error(id, None, 'physical_interface', 'http_delete', err_msg)
                        abort(409, err_msg)


                # Delete default children first
                parent_obj = PhysicalInterface.factory(**read_result)
                self._physical_interface_delete_default_children(parent_obj)

                r_class.http_delete(id, read_result)
            #end if read_ok

        (ok, del_result) = \
             db_conn.dbe_delete('physical-interface', obj_ids)
        if not ok:
            self.config_object_error(id, None, 'physical_interface', 'http_delete', del_result)
            abort(409, del_result)

    #end physical_interface_http_delete
    def physical_interfaces_http_post(self):
        key = 'physical-interface'
        obj_dict = request.json[key]
        # common handling for all resource create
        (ok, result) = self._post_common(request, 'physical-interface', obj_dict)
        if not ok:
            (code, msg) = result
            fq_name_str = ':'.join(obj_dict.get('fq_name', []))
            self.config_object_error(None, fq_name_str, 'physical_interface', 'http_post', msg)
            abort(code, msg)

        # Alloc and Store id-mappings before creating entry on pubsub store.
        # Else a subscriber can ask for an id mapping before we have stored it
        uuid_requested = result
        db_conn = self._db_conn
        (ok, result) = db_conn.dbe_alloc('physical-interface', obj_dict, uuid_requested)
        if not ok:
            fq_name_str = ':'.join(obj_dict['fq_name'])
            self.config_object_error(None, fq_name_str, 'physical_interface', 'http_post', result)
            abort(code, result)

        obj_ids = result

        name = obj_dict['fq_name'][-1]
        fq_name = obj_dict['fq_name']


        if 'parent_type' in obj_dict:
            # non config-root child, verify parent exists
            parent_type = obj_dict['parent_type']
            parent_fq_name = obj_dict['fq_name'][:-1]
            try:
                parent_uuid = self._db_conn.fq_name_to_uuid(parent_type, parent_fq_name)
                (ok, status) = self._permissions.check_perms_write(request, parent_uuid)
                if not ok:
                    (code, err_msg) = status
                    abort(code, err_msg)
                self._permissions.set_user_role(request, obj_dict)
            except NoIdError:
                err_msg = 'Parent ' + pformat(parent_fq_name) + ' type ' + parent_type + ' does not exist'
                fq_name_str = ':'.join(parent_fq_name)
                self.config_object_error(None, fq_name_str, 'physical_interface', 'http_post', err_msg)
                abort(400, err_msg)

        env = request.headers.environ
        tenant_name = env.get(hdr_server_tenant(), 'default-project')


        # type-specific hook
        r_class = self._resource_classes.get('physical-interface', None)
        if r_class:
            (ok, result) = r_class.http_post_collection(tenant_name, obj_dict)
            if not ok:
                (code, msg) = result
                fq_name_str = ':'.join(fq_name)
                self.config_object_error(None, fq_name_str, 'physical_interface', 'http_post', msg)
                abort(code, msg)

        # Validate perms
        objtype_list = eval("[u'logical_interface']")
        for obj_type in objtype_list:
            refs = obj_dict.get('%s_refs'%(obj_type), None)
            if refs:
                for ref in refs:
                    ref_uuid = db_conn.fq_name_to_uuid(obj_type, ref['to'])
                    (ok, status) = self._permissions.check_perms_link(request, ref_uuid)
                    if not ok:
                        (code, err_msg) = status
                        abort(code, err_msg)

        (ok, result) = \
             db_conn.dbe_create('physical-interface', obj_ids, obj_dict)

        if not ok:
            fq_name_str = ':'.join(fq_name)
            self.config_object_error(None, fq_name_str, 'physical_interface', 'http_post', result)
            abort(404, result)

        rsp_body = {}
        rsp_body['name'] = name
        rsp_body['fq_name'] = fq_name
        rsp_body['uuid'] = obj_ids['uuid']
        rsp_body['href'] = self.generate_url('physical-interface', obj_ids['uuid'])
        if 'parent_type' in obj_dict:
            # non config-root child, send back parent uuid/href
            rsp_body['parent_uuid'] = parent_uuid
            rsp_body['parent_href'] = self.generate_url(parent_type, parent_uuid)

        parent_obj = PhysicalInterface.factory(**rsp_body)
        self._physical_interface_create_default_children(parent_obj)

        return {'physical-interface': rsp_body} 
    #end physical_interfaces_http_post

    def physical_interfaces_http_get(self):
        env = request.headers.environ
        tenant_name = env.get(hdr_server_tenant(), 'default-project')
        parent_uuid = None
        resource_id = 'physical_interfaces'
        if (('parent_fq_name_str' in request.query) and
            ('parent_type' in request.query)):
            parent_fq_name = request.query.parent_fq_name_str.split(':')
            parent_type = request.query.parent_type
            parent_uuid = self._db_conn.fq_name_to_uuid(parent_type, parent_fq_name)
        elif 'parent_id' in request.query:
            parent_uuid = str(uuid.UUID(request.query.parent_id))

        if parent_uuid:
            resource_id = parent_uuid

        # common handling for all resource get
        (ok, result) = self._get_common(request, parent_uuid)
        if not ok:
            (code, msg) = result
            self.config_object_error(None, None, 'physical_interfaces', 'http_get_collection', msg)
            abort(code, msg)

        db_conn = self._db_conn
        (ok, result) = \
             db_conn.dbe_list('physical-interface', parent_uuid)

        if not ok:
            self.config_object_error(None, None, 'physical_interfaces', 'http_get_collection', result)
            abort(404, result)

        fq_names = result
        obj_dicts = []
        for fq_name in fq_names:
            obj_dict = {}
            id = db_conn.fq_name_to_uuid('physical_interface', fq_name)
            obj_dict['uuid'] = id
            obj_dict['fq_name'] = fq_name
            obj_dict['href'] = self.generate_url('physical-interface', id)
            obj_dicts.append(obj_dict)

        return {'physical-interfaces': obj_dicts} 
    #end physical_interfaces_http_get

    def _physical_interface_create_default_children(self, parent_obj):
        # Create a default child only if provisioned for
        r_class = self._resource_classes.get('logical-interface', None)
        if r_class.generate_default_instance:
            child_obj = LogicalInterface(parent_obj = parent_obj)
            child_dict = child_obj.__dict__
            fq_name = child_dict['fq_name']
            child_dict['id_perms'] = self._get_default_id_perms('logical-interface')

            db_conn = self._db_conn
            (ok, result) = db_conn.dbe_alloc('logical-interface', child_dict)
            if not ok:
                return (ok, result)

            obj_ids = result
            db_conn.dbe_create('logical-interface', obj_ids, child_dict)
            self._logical_interface_create_default_children(child_obj)

        pass
    #end _physical_interface_create_default_children

    def _physical_interface_delete_default_children(self, parent_obj):
        # Delete a default child only if provisioned for
        r_class = self._resource_classes.get('logical-interface', None)
        if r_class.generate_default_instance:
            # first locate default child then delete it
            has_infos = parent_obj.get_logical_interfaces()
            if has_infos:
                for has_info in has_infos:
                    if has_info['to'][-1] == 'default-logical-interface':
                        default_child_id = has_info['href'].split('/')[-1]
                        self.logical_interface_http_delete(default_child_id)
                        break

        pass
    #end _physical_interface_delete_default_children

    def access_control_list_http_get(self, id):
        # TODO get vals from request out of the global ASAP
        etag = request.headers.get('If-None-Match')
        # common handling for all resource get
        (ok, result) = self._get_common(request, id)
        if not ok:
            (code, msg) = result
            self.config_object_error(id, None, 'access_control_list', 'http_get', msg)
            abort(code, msg)

        # type-specific hook
        r_class = self._resource_classes.get('access-control-list', None)
        if r_class:
            r_class.http_get(id)

        db_conn = self._db_conn
        if etag:
            obj_ids = {'uuid': id}
            (ok, result) = db_conn.dbe_is_latest(obj_ids, etag.replace('"', ''))
            if not ok:
                # Not present in DB
                self.config_object_error(id, None, 'access_control_list', 'http_get', result)
                abort(404, result)

            is_latest = result
            if is_latest:
                # send Not-Modified, caches use this for read optimization
                response.status = 304
                return
        #end if etag

        obj_ids = {'uuid': id}
        if 'fields' in request.query:
            obj_fields = request.query.fields.split(',')
        else:
            obj_fields = None
        (ok, result) = db_conn.dbe_read('access-control-list', obj_ids, obj_fields)
        if not ok:
            # Not present in DB
            self.config_object_error(id, None, 'access_control_list', 'http_get', result)
            abort(404, result)

        rsp_body = {}
        rsp_body['uuid'] = id
        rsp_body['href'] = self.generate_url('access-control-list', id)
        rsp_body['name'] = result['fq_name'][-1]
        rsp_body.update(result)
        id_perms = result['id_perms']
        response.set_header('ETag', '"' + id_perms['last_modified'] + '"')
        return {'access-control-list': rsp_body} 
    #end access_control_list_http_get

    def access_control_list_http_put(self, id):
        key = 'access-control-list'
        obj_dict = request.json[key]
        # common handling for all resource put
        (ok, result) = self._put_common(request, 'access_control_list', obj_dict, id)
        if not ok:
            (code, msg) = result
            self.config_object_error(id, None, 'access_control_list', 'http_put', msg)
            abort(code, msg)

        # type-specific hook
        r_class = self._resource_classes.get('access-control-list', None)
        if r_class:
            (ok, msg) = r_class.http_put(id, obj_dict)
            if not ok:
                self.config_object_error(id, None, 'access_control_list', 'http_put', msg)
                abort(409, msg)

        db_conn = self._db_conn


        obj_ids = {'uuid': id}
        (ok, result) = \
             db_conn.dbe_update('access-control-list', obj_ids, obj_dict)
        if not ok:
            self.config_object_error(id, None, 'access_control_list', 'http_put', result)
            abort(404, result)

        rsp_body = {}
        rsp_body['uuid'] = id
        rsp_body['href'] = self.generate_url('access-control-list', id)
        return {'access-control-list': rsp_body} 
    #end access_control_list_http_put

    def access_control_list_http_delete(self, id):
        db_conn = self._db_conn
        # read in obj from db (accepting error) to get details of it
        obj_ids = {'uuid': id}
        (read_ok, read_result) = db_conn.dbe_read('access-control-list', obj_ids)
        if not read_ok:
            self.config_object_error(id, None, 'access_control_list', 'http_delete', read_result)
            # proceed down to delete the resource

        # common handling for all resource delete
        parent_type = read_result.get('parent_type', None)
        (ok, del_result) = self._delete_common(request, 'access_control_list', id, parent_type)
        if not ok:
            (code, msg) = del_result
            self.config_object_error(id, None, 'access_control_list', 'http_delete', msg)
            abort(code, msg)

        fq_name = read_result['fq_name']
        ifmap_id = common.imid.get_ifmap_id_from_fq_name('access-control-list', fq_name)
        obj_ids['imid'] = ifmap_id
        if parent_type:
            parent_imid = common.imid.get_ifmap_id_from_fq_name(parent_type, fq_name[:-1])
            obj_ids['parent_imid'] = parent_imid

        # type-specific hook
        r_class = self._resource_classes.get('access-control-list', None)
        if r_class:
            if read_ok:
                # fail if non-default children or backrefs exist

                # Delete default children first
                parent_obj = AccessControlList.factory(**read_result)
                self._access_control_list_delete_default_children(parent_obj)

                r_class.http_delete(id, read_result)
            #end if read_ok

        (ok, del_result) = \
             db_conn.dbe_delete('access-control-list', obj_ids)
        if not ok:
            self.config_object_error(id, None, 'access_control_list', 'http_delete', del_result)
            abort(409, del_result)

    #end access_control_list_http_delete
    def access_control_lists_http_post(self):
        key = 'access-control-list'
        obj_dict = request.json[key]
        # common handling for all resource create
        (ok, result) = self._post_common(request, 'access-control-list', obj_dict)
        if not ok:
            (code, msg) = result
            fq_name_str = ':'.join(obj_dict.get('fq_name', []))
            self.config_object_error(None, fq_name_str, 'access_control_list', 'http_post', msg)
            abort(code, msg)

        # Alloc and Store id-mappings before creating entry on pubsub store.
        # Else a subscriber can ask for an id mapping before we have stored it
        uuid_requested = result
        db_conn = self._db_conn
        (ok, result) = db_conn.dbe_alloc('access-control-list', obj_dict, uuid_requested)
        if not ok:
            fq_name_str = ':'.join(obj_dict['fq_name'])
            self.config_object_error(None, fq_name_str, 'access_control_list', 'http_post', result)
            abort(code, result)

        obj_ids = result

        name = obj_dict['fq_name'][-1]
        fq_name = obj_dict['fq_name']


        if 'parent_type' in obj_dict:
            # non config-root child, verify parent exists
            parent_type = obj_dict['parent_type']
            parent_fq_name = obj_dict['fq_name'][:-1]
            try:
                parent_uuid = self._db_conn.fq_name_to_uuid(parent_type, parent_fq_name)
                (ok, status) = self._permissions.check_perms_write(request, parent_uuid)
                if not ok:
                    (code, err_msg) = status
                    abort(code, err_msg)
                self._permissions.set_user_role(request, obj_dict)
            except NoIdError:
                err_msg = 'Parent ' + pformat(parent_fq_name) + ' type ' + parent_type + ' does not exist'
                fq_name_str = ':'.join(parent_fq_name)
                self.config_object_error(None, fq_name_str, 'access_control_list', 'http_post', err_msg)
                abort(400, err_msg)

        env = request.headers.environ
        tenant_name = env.get(hdr_server_tenant(), 'default-project')


        # type-specific hook
        r_class = self._resource_classes.get('access-control-list', None)
        if r_class:
            (ok, result) = r_class.http_post_collection(tenant_name, obj_dict)
            if not ok:
                (code, msg) = result
                fq_name_str = ':'.join(fq_name)
                self.config_object_error(None, fq_name_str, 'access_control_list', 'http_post', msg)
                abort(code, msg)


        (ok, result) = \
             db_conn.dbe_create('access-control-list', obj_ids, obj_dict)

        if not ok:
            fq_name_str = ':'.join(fq_name)
            self.config_object_error(None, fq_name_str, 'access_control_list', 'http_post', result)
            abort(404, result)

        rsp_body = {}
        rsp_body['name'] = name
        rsp_body['fq_name'] = fq_name
        rsp_body['uuid'] = obj_ids['uuid']
        rsp_body['href'] = self.generate_url('access-control-list', obj_ids['uuid'])
        if 'parent_type' in obj_dict:
            # non config-root child, send back parent uuid/href
            rsp_body['parent_uuid'] = parent_uuid
            rsp_body['parent_href'] = self.generate_url(parent_type, parent_uuid)

        parent_obj = AccessControlList.factory(**rsp_body)
        self._access_control_list_create_default_children(parent_obj)

        return {'access-control-list': rsp_body} 
    #end access_control_lists_http_post

    def access_control_lists_http_get(self):
        env = request.headers.environ
        tenant_name = env.get(hdr_server_tenant(), 'default-project')
        parent_uuid = None
        resource_id = 'access_control_lists'
        if (('parent_fq_name_str' in request.query) and
            ('parent_type' in request.query)):
            parent_fq_name = request.query.parent_fq_name_str.split(':')
            parent_type = request.query.parent_type
            parent_uuid = self._db_conn.fq_name_to_uuid(parent_type, parent_fq_name)
        elif 'parent_id' in request.query:
            parent_uuid = str(uuid.UUID(request.query.parent_id))

        if parent_uuid:
            resource_id = parent_uuid

        # common handling for all resource get
        (ok, result) = self._get_common(request, parent_uuid)
        if not ok:
            (code, msg) = result
            self.config_object_error(None, None, 'access_control_lists', 'http_get_collection', msg)
            abort(code, msg)

        db_conn = self._db_conn
        (ok, result) = \
             db_conn.dbe_list('access-control-list', parent_uuid)

        if not ok:
            self.config_object_error(None, None, 'access_control_lists', 'http_get_collection', result)
            abort(404, result)

        fq_names = result
        obj_dicts = []
        for fq_name in fq_names:
            obj_dict = {}
            id = db_conn.fq_name_to_uuid('access_control_list', fq_name)
            obj_dict['uuid'] = id
            obj_dict['fq_name'] = fq_name
            obj_dict['href'] = self.generate_url('access-control-list', id)
            obj_dicts.append(obj_dict)

        return {'access-control-lists': obj_dicts} 
    #end access_control_lists_http_get

    def _access_control_list_create_default_children(self, parent_obj):
        pass
    #end _access_control_list_create_default_children

    def _access_control_list_delete_default_children(self, parent_obj):
        pass
    #end _access_control_list_delete_default_children

    def virtual_DNS_http_get(self, id):
        # TODO get vals from request out of the global ASAP
        etag = request.headers.get('If-None-Match')
        # common handling for all resource get
        (ok, result) = self._get_common(request, id)
        if not ok:
            (code, msg) = result
            self.config_object_error(id, None, 'virtual_DNS', 'http_get', msg)
            abort(code, msg)

        # type-specific hook
        r_class = self._resource_classes.get('virtual-DNS', None)
        if r_class:
            r_class.http_get(id)

        db_conn = self._db_conn
        if etag:
            obj_ids = {'uuid': id}
            (ok, result) = db_conn.dbe_is_latest(obj_ids, etag.replace('"', ''))
            if not ok:
                # Not present in DB
                self.config_object_error(id, None, 'virtual_DNS', 'http_get', result)
                abort(404, result)

            is_latest = result
            if is_latest:
                # send Not-Modified, caches use this for read optimization
                response.status = 304
                return
        #end if etag

        obj_ids = {'uuid': id}
        if 'fields' in request.query:
            obj_fields = request.query.fields.split(',')
        else:
            obj_fields = None
        (ok, result) = db_conn.dbe_read('virtual-DNS', obj_ids, obj_fields)
        if not ok:
            # Not present in DB
            self.config_object_error(id, None, 'virtual_DNS', 'http_get', result)
            abort(404, result)

        rsp_body = {}
        rsp_body['uuid'] = id
        rsp_body['href'] = self.generate_url('virtual-DNS', id)
        rsp_body['name'] = result['fq_name'][-1]
        rsp_body.update(result)
        id_perms = result['id_perms']
        response.set_header('ETag', '"' + id_perms['last_modified'] + '"')
        return {'virtual-DNS': rsp_body} 
    #end virtual_DNS_http_get

    def virtual_DNS_http_put(self, id):
        key = 'virtual-DNS'
        obj_dict = request.json[key]
        # common handling for all resource put
        (ok, result) = self._put_common(request, 'virtual_DNS', obj_dict, id)
        if not ok:
            (code, msg) = result
            self.config_object_error(id, None, 'virtual_DNS', 'http_put', msg)
            abort(code, msg)

        # type-specific hook
        r_class = self._resource_classes.get('virtual-DNS', None)
        if r_class:
            (ok, msg) = r_class.http_put(id, obj_dict)
            if not ok:
                self.config_object_error(id, None, 'virtual_DNS', 'http_put', msg)
                abort(409, msg)

        db_conn = self._db_conn

        # Validate perms
        objtype_list = eval("[u'virtual_DNS_record']")
        for obj_type in objtype_list:
            refs = obj_dict.get('%s_refs'%(obj_type), None)
            if refs:
                for ref in refs:
                    ref_uuid = db_conn.fq_name_to_uuid(obj_type, ref['to'])
                    (ok, status) = self._permissions.check_perms_link(request, ref_uuid)
                    if not ok:
                        (code, err_msg) = status
                        abort(code, err_msg)

        obj_ids = {'uuid': id}
        (ok, result) = \
             db_conn.dbe_update('virtual-DNS', obj_ids, obj_dict)
        if not ok:
            self.config_object_error(id, None, 'virtual_DNS', 'http_put', result)
            abort(404, result)

        rsp_body = {}
        rsp_body['uuid'] = id
        rsp_body['href'] = self.generate_url('virtual-DNS', id)
        return {'virtual-DNS': rsp_body} 
    #end virtual_DNS_http_put

    def virtual_DNS_http_delete(self, id):
        db_conn = self._db_conn
        # read in obj from db (accepting error) to get details of it
        obj_ids = {'uuid': id}
        (read_ok, read_result) = db_conn.dbe_read('virtual-DNS', obj_ids)
        if not read_ok:
            self.config_object_error(id, None, 'virtual_DNS', 'http_delete', read_result)
            # proceed down to delete the resource

        # common handling for all resource delete
        parent_type = read_result.get('parent_type', None)
        (ok, del_result) = self._delete_common(request, 'virtual_DNS', id, parent_type)
        if not ok:
            (code, msg) = del_result
            self.config_object_error(id, None, 'virtual_DNS', 'http_delete', msg)
            abort(code, msg)

        fq_name = read_result['fq_name']
        ifmap_id = common.imid.get_ifmap_id_from_fq_name('virtual-DNS', fq_name)
        obj_ids['imid'] = ifmap_id
        if parent_type:
            parent_imid = common.imid.get_ifmap_id_from_fq_name(parent_type, fq_name[:-1])
            obj_ids['parent_imid'] = parent_imid

        # type-specific hook
        r_class = self._resource_classes.get('virtual-DNS', None)
        if r_class:
            if read_ok:
                # fail if non-default children or backrefs exist
                virtual_DNS_records = read_result.get('virtual_DNS_records', None)
                if virtual_DNS_records:
                    has_infos = read_result['virtual_DNS_records']
                    if ((len(has_infos) > 1) or 
                        (len(has_infos) == 1 and has_infos[0]['to'][-1] != 'default-virtual-DNS-record')):
                        has_urls = [has_info['href'] for has_info in has_infos]
                        has_str = ', '.join(has_urls)
                        err_msg = 'Children ' + has_str + ' still exist'
                        self.config_object_error(id, None, 'virtual_DNS', 'http_delete', err_msg)
                        abort(409, err_msg)

                network_ipam_back_refs = read_result.get('network_ipam_back_refs', None)
                if network_ipam_back_refs:
                    back_ref_urls = [back_ref_info['href'] for back_ref_info in read_result['network_ipam_back_refs']]
                    back_ref_str = ', '.join(back_ref_urls)
                    err_msg = 'Back-References from ' + back_ref_str + ' still exist'
                    self.config_object_error(id, None, 'virtual_DNS', 'http_delete', err_msg)
                    abort(409, err_msg)


                # Delete default children first
                parent_obj = VirtualDns.factory(**read_result)
                self._virtual_DNS_delete_default_children(parent_obj)

                r_class.http_delete(id, read_result)
            #end if read_ok

        (ok, del_result) = \
             db_conn.dbe_delete('virtual-DNS', obj_ids)
        if not ok:
            self.config_object_error(id, None, 'virtual_DNS', 'http_delete', del_result)
            abort(409, del_result)

    #end virtual_DNS_http_delete
    def virtual_DNSs_http_post(self):
        key = 'virtual-DNS'
        obj_dict = request.json[key]
        # common handling for all resource create
        (ok, result) = self._post_common(request, 'virtual-DNS', obj_dict)
        if not ok:
            (code, msg) = result
            fq_name_str = ':'.join(obj_dict.get('fq_name', []))
            self.config_object_error(None, fq_name_str, 'virtual_DNS', 'http_post', msg)
            abort(code, msg)

        # Alloc and Store id-mappings before creating entry on pubsub store.
        # Else a subscriber can ask for an id mapping before we have stored it
        uuid_requested = result
        db_conn = self._db_conn
        (ok, result) = db_conn.dbe_alloc('virtual-DNS', obj_dict, uuid_requested)
        if not ok:
            fq_name_str = ':'.join(obj_dict['fq_name'])
            self.config_object_error(None, fq_name_str, 'virtual_DNS', 'http_post', result)
            abort(code, result)

        obj_ids = result

        name = obj_dict['fq_name'][-1]
        fq_name = obj_dict['fq_name']


        if 'parent_type' in obj_dict:
            # non config-root child, verify parent exists
            parent_type = obj_dict['parent_type']
            parent_fq_name = obj_dict['fq_name'][:-1]
            try:
                parent_uuid = self._db_conn.fq_name_to_uuid(parent_type, parent_fq_name)
                (ok, status) = self._permissions.check_perms_write(request, parent_uuid)
                if not ok:
                    (code, err_msg) = status
                    abort(code, err_msg)
                self._permissions.set_user_role(request, obj_dict)
            except NoIdError:
                err_msg = 'Parent ' + pformat(parent_fq_name) + ' type ' + parent_type + ' does not exist'
                fq_name_str = ':'.join(parent_fq_name)
                self.config_object_error(None, fq_name_str, 'virtual_DNS', 'http_post', err_msg)
                abort(400, err_msg)

        env = request.headers.environ
        tenant_name = env.get(hdr_server_tenant(), 'default-project')


        # type-specific hook
        r_class = self._resource_classes.get('virtual-DNS', None)
        if r_class:
            (ok, result) = r_class.http_post_collection(tenant_name, obj_dict)
            if not ok:
                (code, msg) = result
                fq_name_str = ':'.join(fq_name)
                self.config_object_error(None, fq_name_str, 'virtual_DNS', 'http_post', msg)
                abort(code, msg)

        # Validate perms
        objtype_list = eval("[u'virtual_DNS_record']")
        for obj_type in objtype_list:
            refs = obj_dict.get('%s_refs'%(obj_type), None)
            if refs:
                for ref in refs:
                    ref_uuid = db_conn.fq_name_to_uuid(obj_type, ref['to'])
                    (ok, status) = self._permissions.check_perms_link(request, ref_uuid)
                    if not ok:
                        (code, err_msg) = status
                        abort(code, err_msg)

        (ok, result) = \
             db_conn.dbe_create('virtual-DNS', obj_ids, obj_dict)

        if not ok:
            fq_name_str = ':'.join(fq_name)
            self.config_object_error(None, fq_name_str, 'virtual_DNS', 'http_post', result)
            abort(404, result)

        rsp_body = {}
        rsp_body['name'] = name
        rsp_body['fq_name'] = fq_name
        rsp_body['uuid'] = obj_ids['uuid']
        rsp_body['href'] = self.generate_url('virtual-DNS', obj_ids['uuid'])
        if 'parent_type' in obj_dict:
            # non config-root child, send back parent uuid/href
            rsp_body['parent_uuid'] = parent_uuid
            rsp_body['parent_href'] = self.generate_url(parent_type, parent_uuid)

        parent_obj = VirtualDns.factory(**rsp_body)
        self._virtual_DNS_create_default_children(parent_obj)

        return {'virtual-DNS': rsp_body} 
    #end virtual_DNSs_http_post

    def virtual_DNSs_http_get(self):
        env = request.headers.environ
        tenant_name = env.get(hdr_server_tenant(), 'default-project')
        parent_uuid = None
        resource_id = 'virtual_DNSs'
        if (('parent_fq_name_str' in request.query) and
            ('parent_type' in request.query)):
            parent_fq_name = request.query.parent_fq_name_str.split(':')
            parent_type = request.query.parent_type
            parent_uuid = self._db_conn.fq_name_to_uuid(parent_type, parent_fq_name)
        elif 'parent_id' in request.query:
            parent_uuid = str(uuid.UUID(request.query.parent_id))

        if parent_uuid:
            resource_id = parent_uuid

        # common handling for all resource get
        (ok, result) = self._get_common(request, parent_uuid)
        if not ok:
            (code, msg) = result
            self.config_object_error(None, None, 'virtual_DNSs', 'http_get_collection', msg)
            abort(code, msg)

        db_conn = self._db_conn
        (ok, result) = \
             db_conn.dbe_list('virtual-DNS', parent_uuid)

        if not ok:
            self.config_object_error(None, None, 'virtual_DNSs', 'http_get_collection', result)
            abort(404, result)

        fq_names = result
        obj_dicts = []
        for fq_name in fq_names:
            obj_dict = {}
            id = db_conn.fq_name_to_uuid('virtual_DNS', fq_name)
            obj_dict['uuid'] = id
            obj_dict['fq_name'] = fq_name
            obj_dict['href'] = self.generate_url('virtual-DNS', id)
            obj_dicts.append(obj_dict)

        return {'virtual-DNSs': obj_dicts} 
    #end virtual_DNSs_http_get

    def _virtual_DNS_create_default_children(self, parent_obj):
        # Create a default child only if provisioned for
        r_class = self._resource_classes.get('virtual-DNS-record', None)
        if r_class.generate_default_instance:
            child_obj = VirtualDnsRecord(parent_obj = parent_obj)
            child_dict = child_obj.__dict__
            fq_name = child_dict['fq_name']
            child_dict['id_perms'] = self._get_default_id_perms('virtual-DNS-record')

            db_conn = self._db_conn
            (ok, result) = db_conn.dbe_alloc('virtual-DNS-record', child_dict)
            if not ok:
                return (ok, result)

            obj_ids = result
            db_conn.dbe_create('virtual-DNS-record', obj_ids, child_dict)
            self._virtual_DNS_record_create_default_children(child_obj)

        pass
    #end _virtual_DNS_create_default_children

    def _virtual_DNS_delete_default_children(self, parent_obj):
        # Delete a default child only if provisioned for
        r_class = self._resource_classes.get('virtual-DNS-record', None)
        if r_class.generate_default_instance:
            # first locate default child then delete it
            has_infos = parent_obj.get_virtual_DNS_records()
            if has_infos:
                for has_info in has_infos:
                    if has_info['to'][-1] == 'default-virtual-DNS-record':
                        default_child_id = has_info['href'].split('/')[-1]
                        self.virtual_DNS_record_http_delete(default_child_id)
                        break

        pass
    #end _virtual_DNS_delete_default_children

    def customer_attachment_http_get(self, id):
        # TODO get vals from request out of the global ASAP
        etag = request.headers.get('If-None-Match')
        # common handling for all resource get
        (ok, result) = self._get_common(request, id)
        if not ok:
            (code, msg) = result
            self.config_object_error(id, None, 'customer_attachment', 'http_get', msg)
            abort(code, msg)

        # type-specific hook
        r_class = self._resource_classes.get('customer-attachment', None)
        if r_class:
            r_class.http_get(id)

        db_conn = self._db_conn
        if etag:
            obj_ids = {'uuid': id}
            (ok, result) = db_conn.dbe_is_latest(obj_ids, etag.replace('"', ''))
            if not ok:
                # Not present in DB
                self.config_object_error(id, None, 'customer_attachment', 'http_get', result)
                abort(404, result)

            is_latest = result
            if is_latest:
                # send Not-Modified, caches use this for read optimization
                response.status = 304
                return
        #end if etag

        obj_ids = {'uuid': id}
        if 'fields' in request.query:
            obj_fields = request.query.fields.split(',')
        else:
            obj_fields = None
        (ok, result) = db_conn.dbe_read('customer-attachment', obj_ids, obj_fields)
        if not ok:
            # Not present in DB
            self.config_object_error(id, None, 'customer_attachment', 'http_get', result)
            abort(404, result)

        rsp_body = {}
        rsp_body['uuid'] = id
        rsp_body['href'] = self.generate_url('customer-attachment', id)
        rsp_body['name'] = result['fq_name'][-1]
        rsp_body.update(result)
        id_perms = result['id_perms']
        response.set_header('ETag', '"' + id_perms['last_modified'] + '"')
        return {'customer-attachment': rsp_body} 
    #end customer_attachment_http_get

    def customer_attachment_http_put(self, id):
        key = 'customer-attachment'
        obj_dict = request.json[key]
        # common handling for all resource put
        (ok, result) = self._put_common(request, 'customer_attachment', obj_dict, id)
        if not ok:
            (code, msg) = result
            self.config_object_error(id, None, 'customer_attachment', 'http_put', msg)
            abort(code, msg)

        # type-specific hook
        r_class = self._resource_classes.get('customer-attachment', None)
        if r_class:
            (ok, msg) = r_class.http_put(id, obj_dict)
            if not ok:
                self.config_object_error(id, None, 'customer_attachment', 'http_put', msg)
                abort(409, msg)

        db_conn = self._db_conn

        # Validate perms
        objtype_list = eval("[u'virtual_machine_interface', u'floating_ip', 'routing_instance', 'provider_attachment']")
        for obj_type in objtype_list:
            refs = obj_dict.get('%s_refs'%(obj_type), None)
            if refs:
                for ref in refs:
                    ref_uuid = db_conn.fq_name_to_uuid(obj_type, ref['to'])
                    (ok, status) = self._permissions.check_perms_link(request, ref_uuid)
                    if not ok:
                        (code, err_msg) = status
                        abort(code, err_msg)

        obj_ids = {'uuid': id}
        (ok, result) = \
             db_conn.dbe_update('customer-attachment', obj_ids, obj_dict)
        if not ok:
            self.config_object_error(id, None, 'customer_attachment', 'http_put', result)
            abort(404, result)

        rsp_body = {}
        rsp_body['uuid'] = id
        rsp_body['href'] = self.generate_url('customer-attachment', id)
        return {'customer-attachment': rsp_body} 
    #end customer_attachment_http_put

    def customer_attachment_http_delete(self, id):
        db_conn = self._db_conn
        # read in obj from db (accepting error) to get details of it
        obj_ids = {'uuid': id}
        (read_ok, read_result) = db_conn.dbe_read('customer-attachment', obj_ids)
        if not read_ok:
            self.config_object_error(id, None, 'customer_attachment', 'http_delete', read_result)
            # proceed down to delete the resource

        # common handling for all resource delete
        parent_type = read_result.get('parent_type', None)
        (ok, del_result) = self._delete_common(request, 'customer_attachment', id, parent_type)
        if not ok:
            (code, msg) = del_result
            self.config_object_error(id, None, 'customer_attachment', 'http_delete', msg)
            abort(code, msg)

        fq_name = read_result['fq_name']
        ifmap_id = common.imid.get_ifmap_id_from_fq_name('customer-attachment', fq_name)
        obj_ids['imid'] = ifmap_id
        if parent_type:
            parent_imid = common.imid.get_ifmap_id_from_fq_name(parent_type, fq_name[:-1])
            obj_ids['parent_imid'] = parent_imid

        # type-specific hook
        r_class = self._resource_classes.get('customer-attachment', None)
        if r_class:
            if read_ok:
                # fail if non-default children or backrefs exist

                # Delete default children first
                parent_obj = CustomerAttachment.factory(**read_result)
                self._customer_attachment_delete_default_children(parent_obj)

                r_class.http_delete(id, read_result)
            #end if read_ok

        (ok, del_result) = \
             db_conn.dbe_delete('customer-attachment', obj_ids)
        if not ok:
            self.config_object_error(id, None, 'customer_attachment', 'http_delete', del_result)
            abort(409, del_result)

    #end customer_attachment_http_delete
    def customer_attachments_http_post(self):
        key = 'customer-attachment'
        obj_dict = request.json[key]
        # common handling for all resource create
        (ok, result) = self._post_common(request, 'customer-attachment', obj_dict)
        if not ok:
            (code, msg) = result
            fq_name_str = ':'.join(obj_dict.get('fq_name', []))
            self.config_object_error(None, fq_name_str, 'customer_attachment', 'http_post', msg)
            abort(code, msg)

        # Alloc and Store id-mappings before creating entry on pubsub store.
        # Else a subscriber can ask for an id mapping before we have stored it
        uuid_requested = result
        db_conn = self._db_conn
        (ok, result) = db_conn.dbe_alloc('customer-attachment', obj_dict, uuid_requested)
        if not ok:
            fq_name_str = ':'.join(obj_dict['fq_name'])
            self.config_object_error(None, fq_name_str, 'customer_attachment', 'http_post', result)
            abort(code, result)

        obj_ids = result

        name = obj_dict['fq_name'][-1]
        fq_name = obj_dict['fq_name']


        env = request.headers.environ
        tenant_name = env.get(hdr_server_tenant(), 'default-project')


        # type-specific hook
        r_class = self._resource_classes.get('customer-attachment', None)
        if r_class:
            (ok, result) = r_class.http_post_collection(tenant_name, obj_dict)
            if not ok:
                (code, msg) = result
                fq_name_str = ':'.join(fq_name)
                self.config_object_error(None, fq_name_str, 'customer_attachment', 'http_post', msg)
                abort(code, msg)

        # Validate perms
        objtype_list = eval("[u'virtual_machine_interface', u'floating_ip', 'routing_instance', 'provider_attachment']")
        for obj_type in objtype_list:
            refs = obj_dict.get('%s_refs'%(obj_type), None)
            if refs:
                for ref in refs:
                    ref_uuid = db_conn.fq_name_to_uuid(obj_type, ref['to'])
                    (ok, status) = self._permissions.check_perms_link(request, ref_uuid)
                    if not ok:
                        (code, err_msg) = status
                        abort(code, err_msg)

        (ok, result) = \
             db_conn.dbe_create('customer-attachment', obj_ids, obj_dict)

        if not ok:
            fq_name_str = ':'.join(fq_name)
            self.config_object_error(None, fq_name_str, 'customer_attachment', 'http_post', result)
            abort(404, result)

        rsp_body = {}
        rsp_body['name'] = name
        rsp_body['fq_name'] = fq_name
        rsp_body['uuid'] = obj_ids['uuid']
        rsp_body['href'] = self.generate_url('customer-attachment', obj_ids['uuid'])

        parent_obj = CustomerAttachment.factory(**rsp_body)
        self._customer_attachment_create_default_children(parent_obj)

        return {'customer-attachment': rsp_body} 
    #end customer_attachments_http_post

    def customer_attachments_http_get(self):
        env = request.headers.environ
        tenant_name = env.get(hdr_server_tenant(), 'default-project')
        parent_uuid = None
        resource_id = 'customer_attachments'
        if (('parent_fq_name_str' in request.query) and
            ('parent_type' in request.query)):
            parent_fq_name = request.query.parent_fq_name_str.split(':')
            parent_type = request.query.parent_type
            parent_uuid = self._db_conn.fq_name_to_uuid(parent_type, parent_fq_name)
        elif 'parent_id' in request.query:
            parent_uuid = str(uuid.UUID(request.query.parent_id))

        if parent_uuid:
            resource_id = parent_uuid

        # common handling for all resource get
        (ok, result) = self._get_common(request, parent_uuid)
        if not ok:
            (code, msg) = result
            self.config_object_error(None, None, 'customer_attachments', 'http_get_collection', msg)
            abort(code, msg)

        db_conn = self._db_conn
        (ok, result) = \
             db_conn.dbe_list('customer-attachment', parent_uuid)

        if not ok:
            self.config_object_error(None, None, 'customer_attachments', 'http_get_collection', result)
            abort(404, result)

        fq_names = result
        obj_dicts = []
        for fq_name in fq_names:
            obj_dict = {}
            id = db_conn.fq_name_to_uuid('customer_attachment', fq_name)
            obj_dict['uuid'] = id
            obj_dict['fq_name'] = fq_name
            obj_dict['href'] = self.generate_url('customer-attachment', id)
            obj_dicts.append(obj_dict)

        return {'customer-attachments': obj_dicts} 
    #end customer_attachments_http_get

    def _customer_attachment_create_default_children(self, parent_obj):
        pass
    #end _customer_attachment_create_default_children

    def _customer_attachment_delete_default_children(self, parent_obj):
        pass
    #end _customer_attachment_delete_default_children

    def virtual_machine_http_get(self, id):
        # TODO get vals from request out of the global ASAP
        etag = request.headers.get('If-None-Match')
        # common handling for all resource get
        (ok, result) = self._get_common(request, id)
        if not ok:
            (code, msg) = result
            self.config_object_error(id, None, 'virtual_machine', 'http_get', msg)
            abort(code, msg)

        # type-specific hook
        r_class = self._resource_classes.get('virtual-machine', None)
        if r_class:
            r_class.http_get(id)

        db_conn = self._db_conn
        if etag:
            obj_ids = {'uuid': id}
            (ok, result) = db_conn.dbe_is_latest(obj_ids, etag.replace('"', ''))
            if not ok:
                # Not present in DB
                self.config_object_error(id, None, 'virtual_machine', 'http_get', result)
                abort(404, result)

            is_latest = result
            if is_latest:
                # send Not-Modified, caches use this for read optimization
                response.status = 304
                return
        #end if etag

        obj_ids = {'uuid': id}
        if 'fields' in request.query:
            obj_fields = request.query.fields.split(',')
        else:
            obj_fields = None
        (ok, result) = db_conn.dbe_read('virtual-machine', obj_ids, obj_fields)
        if not ok:
            # Not present in DB
            self.config_object_error(id, None, 'virtual_machine', 'http_get', result)
            abort(404, result)

        rsp_body = {}
        rsp_body['uuid'] = id
        rsp_body['href'] = self.generate_url('virtual-machine', id)
        rsp_body['name'] = result['fq_name'][-1]
        rsp_body.update(result)
        id_perms = result['id_perms']
        response.set_header('ETag', '"' + id_perms['last_modified'] + '"')
        return {'virtual-machine': rsp_body} 
    #end virtual_machine_http_get

    def virtual_machine_http_put(self, id):
        key = 'virtual-machine'
        obj_dict = request.json[key]
        # common handling for all resource put
        (ok, result) = self._put_common(request, 'virtual_machine', obj_dict, id)
        if not ok:
            (code, msg) = result
            self.config_object_error(id, None, 'virtual_machine', 'http_put', msg)
            abort(code, msg)

        # type-specific hook
        r_class = self._resource_classes.get('virtual-machine', None)
        if r_class:
            (ok, msg) = r_class.http_put(id, obj_dict)
            if not ok:
                self.config_object_error(id, None, 'virtual_machine', 'http_put', msg)
                abort(409, msg)

        db_conn = self._db_conn

        # Validate perms
        objtype_list = eval("[u'security_group', u'virtual_machine_interface', u'service_instance']")
        for obj_type in objtype_list:
            refs = obj_dict.get('%s_refs'%(obj_type), None)
            if refs:
                for ref in refs:
                    ref_uuid = db_conn.fq_name_to_uuid(obj_type, ref['to'])
                    (ok, status) = self._permissions.check_perms_link(request, ref_uuid)
                    if not ok:
                        (code, err_msg) = status
                        abort(code, err_msg)

        obj_ids = {'uuid': id}
        (ok, result) = \
             db_conn.dbe_update('virtual-machine', obj_ids, obj_dict)
        if not ok:
            self.config_object_error(id, None, 'virtual_machine', 'http_put', result)
            abort(404, result)

        rsp_body = {}
        rsp_body['uuid'] = id
        rsp_body['href'] = self.generate_url('virtual-machine', id)
        return {'virtual-machine': rsp_body} 
    #end virtual_machine_http_put

    def virtual_machine_http_delete(self, id):
        db_conn = self._db_conn
        # read in obj from db (accepting error) to get details of it
        obj_ids = {'uuid': id}
        (read_ok, read_result) = db_conn.dbe_read('virtual-machine', obj_ids)
        if not read_ok:
            self.config_object_error(id, None, 'virtual_machine', 'http_delete', read_result)
            # proceed down to delete the resource

        # common handling for all resource delete
        parent_type = read_result.get('parent_type', None)
        (ok, del_result) = self._delete_common(request, 'virtual_machine', id, parent_type)
        if not ok:
            (code, msg) = del_result
            self.config_object_error(id, None, 'virtual_machine', 'http_delete', msg)
            abort(code, msg)

        fq_name = read_result['fq_name']
        ifmap_id = common.imid.get_ifmap_id_from_fq_name('virtual-machine', fq_name)
        obj_ids['imid'] = ifmap_id
        if parent_type:
            parent_imid = common.imid.get_ifmap_id_from_fq_name(parent_type, fq_name[:-1])
            obj_ids['parent_imid'] = parent_imid

        # type-specific hook
        r_class = self._resource_classes.get('virtual-machine', None)
        if r_class:
            if read_ok:
                # fail if non-default children or backrefs exist
                virtual_machine_interfaces = read_result.get('virtual_machine_interfaces', None)
                if virtual_machine_interfaces:
                    has_infos = read_result['virtual_machine_interfaces']
                    if ((len(has_infos) > 1) or 
                        (len(has_infos) == 1 and has_infos[0]['to'][-1] != 'default-virtual-machine-interface')):
                        has_urls = [has_info['href'] for has_info in has_infos]
                        has_str = ', '.join(has_urls)
                        err_msg = 'Children ' + has_str + ' still exist'
                        self.config_object_error(id, None, 'virtual_machine', 'http_delete', err_msg)
                        abort(409, err_msg)

                virtual_router_back_refs = read_result.get('virtual_router_back_refs', None)
                if virtual_router_back_refs:
                    back_ref_urls = [back_ref_info['href'] for back_ref_info in read_result['virtual_router_back_refs']]
                    back_ref_str = ', '.join(back_ref_urls)
                    err_msg = 'Back-References from ' + back_ref_str + ' still exist'
                    self.config_object_error(id, None, 'virtual_machine', 'http_delete', err_msg)
                    abort(409, err_msg)


                # Delete default children first
                parent_obj = VirtualMachine.factory(**read_result)
                self._virtual_machine_delete_default_children(parent_obj)

                r_class.http_delete(id, read_result)
            #end if read_ok

        (ok, del_result) = \
             db_conn.dbe_delete('virtual-machine', obj_ids)
        if not ok:
            self.config_object_error(id, None, 'virtual_machine', 'http_delete', del_result)
            abort(409, del_result)

    #end virtual_machine_http_delete
    def virtual_machines_http_post(self):
        key = 'virtual-machine'
        obj_dict = request.json[key]
        # common handling for all resource create
        (ok, result) = self._post_common(request, 'virtual-machine', obj_dict)
        if not ok:
            (code, msg) = result
            fq_name_str = ':'.join(obj_dict.get('fq_name', []))
            self.config_object_error(None, fq_name_str, 'virtual_machine', 'http_post', msg)
            abort(code, msg)

        # Alloc and Store id-mappings before creating entry on pubsub store.
        # Else a subscriber can ask for an id mapping before we have stored it
        uuid_requested = result
        db_conn = self._db_conn
        (ok, result) = db_conn.dbe_alloc('virtual-machine', obj_dict, uuid_requested)
        if not ok:
            fq_name_str = ':'.join(obj_dict['fq_name'])
            self.config_object_error(None, fq_name_str, 'virtual_machine', 'http_post', result)
            abort(code, result)

        obj_ids = result

        name = obj_dict['fq_name'][-1]
        fq_name = obj_dict['fq_name']


        env = request.headers.environ
        tenant_name = env.get(hdr_server_tenant(), 'default-project')


        # type-specific hook
        r_class = self._resource_classes.get('virtual-machine', None)
        if r_class:
            (ok, result) = r_class.http_post_collection(tenant_name, obj_dict)
            if not ok:
                (code, msg) = result
                fq_name_str = ':'.join(fq_name)
                self.config_object_error(None, fq_name_str, 'virtual_machine', 'http_post', msg)
                abort(code, msg)

        # Validate perms
        objtype_list = eval("[u'security_group', u'virtual_machine_interface', u'service_instance']")
        for obj_type in objtype_list:
            refs = obj_dict.get('%s_refs'%(obj_type), None)
            if refs:
                for ref in refs:
                    ref_uuid = db_conn.fq_name_to_uuid(obj_type, ref['to'])
                    (ok, status) = self._permissions.check_perms_link(request, ref_uuid)
                    if not ok:
                        (code, err_msg) = status
                        abort(code, err_msg)

        (ok, result) = \
             db_conn.dbe_create('virtual-machine', obj_ids, obj_dict)

        if not ok:
            fq_name_str = ':'.join(fq_name)
            self.config_object_error(None, fq_name_str, 'virtual_machine', 'http_post', result)
            abort(404, result)

        rsp_body = {}
        rsp_body['name'] = name
        rsp_body['fq_name'] = fq_name
        rsp_body['uuid'] = obj_ids['uuid']
        rsp_body['href'] = self.generate_url('virtual-machine', obj_ids['uuid'])

        parent_obj = VirtualMachine.factory(**rsp_body)
        self._virtual_machine_create_default_children(parent_obj)

        return {'virtual-machine': rsp_body} 
    #end virtual_machines_http_post

    def virtual_machines_http_get(self):
        env = request.headers.environ
        tenant_name = env.get(hdr_server_tenant(), 'default-project')
        parent_uuid = None
        resource_id = 'virtual_machines'
        if (('parent_fq_name_str' in request.query) and
            ('parent_type' in request.query)):
            parent_fq_name = request.query.parent_fq_name_str.split(':')
            parent_type = request.query.parent_type
            parent_uuid = self._db_conn.fq_name_to_uuid(parent_type, parent_fq_name)
        elif 'parent_id' in request.query:
            parent_uuid = str(uuid.UUID(request.query.parent_id))

        if parent_uuid:
            resource_id = parent_uuid

        # common handling for all resource get
        (ok, result) = self._get_common(request, parent_uuid)
        if not ok:
            (code, msg) = result
            self.config_object_error(None, None, 'virtual_machines', 'http_get_collection', msg)
            abort(code, msg)

        db_conn = self._db_conn
        (ok, result) = \
             db_conn.dbe_list('virtual-machine', parent_uuid)

        if not ok:
            self.config_object_error(None, None, 'virtual_machines', 'http_get_collection', result)
            abort(404, result)

        fq_names = result
        obj_dicts = []
        for fq_name in fq_names:
            obj_dict = {}
            id = db_conn.fq_name_to_uuid('virtual_machine', fq_name)
            obj_dict['uuid'] = id
            obj_dict['fq_name'] = fq_name
            obj_dict['href'] = self.generate_url('virtual-machine', id)
            obj_dicts.append(obj_dict)

        return {'virtual-machines': obj_dicts} 
    #end virtual_machines_http_get

    def _virtual_machine_create_default_children(self, parent_obj):
        # Create a default child only if provisioned for
        r_class = self._resource_classes.get('virtual-machine-interface', None)
        if r_class.generate_default_instance:
            child_obj = VirtualMachineInterface(parent_obj = parent_obj)
            child_dict = child_obj.__dict__
            fq_name = child_dict['fq_name']
            child_dict['id_perms'] = self._get_default_id_perms('virtual-machine-interface')

            db_conn = self._db_conn
            (ok, result) = db_conn.dbe_alloc('virtual-machine-interface', child_dict)
            if not ok:
                return (ok, result)

            obj_ids = result
            db_conn.dbe_create('virtual-machine-interface', obj_ids, child_dict)
            self._virtual_machine_interface_create_default_children(child_obj)

        pass
    #end _virtual_machine_create_default_children

    def _virtual_machine_delete_default_children(self, parent_obj):
        # Delete a default child only if provisioned for
        r_class = self._resource_classes.get('virtual-machine-interface', None)
        if r_class.generate_default_instance:
            # first locate default child then delete it
            has_infos = parent_obj.get_virtual_machine_interfaces()
            if has_infos:
                for has_info in has_infos:
                    if has_info['to'][-1] == 'default-virtual-machine-interface':
                        default_child_id = has_info['href'].split('/')[-1]
                        self.virtual_machine_interface_http_delete(default_child_id)
                        break

        pass
    #end _virtual_machine_delete_default_children

    def service_template_http_get(self, id):
        # TODO get vals from request out of the global ASAP
        etag = request.headers.get('If-None-Match')
        # common handling for all resource get
        (ok, result) = self._get_common(request, id)
        if not ok:
            (code, msg) = result
            self.config_object_error(id, None, 'service_template', 'http_get', msg)
            abort(code, msg)

        # type-specific hook
        r_class = self._resource_classes.get('service-template', None)
        if r_class:
            r_class.http_get(id)

        db_conn = self._db_conn
        if etag:
            obj_ids = {'uuid': id}
            (ok, result) = db_conn.dbe_is_latest(obj_ids, etag.replace('"', ''))
            if not ok:
                # Not present in DB
                self.config_object_error(id, None, 'service_template', 'http_get', result)
                abort(404, result)

            is_latest = result
            if is_latest:
                # send Not-Modified, caches use this for read optimization
                response.status = 304
                return
        #end if etag

        obj_ids = {'uuid': id}
        if 'fields' in request.query:
            obj_fields = request.query.fields.split(',')
        else:
            obj_fields = None
        (ok, result) = db_conn.dbe_read('service-template', obj_ids, obj_fields)
        if not ok:
            # Not present in DB
            self.config_object_error(id, None, 'service_template', 'http_get', result)
            abort(404, result)

        rsp_body = {}
        rsp_body['uuid'] = id
        rsp_body['href'] = self.generate_url('service-template', id)
        rsp_body['name'] = result['fq_name'][-1]
        rsp_body.update(result)
        id_perms = result['id_perms']
        response.set_header('ETag', '"' + id_perms['last_modified'] + '"')
        return {'service-template': rsp_body} 
    #end service_template_http_get

    def service_template_http_put(self, id):
        key = 'service-template'
        obj_dict = request.json[key]
        # common handling for all resource put
        (ok, result) = self._put_common(request, 'service_template', obj_dict, id)
        if not ok:
            (code, msg) = result
            self.config_object_error(id, None, 'service_template', 'http_put', msg)
            abort(code, msg)

        # type-specific hook
        r_class = self._resource_classes.get('service-template', None)
        if r_class:
            (ok, msg) = r_class.http_put(id, obj_dict)
            if not ok:
                self.config_object_error(id, None, 'service_template', 'http_put', msg)
                abort(409, msg)

        db_conn = self._db_conn


        obj_ids = {'uuid': id}
        (ok, result) = \
             db_conn.dbe_update('service-template', obj_ids, obj_dict)
        if not ok:
            self.config_object_error(id, None, 'service_template', 'http_put', result)
            abort(404, result)

        rsp_body = {}
        rsp_body['uuid'] = id
        rsp_body['href'] = self.generate_url('service-template', id)
        return {'service-template': rsp_body} 
    #end service_template_http_put

    def service_template_http_delete(self, id):
        db_conn = self._db_conn
        # read in obj from db (accepting error) to get details of it
        obj_ids = {'uuid': id}
        (read_ok, read_result) = db_conn.dbe_read('service-template', obj_ids)
        if not read_ok:
            self.config_object_error(id, None, 'service_template', 'http_delete', read_result)
            # proceed down to delete the resource

        # common handling for all resource delete
        parent_type = read_result.get('parent_type', None)
        (ok, del_result) = self._delete_common(request, 'service_template', id, parent_type)
        if not ok:
            (code, msg) = del_result
            self.config_object_error(id, None, 'service_template', 'http_delete', msg)
            abort(code, msg)

        fq_name = read_result['fq_name']
        ifmap_id = common.imid.get_ifmap_id_from_fq_name('service-template', fq_name)
        obj_ids['imid'] = ifmap_id
        if parent_type:
            parent_imid = common.imid.get_ifmap_id_from_fq_name(parent_type, fq_name[:-1])
            obj_ids['parent_imid'] = parent_imid

        # type-specific hook
        r_class = self._resource_classes.get('service-template', None)
        if r_class:
            if read_ok:
                # fail if non-default children or backrefs exist
                service_instance_back_refs = read_result.get('service_instance_back_refs', None)
                if service_instance_back_refs:
                    back_ref_urls = [back_ref_info['href'] for back_ref_info in read_result['service_instance_back_refs']]
                    back_ref_str = ', '.join(back_ref_urls)
                    err_msg = 'Back-References from ' + back_ref_str + ' still exist'
                    self.config_object_error(id, None, 'service_template', 'http_delete', err_msg)
                    abort(409, err_msg)


                # Delete default children first
                parent_obj = ServiceTemplate.factory(**read_result)
                self._service_template_delete_default_children(parent_obj)

                r_class.http_delete(id, read_result)
            #end if read_ok

        (ok, del_result) = \
             db_conn.dbe_delete('service-template', obj_ids)
        if not ok:
            self.config_object_error(id, None, 'service_template', 'http_delete', del_result)
            abort(409, del_result)

    #end service_template_http_delete
    def service_templates_http_post(self):
        key = 'service-template'
        obj_dict = request.json[key]
        # common handling for all resource create
        (ok, result) = self._post_common(request, 'service-template', obj_dict)
        if not ok:
            (code, msg) = result
            fq_name_str = ':'.join(obj_dict.get('fq_name', []))
            self.config_object_error(None, fq_name_str, 'service_template', 'http_post', msg)
            abort(code, msg)

        # Alloc and Store id-mappings before creating entry on pubsub store.
        # Else a subscriber can ask for an id mapping before we have stored it
        uuid_requested = result
        db_conn = self._db_conn
        (ok, result) = db_conn.dbe_alloc('service-template', obj_dict, uuid_requested)
        if not ok:
            fq_name_str = ':'.join(obj_dict['fq_name'])
            self.config_object_error(None, fq_name_str, 'service_template', 'http_post', result)
            abort(code, result)

        obj_ids = result

        name = obj_dict['fq_name'][-1]
        fq_name = obj_dict['fq_name']


        if 'parent_type' in obj_dict:
            # non config-root child, verify parent exists
            parent_type = obj_dict['parent_type']
            parent_fq_name = obj_dict['fq_name'][:-1]
            try:
                parent_uuid = self._db_conn.fq_name_to_uuid(parent_type, parent_fq_name)
                (ok, status) = self._permissions.check_perms_write(request, parent_uuid)
                if not ok:
                    (code, err_msg) = status
                    abort(code, err_msg)
                self._permissions.set_user_role(request, obj_dict)
            except NoIdError:
                err_msg = 'Parent ' + pformat(parent_fq_name) + ' type ' + parent_type + ' does not exist'
                fq_name_str = ':'.join(parent_fq_name)
                self.config_object_error(None, fq_name_str, 'service_template', 'http_post', err_msg)
                abort(400, err_msg)

        env = request.headers.environ
        tenant_name = env.get(hdr_server_tenant(), 'default-project')


        # type-specific hook
        r_class = self._resource_classes.get('service-template', None)
        if r_class:
            (ok, result) = r_class.http_post_collection(tenant_name, obj_dict)
            if not ok:
                (code, msg) = result
                fq_name_str = ':'.join(fq_name)
                self.config_object_error(None, fq_name_str, 'service_template', 'http_post', msg)
                abort(code, msg)


        (ok, result) = \
             db_conn.dbe_create('service-template', obj_ids, obj_dict)

        if not ok:
            fq_name_str = ':'.join(fq_name)
            self.config_object_error(None, fq_name_str, 'service_template', 'http_post', result)
            abort(404, result)

        rsp_body = {}
        rsp_body['name'] = name
        rsp_body['fq_name'] = fq_name
        rsp_body['uuid'] = obj_ids['uuid']
        rsp_body['href'] = self.generate_url('service-template', obj_ids['uuid'])
        if 'parent_type' in obj_dict:
            # non config-root child, send back parent uuid/href
            rsp_body['parent_uuid'] = parent_uuid
            rsp_body['parent_href'] = self.generate_url(parent_type, parent_uuid)

        parent_obj = ServiceTemplate.factory(**rsp_body)
        self._service_template_create_default_children(parent_obj)

        return {'service-template': rsp_body} 
    #end service_templates_http_post

    def service_templates_http_get(self):
        env = request.headers.environ
        tenant_name = env.get(hdr_server_tenant(), 'default-project')
        parent_uuid = None
        resource_id = 'service_templates'
        if (('parent_fq_name_str' in request.query) and
            ('parent_type' in request.query)):
            parent_fq_name = request.query.parent_fq_name_str.split(':')
            parent_type = request.query.parent_type
            parent_uuid = self._db_conn.fq_name_to_uuid(parent_type, parent_fq_name)
        elif 'parent_id' in request.query:
            parent_uuid = str(uuid.UUID(request.query.parent_id))

        if parent_uuid:
            resource_id = parent_uuid

        # common handling for all resource get
        (ok, result) = self._get_common(request, parent_uuid)
        if not ok:
            (code, msg) = result
            self.config_object_error(None, None, 'service_templates', 'http_get_collection', msg)
            abort(code, msg)

        db_conn = self._db_conn
        (ok, result) = \
             db_conn.dbe_list('service-template', parent_uuid)

        if not ok:
            self.config_object_error(None, None, 'service_templates', 'http_get_collection', result)
            abort(404, result)

        fq_names = result
        obj_dicts = []
        for fq_name in fq_names:
            obj_dict = {}
            id = db_conn.fq_name_to_uuid('service_template', fq_name)
            obj_dict['uuid'] = id
            obj_dict['fq_name'] = fq_name
            obj_dict['href'] = self.generate_url('service-template', id)
            obj_dicts.append(obj_dict)

        return {'service-templates': obj_dicts} 
    #end service_templates_http_get

    def _service_template_create_default_children(self, parent_obj):
        pass
    #end _service_template_create_default_children

    def _service_template_delete_default_children(self, parent_obj):
        pass
    #end _service_template_delete_default_children

    def security_group_http_get(self, id):
        # TODO get vals from request out of the global ASAP
        etag = request.headers.get('If-None-Match')
        # common handling for all resource get
        (ok, result) = self._get_common(request, id)
        if not ok:
            (code, msg) = result
            self.config_object_error(id, None, 'security_group', 'http_get', msg)
            abort(code, msg)

        # type-specific hook
        r_class = self._resource_classes.get('security-group', None)
        if r_class:
            r_class.http_get(id)

        db_conn = self._db_conn
        if etag:
            obj_ids = {'uuid': id}
            (ok, result) = db_conn.dbe_is_latest(obj_ids, etag.replace('"', ''))
            if not ok:
                # Not present in DB
                self.config_object_error(id, None, 'security_group', 'http_get', result)
                abort(404, result)

            is_latest = result
            if is_latest:
                # send Not-Modified, caches use this for read optimization
                response.status = 304
                return
        #end if etag

        obj_ids = {'uuid': id}
        if 'fields' in request.query:
            obj_fields = request.query.fields.split(',')
        else:
            obj_fields = None
        (ok, result) = db_conn.dbe_read('security-group', obj_ids, obj_fields)
        if not ok:
            # Not present in DB
            self.config_object_error(id, None, 'security_group', 'http_get', result)
            abort(404, result)

        rsp_body = {}
        rsp_body['uuid'] = id
        rsp_body['href'] = self.generate_url('security-group', id)
        rsp_body['name'] = result['fq_name'][-1]
        rsp_body.update(result)
        id_perms = result['id_perms']
        response.set_header('ETag', '"' + id_perms['last_modified'] + '"')
        return {'security-group': rsp_body} 
    #end security_group_http_get

    def security_group_http_put(self, id):
        key = 'security-group'
        obj_dict = request.json[key]
        # common handling for all resource put
        (ok, result) = self._put_common(request, 'security_group', obj_dict, id)
        if not ok:
            (code, msg) = result
            self.config_object_error(id, None, 'security_group', 'http_put', msg)
            abort(code, msg)

        # type-specific hook
        r_class = self._resource_classes.get('security-group', None)
        if r_class:
            (ok, msg) = r_class.http_put(id, obj_dict)
            if not ok:
                self.config_object_error(id, None, 'security_group', 'http_put', msg)
                abort(409, msg)

        db_conn = self._db_conn


        obj_ids = {'uuid': id}
        (ok, result) = \
             db_conn.dbe_update('security-group', obj_ids, obj_dict)
        if not ok:
            self.config_object_error(id, None, 'security_group', 'http_put', result)
            abort(404, result)

        rsp_body = {}
        rsp_body['uuid'] = id
        rsp_body['href'] = self.generate_url('security-group', id)
        return {'security-group': rsp_body} 
    #end security_group_http_put

    def security_group_http_delete(self, id):
        db_conn = self._db_conn
        # read in obj from db (accepting error) to get details of it
        obj_ids = {'uuid': id}
        (read_ok, read_result) = db_conn.dbe_read('security-group', obj_ids)
        if not read_ok:
            self.config_object_error(id, None, 'security_group', 'http_delete', read_result)
            # proceed down to delete the resource

        # common handling for all resource delete
        parent_type = read_result.get('parent_type', None)
        (ok, del_result) = self._delete_common(request, 'security_group', id, parent_type)
        if not ok:
            (code, msg) = del_result
            self.config_object_error(id, None, 'security_group', 'http_delete', msg)
            abort(code, msg)

        fq_name = read_result['fq_name']
        ifmap_id = common.imid.get_ifmap_id_from_fq_name('security-group', fq_name)
        obj_ids['imid'] = ifmap_id
        if parent_type:
            parent_imid = common.imid.get_ifmap_id_from_fq_name(parent_type, fq_name[:-1])
            obj_ids['parent_imid'] = parent_imid

        # type-specific hook
        r_class = self._resource_classes.get('security-group', None)
        if r_class:
            if read_ok:
                # fail if non-default children or backrefs exist
                virtual_machine_back_refs = read_result.get('virtual_machine_back_refs', None)
                if virtual_machine_back_refs:
                    back_ref_urls = [back_ref_info['href'] for back_ref_info in read_result['virtual_machine_back_refs']]
                    back_ref_str = ', '.join(back_ref_urls)
                    err_msg = 'Back-References from ' + back_ref_str + ' still exist'
                    self.config_object_error(id, None, 'security_group', 'http_delete', err_msg)
                    abort(409, err_msg)


                # Delete default children first
                parent_obj = SecurityGroup.factory(**read_result)
                self._security_group_delete_default_children(parent_obj)

                r_class.http_delete(id, read_result)
            #end if read_ok

        (ok, del_result) = \
             db_conn.dbe_delete('security-group', obj_ids)
        if not ok:
            self.config_object_error(id, None, 'security_group', 'http_delete', del_result)
            abort(409, del_result)

    #end security_group_http_delete
    def security_groups_http_post(self):
        key = 'security-group'
        obj_dict = request.json[key]
        # common handling for all resource create
        (ok, result) = self._post_common(request, 'security-group', obj_dict)
        if not ok:
            (code, msg) = result
            fq_name_str = ':'.join(obj_dict.get('fq_name', []))
            self.config_object_error(None, fq_name_str, 'security_group', 'http_post', msg)
            abort(code, msg)

        # Alloc and Store id-mappings before creating entry on pubsub store.
        # Else a subscriber can ask for an id mapping before we have stored it
        uuid_requested = result
        db_conn = self._db_conn
        (ok, result) = db_conn.dbe_alloc('security-group', obj_dict, uuid_requested)
        if not ok:
            fq_name_str = ':'.join(obj_dict['fq_name'])
            self.config_object_error(None, fq_name_str, 'security_group', 'http_post', result)
            abort(code, result)

        obj_ids = result

        name = obj_dict['fq_name'][-1]
        fq_name = obj_dict['fq_name']


        if 'parent_type' in obj_dict:
            # non config-root child, verify parent exists
            parent_type = obj_dict['parent_type']
            parent_fq_name = obj_dict['fq_name'][:-1]
            try:
                parent_uuid = self._db_conn.fq_name_to_uuid(parent_type, parent_fq_name)
                (ok, status) = self._permissions.check_perms_write(request, parent_uuid)
                if not ok:
                    (code, err_msg) = status
                    abort(code, err_msg)
                self._permissions.set_user_role(request, obj_dict)
            except NoIdError:
                err_msg = 'Parent ' + pformat(parent_fq_name) + ' type ' + parent_type + ' does not exist'
                fq_name_str = ':'.join(parent_fq_name)
                self.config_object_error(None, fq_name_str, 'security_group', 'http_post', err_msg)
                abort(400, err_msg)

        env = request.headers.environ
        tenant_name = env.get(hdr_server_tenant(), 'default-project')


        # type-specific hook
        r_class = self._resource_classes.get('security-group', None)
        if r_class:
            (ok, result) = r_class.http_post_collection(tenant_name, obj_dict)
            if not ok:
                (code, msg) = result
                fq_name_str = ':'.join(fq_name)
                self.config_object_error(None, fq_name_str, 'security_group', 'http_post', msg)
                abort(code, msg)


        (ok, result) = \
             db_conn.dbe_create('security-group', obj_ids, obj_dict)

        if not ok:
            fq_name_str = ':'.join(fq_name)
            self.config_object_error(None, fq_name_str, 'security_group', 'http_post', result)
            abort(404, result)

        rsp_body = {}
        rsp_body['name'] = name
        rsp_body['fq_name'] = fq_name
        rsp_body['uuid'] = obj_ids['uuid']
        rsp_body['href'] = self.generate_url('security-group', obj_ids['uuid'])
        if 'parent_type' in obj_dict:
            # non config-root child, send back parent uuid/href
            rsp_body['parent_uuid'] = parent_uuid
            rsp_body['parent_href'] = self.generate_url(parent_type, parent_uuid)

        parent_obj = SecurityGroup.factory(**rsp_body)
        self._security_group_create_default_children(parent_obj)

        return {'security-group': rsp_body} 
    #end security_groups_http_post

    def security_groups_http_get(self):
        env = request.headers.environ
        tenant_name = env.get(hdr_server_tenant(), 'default-project')
        parent_uuid = None
        resource_id = 'security_groups'
        if (('parent_fq_name_str' in request.query) and
            ('parent_type' in request.query)):
            parent_fq_name = request.query.parent_fq_name_str.split(':')
            parent_type = request.query.parent_type
            parent_uuid = self._db_conn.fq_name_to_uuid(parent_type, parent_fq_name)
        elif 'parent_id' in request.query:
            parent_uuid = str(uuid.UUID(request.query.parent_id))

        if parent_uuid:
            resource_id = parent_uuid

        # common handling for all resource get
        (ok, result) = self._get_common(request, parent_uuid)
        if not ok:
            (code, msg) = result
            self.config_object_error(None, None, 'security_groups', 'http_get_collection', msg)
            abort(code, msg)

        db_conn = self._db_conn
        (ok, result) = \
             db_conn.dbe_list('security-group', parent_uuid)

        if not ok:
            self.config_object_error(None, None, 'security_groups', 'http_get_collection', result)
            abort(404, result)

        fq_names = result
        obj_dicts = []
        for fq_name in fq_names:
            obj_dict = {}
            id = db_conn.fq_name_to_uuid('security_group', fq_name)
            obj_dict['uuid'] = id
            obj_dict['fq_name'] = fq_name
            obj_dict['href'] = self.generate_url('security-group', id)
            obj_dicts.append(obj_dict)

        return {'security-groups': obj_dicts} 
    #end security_groups_http_get

    def _security_group_create_default_children(self, parent_obj):
        pass
    #end _security_group_create_default_children

    def _security_group_delete_default_children(self, parent_obj):
        pass
    #end _security_group_delete_default_children

    def provider_attachment_http_get(self, id):
        # TODO get vals from request out of the global ASAP
        etag = request.headers.get('If-None-Match')
        # common handling for all resource get
        (ok, result) = self._get_common(request, id)
        if not ok:
            (code, msg) = result
            self.config_object_error(id, None, 'provider_attachment', 'http_get', msg)
            abort(code, msg)

        # type-specific hook
        r_class = self._resource_classes.get('provider-attachment', None)
        if r_class:
            r_class.http_get(id)

        db_conn = self._db_conn
        if etag:
            obj_ids = {'uuid': id}
            (ok, result) = db_conn.dbe_is_latest(obj_ids, etag.replace('"', ''))
            if not ok:
                # Not present in DB
                self.config_object_error(id, None, 'provider_attachment', 'http_get', result)
                abort(404, result)

            is_latest = result
            if is_latest:
                # send Not-Modified, caches use this for read optimization
                response.status = 304
                return
        #end if etag

        obj_ids = {'uuid': id}
        if 'fields' in request.query:
            obj_fields = request.query.fields.split(',')
        else:
            obj_fields = None
        (ok, result) = db_conn.dbe_read('provider-attachment', obj_ids, obj_fields)
        if not ok:
            # Not present in DB
            self.config_object_error(id, None, 'provider_attachment', 'http_get', result)
            abort(404, result)

        rsp_body = {}
        rsp_body['uuid'] = id
        rsp_body['href'] = self.generate_url('provider-attachment', id)
        rsp_body['name'] = result['fq_name'][-1]
        rsp_body.update(result)
        id_perms = result['id_perms']
        response.set_header('ETag', '"' + id_perms['last_modified'] + '"')
        return {'provider-attachment': rsp_body} 
    #end provider_attachment_http_get

    def provider_attachment_http_put(self, id):
        key = 'provider-attachment'
        obj_dict = request.json[key]
        # common handling for all resource put
        (ok, result) = self._put_common(request, 'provider_attachment', obj_dict, id)
        if not ok:
            (code, msg) = result
            self.config_object_error(id, None, 'provider_attachment', 'http_put', msg)
            abort(code, msg)

        # type-specific hook
        r_class = self._resource_classes.get('provider-attachment', None)
        if r_class:
            (ok, msg) = r_class.http_put(id, obj_dict)
            if not ok:
                self.config_object_error(id, None, 'provider_attachment', 'http_put', msg)
                abort(409, msg)

        db_conn = self._db_conn

        # Validate perms
        objtype_list = eval("[u'virtual_router']")
        for obj_type in objtype_list:
            refs = obj_dict.get('%s_refs'%(obj_type), None)
            if refs:
                for ref in refs:
                    ref_uuid = db_conn.fq_name_to_uuid(obj_type, ref['to'])
                    (ok, status) = self._permissions.check_perms_link(request, ref_uuid)
                    if not ok:
                        (code, err_msg) = status
                        abort(code, err_msg)

        obj_ids = {'uuid': id}
        (ok, result) = \
             db_conn.dbe_update('provider-attachment', obj_ids, obj_dict)
        if not ok:
            self.config_object_error(id, None, 'provider_attachment', 'http_put', result)
            abort(404, result)

        rsp_body = {}
        rsp_body['uuid'] = id
        rsp_body['href'] = self.generate_url('provider-attachment', id)
        return {'provider-attachment': rsp_body} 
    #end provider_attachment_http_put

    def provider_attachment_http_delete(self, id):
        db_conn = self._db_conn
        # read in obj from db (accepting error) to get details of it
        obj_ids = {'uuid': id}
        (read_ok, read_result) = db_conn.dbe_read('provider-attachment', obj_ids)
        if not read_ok:
            self.config_object_error(id, None, 'provider_attachment', 'http_delete', read_result)
            # proceed down to delete the resource

        # common handling for all resource delete
        parent_type = read_result.get('parent_type', None)
        (ok, del_result) = self._delete_common(request, 'provider_attachment', id, parent_type)
        if not ok:
            (code, msg) = del_result
            self.config_object_error(id, None, 'provider_attachment', 'http_delete', msg)
            abort(code, msg)

        fq_name = read_result['fq_name']
        ifmap_id = common.imid.get_ifmap_id_from_fq_name('provider-attachment', fq_name)
        obj_ids['imid'] = ifmap_id
        if parent_type:
            parent_imid = common.imid.get_ifmap_id_from_fq_name(parent_type, fq_name[:-1])
            obj_ids['parent_imid'] = parent_imid

        # type-specific hook
        r_class = self._resource_classes.get('provider-attachment', None)
        if r_class:
            if read_ok:
                # fail if non-default children or backrefs exist

                # Delete default children first
                parent_obj = ProviderAttachment.factory(**read_result)
                self._provider_attachment_delete_default_children(parent_obj)

                r_class.http_delete(id, read_result)
            #end if read_ok

        (ok, del_result) = \
             db_conn.dbe_delete('provider-attachment', obj_ids)
        if not ok:
            self.config_object_error(id, None, 'provider_attachment', 'http_delete', del_result)
            abort(409, del_result)

    #end provider_attachment_http_delete
    def provider_attachments_http_post(self):
        key = 'provider-attachment'
        obj_dict = request.json[key]
        # common handling for all resource create
        (ok, result) = self._post_common(request, 'provider-attachment', obj_dict)
        if not ok:
            (code, msg) = result
            fq_name_str = ':'.join(obj_dict.get('fq_name', []))
            self.config_object_error(None, fq_name_str, 'provider_attachment', 'http_post', msg)
            abort(code, msg)

        # Alloc and Store id-mappings before creating entry on pubsub store.
        # Else a subscriber can ask for an id mapping before we have stored it
        uuid_requested = result
        db_conn = self._db_conn
        (ok, result) = db_conn.dbe_alloc('provider-attachment', obj_dict, uuid_requested)
        if not ok:
            fq_name_str = ':'.join(obj_dict['fq_name'])
            self.config_object_error(None, fq_name_str, 'provider_attachment', 'http_post', result)
            abort(code, result)

        obj_ids = result

        name = obj_dict['fq_name'][-1]
        fq_name = obj_dict['fq_name']


        env = request.headers.environ
        tenant_name = env.get(hdr_server_tenant(), 'default-project')


        # type-specific hook
        r_class = self._resource_classes.get('provider-attachment', None)
        if r_class:
            (ok, result) = r_class.http_post_collection(tenant_name, obj_dict)
            if not ok:
                (code, msg) = result
                fq_name_str = ':'.join(fq_name)
                self.config_object_error(None, fq_name_str, 'provider_attachment', 'http_post', msg)
                abort(code, msg)

        # Validate perms
        objtype_list = eval("[u'virtual_router']")
        for obj_type in objtype_list:
            refs = obj_dict.get('%s_refs'%(obj_type), None)
            if refs:
                for ref in refs:
                    ref_uuid = db_conn.fq_name_to_uuid(obj_type, ref['to'])
                    (ok, status) = self._permissions.check_perms_link(request, ref_uuid)
                    if not ok:
                        (code, err_msg) = status
                        abort(code, err_msg)

        (ok, result) = \
             db_conn.dbe_create('provider-attachment', obj_ids, obj_dict)

        if not ok:
            fq_name_str = ':'.join(fq_name)
            self.config_object_error(None, fq_name_str, 'provider_attachment', 'http_post', result)
            abort(404, result)

        rsp_body = {}
        rsp_body['name'] = name
        rsp_body['fq_name'] = fq_name
        rsp_body['uuid'] = obj_ids['uuid']
        rsp_body['href'] = self.generate_url('provider-attachment', obj_ids['uuid'])

        parent_obj = ProviderAttachment.factory(**rsp_body)
        self._provider_attachment_create_default_children(parent_obj)

        return {'provider-attachment': rsp_body} 
    #end provider_attachments_http_post

    def provider_attachments_http_get(self):
        env = request.headers.environ
        tenant_name = env.get(hdr_server_tenant(), 'default-project')
        parent_uuid = None
        resource_id = 'provider_attachments'
        if (('parent_fq_name_str' in request.query) and
            ('parent_type' in request.query)):
            parent_fq_name = request.query.parent_fq_name_str.split(':')
            parent_type = request.query.parent_type
            parent_uuid = self._db_conn.fq_name_to_uuid(parent_type, parent_fq_name)
        elif 'parent_id' in request.query:
            parent_uuid = str(uuid.UUID(request.query.parent_id))

        if parent_uuid:
            resource_id = parent_uuid

        # common handling for all resource get
        (ok, result) = self._get_common(request, parent_uuid)
        if not ok:
            (code, msg) = result
            self.config_object_error(None, None, 'provider_attachments', 'http_get_collection', msg)
            abort(code, msg)

        db_conn = self._db_conn
        (ok, result) = \
             db_conn.dbe_list('provider-attachment', parent_uuid)

        if not ok:
            self.config_object_error(None, None, 'provider_attachments', 'http_get_collection', result)
            abort(404, result)

        fq_names = result
        obj_dicts = []
        for fq_name in fq_names:
            obj_dict = {}
            id = db_conn.fq_name_to_uuid('provider_attachment', fq_name)
            obj_dict['uuid'] = id
            obj_dict['fq_name'] = fq_name
            obj_dict['href'] = self.generate_url('provider-attachment', id)
            obj_dicts.append(obj_dict)

        return {'provider-attachments': obj_dicts} 
    #end provider_attachments_http_get

    def _provider_attachment_create_default_children(self, parent_obj):
        pass
    #end _provider_attachment_create_default_children

    def _provider_attachment_delete_default_children(self, parent_obj):
        pass
    #end _provider_attachment_delete_default_children

    def network_ipam_http_get(self, id):
        # TODO get vals from request out of the global ASAP
        etag = request.headers.get('If-None-Match')
        # common handling for all resource get
        (ok, result) = self._get_common(request, id)
        if not ok:
            (code, msg) = result
            self.config_object_error(id, None, 'network_ipam', 'http_get', msg)
            abort(code, msg)

        # type-specific hook
        r_class = self._resource_classes.get('network-ipam', None)
        if r_class:
            r_class.http_get(id)

        db_conn = self._db_conn
        if etag:
            obj_ids = {'uuid': id}
            (ok, result) = db_conn.dbe_is_latest(obj_ids, etag.replace('"', ''))
            if not ok:
                # Not present in DB
                self.config_object_error(id, None, 'network_ipam', 'http_get', result)
                abort(404, result)

            is_latest = result
            if is_latest:
                # send Not-Modified, caches use this for read optimization
                response.status = 304
                return
        #end if etag

        obj_ids = {'uuid': id}
        if 'fields' in request.query:
            obj_fields = request.query.fields.split(',')
        else:
            obj_fields = None
        (ok, result) = db_conn.dbe_read('network-ipam', obj_ids, obj_fields)
        if not ok:
            # Not present in DB
            self.config_object_error(id, None, 'network_ipam', 'http_get', result)
            abort(404, result)

        rsp_body = {}
        rsp_body['uuid'] = id
        rsp_body['href'] = self.generate_url('network-ipam', id)
        rsp_body['name'] = result['fq_name'][-1]
        rsp_body.update(result)
        id_perms = result['id_perms']
        response.set_header('ETag', '"' + id_perms['last_modified'] + '"')
        return {'network-ipam': rsp_body} 
    #end network_ipam_http_get

    def network_ipam_http_put(self, id):
        key = 'network-ipam'
        obj_dict = request.json[key]
        # common handling for all resource put
        (ok, result) = self._put_common(request, 'network_ipam', obj_dict, id)
        if not ok:
            (code, msg) = result
            self.config_object_error(id, None, 'network_ipam', 'http_put', msg)
            abort(code, msg)

        # type-specific hook
        r_class = self._resource_classes.get('network-ipam', None)
        if r_class:
            (ok, msg) = r_class.http_put(id, obj_dict)
            if not ok:
                self.config_object_error(id, None, 'network_ipam', 'http_put', msg)
                abort(409, msg)

        db_conn = self._db_conn

        # Validate perms
        objtype_list = eval("[u'virtual_DNS']")
        for obj_type in objtype_list:
            refs = obj_dict.get('%s_refs'%(obj_type), None)
            if refs:
                for ref in refs:
                    ref_uuid = db_conn.fq_name_to_uuid(obj_type, ref['to'])
                    (ok, status) = self._permissions.check_perms_link(request, ref_uuid)
                    if not ok:
                        (code, err_msg) = status
                        abort(code, err_msg)

        obj_ids = {'uuid': id}
        (ok, result) = \
             db_conn.dbe_update('network-ipam', obj_ids, obj_dict)
        if not ok:
            self.config_object_error(id, None, 'network_ipam', 'http_put', result)
            abort(404, result)

        rsp_body = {}
        rsp_body['uuid'] = id
        rsp_body['href'] = self.generate_url('network-ipam', id)
        return {'network-ipam': rsp_body} 
    #end network_ipam_http_put

    def network_ipam_http_delete(self, id):
        db_conn = self._db_conn
        # read in obj from db (accepting error) to get details of it
        obj_ids = {'uuid': id}
        (read_ok, read_result) = db_conn.dbe_read('network-ipam', obj_ids)
        if not read_ok:
            self.config_object_error(id, None, 'network_ipam', 'http_delete', read_result)
            # proceed down to delete the resource

        # common handling for all resource delete
        parent_type = read_result.get('parent_type', None)
        (ok, del_result) = self._delete_common(request, 'network_ipam', id, parent_type)
        if not ok:
            (code, msg) = del_result
            self.config_object_error(id, None, 'network_ipam', 'http_delete', msg)
            abort(code, msg)

        fq_name = read_result['fq_name']
        ifmap_id = common.imid.get_ifmap_id_from_fq_name('network-ipam', fq_name)
        obj_ids['imid'] = ifmap_id
        if parent_type:
            parent_imid = common.imid.get_ifmap_id_from_fq_name(parent_type, fq_name[:-1])
            obj_ids['parent_imid'] = parent_imid

        # type-specific hook
        r_class = self._resource_classes.get('network-ipam', None)
        if r_class:
            if read_ok:
                # fail if non-default children or backrefs exist
                virtual_network_back_refs = read_result.get('virtual_network_back_refs', None)
                if virtual_network_back_refs:
                    back_ref_urls = [back_ref_info['href'] for back_ref_info in read_result['virtual_network_back_refs']]
                    back_ref_str = ', '.join(back_ref_urls)
                    err_msg = 'Back-References from ' + back_ref_str + ' still exist'
                    self.config_object_error(id, None, 'network_ipam', 'http_delete', err_msg)
                    abort(409, err_msg)


                # Delete default children first
                parent_obj = NetworkIpam.factory(**read_result)
                self._network_ipam_delete_default_children(parent_obj)

                r_class.http_delete(id, read_result)
            #end if read_ok

        (ok, del_result) = \
             db_conn.dbe_delete('network-ipam', obj_ids)
        if not ok:
            self.config_object_error(id, None, 'network_ipam', 'http_delete', del_result)
            abort(409, del_result)

    #end network_ipam_http_delete
    def network_ipams_http_post(self):
        key = 'network-ipam'
        obj_dict = request.json[key]
        # common handling for all resource create
        (ok, result) = self._post_common(request, 'network-ipam', obj_dict)
        if not ok:
            (code, msg) = result
            fq_name_str = ':'.join(obj_dict.get('fq_name', []))
            self.config_object_error(None, fq_name_str, 'network_ipam', 'http_post', msg)
            abort(code, msg)

        # Alloc and Store id-mappings before creating entry on pubsub store.
        # Else a subscriber can ask for an id mapping before we have stored it
        uuid_requested = result
        db_conn = self._db_conn
        (ok, result) = db_conn.dbe_alloc('network-ipam', obj_dict, uuid_requested)
        if not ok:
            fq_name_str = ':'.join(obj_dict['fq_name'])
            self.config_object_error(None, fq_name_str, 'network_ipam', 'http_post', result)
            abort(code, result)

        obj_ids = result

        name = obj_dict['fq_name'][-1]
        fq_name = obj_dict['fq_name']


        if 'parent_type' in obj_dict:
            # non config-root child, verify parent exists
            parent_type = obj_dict['parent_type']
            parent_fq_name = obj_dict['fq_name'][:-1]
            try:
                parent_uuid = self._db_conn.fq_name_to_uuid(parent_type, parent_fq_name)
                (ok, status) = self._permissions.check_perms_write(request, parent_uuid)
                if not ok:
                    (code, err_msg) = status
                    abort(code, err_msg)
                self._permissions.set_user_role(request, obj_dict)
            except NoIdError:
                err_msg = 'Parent ' + pformat(parent_fq_name) + ' type ' + parent_type + ' does not exist'
                fq_name_str = ':'.join(parent_fq_name)
                self.config_object_error(None, fq_name_str, 'network_ipam', 'http_post', err_msg)
                abort(400, err_msg)

        env = request.headers.environ
        tenant_name = env.get(hdr_server_tenant(), 'default-project')


        # type-specific hook
        r_class = self._resource_classes.get('network-ipam', None)
        if r_class:
            (ok, result) = r_class.http_post_collection(tenant_name, obj_dict)
            if not ok:
                (code, msg) = result
                fq_name_str = ':'.join(fq_name)
                self.config_object_error(None, fq_name_str, 'network_ipam', 'http_post', msg)
                abort(code, msg)

        # Validate perms
        objtype_list = eval("[u'virtual_DNS']")
        for obj_type in objtype_list:
            refs = obj_dict.get('%s_refs'%(obj_type), None)
            if refs:
                for ref in refs:
                    ref_uuid = db_conn.fq_name_to_uuid(obj_type, ref['to'])
                    (ok, status) = self._permissions.check_perms_link(request, ref_uuid)
                    if not ok:
                        (code, err_msg) = status
                        abort(code, err_msg)

        (ok, result) = \
             db_conn.dbe_create('network-ipam', obj_ids, obj_dict)

        if not ok:
            fq_name_str = ':'.join(fq_name)
            self.config_object_error(None, fq_name_str, 'network_ipam', 'http_post', result)
            abort(404, result)

        rsp_body = {}
        rsp_body['name'] = name
        rsp_body['fq_name'] = fq_name
        rsp_body['uuid'] = obj_ids['uuid']
        rsp_body['href'] = self.generate_url('network-ipam', obj_ids['uuid'])
        if 'parent_type' in obj_dict:
            # non config-root child, send back parent uuid/href
            rsp_body['parent_uuid'] = parent_uuid
            rsp_body['parent_href'] = self.generate_url(parent_type, parent_uuid)

        parent_obj = NetworkIpam.factory(**rsp_body)
        self._network_ipam_create_default_children(parent_obj)

        return {'network-ipam': rsp_body} 
    #end network_ipams_http_post

    def network_ipams_http_get(self):
        env = request.headers.environ
        tenant_name = env.get(hdr_server_tenant(), 'default-project')
        parent_uuid = None
        resource_id = 'network_ipams'
        if (('parent_fq_name_str' in request.query) and
            ('parent_type' in request.query)):
            parent_fq_name = request.query.parent_fq_name_str.split(':')
            parent_type = request.query.parent_type
            parent_uuid = self._db_conn.fq_name_to_uuid(parent_type, parent_fq_name)
        elif 'parent_id' in request.query:
            parent_uuid = str(uuid.UUID(request.query.parent_id))

        if parent_uuid:
            resource_id = parent_uuid

        # common handling for all resource get
        (ok, result) = self._get_common(request, parent_uuid)
        if not ok:
            (code, msg) = result
            self.config_object_error(None, None, 'network_ipams', 'http_get_collection', msg)
            abort(code, msg)

        db_conn = self._db_conn
        (ok, result) = \
             db_conn.dbe_list('network-ipam', parent_uuid)

        if not ok:
            self.config_object_error(None, None, 'network_ipams', 'http_get_collection', result)
            abort(404, result)

        fq_names = result
        obj_dicts = []
        for fq_name in fq_names:
            obj_dict = {}
            id = db_conn.fq_name_to_uuid('network_ipam', fq_name)
            obj_dict['uuid'] = id
            obj_dict['fq_name'] = fq_name
            obj_dict['href'] = self.generate_url('network-ipam', id)
            obj_dicts.append(obj_dict)

        return {'network-ipams': obj_dicts} 
    #end network_ipams_http_get

    def _network_ipam_create_default_children(self, parent_obj):
        pass
    #end _network_ipam_create_default_children

    def _network_ipam_delete_default_children(self, parent_obj):
        pass
    #end _network_ipam_delete_default_children

    def virtual_network_http_get(self, id):
        # TODO get vals from request out of the global ASAP
        etag = request.headers.get('If-None-Match')
        # common handling for all resource get
        (ok, result) = self._get_common(request, id)
        if not ok:
            (code, msg) = result
            self.config_object_error(id, None, 'virtual_network', 'http_get', msg)
            abort(code, msg)

        # type-specific hook
        r_class = self._resource_classes.get('virtual-network', None)
        if r_class:
            r_class.http_get(id)

        db_conn = self._db_conn
        if etag:
            obj_ids = {'uuid': id}
            (ok, result) = db_conn.dbe_is_latest(obj_ids, etag.replace('"', ''))
            if not ok:
                # Not present in DB
                self.config_object_error(id, None, 'virtual_network', 'http_get', result)
                abort(404, result)

            is_latest = result
            if is_latest:
                # send Not-Modified, caches use this for read optimization
                response.status = 304
                return
        #end if etag

        obj_ids = {'uuid': id}
        if 'fields' in request.query:
            obj_fields = request.query.fields.split(',')
        else:
            obj_fields = None
        (ok, result) = db_conn.dbe_read('virtual-network', obj_ids, obj_fields)
        if not ok:
            # Not present in DB
            self.config_object_error(id, None, 'virtual_network', 'http_get', result)
            abort(404, result)

        rsp_body = {}
        rsp_body['uuid'] = id
        rsp_body['href'] = self.generate_url('virtual-network', id)
        rsp_body['name'] = result['fq_name'][-1]
        rsp_body.update(result)
        id_perms = result['id_perms']
        response.set_header('ETag', '"' + id_perms['last_modified'] + '"')
        return {'virtual-network': rsp_body} 
    #end virtual_network_http_get

    def virtual_network_http_put(self, id):
        key = 'virtual-network'
        obj_dict = request.json[key]
        # common handling for all resource put
        (ok, result) = self._put_common(request, 'virtual_network', obj_dict, id)
        if not ok:
            (code, msg) = result
            self.config_object_error(id, None, 'virtual_network', 'http_put', msg)
            abort(code, msg)

        # type-specific hook
        r_class = self._resource_classes.get('virtual-network', None)
        if r_class:
            (ok, msg) = r_class.http_put(id, obj_dict)
            if not ok:
                self.config_object_error(id, None, 'virtual_network', 'http_put', msg)
                abort(409, msg)

        db_conn = self._db_conn

        # Validate perms
        objtype_list = eval("[u'network_ipam', u'network_policy', u'access_control_list', u'floating_ip_pool', 'routing_instance']")
        for obj_type in objtype_list:
            refs = obj_dict.get('%s_refs'%(obj_type), None)
            if refs:
                for ref in refs:
                    ref_uuid = db_conn.fq_name_to_uuid(obj_type, ref['to'])
                    (ok, status) = self._permissions.check_perms_link(request, ref_uuid)
                    if not ok:
                        (code, err_msg) = status
                        abort(code, err_msg)

        obj_ids = {'uuid': id}
        (ok, result) = \
             db_conn.dbe_update('virtual-network', obj_ids, obj_dict)
        if not ok:
            self.config_object_error(id, None, 'virtual_network', 'http_put', result)
            abort(404, result)

        rsp_body = {}
        rsp_body['uuid'] = id
        rsp_body['href'] = self.generate_url('virtual-network', id)
        return {'virtual-network': rsp_body} 
    #end virtual_network_http_put

    def virtual_network_http_delete(self, id):
        db_conn = self._db_conn
        # read in obj from db (accepting error) to get details of it
        obj_ids = {'uuid': id}
        (read_ok, read_result) = db_conn.dbe_read('virtual-network', obj_ids)
        if not read_ok:
            self.config_object_error(id, None, 'virtual_network', 'http_delete', read_result)
            # proceed down to delete the resource

        # common handling for all resource delete
        parent_type = read_result.get('parent_type', None)
        (ok, del_result) = self._delete_common(request, 'virtual_network', id, parent_type)
        if not ok:
            (code, msg) = del_result
            self.config_object_error(id, None, 'virtual_network', 'http_delete', msg)
            abort(code, msg)

        fq_name = read_result['fq_name']
        ifmap_id = common.imid.get_ifmap_id_from_fq_name('virtual-network', fq_name)
        obj_ids['imid'] = ifmap_id
        if parent_type:
            parent_imid = common.imid.get_ifmap_id_from_fq_name(parent_type, fq_name[:-1])
            obj_ids['parent_imid'] = parent_imid

        # type-specific hook
        r_class = self._resource_classes.get('virtual-network', None)
        if r_class:
            if read_ok:
                # fail if non-default children or backrefs exist
                floating_ip_pools = read_result.get('floating_ip_pools', None)
                if floating_ip_pools:
                    has_infos = read_result['floating_ip_pools']
                    if ((len(has_infos) > 1) or 
                        (len(has_infos) == 1 and has_infos[0]['to'][-1] != 'default-floating-ip-pool')):
                        has_urls = [has_info['href'] for has_info in has_infos]
                        has_str = ', '.join(has_urls)
                        err_msg = 'Children ' + has_str + ' still exist'
                        self.config_object_error(id, None, 'virtual_network', 'http_delete', err_msg)
                        abort(409, err_msg)

                virtual_machine_interface_back_refs = read_result.get('virtual_machine_interface_back_refs', None)
                if virtual_machine_interface_back_refs:
                    back_ref_urls = [back_ref_info['href'] for back_ref_info in read_result['virtual_machine_interface_back_refs']]
                    back_ref_str = ', '.join(back_ref_urls)
                    err_msg = 'Back-References from ' + back_ref_str + ' still exist'
                    self.config_object_error(id, None, 'virtual_network', 'http_delete', err_msg)
                    abort(409, err_msg)

                instance_ip_back_refs = read_result.get('instance_ip_back_refs', None)
                if instance_ip_back_refs:
                    back_ref_urls = [back_ref_info['href'] for back_ref_info in read_result['instance_ip_back_refs']]
                    back_ref_str = ', '.join(back_ref_urls)
                    err_msg = 'Back-References from ' + back_ref_str + ' still exist'
                    self.config_object_error(id, None, 'virtual_network', 'http_delete', err_msg)
                    abort(409, err_msg)

                logical_interface_back_refs = read_result.get('logical_interface_back_refs', None)
                if logical_interface_back_refs:
                    back_ref_urls = [back_ref_info['href'] for back_ref_info in read_result['logical_interface_back_refs']]
                    back_ref_str = ', '.join(back_ref_urls)
                    err_msg = 'Back-References from ' + back_ref_str + ' still exist'
                    self.config_object_error(id, None, 'virtual_network', 'http_delete', err_msg)
                    abort(409, err_msg)


                # Delete default children first
                parent_obj = VirtualNetwork.factory(**read_result)
                self._virtual_network_delete_default_children(parent_obj)

                r_class.http_delete(id, read_result)
            #end if read_ok

        (ok, del_result) = \
             db_conn.dbe_delete('virtual-network', obj_ids)
        if not ok:
            self.config_object_error(id, None, 'virtual_network', 'http_delete', del_result)
            abort(409, del_result)

    #end virtual_network_http_delete
    def virtual_networks_http_post(self):
        key = 'virtual-network'
        obj_dict = request.json[key]
        # common handling for all resource create
        (ok, result) = self._post_common(request, 'virtual-network', obj_dict)
        if not ok:
            (code, msg) = result
            fq_name_str = ':'.join(obj_dict.get('fq_name', []))
            self.config_object_error(None, fq_name_str, 'virtual_network', 'http_post', msg)
            abort(code, msg)

        # Alloc and Store id-mappings before creating entry on pubsub store.
        # Else a subscriber can ask for an id mapping before we have stored it
        uuid_requested = result
        db_conn = self._db_conn
        (ok, result) = db_conn.dbe_alloc('virtual-network', obj_dict, uuid_requested)
        if not ok:
            fq_name_str = ':'.join(obj_dict['fq_name'])
            self.config_object_error(None, fq_name_str, 'virtual_network', 'http_post', result)
            abort(code, result)

        obj_ids = result

        name = obj_dict['fq_name'][-1]
        fq_name = obj_dict['fq_name']


        if 'parent_type' in obj_dict:
            # non config-root child, verify parent exists
            parent_type = obj_dict['parent_type']
            parent_fq_name = obj_dict['fq_name'][:-1]
            try:
                parent_uuid = self._db_conn.fq_name_to_uuid(parent_type, parent_fq_name)
                (ok, status) = self._permissions.check_perms_write(request, parent_uuid)
                if not ok:
                    (code, err_msg) = status
                    abort(code, err_msg)
                self._permissions.set_user_role(request, obj_dict)
            except NoIdError:
                err_msg = 'Parent ' + pformat(parent_fq_name) + ' type ' + parent_type + ' does not exist'
                fq_name_str = ':'.join(parent_fq_name)
                self.config_object_error(None, fq_name_str, 'virtual_network', 'http_post', err_msg)
                abort(400, err_msg)

        env = request.headers.environ
        tenant_name = env.get(hdr_server_tenant(), 'default-project')


        # type-specific hook
        r_class = self._resource_classes.get('virtual-network', None)
        if r_class:
            (ok, result) = r_class.http_post_collection(tenant_name, obj_dict)
            if not ok:
                (code, msg) = result
                fq_name_str = ':'.join(fq_name)
                self.config_object_error(None, fq_name_str, 'virtual_network', 'http_post', msg)
                abort(code, msg)

        # Validate perms
        objtype_list = eval("[u'network_ipam', u'network_policy', u'access_control_list', u'floating_ip_pool', 'routing_instance']")
        for obj_type in objtype_list:
            refs = obj_dict.get('%s_refs'%(obj_type), None)
            if refs:
                for ref in refs:
                    ref_uuid = db_conn.fq_name_to_uuid(obj_type, ref['to'])
                    (ok, status) = self._permissions.check_perms_link(request, ref_uuid)
                    if not ok:
                        (code, err_msg) = status
                        abort(code, err_msg)

        (ok, result) = \
             db_conn.dbe_create('virtual-network', obj_ids, obj_dict)

        if not ok:
            fq_name_str = ':'.join(fq_name)
            self.config_object_error(None, fq_name_str, 'virtual_network', 'http_post', result)
            abort(404, result)

        rsp_body = {}
        rsp_body['name'] = name
        rsp_body['fq_name'] = fq_name
        rsp_body['uuid'] = obj_ids['uuid']
        rsp_body['href'] = self.generate_url('virtual-network', obj_ids['uuid'])
        if 'parent_type' in obj_dict:
            # non config-root child, send back parent uuid/href
            rsp_body['parent_uuid'] = parent_uuid
            rsp_body['parent_href'] = self.generate_url(parent_type, parent_uuid)

        parent_obj = VirtualNetwork.factory(**rsp_body)
        self._virtual_network_create_default_children(parent_obj)

        return {'virtual-network': rsp_body} 
    #end virtual_networks_http_post

    def virtual_networks_http_get(self):
        env = request.headers.environ
        tenant_name = env.get(hdr_server_tenant(), 'default-project')
        parent_uuid = None
        resource_id = 'virtual_networks'
        if (('parent_fq_name_str' in request.query) and
            ('parent_type' in request.query)):
            parent_fq_name = request.query.parent_fq_name_str.split(':')
            parent_type = request.query.parent_type
            parent_uuid = self._db_conn.fq_name_to_uuid(parent_type, parent_fq_name)
        elif 'parent_id' in request.query:
            parent_uuid = str(uuid.UUID(request.query.parent_id))

        if parent_uuid:
            resource_id = parent_uuid

        # common handling for all resource get
        (ok, result) = self._get_common(request, parent_uuid)
        if not ok:
            (code, msg) = result
            self.config_object_error(None, None, 'virtual_networks', 'http_get_collection', msg)
            abort(code, msg)

        db_conn = self._db_conn
        (ok, result) = \
             db_conn.dbe_list('virtual-network', parent_uuid)

        if not ok:
            self.config_object_error(None, None, 'virtual_networks', 'http_get_collection', result)
            abort(404, result)

        fq_names = result
        obj_dicts = []
        for fq_name in fq_names:
            obj_dict = {}
            id = db_conn.fq_name_to_uuid('virtual_network', fq_name)
            obj_dict['uuid'] = id
            obj_dict['fq_name'] = fq_name
            obj_dict['href'] = self.generate_url('virtual-network', id)
            obj_dicts.append(obj_dict)

        return {'virtual-networks': obj_dicts} 
    #end virtual_networks_http_get

    def _virtual_network_create_default_children(self, parent_obj):
        # Create a default child only if provisioned for
        r_class = self._resource_classes.get('floating-ip-pool', None)
        if r_class.generate_default_instance:
            child_obj = FloatingIpPool(parent_obj = parent_obj)
            child_dict = child_obj.__dict__
            fq_name = child_dict['fq_name']
            child_dict['id_perms'] = self._get_default_id_perms('floating-ip-pool')

            db_conn = self._db_conn
            (ok, result) = db_conn.dbe_alloc('floating-ip-pool', child_dict)
            if not ok:
                return (ok, result)

            obj_ids = result
            db_conn.dbe_create('floating-ip-pool', obj_ids, child_dict)
            self._floating_ip_pool_create_default_children(child_obj)

        pass
    #end _virtual_network_create_default_children

    def _virtual_network_delete_default_children(self, parent_obj):
        # Delete a default child only if provisioned for
        r_class = self._resource_classes.get('floating-ip-pool', None)
        if r_class.generate_default_instance:
            # first locate default child then delete it
            has_infos = parent_obj.get_access_control_lists()
            if has_infos:
                for has_info in has_infos:
                    if has_info['to'][-1] == 'default-access-control-list':
                        default_child_id = has_info['href'].split('/')[-1]
                        self.access_control_list_http_delete(default_child_id)
                        break

        # Delete a default child only if provisioned for
        r_class = self._resource_classes.get('floating-ip-pool', None)
        if r_class.generate_default_instance:
            # first locate default child then delete it
            has_infos = parent_obj.get_floating_ip_pools()
            if has_infos:
                for has_info in has_infos:
                    if has_info['to'][-1] == 'default-floating-ip-pool':
                        default_child_id = has_info['href'].split('/')[-1]
                        self.floating_ip_pool_http_delete(default_child_id)
                        break

        # Delete a default child only if provisioned for
        r_class = self._resource_classes.get('floating-ip-pool', None)
        if r_class.generate_default_instance:
            # first locate default child then delete it
            has_infos = parent_obj.get_routing_instances()
            if has_infos:
                for has_info in has_infos:
                    if has_info['to'][-1] == 'default-routing-instance':
                        default_child_id = has_info['href'].split('/')[-1]
                        self.routing_instance_http_delete(default_child_id)
                        break

        pass
    #end _virtual_network_delete_default_children

    def project_http_get(self, id):
        # TODO get vals from request out of the global ASAP
        etag = request.headers.get('If-None-Match')
        # common handling for all resource get
        (ok, result) = self._get_common(request, id)
        if not ok:
            (code, msg) = result
            self.config_object_error(id, None, 'project', 'http_get', msg)
            abort(code, msg)

        # type-specific hook
        r_class = self._resource_classes.get('project', None)
        if r_class:
            r_class.http_get(id)

        db_conn = self._db_conn
        if etag:
            obj_ids = {'uuid': id}
            (ok, result) = db_conn.dbe_is_latest(obj_ids, etag.replace('"', ''))
            if not ok:
                # Not present in DB
                self.config_object_error(id, None, 'project', 'http_get', result)
                abort(404, result)

            is_latest = result
            if is_latest:
                # send Not-Modified, caches use this for read optimization
                response.status = 304
                return
        #end if etag

        obj_ids = {'uuid': id}
        if 'fields' in request.query:
            obj_fields = request.query.fields.split(',')
        else:
            obj_fields = None
        (ok, result) = db_conn.dbe_read('project', obj_ids, obj_fields)
        if not ok:
            # Not present in DB
            self.config_object_error(id, None, 'project', 'http_get', result)
            abort(404, result)

        rsp_body = {}
        rsp_body['uuid'] = id
        rsp_body['href'] = self.generate_url('project', id)
        rsp_body['name'] = result['fq_name'][-1]
        rsp_body.update(result)
        id_perms = result['id_perms']
        response.set_header('ETag', '"' + id_perms['last_modified'] + '"')
        return {'project': rsp_body} 
    #end project_http_get

    def project_http_put(self, id):
        key = 'project'
        obj_dict = request.json[key]
        # common handling for all resource put
        (ok, result) = self._put_common(request, 'project', obj_dict, id)
        if not ok:
            (code, msg) = result
            self.config_object_error(id, None, 'project', 'http_put', msg)
            abort(code, msg)

        # type-specific hook
        r_class = self._resource_classes.get('project', None)
        if r_class:
            (ok, msg) = r_class.http_put(id, obj_dict)
            if not ok:
                self.config_object_error(id, None, 'project', 'http_put', msg)
                abort(409, msg)

        db_conn = self._db_conn

        # Validate perms
        objtype_list = eval("[u'namespace', u'security_group', u'virtual_network', u'network_ipam', u'network_policy', u'floating_ip_pool', u'service_instance']")
        for obj_type in objtype_list:
            refs = obj_dict.get('%s_refs'%(obj_type), None)
            if refs:
                for ref in refs:
                    ref_uuid = db_conn.fq_name_to_uuid(obj_type, ref['to'])
                    (ok, status) = self._permissions.check_perms_link(request, ref_uuid)
                    if not ok:
                        (code, err_msg) = status
                        abort(code, err_msg)

        obj_ids = {'uuid': id}
        (ok, result) = \
             db_conn.dbe_update('project', obj_ids, obj_dict)
        if not ok:
            self.config_object_error(id, None, 'project', 'http_put', result)
            abort(404, result)

        rsp_body = {}
        rsp_body['uuid'] = id
        rsp_body['href'] = self.generate_url('project', id)
        return {'project': rsp_body} 
    #end project_http_put

    def project_http_delete(self, id):
        db_conn = self._db_conn
        # read in obj from db (accepting error) to get details of it
        obj_ids = {'uuid': id}
        (read_ok, read_result) = db_conn.dbe_read('project', obj_ids)
        if not read_ok:
            self.config_object_error(id, None, 'project', 'http_delete', read_result)
            # proceed down to delete the resource

        # common handling for all resource delete
        parent_type = read_result.get('parent_type', None)
        (ok, del_result) = self._delete_common(request, 'project', id, parent_type)
        if not ok:
            (code, msg) = del_result
            self.config_object_error(id, None, 'project', 'http_delete', msg)
            abort(code, msg)

        fq_name = read_result['fq_name']
        ifmap_id = common.imid.get_ifmap_id_from_fq_name('project', fq_name)
        obj_ids['imid'] = ifmap_id
        if parent_type:
            parent_imid = common.imid.get_ifmap_id_from_fq_name(parent_type, fq_name[:-1])
            obj_ids['parent_imid'] = parent_imid

        # type-specific hook
        r_class = self._resource_classes.get('project', None)
        if r_class:
            if read_ok:
                # fail if non-default children or backrefs exist
                security_groups = read_result.get('security_groups', None)
                if security_groups:
                    has_infos = read_result['security_groups']
                    if ((len(has_infos) > 1) or 
                        (len(has_infos) == 1 and has_infos[0]['to'][-1] != 'default-security-group')):
                        has_urls = [has_info['href'] for has_info in has_infos]
                        has_str = ', '.join(has_urls)
                        err_msg = 'Children ' + has_str + ' still exist'
                        self.config_object_error(id, None, 'project', 'http_delete', err_msg)
                        abort(409, err_msg)

                virtual_networks = read_result.get('virtual_networks', None)
                if virtual_networks:
                    has_infos = read_result['virtual_networks']
                    if ((len(has_infos) > 1) or 
                        (len(has_infos) == 1 and has_infos[0]['to'][-1] != 'default-virtual-network')):
                        has_urls = [has_info['href'] for has_info in has_infos]
                        has_str = ', '.join(has_urls)
                        err_msg = 'Children ' + has_str + ' still exist'
                        self.config_object_error(id, None, 'project', 'http_delete', err_msg)
                        abort(409, err_msg)

                network_ipams = read_result.get('network_ipams', None)
                if network_ipams:
                    has_infos = read_result['network_ipams']
                    if ((len(has_infos) > 1) or 
                        (len(has_infos) == 1 and has_infos[0]['to'][-1] != 'default-network-ipam')):
                        has_urls = [has_info['href'] for has_info in has_infos]
                        has_str = ', '.join(has_urls)
                        err_msg = 'Children ' + has_str + ' still exist'
                        self.config_object_error(id, None, 'project', 'http_delete', err_msg)
                        abort(409, err_msg)

                network_policys = read_result.get('network_policys', None)
                if network_policys:
                    has_infos = read_result['network_policys']
                    if ((len(has_infos) > 1) or 
                        (len(has_infos) == 1 and has_infos[0]['to'][-1] != 'default-network-policy')):
                        has_urls = [has_info['href'] for has_info in has_infos]
                        has_str = ', '.join(has_urls)
                        err_msg = 'Children ' + has_str + ' still exist'
                        self.config_object_error(id, None, 'project', 'http_delete', err_msg)
                        abort(409, err_msg)

                service_instances = read_result.get('service_instances', None)
                if service_instances:
                    has_infos = read_result['service_instances']
                    if ((len(has_infos) > 1) or 
                        (len(has_infos) == 1 and has_infos[0]['to'][-1] != 'default-service-instance')):
                        has_urls = [has_info['href'] for has_info in has_infos]
                        has_str = ', '.join(has_urls)
                        err_msg = 'Children ' + has_str + ' still exist'
                        self.config_object_error(id, None, 'project', 'http_delete', err_msg)
                        abort(409, err_msg)

                floating_ip_back_refs = read_result.get('floating_ip_back_refs', None)
                if floating_ip_back_refs:
                    back_ref_urls = [back_ref_info['href'] for back_ref_info in read_result['floating_ip_back_refs']]
                    back_ref_str = ', '.join(back_ref_urls)
                    err_msg = 'Back-References from ' + back_ref_str + ' still exist'
                    self.config_object_error(id, None, 'project', 'http_delete', err_msg)
                    abort(409, err_msg)


                # Delete default children first
                parent_obj = Project.factory(**read_result)
                self._project_delete_default_children(parent_obj)

                r_class.http_delete(id, read_result)
            #end if read_ok

        (ok, del_result) = \
             db_conn.dbe_delete('project', obj_ids)
        if not ok:
            self.config_object_error(id, None, 'project', 'http_delete', del_result)
            abort(409, del_result)

    #end project_http_delete
    def projects_http_post(self):
        key = 'project'
        obj_dict = request.json[key]
        # common handling for all resource create
        (ok, result) = self._post_common(request, 'project', obj_dict)
        if not ok:
            (code, msg) = result
            fq_name_str = ':'.join(obj_dict.get('fq_name', []))
            self.config_object_error(None, fq_name_str, 'project', 'http_post', msg)
            abort(code, msg)

        # Alloc and Store id-mappings before creating entry on pubsub store.
        # Else a subscriber can ask for an id mapping before we have stored it
        uuid_requested = result
        db_conn = self._db_conn
        (ok, result) = db_conn.dbe_alloc('project', obj_dict, uuid_requested)
        if not ok:
            fq_name_str = ':'.join(obj_dict['fq_name'])
            self.config_object_error(None, fq_name_str, 'project', 'http_post', result)
            abort(code, result)

        obj_ids = result

        name = obj_dict['fq_name'][-1]
        fq_name = obj_dict['fq_name']


        if 'parent_type' in obj_dict:
            # non config-root child, verify parent exists
            parent_type = obj_dict['parent_type']
            parent_fq_name = obj_dict['fq_name'][:-1]
            try:
                parent_uuid = self._db_conn.fq_name_to_uuid(parent_type, parent_fq_name)
                (ok, status) = self._permissions.check_perms_write(request, parent_uuid)
                if not ok:
                    (code, err_msg) = status
                    abort(code, err_msg)
                self._permissions.set_user_role(request, obj_dict)
            except NoIdError:
                err_msg = 'Parent ' + pformat(parent_fq_name) + ' type ' + parent_type + ' does not exist'
                fq_name_str = ':'.join(parent_fq_name)
                self.config_object_error(None, fq_name_str, 'project', 'http_post', err_msg)
                abort(400, err_msg)

        env = request.headers.environ
        tenant_name = env.get(hdr_server_tenant(), 'default-project')


        # type-specific hook
        r_class = self._resource_classes.get('project', None)
        if r_class:
            (ok, result) = r_class.http_post_collection(tenant_name, obj_dict)
            if not ok:
                (code, msg) = result
                fq_name_str = ':'.join(fq_name)
                self.config_object_error(None, fq_name_str, 'project', 'http_post', msg)
                abort(code, msg)

        # Validate perms
        objtype_list = eval("[u'namespace', u'security_group', u'virtual_network', u'network_ipam', u'network_policy', u'floating_ip_pool', u'service_instance']")
        for obj_type in objtype_list:
            refs = obj_dict.get('%s_refs'%(obj_type), None)
            if refs:
                for ref in refs:
                    ref_uuid = db_conn.fq_name_to_uuid(obj_type, ref['to'])
                    (ok, status) = self._permissions.check_perms_link(request, ref_uuid)
                    if not ok:
                        (code, err_msg) = status
                        abort(code, err_msg)

        (ok, result) = \
             db_conn.dbe_create('project', obj_ids, obj_dict)

        if not ok:
            fq_name_str = ':'.join(fq_name)
            self.config_object_error(None, fq_name_str, 'project', 'http_post', result)
            abort(404, result)

        rsp_body = {}
        rsp_body['name'] = name
        rsp_body['fq_name'] = fq_name
        rsp_body['uuid'] = obj_ids['uuid']
        rsp_body['href'] = self.generate_url('project', obj_ids['uuid'])
        if 'parent_type' in obj_dict:
            # non config-root child, send back parent uuid/href
            rsp_body['parent_uuid'] = parent_uuid
            rsp_body['parent_href'] = self.generate_url(parent_type, parent_uuid)

        parent_obj = Project.factory(**rsp_body)
        self._project_create_default_children(parent_obj)

        return {'project': rsp_body} 
    #end projects_http_post

    def projects_http_get(self):
        env = request.headers.environ
        tenant_name = env.get(hdr_server_tenant(), 'default-project')
        parent_uuid = None
        resource_id = 'projects'
        if (('parent_fq_name_str' in request.query) and
            ('parent_type' in request.query)):
            parent_fq_name = request.query.parent_fq_name_str.split(':')
            parent_type = request.query.parent_type
            parent_uuid = self._db_conn.fq_name_to_uuid(parent_type, parent_fq_name)
        elif 'parent_id' in request.query:
            parent_uuid = str(uuid.UUID(request.query.parent_id))

        if parent_uuid:
            resource_id = parent_uuid

        # common handling for all resource get
        (ok, result) = self._get_common(request, parent_uuid)
        if not ok:
            (code, msg) = result
            self.config_object_error(None, None, 'projects', 'http_get_collection', msg)
            abort(code, msg)

        db_conn = self._db_conn
        (ok, result) = \
             db_conn.dbe_list('project', parent_uuid)

        if not ok:
            self.config_object_error(None, None, 'projects', 'http_get_collection', result)
            abort(404, result)

        fq_names = result
        obj_dicts = []
        for fq_name in fq_names:
            obj_dict = {}
            id = db_conn.fq_name_to_uuid('project', fq_name)
            obj_dict['uuid'] = id
            obj_dict['fq_name'] = fq_name
            obj_dict['href'] = self.generate_url('project', id)
            obj_dicts.append(obj_dict)

        return {'projects': obj_dicts} 
    #end projects_http_get

    def _project_create_default_children(self, parent_obj):
        # Create a default child only if provisioned for
        r_class = self._resource_classes.get('security-group', None)
        if r_class.generate_default_instance:
            child_obj = SecurityGroup(parent_obj = parent_obj)
            child_dict = child_obj.__dict__
            fq_name = child_dict['fq_name']
            child_dict['id_perms'] = self._get_default_id_perms('security-group')

            db_conn = self._db_conn
            (ok, result) = db_conn.dbe_alloc('security-group', child_dict)
            if not ok:
                return (ok, result)

            obj_ids = result
            db_conn.dbe_create('security-group', obj_ids, child_dict)
            self._security_group_create_default_children(child_obj)

        # Create a default child only if provisioned for
        r_class = self._resource_classes.get('virtual-network', None)
        if r_class.generate_default_instance:
            child_obj = VirtualNetwork(parent_obj = parent_obj)
            child_dict = child_obj.__dict__
            fq_name = child_dict['fq_name']
            child_dict['id_perms'] = self._get_default_id_perms('virtual-network')

            db_conn = self._db_conn
            (ok, result) = db_conn.dbe_alloc('virtual-network', child_dict)
            if not ok:
                return (ok, result)

            obj_ids = result
            db_conn.dbe_create('virtual-network', obj_ids, child_dict)
            self._virtual_network_create_default_children(child_obj)

        # Create a default child only if provisioned for
        r_class = self._resource_classes.get('network-ipam', None)
        if r_class.generate_default_instance:
            child_obj = NetworkIpam(parent_obj = parent_obj)
            child_dict = child_obj.__dict__
            fq_name = child_dict['fq_name']
            child_dict['id_perms'] = self._get_default_id_perms('network-ipam')

            db_conn = self._db_conn
            (ok, result) = db_conn.dbe_alloc('network-ipam', child_dict)
            if not ok:
                return (ok, result)

            obj_ids = result
            db_conn.dbe_create('network-ipam', obj_ids, child_dict)
            self._network_ipam_create_default_children(child_obj)

        # Create a default child only if provisioned for
        r_class = self._resource_classes.get('network-policy', None)
        if r_class.generate_default_instance:
            child_obj = NetworkPolicy(parent_obj = parent_obj)
            child_dict = child_obj.__dict__
            fq_name = child_dict['fq_name']
            child_dict['id_perms'] = self._get_default_id_perms('network-policy')

            db_conn = self._db_conn
            (ok, result) = db_conn.dbe_alloc('network-policy', child_dict)
            if not ok:
                return (ok, result)

            obj_ids = result
            db_conn.dbe_create('network-policy', obj_ids, child_dict)
            self._network_policy_create_default_children(child_obj)

        # Create a default child only if provisioned for
        r_class = self._resource_classes.get('service-instance', None)
        if r_class.generate_default_instance:
            child_obj = ServiceInstance(parent_obj = parent_obj)
            child_dict = child_obj.__dict__
            fq_name = child_dict['fq_name']
            child_dict['id_perms'] = self._get_default_id_perms('service-instance')

            db_conn = self._db_conn
            (ok, result) = db_conn.dbe_alloc('service-instance', child_dict)
            if not ok:
                return (ok, result)

            obj_ids = result
            db_conn.dbe_create('service-instance', obj_ids, child_dict)
            self._service_instance_create_default_children(child_obj)

        pass
    #end _project_create_default_children

    def _project_delete_default_children(self, parent_obj):
        # Delete a default child only if provisioned for
        r_class = self._resource_classes.get('service-instance', None)
        if r_class.generate_default_instance:
            # first locate default child then delete it
            has_infos = parent_obj.get_security_groups()
            if has_infos:
                for has_info in has_infos:
                    if has_info['to'][-1] == 'default-security-group':
                        default_child_id = has_info['href'].split('/')[-1]
                        self.security_group_http_delete(default_child_id)
                        break

        # Delete a default child only if provisioned for
        r_class = self._resource_classes.get('service-instance', None)
        if r_class.generate_default_instance:
            # first locate default child then delete it
            has_infos = parent_obj.get_virtual_networks()
            if has_infos:
                for has_info in has_infos:
                    if has_info['to'][-1] == 'default-virtual-network':
                        default_child_id = has_info['href'].split('/')[-1]
                        self.virtual_network_http_delete(default_child_id)
                        break

        # Delete a default child only if provisioned for
        r_class = self._resource_classes.get('service-instance', None)
        if r_class.generate_default_instance:
            # first locate default child then delete it
            has_infos = parent_obj.get_network_ipams()
            if has_infos:
                for has_info in has_infos:
                    if has_info['to'][-1] == 'default-network-ipam':
                        default_child_id = has_info['href'].split('/')[-1]
                        self.network_ipam_http_delete(default_child_id)
                        break

        # Delete a default child only if provisioned for
        r_class = self._resource_classes.get('service-instance', None)
        if r_class.generate_default_instance:
            # first locate default child then delete it
            has_infos = parent_obj.get_network_policys()
            if has_infos:
                for has_info in has_infos:
                    if has_info['to'][-1] == 'default-network-policy':
                        default_child_id = has_info['href'].split('/')[-1]
                        self.network_policy_http_delete(default_child_id)
                        break

        # Delete a default child only if provisioned for
        r_class = self._resource_classes.get('service-instance', None)
        if r_class.generate_default_instance:
            # first locate default child then delete it
            has_infos = parent_obj.get_service_instances()
            if has_infos:
                for has_info in has_infos:
                    if has_info['to'][-1] == 'default-service-instance':
                        default_child_id = has_info['href'].split('/')[-1]
                        self.service_instance_http_delete(default_child_id)
                        break

        pass
    #end _project_delete_default_children

    def logical_interface_http_get(self, id):
        # TODO get vals from request out of the global ASAP
        etag = request.headers.get('If-None-Match')
        # common handling for all resource get
        (ok, result) = self._get_common(request, id)
        if not ok:
            (code, msg) = result
            self.config_object_error(id, None, 'logical_interface', 'http_get', msg)
            abort(code, msg)

        # type-specific hook
        r_class = self._resource_classes.get('logical-interface', None)
        if r_class:
            r_class.http_get(id)

        db_conn = self._db_conn
        if etag:
            obj_ids = {'uuid': id}
            (ok, result) = db_conn.dbe_is_latest(obj_ids, etag.replace('"', ''))
            if not ok:
                # Not present in DB
                self.config_object_error(id, None, 'logical_interface', 'http_get', result)
                abort(404, result)

            is_latest = result
            if is_latest:
                # send Not-Modified, caches use this for read optimization
                response.status = 304
                return
        #end if etag

        obj_ids = {'uuid': id}
        if 'fields' in request.query:
            obj_fields = request.query.fields.split(',')
        else:
            obj_fields = None
        (ok, result) = db_conn.dbe_read('logical-interface', obj_ids, obj_fields)
        if not ok:
            # Not present in DB
            self.config_object_error(id, None, 'logical_interface', 'http_get', result)
            abort(404, result)

        rsp_body = {}
        rsp_body['uuid'] = id
        rsp_body['href'] = self.generate_url('logical-interface', id)
        rsp_body['name'] = result['fq_name'][-1]
        rsp_body.update(result)
        id_perms = result['id_perms']
        response.set_header('ETag', '"' + id_perms['last_modified'] + '"')
        return {'logical-interface': rsp_body} 
    #end logical_interface_http_get

    def logical_interface_http_put(self, id):
        key = 'logical-interface'
        obj_dict = request.json[key]
        # common handling for all resource put
        (ok, result) = self._put_common(request, 'logical_interface', obj_dict, id)
        if not ok:
            (code, msg) = result
            self.config_object_error(id, None, 'logical_interface', 'http_put', msg)
            abort(code, msg)

        # type-specific hook
        r_class = self._resource_classes.get('logical-interface', None)
        if r_class:
            (ok, msg) = r_class.http_put(id, obj_dict)
            if not ok:
                self.config_object_error(id, None, 'logical_interface', 'http_put', msg)
                abort(409, msg)

        db_conn = self._db_conn

        # Validate perms
        objtype_list = eval("[u'virtual_network']")
        for obj_type in objtype_list:
            refs = obj_dict.get('%s_refs'%(obj_type), None)
            if refs:
                for ref in refs:
                    ref_uuid = db_conn.fq_name_to_uuid(obj_type, ref['to'])
                    (ok, status) = self._permissions.check_perms_link(request, ref_uuid)
                    if not ok:
                        (code, err_msg) = status
                        abort(code, err_msg)

        obj_ids = {'uuid': id}
        (ok, result) = \
             db_conn.dbe_update('logical-interface', obj_ids, obj_dict)
        if not ok:
            self.config_object_error(id, None, 'logical_interface', 'http_put', result)
            abort(404, result)

        rsp_body = {}
        rsp_body['uuid'] = id
        rsp_body['href'] = self.generate_url('logical-interface', id)
        return {'logical-interface': rsp_body} 
    #end logical_interface_http_put

    def logical_interface_http_delete(self, id):
        db_conn = self._db_conn
        # read in obj from db (accepting error) to get details of it
        obj_ids = {'uuid': id}
        (read_ok, read_result) = db_conn.dbe_read('logical-interface', obj_ids)
        if not read_ok:
            self.config_object_error(id, None, 'logical_interface', 'http_delete', read_result)
            # proceed down to delete the resource

        # common handling for all resource delete
        parent_type = read_result.get('parent_type', None)
        (ok, del_result) = self._delete_common(request, 'logical_interface', id, parent_type)
        if not ok:
            (code, msg) = del_result
            self.config_object_error(id, None, 'logical_interface', 'http_delete', msg)
            abort(code, msg)

        fq_name = read_result['fq_name']
        ifmap_id = common.imid.get_ifmap_id_from_fq_name('logical-interface', fq_name)
        obj_ids['imid'] = ifmap_id
        if parent_type:
            parent_imid = common.imid.get_ifmap_id_from_fq_name(parent_type, fq_name[:-1])
            obj_ids['parent_imid'] = parent_imid

        # type-specific hook
        r_class = self._resource_classes.get('logical-interface', None)
        if r_class:
            if read_ok:
                # fail if non-default children or backrefs exist

                # Delete default children first
                parent_obj = LogicalInterface.factory(**read_result)
                self._logical_interface_delete_default_children(parent_obj)

                r_class.http_delete(id, read_result)
            #end if read_ok

        (ok, del_result) = \
             db_conn.dbe_delete('logical-interface', obj_ids)
        if not ok:
            self.config_object_error(id, None, 'logical_interface', 'http_delete', del_result)
            abort(409, del_result)

    #end logical_interface_http_delete
    def logical_interfaces_http_post(self):
        key = 'logical-interface'
        obj_dict = request.json[key]
        # common handling for all resource create
        (ok, result) = self._post_common(request, 'logical-interface', obj_dict)
        if not ok:
            (code, msg) = result
            fq_name_str = ':'.join(obj_dict.get('fq_name', []))
            self.config_object_error(None, fq_name_str, 'logical_interface', 'http_post', msg)
            abort(code, msg)

        # Alloc and Store id-mappings before creating entry on pubsub store.
        # Else a subscriber can ask for an id mapping before we have stored it
        uuid_requested = result
        db_conn = self._db_conn
        (ok, result) = db_conn.dbe_alloc('logical-interface', obj_dict, uuid_requested)
        if not ok:
            fq_name_str = ':'.join(obj_dict['fq_name'])
            self.config_object_error(None, fq_name_str, 'logical_interface', 'http_post', result)
            abort(code, result)

        obj_ids = result

        name = obj_dict['fq_name'][-1]
        fq_name = obj_dict['fq_name']


        if 'parent_type' in obj_dict:
            # non config-root child, verify parent exists
            parent_type = obj_dict['parent_type']
            parent_fq_name = obj_dict['fq_name'][:-1]
            try:
                parent_uuid = self._db_conn.fq_name_to_uuid(parent_type, parent_fq_name)
                (ok, status) = self._permissions.check_perms_write(request, parent_uuid)
                if not ok:
                    (code, err_msg) = status
                    abort(code, err_msg)
                self._permissions.set_user_role(request, obj_dict)
            except NoIdError:
                err_msg = 'Parent ' + pformat(parent_fq_name) + ' type ' + parent_type + ' does not exist'
                fq_name_str = ':'.join(parent_fq_name)
                self.config_object_error(None, fq_name_str, 'logical_interface', 'http_post', err_msg)
                abort(400, err_msg)

        env = request.headers.environ
        tenant_name = env.get(hdr_server_tenant(), 'default-project')


        # type-specific hook
        r_class = self._resource_classes.get('logical-interface', None)
        if r_class:
            (ok, result) = r_class.http_post_collection(tenant_name, obj_dict)
            if not ok:
                (code, msg) = result
                fq_name_str = ':'.join(fq_name)
                self.config_object_error(None, fq_name_str, 'logical_interface', 'http_post', msg)
                abort(code, msg)

        # Validate perms
        objtype_list = eval("[u'virtual_network']")
        for obj_type in objtype_list:
            refs = obj_dict.get('%s_refs'%(obj_type), None)
            if refs:
                for ref in refs:
                    ref_uuid = db_conn.fq_name_to_uuid(obj_type, ref['to'])
                    (ok, status) = self._permissions.check_perms_link(request, ref_uuid)
                    if not ok:
                        (code, err_msg) = status
                        abort(code, err_msg)

        (ok, result) = \
             db_conn.dbe_create('logical-interface', obj_ids, obj_dict)

        if not ok:
            fq_name_str = ':'.join(fq_name)
            self.config_object_error(None, fq_name_str, 'logical_interface', 'http_post', result)
            abort(404, result)

        rsp_body = {}
        rsp_body['name'] = name
        rsp_body['fq_name'] = fq_name
        rsp_body['uuid'] = obj_ids['uuid']
        rsp_body['href'] = self.generate_url('logical-interface', obj_ids['uuid'])
        if 'parent_type' in obj_dict:
            # non config-root child, send back parent uuid/href
            rsp_body['parent_uuid'] = parent_uuid
            rsp_body['parent_href'] = self.generate_url(parent_type, parent_uuid)

        parent_obj = LogicalInterface.factory(**rsp_body)
        self._logical_interface_create_default_children(parent_obj)

        return {'logical-interface': rsp_body} 
    #end logical_interfaces_http_post

    def logical_interfaces_http_get(self):
        env = request.headers.environ
        tenant_name = env.get(hdr_server_tenant(), 'default-project')
        parent_uuid = None
        resource_id = 'logical_interfaces'
        if (('parent_fq_name_str' in request.query) and
            ('parent_type' in request.query)):
            parent_fq_name = request.query.parent_fq_name_str.split(':')
            parent_type = request.query.parent_type
            parent_uuid = self._db_conn.fq_name_to_uuid(parent_type, parent_fq_name)
        elif 'parent_id' in request.query:
            parent_uuid = str(uuid.UUID(request.query.parent_id))

        if parent_uuid:
            resource_id = parent_uuid

        # common handling for all resource get
        (ok, result) = self._get_common(request, parent_uuid)
        if not ok:
            (code, msg) = result
            self.config_object_error(None, None, 'logical_interfaces', 'http_get_collection', msg)
            abort(code, msg)

        db_conn = self._db_conn
        (ok, result) = \
             db_conn.dbe_list('logical-interface', parent_uuid)

        if not ok:
            self.config_object_error(None, None, 'logical_interfaces', 'http_get_collection', result)
            abort(404, result)

        fq_names = result
        obj_dicts = []
        for fq_name in fq_names:
            obj_dict = {}
            id = db_conn.fq_name_to_uuid('logical_interface', fq_name)
            obj_dict['uuid'] = id
            obj_dict['fq_name'] = fq_name
            obj_dict['href'] = self.generate_url('logical-interface', id)
            obj_dicts.append(obj_dict)

        return {'logical-interfaces': obj_dicts} 
    #end logical_interfaces_http_get

    def _logical_interface_create_default_children(self, parent_obj):
        pass
    #end _logical_interface_create_default_children

    def _logical_interface_delete_default_children(self, parent_obj):
        pass
    #end _logical_interface_delete_default_children

    def routing_instance_http_get(self, id):
        # TODO get vals from request out of the global ASAP
        etag = request.headers.get('If-None-Match')
        # common handling for all resource get
        (ok, result) = self._get_common(request, id)
        if not ok:
            (code, msg) = result
            self.config_object_error(id, None, 'routing_instance', 'http_get', msg)
            abort(code, msg)

        # type-specific hook
        r_class = self._resource_classes.get('routing-instance', None)
        if r_class:
            r_class.http_get(id)

        db_conn = self._db_conn
        if etag:
            obj_ids = {'uuid': id}
            (ok, result) = db_conn.dbe_is_latest(obj_ids, etag.replace('"', ''))
            if not ok:
                # Not present in DB
                self.config_object_error(id, None, 'routing_instance', 'http_get', result)
                abort(404, result)

            is_latest = result
            if is_latest:
                # send Not-Modified, caches use this for read optimization
                response.status = 304
                return
        #end if etag

        obj_ids = {'uuid': id}
        if 'fields' in request.query:
            obj_fields = request.query.fields.split(',')
        else:
            obj_fields = None
        (ok, result) = db_conn.dbe_read('routing-instance', obj_ids, obj_fields)
        if not ok:
            # Not present in DB
            self.config_object_error(id, None, 'routing_instance', 'http_get', result)
            abort(404, result)

        rsp_body = {}
        rsp_body['uuid'] = id
        rsp_body['href'] = self.generate_url('routing-instance', id)
        rsp_body['name'] = result['fq_name'][-1]
        rsp_body.update(result)
        id_perms = result['id_perms']
        response.set_header('ETag', '"' + id_perms['last_modified'] + '"')
        return {'routing-instance': rsp_body} 
    #end routing_instance_http_get

    def routing_instance_http_put(self, id):
        key = 'routing-instance'
        obj_dict = request.json[key]
        # common handling for all resource put
        (ok, result) = self._put_common(request, 'routing_instance', obj_dict, id)
        if not ok:
            (code, msg) = result
            self.config_object_error(id, None, 'routing_instance', 'http_put', msg)
            abort(code, msg)

        # type-specific hook
        r_class = self._resource_classes.get('routing-instance', None)
        if r_class:
            (ok, msg) = r_class.http_put(id, obj_dict)
            if not ok:
                self.config_object_error(id, None, 'routing_instance', 'http_put', msg)
                abort(409, msg)

        db_conn = self._db_conn

        # Validate perms
        objtype_list = eval("['bgp_router', 'routing_instance', u'route_target']")
        for obj_type in objtype_list:
            refs = obj_dict.get('%s_refs'%(obj_type), None)
            if refs:
                for ref in refs:
                    ref_uuid = db_conn.fq_name_to_uuid(obj_type, ref['to'])
                    (ok, status) = self._permissions.check_perms_link(request, ref_uuid)
                    if not ok:
                        (code, err_msg) = status
                        abort(code, err_msg)

        obj_ids = {'uuid': id}
        (ok, result) = \
             db_conn.dbe_update('routing-instance', obj_ids, obj_dict)
        if not ok:
            self.config_object_error(id, None, 'routing_instance', 'http_put', result)
            abort(404, result)

        rsp_body = {}
        rsp_body['uuid'] = id
        rsp_body['href'] = self.generate_url('routing-instance', id)
        return {'routing-instance': rsp_body} 
    #end routing_instance_http_put

    def routing_instance_http_delete(self, id):
        db_conn = self._db_conn
        # read in obj from db (accepting error) to get details of it
        obj_ids = {'uuid': id}
        (read_ok, read_result) = db_conn.dbe_read('routing-instance', obj_ids)
        if not read_ok:
            self.config_object_error(id, None, 'routing_instance', 'http_delete', read_result)
            # proceed down to delete the resource

        # common handling for all resource delete
        parent_type = read_result.get('parent_type', None)
        (ok, del_result) = self._delete_common(request, 'routing_instance', id, parent_type)
        if not ok:
            (code, msg) = del_result
            self.config_object_error(id, None, 'routing_instance', 'http_delete', msg)
            abort(code, msg)

        fq_name = read_result['fq_name']
        ifmap_id = common.imid.get_ifmap_id_from_fq_name('routing-instance', fq_name)
        obj_ids['imid'] = ifmap_id
        if parent_type:
            parent_imid = common.imid.get_ifmap_id_from_fq_name(parent_type, fq_name[:-1])
            obj_ids['parent_imid'] = parent_imid

        # type-specific hook
        r_class = self._resource_classes.get('routing-instance', None)
        if r_class:
            if read_ok:
                # fail if non-default children or backrefs exist
                bgp_routers = read_result.get('bgp_routers', None)
                if bgp_routers:
                    has_infos = read_result['bgp_routers']
                    if ((len(has_infos) > 1) or 
                        (len(has_infos) == 1 and has_infos[0]['to'][-1] != 'default-bgp-router')):
                        has_urls = [has_info['href'] for has_info in has_infos]
                        has_str = ', '.join(has_urls)
                        err_msg = 'Children ' + has_str + ' still exist'
                        self.config_object_error(id, None, 'routing_instance', 'http_delete', err_msg)
                        abort(409, err_msg)

                virtual_machine_interface_back_refs = read_result.get('virtual_machine_interface_back_refs', None)
                if virtual_machine_interface_back_refs:
                    back_ref_urls = [back_ref_info['href'] for back_ref_info in read_result['virtual_machine_interface_back_refs']]
                    back_ref_str = ', '.join(back_ref_urls)
                    err_msg = 'Back-References from ' + back_ref_str + ' still exist'
                    self.config_object_error(id, None, 'routing_instance', 'http_delete', err_msg)
                    abort(409, err_msg)

                routing_instance_back_refs = read_result.get('routing_instance_back_refs', None)
                if routing_instance_back_refs:
                    back_ref_urls = [back_ref_info['href'] for back_ref_info in read_result['routing_instance_back_refs']]
                    back_ref_str = ', '.join(back_ref_urls)
                    err_msg = 'Back-References from ' + back_ref_str + ' still exist'
                    self.config_object_error(id, None, 'routing_instance', 'http_delete', err_msg)
                    abort(409, err_msg)


                # Delete default children first
                parent_obj = RoutingInstance.factory(**read_result)
                self._routing_instance_delete_default_children(parent_obj)

                r_class.http_delete(id, read_result)
            #end if read_ok

        (ok, del_result) = \
             db_conn.dbe_delete('routing-instance', obj_ids)
        if not ok:
            self.config_object_error(id, None, 'routing_instance', 'http_delete', del_result)
            abort(409, del_result)

    #end routing_instance_http_delete
    def routing_instances_http_post(self):
        key = 'routing-instance'
        obj_dict = request.json[key]
        # common handling for all resource create
        (ok, result) = self._post_common(request, 'routing-instance', obj_dict)
        if not ok:
            (code, msg) = result
            fq_name_str = ':'.join(obj_dict.get('fq_name', []))
            self.config_object_error(None, fq_name_str, 'routing_instance', 'http_post', msg)
            abort(code, msg)

        # Alloc and Store id-mappings before creating entry on pubsub store.
        # Else a subscriber can ask for an id mapping before we have stored it
        uuid_requested = result
        db_conn = self._db_conn
        (ok, result) = db_conn.dbe_alloc('routing-instance', obj_dict, uuid_requested)
        if not ok:
            fq_name_str = ':'.join(obj_dict['fq_name'])
            self.config_object_error(None, fq_name_str, 'routing_instance', 'http_post', result)
            abort(code, result)

        obj_ids = result

        name = obj_dict['fq_name'][-1]
        fq_name = obj_dict['fq_name']


        if 'parent_type' in obj_dict:
            # non config-root child, verify parent exists
            parent_type = obj_dict['parent_type']
            parent_fq_name = obj_dict['fq_name'][:-1]
            try:
                parent_uuid = self._db_conn.fq_name_to_uuid(parent_type, parent_fq_name)
                (ok, status) = self._permissions.check_perms_write(request, parent_uuid)
                if not ok:
                    (code, err_msg) = status
                    abort(code, err_msg)
                self._permissions.set_user_role(request, obj_dict)
            except NoIdError:
                err_msg = 'Parent ' + pformat(parent_fq_name) + ' type ' + parent_type + ' does not exist'
                fq_name_str = ':'.join(parent_fq_name)
                self.config_object_error(None, fq_name_str, 'routing_instance', 'http_post', err_msg)
                abort(400, err_msg)

        env = request.headers.environ
        tenant_name = env.get(hdr_server_tenant(), 'default-project')


        # type-specific hook
        r_class = self._resource_classes.get('routing-instance', None)
        if r_class:
            (ok, result) = r_class.http_post_collection(tenant_name, obj_dict)
            if not ok:
                (code, msg) = result
                fq_name_str = ':'.join(fq_name)
                self.config_object_error(None, fq_name_str, 'routing_instance', 'http_post', msg)
                abort(code, msg)

        # Validate perms
        objtype_list = eval("['bgp_router', 'routing_instance', u'route_target']")
        for obj_type in objtype_list:
            refs = obj_dict.get('%s_refs'%(obj_type), None)
            if refs:
                for ref in refs:
                    ref_uuid = db_conn.fq_name_to_uuid(obj_type, ref['to'])
                    (ok, status) = self._permissions.check_perms_link(request, ref_uuid)
                    if not ok:
                        (code, err_msg) = status
                        abort(code, err_msg)

        (ok, result) = \
             db_conn.dbe_create('routing-instance', obj_ids, obj_dict)

        if not ok:
            fq_name_str = ':'.join(fq_name)
            self.config_object_error(None, fq_name_str, 'routing_instance', 'http_post', result)
            abort(404, result)

        rsp_body = {}
        rsp_body['name'] = name
        rsp_body['fq_name'] = fq_name
        rsp_body['uuid'] = obj_ids['uuid']
        rsp_body['href'] = self.generate_url('routing-instance', obj_ids['uuid'])
        if 'parent_type' in obj_dict:
            # non config-root child, send back parent uuid/href
            rsp_body['parent_uuid'] = parent_uuid
            rsp_body['parent_href'] = self.generate_url(parent_type, parent_uuid)

        parent_obj = RoutingInstance.factory(**rsp_body)
        self._routing_instance_create_default_children(parent_obj)

        return {'routing-instance': rsp_body} 
    #end routing_instances_http_post

    def routing_instances_http_get(self):
        env = request.headers.environ
        tenant_name = env.get(hdr_server_tenant(), 'default-project')
        parent_uuid = None
        resource_id = 'routing_instances'
        if (('parent_fq_name_str' in request.query) and
            ('parent_type' in request.query)):
            parent_fq_name = request.query.parent_fq_name_str.split(':')
            parent_type = request.query.parent_type
            parent_uuid = self._db_conn.fq_name_to_uuid(parent_type, parent_fq_name)
        elif 'parent_id' in request.query:
            parent_uuid = str(uuid.UUID(request.query.parent_id))

        if parent_uuid:
            resource_id = parent_uuid

        # common handling for all resource get
        (ok, result) = self._get_common(request, parent_uuid)
        if not ok:
            (code, msg) = result
            self.config_object_error(None, None, 'routing_instances', 'http_get_collection', msg)
            abort(code, msg)

        db_conn = self._db_conn
        (ok, result) = \
             db_conn.dbe_list('routing-instance', parent_uuid)

        if not ok:
            self.config_object_error(None, None, 'routing_instances', 'http_get_collection', result)
            abort(404, result)

        fq_names = result
        obj_dicts = []
        for fq_name in fq_names:
            obj_dict = {}
            id = db_conn.fq_name_to_uuid('routing_instance', fq_name)
            obj_dict['uuid'] = id
            obj_dict['fq_name'] = fq_name
            obj_dict['href'] = self.generate_url('routing-instance', id)
            obj_dicts.append(obj_dict)

        return {'routing-instances': obj_dicts} 
    #end routing_instances_http_get

    def _routing_instance_create_default_children(self, parent_obj):
        # Create a default child only if provisioned for
        r_class = self._resource_classes.get('bgp-router', None)
        if r_class.generate_default_instance:
            child_obj = BgpRouter(parent_obj = parent_obj)
            child_dict = child_obj.__dict__
            fq_name = child_dict['fq_name']
            child_dict['id_perms'] = self._get_default_id_perms('bgp-router')

            db_conn = self._db_conn
            (ok, result) = db_conn.dbe_alloc('bgp-router', child_dict)
            if not ok:
                return (ok, result)

            obj_ids = result
            db_conn.dbe_create('bgp-router', obj_ids, child_dict)
            self._bgp_router_create_default_children(child_obj)

        pass
    #end _routing_instance_create_default_children

    def _routing_instance_delete_default_children(self, parent_obj):
        # Delete a default child only if provisioned for
        r_class = self._resource_classes.get('bgp-router', None)
        if r_class.generate_default_instance:
            # first locate default child then delete it
            has_infos = parent_obj.get_bgp_routers()
            if has_infos:
                for has_info in has_infos:
                    if has_info['to'][-1] == 'default-bgp-router':
                        default_child_id = has_info['href'].split('/')[-1]
                        self.bgp_router_http_delete(default_child_id)
                        break

        pass
    #end _routing_instance_delete_default_children

    def virtual_machine_interface_http_get(self, id):
        # TODO get vals from request out of the global ASAP
        etag = request.headers.get('If-None-Match')
        # common handling for all resource get
        (ok, result) = self._get_common(request, id)
        if not ok:
            (code, msg) = result
            self.config_object_error(id, None, 'virtual_machine_interface', 'http_get', msg)
            abort(code, msg)

        # type-specific hook
        r_class = self._resource_classes.get('virtual-machine-interface', None)
        if r_class:
            r_class.http_get(id)

        db_conn = self._db_conn
        if etag:
            obj_ids = {'uuid': id}
            (ok, result) = db_conn.dbe_is_latest(obj_ids, etag.replace('"', ''))
            if not ok:
                # Not present in DB
                self.config_object_error(id, None, 'virtual_machine_interface', 'http_get', result)
                abort(404, result)

            is_latest = result
            if is_latest:
                # send Not-Modified, caches use this for read optimization
                response.status = 304
                return
        #end if etag

        obj_ids = {'uuid': id}
        if 'fields' in request.query:
            obj_fields = request.query.fields.split(',')
        else:
            obj_fields = None
        (ok, result) = db_conn.dbe_read('virtual-machine-interface', obj_ids, obj_fields)
        if not ok:
            # Not present in DB
            self.config_object_error(id, None, 'virtual_machine_interface', 'http_get', result)
            abort(404, result)

        rsp_body = {}
        rsp_body['uuid'] = id
        rsp_body['href'] = self.generate_url('virtual-machine-interface', id)
        rsp_body['name'] = result['fq_name'][-1]
        rsp_body.update(result)
        id_perms = result['id_perms']
        response.set_header('ETag', '"' + id_perms['last_modified'] + '"')
        return {'virtual-machine-interface': rsp_body} 
    #end virtual_machine_interface_http_get

    def virtual_machine_interface_http_put(self, id):
        key = 'virtual-machine-interface'
        obj_dict = request.json[key]
        # common handling for all resource put
        (ok, result) = self._put_common(request, 'virtual_machine_interface', obj_dict, id)
        if not ok:
            (code, msg) = result
            self.config_object_error(id, None, 'virtual_machine_interface', 'http_put', msg)
            abort(code, msg)

        # type-specific hook
        r_class = self._resource_classes.get('virtual-machine-interface', None)
        if r_class:
            (ok, msg) = r_class.http_put(id, obj_dict)
            if not ok:
                self.config_object_error(id, None, 'virtual_machine_interface', 'http_put', msg)
                abort(409, msg)

        db_conn = self._db_conn

        # Validate perms
        objtype_list = eval("[u'virtual_network', 'routing_instance']")
        for obj_type in objtype_list:
            refs = obj_dict.get('%s_refs'%(obj_type), None)
            if refs:
                for ref in refs:
                    ref_uuid = db_conn.fq_name_to_uuid(obj_type, ref['to'])
                    (ok, status) = self._permissions.check_perms_link(request, ref_uuid)
                    if not ok:
                        (code, err_msg) = status
                        abort(code, err_msg)

        obj_ids = {'uuid': id}
        (ok, result) = \
             db_conn.dbe_update('virtual-machine-interface', obj_ids, obj_dict)
        if not ok:
            self.config_object_error(id, None, 'virtual_machine_interface', 'http_put', result)
            abort(404, result)

        rsp_body = {}
        rsp_body['uuid'] = id
        rsp_body['href'] = self.generate_url('virtual-machine-interface', id)
        return {'virtual-machine-interface': rsp_body} 
    #end virtual_machine_interface_http_put

    def virtual_machine_interface_http_delete(self, id):
        db_conn = self._db_conn
        # read in obj from db (accepting error) to get details of it
        obj_ids = {'uuid': id}
        (read_ok, read_result) = db_conn.dbe_read('virtual-machine-interface', obj_ids)
        if not read_ok:
            self.config_object_error(id, None, 'virtual_machine_interface', 'http_delete', read_result)
            # proceed down to delete the resource

        # common handling for all resource delete
        parent_type = read_result.get('parent_type', None)
        (ok, del_result) = self._delete_common(request, 'virtual_machine_interface', id, parent_type)
        if not ok:
            (code, msg) = del_result
            self.config_object_error(id, None, 'virtual_machine_interface', 'http_delete', msg)
            abort(code, msg)

        fq_name = read_result['fq_name']
        ifmap_id = common.imid.get_ifmap_id_from_fq_name('virtual-machine-interface', fq_name)
        obj_ids['imid'] = ifmap_id
        if parent_type:
            parent_imid = common.imid.get_ifmap_id_from_fq_name(parent_type, fq_name[:-1])
            obj_ids['parent_imid'] = parent_imid

        # type-specific hook
        r_class = self._resource_classes.get('virtual-machine-interface', None)
        if r_class:
            if read_ok:
                # fail if non-default children or backrefs exist
                instance_ip_back_refs = read_result.get('instance_ip_back_refs', None)
                if instance_ip_back_refs:
                    back_ref_urls = [back_ref_info['href'] for back_ref_info in read_result['instance_ip_back_refs']]
                    back_ref_str = ', '.join(back_ref_urls)
                    err_msg = 'Back-References from ' + back_ref_str + ' still exist'
                    self.config_object_error(id, None, 'virtual_machine_interface', 'http_delete', err_msg)
                    abort(409, err_msg)

                floating_ip_back_refs = read_result.get('floating_ip_back_refs', None)
                if floating_ip_back_refs:
                    back_ref_urls = [back_ref_info['href'] for back_ref_info in read_result['floating_ip_back_refs']]
                    back_ref_str = ', '.join(back_ref_urls)
                    err_msg = 'Back-References from ' + back_ref_str + ' still exist'
                    self.config_object_error(id, None, 'virtual_machine_interface', 'http_delete', err_msg)
                    abort(409, err_msg)

                customer_attachment_back_refs = read_result.get('customer_attachment_back_refs', None)
                if customer_attachment_back_refs:
                    back_ref_urls = [back_ref_info['href'] for back_ref_info in read_result['customer_attachment_back_refs']]
                    back_ref_str = ', '.join(back_ref_urls)
                    err_msg = 'Back-References from ' + back_ref_str + ' still exist'
                    self.config_object_error(id, None, 'virtual_machine_interface', 'http_delete', err_msg)
                    abort(409, err_msg)


                # Delete default children first
                parent_obj = VirtualMachineInterface.factory(**read_result)
                self._virtual_machine_interface_delete_default_children(parent_obj)

                r_class.http_delete(id, read_result)
            #end if read_ok

        (ok, del_result) = \
             db_conn.dbe_delete('virtual-machine-interface', obj_ids)
        if not ok:
            self.config_object_error(id, None, 'virtual_machine_interface', 'http_delete', del_result)
            abort(409, del_result)

    #end virtual_machine_interface_http_delete
    def virtual_machine_interfaces_http_post(self):
        key = 'virtual-machine-interface'
        obj_dict = request.json[key]
        # common handling for all resource create
        (ok, result) = self._post_common(request, 'virtual-machine-interface', obj_dict)
        if not ok:
            (code, msg) = result
            fq_name_str = ':'.join(obj_dict.get('fq_name', []))
            self.config_object_error(None, fq_name_str, 'virtual_machine_interface', 'http_post', msg)
            abort(code, msg)

        # Alloc and Store id-mappings before creating entry on pubsub store.
        # Else a subscriber can ask for an id mapping before we have stored it
        uuid_requested = result
        db_conn = self._db_conn
        (ok, result) = db_conn.dbe_alloc('virtual-machine-interface', obj_dict, uuid_requested)
        if not ok:
            fq_name_str = ':'.join(obj_dict['fq_name'])
            self.config_object_error(None, fq_name_str, 'virtual_machine_interface', 'http_post', result)
            abort(code, result)

        obj_ids = result

        name = obj_dict['fq_name'][-1]
        fq_name = obj_dict['fq_name']


        if 'parent_type' in obj_dict:
            # non config-root child, verify parent exists
            parent_type = obj_dict['parent_type']
            parent_fq_name = obj_dict['fq_name'][:-1]
            try:
                parent_uuid = self._db_conn.fq_name_to_uuid(parent_type, parent_fq_name)
                (ok, status) = self._permissions.check_perms_write(request, parent_uuid)
                if not ok:
                    (code, err_msg) = status
                    abort(code, err_msg)
                self._permissions.set_user_role(request, obj_dict)
            except NoIdError:
                err_msg = 'Parent ' + pformat(parent_fq_name) + ' type ' + parent_type + ' does not exist'
                fq_name_str = ':'.join(parent_fq_name)
                self.config_object_error(None, fq_name_str, 'virtual_machine_interface', 'http_post', err_msg)
                abort(400, err_msg)

        env = request.headers.environ
        tenant_name = env.get(hdr_server_tenant(), 'default-project')


        # type-specific hook
        r_class = self._resource_classes.get('virtual-machine-interface', None)
        if r_class:
            (ok, result) = r_class.http_post_collection(tenant_name, obj_dict)
            if not ok:
                (code, msg) = result
                fq_name_str = ':'.join(fq_name)
                self.config_object_error(None, fq_name_str, 'virtual_machine_interface', 'http_post', msg)
                abort(code, msg)

        # Validate perms
        objtype_list = eval("[u'virtual_network', 'routing_instance']")
        for obj_type in objtype_list:
            refs = obj_dict.get('%s_refs'%(obj_type), None)
            if refs:
                for ref in refs:
                    ref_uuid = db_conn.fq_name_to_uuid(obj_type, ref['to'])
                    (ok, status) = self._permissions.check_perms_link(request, ref_uuid)
                    if not ok:
                        (code, err_msg) = status
                        abort(code, err_msg)

        (ok, result) = \
             db_conn.dbe_create('virtual-machine-interface', obj_ids, obj_dict)

        if not ok:
            fq_name_str = ':'.join(fq_name)
            self.config_object_error(None, fq_name_str, 'virtual_machine_interface', 'http_post', result)
            abort(404, result)

        rsp_body = {}
        rsp_body['name'] = name
        rsp_body['fq_name'] = fq_name
        rsp_body['uuid'] = obj_ids['uuid']
        rsp_body['href'] = self.generate_url('virtual-machine-interface', obj_ids['uuid'])
        if 'parent_type' in obj_dict:
            # non config-root child, send back parent uuid/href
            rsp_body['parent_uuid'] = parent_uuid
            rsp_body['parent_href'] = self.generate_url(parent_type, parent_uuid)

        parent_obj = VirtualMachineInterface.factory(**rsp_body)
        self._virtual_machine_interface_create_default_children(parent_obj)

        return {'virtual-machine-interface': rsp_body} 
    #end virtual_machine_interfaces_http_post

    def virtual_machine_interfaces_http_get(self):
        env = request.headers.environ
        tenant_name = env.get(hdr_server_tenant(), 'default-project')
        parent_uuid = None
        resource_id = 'virtual_machine_interfaces'
        if (('parent_fq_name_str' in request.query) and
            ('parent_type' in request.query)):
            parent_fq_name = request.query.parent_fq_name_str.split(':')
            parent_type = request.query.parent_type
            parent_uuid = self._db_conn.fq_name_to_uuid(parent_type, parent_fq_name)
        elif 'parent_id' in request.query:
            parent_uuid = str(uuid.UUID(request.query.parent_id))

        if parent_uuid:
            resource_id = parent_uuid

        # common handling for all resource get
        (ok, result) = self._get_common(request, parent_uuid)
        if not ok:
            (code, msg) = result
            self.config_object_error(None, None, 'virtual_machine_interfaces', 'http_get_collection', msg)
            abort(code, msg)

        db_conn = self._db_conn
        (ok, result) = \
             db_conn.dbe_list('virtual-machine-interface', parent_uuid)

        if not ok:
            self.config_object_error(None, None, 'virtual_machine_interfaces', 'http_get_collection', result)
            abort(404, result)

        fq_names = result
        obj_dicts = []
        for fq_name in fq_names:
            obj_dict = {}
            id = db_conn.fq_name_to_uuid('virtual_machine_interface', fq_name)
            obj_dict['uuid'] = id
            obj_dict['fq_name'] = fq_name
            obj_dict['href'] = self.generate_url('virtual-machine-interface', id)
            obj_dicts.append(obj_dict)

        return {'virtual-machine-interfaces': obj_dicts} 
    #end virtual_machine_interfaces_http_get

    def _virtual_machine_interface_create_default_children(self, parent_obj):
        pass
    #end _virtual_machine_interface_create_default_children

    def _virtual_machine_interface_delete_default_children(self, parent_obj):
        pass
    #end _virtual_machine_interface_delete_default_children

#end class VncApiServerGen

class DefaultsGen(object):
    def __init__(self):
        self.perms = {}
        default_perms = self._common_default_perms
        id_perms = IdPermsType(default_perms, None, True, 0, 0)
        self.perms['domain'] = id_perms
        self.perms['service-instance'] = id_perms
        self.perms['instance-ip'] = id_perms
        self.perms['network-policy'] = id_perms
        self.perms['virtual-DNS-record'] = id_perms
        self.perms['route-target'] = id_perms
        self.perms['floating-ip'] = id_perms
        self.perms['floating-ip-pool'] = id_perms
        self.perms['physical-router'] = id_perms
        self.perms['bgp-router'] = id_perms
        self.perms['virtual-router'] = id_perms
        self.perms['config-root'] = id_perms
        self.perms['global-system-config'] = id_perms
        self.perms['namespace'] = id_perms
        self.perms['physical-interface'] = id_perms
        self.perms['access-control-list'] = id_perms
        self.perms['virtual-DNS'] = id_perms
        self.perms['customer-attachment'] = id_perms
        self.perms['virtual-machine'] = id_perms
        self.perms['service-template'] = id_perms
        self.perms['security-group'] = id_perms
        self.perms['provider-attachment'] = id_perms
        self.perms['network-ipam'] = id_perms
        self.perms['virtual-network'] = id_perms
        self.perms['project'] = id_perms
        self.perms['logical-interface'] = id_perms
        self.perms['routing-instance'] = id_perms
        self.perms['virtual-machine-interface'] = id_perms

        self.resource = {}

    #end __init__
#end class DefaultsGen

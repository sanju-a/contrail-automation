'''
This module defines the fixture classes for all config elements
'''

# AUTO-GENERATED file from IFMapApiGenerator. Do Not Edit!

import cfixture
from vnc_api.common.exceptions import *

from vnc_api.gen.resource_common import *

from vnc_api.gen.resource_xsd import *
from generatedssuper import GeneratedsSuper

class DomainTestFixtureGen(cfixture.ContrailFixture):
    """
    Fixture for :class:`.Domain`
    """
    def __init__(self, conn_drv, domain_name = None, parent_fixt = None, domain_limits=None, api_access_list=None, id_perms=None):
        '''
        Create DomainTestFixtureGen object
        
        constructor

        Args:
            conn_drv (:class:`ConnectionDriver`): connection driver (eg. :class:`vnc_api.vnc_api.VncApi`, :class:`novaclient.client.Client`, etc)

        Kwargs:
            domain_name (str): Name of domain
            parent_fixt (:class:`.ConfigRootTestFixtureGen`): Parent fixture
            domain_limits (instance): instance of :class:`DomainLimitsType`
            api_access_list (instance): instance of :class:`ApiAccessListType`
            id_perms (instance): instance of :class:`IdPermsType`

        '''
        self._conn_drv = conn_drv
        if not domain_name:
            self._name = 'default-domain'
        else:
            self._name = domain_name
        self._obj = None
        self._parent_fixt = parent_fixt
        self.domain_limits = domain_limits
        self.api_access_list = api_access_list
        self.id_perms = id_perms
    #end __init__

    def _update_links (self):
        return None
    #end _update_links


    def populate (self):
        self._obj.set_domain_limits(self.domain_limits or DomainLimitsType.populate())
        self._obj.set_api_access_list(self.api_access_list or ApiAccessListType.populate())
        self._obj.set_id_perms(self.id_perms or IdPermsType.populate())
    #end populate

    def setUp(self):
        super(DomainTestFixtureGen, self).setUp()
        # child of config-root
        self._obj = Domain(self._name)
        try:
            self._obj = self._conn_drv.domain_read (fq_name=self._obj.get_fq_name())
        except NoIdError:
            self._conn_drv.domain_create(self._obj)
        self._update_links ()
        self.populate ()
    #end setUp

    def cleanUp(self):
        if not (self._obj.get_projects() or self._obj.get_namespaces() or self._obj.get_service_templates() or self._obj.get_virtual_DNSs()):
            self._conn_drv.domain_delete(id = self._obj.uuid)
            if hasattr(self, 'parent_type'):
                # non config-root child
                super(DomainTestFixtureGen, self).cleanUp()
    #end cleanUp

    def getObj(self):
        return self._obj
    #end getObj

#end class DomainTestFixtureGen

class ServiceInstanceTestFixtureGen(cfixture.ContrailFixture):
    """
    Fixture for :class:`.ServiceInstance`
    """
    def __init__(self, conn_drv, service_instance_name = None, parent_fixt = None, service_template_refs = None, service_instance_properties=None, id_perms=None):
        '''
        Create ServiceInstanceTestFixtureGen object
        
        constructor

        Args:
            conn_drv (:class:`ConnectionDriver`): connection driver (eg. :class:`vnc_api.vnc_api.VncApi`, :class:`novaclient.client.Client`, etc)

        Kwargs:
            service_instance_name (str): Name of service_instance
            parent_fixt (:class:`.ProjectTestFixtureGen`): Parent fixture
            service_template (list): list of :class:`ServiceTemplate` type
            service_instance_properties (instance): instance of :class:`ServiceInstanceType`
            id_perms (instance): instance of :class:`IdPermsType`

        '''
        self._conn_drv = conn_drv
        if not service_instance_name:
            self._name = 'default-service-instance'
        else:
            self._name = service_instance_name
        self._obj = None
        self._parent_fixt = parent_fixt
        if service_template_refs:
            for ln in service_template_refs:
                self.add_service_template (ln)
        self.service_instance_properties = service_instance_properties
        self.id_perms = id_perms
    #end __init__

    def _update_links (self):
        for ln in self.get_service_templates ():
            self.add_service_template (ln.fixture ())
        return None
    #end _update_links

    def add_service_template (self, lo):
        '''
        add :class:`ServiceTemplate` link to :class:`ServiceInstance`
        Args:
            lo (:class:`ServiceTemplate`): obj to link
        '''
        if self._obj:
            self._obj.add_service_template (lo)
            self._conn_drv.service_instance_update (self._obj)
        return self.add_link('service_template', cfixture.ConrtailLink('service_template', 'service_instance', 'service_template', ['ref'], lo))
    #end add_service_template_link

    def get_service_templates (self):
        return self.get_links ('service_template')
    #end get_service_templates

    def populate (self):
        self._obj.set_service_instance_properties(self.service_instance_properties or ServiceInstanceType.populate())
        self._obj.set_id_perms(self.id_perms or IdPermsType.populate())
    #end populate

    def setUp(self):
        super(ServiceInstanceTestFixtureGen, self).setUp()
        if not self._parent_fixt:
            self._parent_fixt = self.useFixture(ProjectTestFixtureGen(self._conn_drv, 'default-project'))
        self._obj = ServiceInstance(self._name, self._parent_fixt.getObj ())
        try:
            self._obj = self._conn_drv.service_instance_read (fq_name=self._obj.get_fq_name())
        except NoIdError:
            self._conn_drv.service_instance_create(self._obj)
        self._update_links ()
        self.populate ()
    #end setUp

    def cleanUp(self):
        if not (False):
            self._conn_drv.service_instance_delete(id = self._obj.uuid)
            if hasattr(self, 'parent_type'):
                # non config-root child
                super(ServiceInstanceTestFixtureGen, self).cleanUp()
    #end cleanUp

    def getObj(self):
        return self._obj
    #end getObj

#end class ServiceInstanceTestFixtureGen

class InstanceIpTestFixtureGen(cfixture.ContrailFixture):
    """
    Fixture for :class:`.InstanceIp`
    """
    def __init__(self, conn_drv, instance_ip_name = None, virtual_network_refs = None, virtual_machine_interface_refs = None, instance_ip_address=None, id_perms=None):
        '''
        Create InstanceIpTestFixtureGen object
        
        constructor

        Args:
            conn_drv (:class:`ConnectionDriver`): connection driver (eg. :class:`vnc_api.vnc_api.VncApi`, :class:`novaclient.client.Client`, etc)

        Kwargs:
            %s_name (str): Name of %s
            virtual_network (list): list of :class:`VirtualNetwork` type
            virtual_machine_interface (list): list of :class:`VirtualMachineInterface` type
            instance_ip_address (instance): instance of :class:`xsd:string`
            id_perms (instance): instance of :class:`IdPermsType`

        '''
        self._conn_drv = conn_drv
        if not instance_ip_name:
            self._name = 'default-instance-ip'
        else:
            self._name = instance_ip_name
        self._obj = None
        if virtual_network_refs:
            for ln in virtual_network_refs:
                self.add_virtual_network (ln)
        if virtual_machine_interface_refs:
            for ln in virtual_machine_interface_refs:
                self.add_virtual_machine_interface (ln)
        self.instance_ip_address = instance_ip_address
        self.id_perms = id_perms
    #end __init__

    def _update_links (self):
        for ln in self.get_virtual_networks ():
            self.add_virtual_network (ln.fixture ())
        for ln in self.get_virtual_machine_interfaces ():
            self.add_virtual_machine_interface (ln.fixture ())
        return None
    #end _update_links

    def add_virtual_network (self, lo):
        '''
        add :class:`VirtualNetwork` link to :class:`InstanceIp`
        Args:
            lo (:class:`VirtualNetwork`): obj to link
        '''
        if self._obj:
            self._obj.add_virtual_network (lo)
            self._conn_drv.instance_ip_update (self._obj)
        return self.add_link('virtual_network', cfixture.ConrtailLink('virtual_network', 'instance_ip', 'virtual_network', ['ref'], lo))
    #end add_virtual_network_link

    def get_virtual_networks (self):
        return self.get_links ('virtual_network')
    #end get_virtual_networks
    def add_virtual_machine_interface (self, lo):
        '''
        add :class:`VirtualMachineInterface` link to :class:`InstanceIp`
        Args:
            lo (:class:`VirtualMachineInterface`): obj to link
        '''
        if self._obj:
            self._obj.add_virtual_machine_interface (lo)
            self._conn_drv.instance_ip_update (self._obj)
        return self.add_link('virtual_machine_interface', cfixture.ConrtailLink('virtual_machine_interface', 'instance_ip', 'virtual_machine_interface', ['ref'], lo))
    #end add_virtual_machine_interface_link

    def get_virtual_machine_interfaces (self):
        return self.get_links ('virtual_machine_interface')
    #end get_virtual_machine_interfaces

    def populate (self):
        self._obj.set_instance_ip_address(self.instance_ip_address or GeneratedsSuper.populate_string("instance_ip_address"))
        self._obj.set_id_perms(self.id_perms or IdPermsType.populate())
    #end populate

    def setUp(self):
        super(InstanceIpTestFixtureGen, self).setUp()
        self._obj = InstanceIp(self._name)
        try:
            self._obj = self._conn_drv.instance_ip_read (fq_name=self._obj.get_fq_name())
        except NoIdError:
            self._conn_drv.instance_ip_create(self._obj)
        self._update_links ()
        self.populate ()
    #end setUp

    def cleanUp(self):
        if not (False):
            self._conn_drv.instance_ip_delete(id = self._obj.uuid)
    #end cleanUp

    def getObj(self):
        return self._obj
    #end getObj

#end class InstanceIpTestFixtureGen

class NetworkPolicyTestFixtureGen(cfixture.ContrailFixture):
    """
    Fixture for :class:`.NetworkPolicy`
    """
    def __init__(self, conn_drv, network_policy_name = None, parent_fixt = None, network_policy_entries=None, id_perms=None):
        '''
        Create NetworkPolicyTestFixtureGen object
        
        constructor

        Args:
            conn_drv (:class:`ConnectionDriver`): connection driver (eg. :class:`vnc_api.vnc_api.VncApi`, :class:`novaclient.client.Client`, etc)

        Kwargs:
            network_policy_name (str): Name of network_policy
            parent_fixt (:class:`.ProjectTestFixtureGen`): Parent fixture
            network_policy_entries (instance): instance of :class:`PolicyEntriesType`
            id_perms (instance): instance of :class:`IdPermsType`

        '''
        self._conn_drv = conn_drv
        if not network_policy_name:
            self._name = 'default-network-policy'
        else:
            self._name = network_policy_name
        self._obj = None
        self._parent_fixt = parent_fixt
        self.network_policy_entries = network_policy_entries
        self.id_perms = id_perms
    #end __init__

    def _update_links (self):
        return None
    #end _update_links


    def populate (self):
        self._obj.set_network_policy_entries(self.network_policy_entries or PolicyEntriesType.populate())
        self._obj.set_id_perms(self.id_perms or IdPermsType.populate())
    #end populate

    def setUp(self):
        super(NetworkPolicyTestFixtureGen, self).setUp()
        if not self._parent_fixt:
            self._parent_fixt = self.useFixture(ProjectTestFixtureGen(self._conn_drv, 'default-project'))
        self._obj = NetworkPolicy(self._name, self._parent_fixt.getObj ())
        try:
            self._obj = self._conn_drv.network_policy_read (fq_name=self._obj.get_fq_name())
        except NoIdError:
            self._conn_drv.network_policy_create(self._obj)
        self._update_links ()
        self.populate ()
    #end setUp

    def cleanUp(self):
        if not (False):
            self._conn_drv.network_policy_delete(id = self._obj.uuid)
            if hasattr(self, 'parent_type'):
                # non config-root child
                super(NetworkPolicyTestFixtureGen, self).cleanUp()
    #end cleanUp

    def getObj(self):
        return self._obj
    #end getObj

#end class NetworkPolicyTestFixtureGen

class VirtualDnsRecordTestFixtureGen(cfixture.ContrailFixture):
    """
    Fixture for :class:`.VirtualDnsRecord`
    """
    def __init__(self, conn_drv, virtual_DNS_record_name = None, parent_fixt = None, virtual_DNS_record_data=None, id_perms=None):
        '''
        Create VirtualDnsRecordTestFixtureGen object
        
        constructor

        Args:
            conn_drv (:class:`ConnectionDriver`): connection driver (eg. :class:`vnc_api.vnc_api.VncApi`, :class:`novaclient.client.Client`, etc)

        Kwargs:
            virtual_DNS_record_name (str): Name of virtual_DNS_record
            parent_fixt (:class:`.VirtualDnsTestFixtureGen`): Parent fixture
            virtual_DNS_record_data (instance): instance of :class:`VirtualDnsRecordType`
            id_perms (instance): instance of :class:`IdPermsType`

        '''
        self._conn_drv = conn_drv
        if not virtual_DNS_record_name:
            self._name = 'default-virtual-DNS-record'
        else:
            self._name = virtual_DNS_record_name
        self._obj = None
        self._parent_fixt = parent_fixt
        self.virtual_DNS_record_data = virtual_DNS_record_data
        self.id_perms = id_perms
    #end __init__

    def _update_links (self):
        return None
    #end _update_links


    def populate (self):
        self._obj.set_virtual_DNS_record_data(self.virtual_DNS_record_data or VirtualDnsRecordType.populate())
        self._obj.set_id_perms(self.id_perms or IdPermsType.populate())
    #end populate

    def setUp(self):
        super(VirtualDnsRecordTestFixtureGen, self).setUp()
        if not self._parent_fixt:
            self._parent_fixt = self.useFixture(VirtualDnsTestFixtureGen(self._conn_drv, 'default-virtual-DNS'))
        self._obj = VirtualDnsRecord(self._name, self._parent_fixt.getObj ())
        try:
            self._obj = self._conn_drv.virtual_DNS_record_read (fq_name=self._obj.get_fq_name())
        except NoIdError:
            self._conn_drv.virtual_DNS_record_create(self._obj)
        self._update_links ()
        self.populate ()
    #end setUp

    def cleanUp(self):
        if not (False):
            self._conn_drv.virtual_DNS_record_delete(id = self._obj.uuid)
            if hasattr(self, 'parent_type'):
                # non config-root child
                super(VirtualDnsRecordTestFixtureGen, self).cleanUp()
    #end cleanUp

    def getObj(self):
        return self._obj
    #end getObj

#end class VirtualDnsRecordTestFixtureGen

class RouteTargetTestFixtureGen(cfixture.ContrailFixture):
    """
    Fixture for :class:`.RouteTarget`
    """
    def __init__(self, conn_drv, route_target_name = None, id_perms=None):
        '''
        Create RouteTargetTestFixtureGen object
        
        constructor

        Args:
            conn_drv (:class:`ConnectionDriver`): connection driver (eg. :class:`vnc_api.vnc_api.VncApi`, :class:`novaclient.client.Client`, etc)

        Kwargs:
            %s_name (str): Name of %s
            id_perms (instance): instance of :class:`IdPermsType`

        '''
        self._conn_drv = conn_drv
        if not route_target_name:
            self._name = 'default-route-target'
        else:
            self._name = route_target_name
        self._obj = None
        self.id_perms = id_perms
    #end __init__

    def _update_links (self):
        return None
    #end _update_links


    def populate (self):
        self._obj.set_id_perms(self.id_perms or IdPermsType.populate())
    #end populate

    def setUp(self):
        super(RouteTargetTestFixtureGen, self).setUp()
        self._obj = RouteTarget(self._name)
        try:
            self._obj = self._conn_drv.route_target_read (fq_name=self._obj.get_fq_name())
        except NoIdError:
            self._conn_drv.route_target_create(self._obj)
        self._update_links ()
        self.populate ()
    #end setUp

    def cleanUp(self):
        if not (False):
            self._conn_drv.route_target_delete(id = self._obj.uuid)
    #end cleanUp

    def getObj(self):
        return self._obj
    #end getObj

#end class RouteTargetTestFixtureGen

class FloatingIpTestFixtureGen(cfixture.ContrailFixture):
    """
    Fixture for :class:`.FloatingIp`
    """
    def __init__(self, conn_drv, floating_ip_name = None, parent_fixt = None, project_refs = None, virtual_machine_interface_refs = None, floating_ip_address=None, floating_ip_is_virtual_ip=None, id_perms=None):
        '''
        Create FloatingIpTestFixtureGen object
        
        constructor

        Args:
            conn_drv (:class:`ConnectionDriver`): connection driver (eg. :class:`vnc_api.vnc_api.VncApi`, :class:`novaclient.client.Client`, etc)

        Kwargs:
            floating_ip_name (str): Name of floating_ip
            parent_fixt (:class:`.FloatingIpPoolTestFixtureGen`): Parent fixture
            project (list): list of :class:`Project` type
            virtual_machine_interface (list): list of :class:`VirtualMachineInterface` type
            floating_ip_address (instance): instance of :class:`xsd:string`
            floating_ip_is_virtual_ip (instance): instance of :class:`xsd:boolean`
            id_perms (instance): instance of :class:`IdPermsType`

        '''
        self._conn_drv = conn_drv
        if not floating_ip_name:
            self._name = 'default-floating-ip'
        else:
            self._name = floating_ip_name
        self._obj = None
        self._parent_fixt = parent_fixt
        if project_refs:
            for ln in project_refs:
                self.add_project (ln)
        if virtual_machine_interface_refs:
            for ln in virtual_machine_interface_refs:
                self.add_virtual_machine_interface (ln)
        self.floating_ip_address = floating_ip_address
        self.floating_ip_is_virtual_ip = floating_ip_is_virtual_ip
        self.id_perms = id_perms
    #end __init__

    def _update_links (self):
        for ln in self.get_projects ():
            self.add_project (ln.fixture ())
        for ln in self.get_virtual_machine_interfaces ():
            self.add_virtual_machine_interface (ln.fixture ())
        return None
    #end _update_links

    def add_project (self, lo):
        '''
        add :class:`Project` link to :class:`FloatingIp`
        Args:
            lo (:class:`Project`): obj to link
        '''
        if self._obj:
            self._obj.add_project (lo)
            self._conn_drv.floating_ip_update (self._obj)
        return self.add_link('project', cfixture.ConrtailLink('project', 'floating_ip', 'project', ['ref'], lo))
    #end add_project_link

    def get_projects (self):
        return self.get_links ('project')
    #end get_projects
    def add_virtual_machine_interface (self, lo):
        '''
        add :class:`VirtualMachineInterface` link to :class:`FloatingIp`
        Args:
            lo (:class:`VirtualMachineInterface`): obj to link
        '''
        if self._obj:
            self._obj.add_virtual_machine_interface (lo)
            self._conn_drv.floating_ip_update (self._obj)
        return self.add_link('virtual_machine_interface', cfixture.ConrtailLink('virtual_machine_interface', 'floating_ip', 'virtual_machine_interface', ['ref'], lo))
    #end add_virtual_machine_interface_link

    def get_virtual_machine_interfaces (self):
        return self.get_links ('virtual_machine_interface')
    #end get_virtual_machine_interfaces

    def populate (self):
        self._obj.set_floating_ip_address(self.floating_ip_address or GeneratedsSuper.populate_string("floating_ip_address"))
        self._obj.set_floating_ip_is_virtual_ip(self.floating_ip_is_virtual_ip or GeneratedsSuper.populate_boolean("floating_ip_is_virtual_ip"))
        self._obj.set_id_perms(self.id_perms or IdPermsType.populate())
    #end populate

    def setUp(self):
        super(FloatingIpTestFixtureGen, self).setUp()
        if not self._parent_fixt:
            self._parent_fixt = self.useFixture(FloatingIpPoolTestFixtureGen(self._conn_drv, 'default-floating-ip-pool'))
        self._obj = FloatingIp(self._name, self._parent_fixt.getObj ())
        try:
            self._obj = self._conn_drv.floating_ip_read (fq_name=self._obj.get_fq_name())
        except NoIdError:
            self._conn_drv.floating_ip_create(self._obj)
        self._update_links ()
        self.populate ()
    #end setUp

    def cleanUp(self):
        if not (False):
            self._conn_drv.floating_ip_delete(id = self._obj.uuid)
            if hasattr(self, 'parent_type'):
                # non config-root child
                super(FloatingIpTestFixtureGen, self).cleanUp()
    #end cleanUp

    def getObj(self):
        return self._obj
    #end getObj

#end class FloatingIpTestFixtureGen

class FloatingIpPoolTestFixtureGen(cfixture.ContrailFixture):
    """
    Fixture for :class:`.FloatingIpPool`
    """
    def __init__(self, conn_drv, floating_ip_pool_name = None, parent_fixt = None, floating_ip_pool_prefixes=None, id_perms=None):
        '''
        Create FloatingIpPoolTestFixtureGen object
        
        constructor

        Args:
            conn_drv (:class:`ConnectionDriver`): connection driver (eg. :class:`vnc_api.vnc_api.VncApi`, :class:`novaclient.client.Client`, etc)

        Kwargs:
            floating_ip_pool_name (str): Name of floating_ip_pool
            parent_fixt (:class:`.VirtualNetworkTestFixtureGen`): Parent fixture
            floating_ip_pool_prefixes (instance): instance of :class:`FloatingIpPoolType`
            id_perms (instance): instance of :class:`IdPermsType`

        '''
        self._conn_drv = conn_drv
        if not floating_ip_pool_name:
            self._name = 'default-floating-ip-pool'
        else:
            self._name = floating_ip_pool_name
        self._obj = None
        self._parent_fixt = parent_fixt
        self.floating_ip_pool_prefixes = floating_ip_pool_prefixes
        self.id_perms = id_perms
    #end __init__

    def _update_links (self):
        return None
    #end _update_links


    def populate (self):
        self._obj.set_floating_ip_pool_prefixes(self.floating_ip_pool_prefixes or FloatingIpPoolType.populate())
        self._obj.set_id_perms(self.id_perms or IdPermsType.populate())
    #end populate

    def setUp(self):
        super(FloatingIpPoolTestFixtureGen, self).setUp()
        if not self._parent_fixt:
            self._parent_fixt = self.useFixture(VirtualNetworkTestFixtureGen(self._conn_drv, 'default-virtual-network'))
        self._obj = FloatingIpPool(self._name, self._parent_fixt.getObj ())
        try:
            self._obj = self._conn_drv.floating_ip_pool_read (fq_name=self._obj.get_fq_name())
        except NoIdError:
            self._conn_drv.floating_ip_pool_create(self._obj)
        self._update_links ()
        self.populate ()
    #end setUp

    def cleanUp(self):
        if not (self._obj.get_floating_ips()):
            self._conn_drv.floating_ip_pool_delete(id = self._obj.uuid)
            if hasattr(self, 'parent_type'):
                # non config-root child
                super(FloatingIpPoolTestFixtureGen, self).cleanUp()
    #end cleanUp

    def getObj(self):
        return self._obj
    #end getObj

#end class FloatingIpPoolTestFixtureGen

class PhysicalRouterTestFixtureGen(cfixture.ContrailFixture):
    """
    Fixture for :class:`.PhysicalRouter`
    """
    def __init__(self, conn_drv, physical_router_name = None, parent_fixt = None, bgp_router_refs = None, id_perms=None):
        '''
        Create PhysicalRouterTestFixtureGen object
        
        constructor

        Args:
            conn_drv (:class:`ConnectionDriver`): connection driver (eg. :class:`vnc_api.vnc_api.VncApi`, :class:`novaclient.client.Client`, etc)

        Kwargs:
            physical_router_name (str): Name of physical_router
            parent_fixt (:class:`.GlobalSystemConfigTestFixtureGen`): Parent fixture
            bgp_router (list): list of :class:`BgpRouter` type
            id_perms (instance): instance of :class:`IdPermsType`

        '''
        self._conn_drv = conn_drv
        if not physical_router_name:
            self._name = 'default-physical-router'
        else:
            self._name = physical_router_name
        self._obj = None
        self._parent_fixt = parent_fixt
        if bgp_router_refs:
            for ln in bgp_router_refs:
                self.add_bgp_router (ln)
        self.id_perms = id_perms
    #end __init__

    def _update_links (self):
        for ln in self.get_bgp_routers ():
            self.add_bgp_router (ln.fixture ())
        return None
    #end _update_links

    def add_bgp_router (self, lo):
        '''
        add :class:`BgpRouter` link to :class:`PhysicalRouter`
        Args:
            lo (:class:`BgpRouter`): obj to link
        '''
        if self._obj:
            self._obj.add_bgp_router (lo)
            self._conn_drv.physical_router_update (self._obj)
        return self.add_link('bgp_router', cfixture.ConrtailLink('bgp_router', 'physical_router', 'bgp_router', ['ref'], lo))
    #end add_bgp_router_link

    def get_bgp_routers (self):
        return self.get_links ('bgp_router')
    #end get_bgp_routers

    def populate (self):
        self._obj.set_id_perms(self.id_perms or IdPermsType.populate())
    #end populate

    def setUp(self):
        super(PhysicalRouterTestFixtureGen, self).setUp()
        if not self._parent_fixt:
            self._parent_fixt = self.useFixture(GlobalSystemConfigTestFixtureGen(self._conn_drv, 'default-global-system-config'))
        self._obj = PhysicalRouter(self._name, self._parent_fixt.getObj ())
        try:
            self._obj = self._conn_drv.physical_router_read (fq_name=self._obj.get_fq_name())
        except NoIdError:
            self._conn_drv.physical_router_create(self._obj)
        self._update_links ()
        self.populate ()
    #end setUp

    def cleanUp(self):
        if not (self._obj.get_physical_interfaces()):
            self._conn_drv.physical_router_delete(id = self._obj.uuid)
            if hasattr(self, 'parent_type'):
                # non config-root child
                super(PhysicalRouterTestFixtureGen, self).cleanUp()
    #end cleanUp

    def getObj(self):
        return self._obj
    #end getObj

#end class PhysicalRouterTestFixtureGen

class BgpRouterTestFixtureGen(cfixture.ContrailFixture):
    """
    Fixture for :class:`.BgpRouter`
    """
    def __init__(self, conn_drv, bgp_router_name = None, parent_fixt = None, bgp_router_ref_infos = None, bgp_router_parameters=None, id_perms=None):
        '''
        Create BgpRouterTestFixtureGen object
        
        constructor

        Args:
            conn_drv (:class:`ConnectionDriver`): connection driver (eg. :class:`vnc_api.vnc_api.VncApi`, :class:`novaclient.client.Client`, etc)

        Kwargs:
            bgp_router_name (str): Name of bgp_router
            parent_fixt (:class:`.RoutingInstanceTestFixtureGen`): Parent fixture
            bgp_router (list): list of tuple (:class:`BgpRouter`, :class: `BgpPeeringAttributes`) type
            bgp_router_parameters (instance): instance of :class:`BgpRouterParams`
            id_perms (instance): instance of :class:`IdPermsType`

        '''
        self._conn_drv = conn_drv
        if not bgp_router_name:
            self._name = 'default-bgp-router'
        else:
            self._name = bgp_router_name
        self._obj = None
        self._parent_fixt = parent_fixt
        if bgp_router_ref_infos:
            for ln, ref in bgp_router:
                self.add_bgp_router (ln, ref)
        self.bgp_router_parameters = bgp_router_parameters
        self.id_perms = id_perms
    #end __init__

    def _update_links (self):
        for ln in self.get_bgp_routers ():
            self.add_bgp_router (*ln.fixture ())
        return None
    #end _update_links

    def add_bgp_router (self, lo, ref):
        '''
        add :class:`BgpRouter` link to :class:`BgpRouter`
        Args:
            lo (:class:`BgpRouter`): obj to link
            ref (:class:`BgpPeeringAttributes`): property of the link object
        '''
        if self._obj:
            self._obj.add_bgp_router (lo, ref)
            self._conn_drv.bgp_router_update (self._obj)
        return self.add_link('bgp_router', cfixture.ConrtailLink('bgp_router', 'bgp_router', 'bgp_router', ['ref'], (lo, ref)))
    #end add_bgp_router_link

    def get_bgp_routers (self):
        return self.get_links ('bgp_router')
    #end get_bgp_routers

    def populate (self):
        self._obj.set_bgp_router_parameters(self.bgp_router_parameters or BgpRouterParams.populate())
        self._obj.set_id_perms(self.id_perms or IdPermsType.populate())
    #end populate

    def setUp(self):
        super(BgpRouterTestFixtureGen, self).setUp()
        if not self._parent_fixt:
            self._parent_fixt = self.useFixture(RoutingInstanceTestFixtureGen(self._conn_drv, 'default-routing-instance'))
        self._obj = BgpRouter(self._name, self._parent_fixt.getObj ())
        try:
            self._obj = self._conn_drv.bgp_router_read (fq_name=self._obj.get_fq_name())
        except NoIdError:
            self._conn_drv.bgp_router_create(self._obj)
        self._update_links ()
        self.populate ()
    #end setUp

    def cleanUp(self):
        if not (False):
            self._conn_drv.bgp_router_delete(id = self._obj.uuid)
            if hasattr(self, 'parent_type'):
                # non config-root child
                super(BgpRouterTestFixtureGen, self).cleanUp()
    #end cleanUp

    def getObj(self):
        return self._obj
    #end getObj

#end class BgpRouterTestFixtureGen

class VirtualRouterTestFixtureGen(cfixture.ContrailFixture):
    """
    Fixture for :class:`.VirtualRouter`
    """
    def __init__(self, conn_drv, virtual_router_name = None, parent_fixt = None, bgp_router_refs = None, virtual_machine_refs = None, virtual_router_ip_address=None, id_perms=None):
        '''
        Create VirtualRouterTestFixtureGen object
        
        constructor

        Args:
            conn_drv (:class:`ConnectionDriver`): connection driver (eg. :class:`vnc_api.vnc_api.VncApi`, :class:`novaclient.client.Client`, etc)

        Kwargs:
            virtual_router_name (str): Name of virtual_router
            parent_fixt (:class:`.GlobalSystemConfigTestFixtureGen`): Parent fixture
            bgp_router (list): list of :class:`BgpRouter` type
            virtual_machine (list): list of :class:`VirtualMachine` type
            virtual_router_ip_address (instance): instance of :class:`xsd:string`
            id_perms (instance): instance of :class:`IdPermsType`

        '''
        self._conn_drv = conn_drv
        if not virtual_router_name:
            self._name = 'default-virtual-router'
        else:
            self._name = virtual_router_name
        self._obj = None
        self._parent_fixt = parent_fixt
        if bgp_router_refs:
            for ln in bgp_router_refs:
                self.add_bgp_router (ln)
        if virtual_machine_refs:
            for ln in virtual_machine_refs:
                self.add_virtual_machine (ln)
        self.virtual_router_ip_address = virtual_router_ip_address
        self.id_perms = id_perms
    #end __init__

    def _update_links (self):
        for ln in self.get_bgp_routers ():
            self.add_bgp_router (ln.fixture ())
        for ln in self.get_virtual_machines ():
            self.add_virtual_machine (ln.fixture ())
        return None
    #end _update_links

    def add_bgp_router (self, lo):
        '''
        add :class:`BgpRouter` link to :class:`VirtualRouter`
        Args:
            lo (:class:`BgpRouter`): obj to link
        '''
        if self._obj:
            self._obj.add_bgp_router (lo)
            self._conn_drv.virtual_router_update (self._obj)
        return self.add_link('bgp_router', cfixture.ConrtailLink('bgp_router', 'virtual_router', 'bgp_router', ['ref'], lo))
    #end add_bgp_router_link

    def get_bgp_routers (self):
        return self.get_links ('bgp_router')
    #end get_bgp_routers
    def add_virtual_machine (self, lo):
        '''
        add :class:`VirtualMachine` link to :class:`VirtualRouter`
        Args:
            lo (:class:`VirtualMachine`): obj to link
        '''
        if self._obj:
            self._obj.add_virtual_machine (lo)
            self._conn_drv.virtual_router_update (self._obj)
        return self.add_link('virtual_machine', cfixture.ConrtailLink('virtual_machine', 'virtual_router', 'virtual_machine', ['ref'], lo))
    #end add_virtual_machine_link

    def get_virtual_machines (self):
        return self.get_links ('virtual_machine')
    #end get_virtual_machines

    def populate (self):
        self._obj.set_virtual_router_ip_address(self.virtual_router_ip_address or GeneratedsSuper.populate_string("virtual_router_ip_address"))
        self._obj.set_id_perms(self.id_perms or IdPermsType.populate())
    #end populate

    def setUp(self):
        super(VirtualRouterTestFixtureGen, self).setUp()
        if not self._parent_fixt:
            self._parent_fixt = self.useFixture(GlobalSystemConfigTestFixtureGen(self._conn_drv, 'default-global-system-config'))
        self._obj = VirtualRouter(self._name, self._parent_fixt.getObj ())
        try:
            self._obj = self._conn_drv.virtual_router_read (fq_name=self._obj.get_fq_name())
        except NoIdError:
            self._conn_drv.virtual_router_create(self._obj)
        self._update_links ()
        self.populate ()
    #end setUp

    def cleanUp(self):
        if not (False):
            self._conn_drv.virtual_router_delete(id = self._obj.uuid)
            if hasattr(self, 'parent_type'):
                # non config-root child
                super(VirtualRouterTestFixtureGen, self).cleanUp()
    #end cleanUp

    def getObj(self):
        return self._obj
    #end getObj

#end class VirtualRouterTestFixtureGen

class GlobalSystemConfigTestFixtureGen(cfixture.ContrailFixture):
    """
    Fixture for :class:`.GlobalSystemConfig`
    """
    def __init__(self, conn_drv, global_system_config_name = None, parent_fixt = None, bgp_router_refs = None, autonomous_system=None, id_perms=None):
        '''
        Create GlobalSystemConfigTestFixtureGen object
        
        constructor

        Args:
            conn_drv (:class:`ConnectionDriver`): connection driver (eg. :class:`vnc_api.vnc_api.VncApi`, :class:`novaclient.client.Client`, etc)

        Kwargs:
            global_system_config_name (str): Name of global_system_config
            parent_fixt (:class:`.ConfigRootTestFixtureGen`): Parent fixture
            bgp_router (list): list of :class:`BgpRouter` type
            autonomous_system (instance): instance of :class:`xsd:integer`
            id_perms (instance): instance of :class:`IdPermsType`

        '''
        self._conn_drv = conn_drv
        if not global_system_config_name:
            self._name = 'default-global-system-config'
        else:
            self._name = global_system_config_name
        self._obj = None
        self._parent_fixt = parent_fixt
        if bgp_router_refs:
            for ln in bgp_router_refs:
                self.add_bgp_router (ln)
        self.autonomous_system = autonomous_system
        self.id_perms = id_perms
    #end __init__

    def _update_links (self):
        for ln in self.get_bgp_routers ():
            self.add_bgp_router (ln.fixture ())
        return None
    #end _update_links

    def add_bgp_router (self, lo):
        '''
        add :class:`BgpRouter` link to :class:`GlobalSystemConfig`
        Args:
            lo (:class:`BgpRouter`): obj to link
        '''
        if self._obj:
            self._obj.add_bgp_router (lo)
            self._conn_drv.global_system_config_update (self._obj)
        return self.add_link('bgp_router', cfixture.ConrtailLink('bgp_router', 'global_system_config', 'bgp_router', ['ref'], lo))
    #end add_bgp_router_link

    def get_bgp_routers (self):
        return self.get_links ('bgp_router')
    #end get_bgp_routers

    def populate (self):
        self._obj.set_autonomous_system(self.autonomous_system or GeneratedsSuper.populate_integer("autonomous_system"))
        self._obj.set_id_perms(self.id_perms or IdPermsType.populate())
    #end populate

    def setUp(self):
        super(GlobalSystemConfigTestFixtureGen, self).setUp()
        # child of config-root
        self._obj = GlobalSystemConfig(self._name)
        try:
            self._obj = self._conn_drv.global_system_config_read (fq_name=self._obj.get_fq_name())
        except NoIdError:
            self._conn_drv.global_system_config_create(self._obj)
        self._update_links ()
        self.populate ()
    #end setUp

    def cleanUp(self):
        if not (self._obj.get_physical_routers() or self._obj.get_virtual_routers()):
            self._conn_drv.global_system_config_delete(id = self._obj.uuid)
            if hasattr(self, 'parent_type'):
                # non config-root child
                super(GlobalSystemConfigTestFixtureGen, self).cleanUp()
    #end cleanUp

    def getObj(self):
        return self._obj
    #end getObj

#end class GlobalSystemConfigTestFixtureGen

class NamespaceTestFixtureGen(cfixture.ContrailFixture):
    """
    Fixture for :class:`.Namespace`
    """
    def __init__(self, conn_drv, namespace_name = None, parent_fixt = None, namespace_cidr=None, id_perms=None):
        '''
        Create NamespaceTestFixtureGen object
        
        constructor

        Args:
            conn_drv (:class:`ConnectionDriver`): connection driver (eg. :class:`vnc_api.vnc_api.VncApi`, :class:`novaclient.client.Client`, etc)

        Kwargs:
            namespace_name (str): Name of namespace
            parent_fixt (:class:`.DomainTestFixtureGen`): Parent fixture
            namespace_cidr (instance): instance of :class:`SubnetType`
            id_perms (instance): instance of :class:`IdPermsType`

        '''
        self._conn_drv = conn_drv
        if not namespace_name:
            self._name = 'default-namespace'
        else:
            self._name = namespace_name
        self._obj = None
        self._parent_fixt = parent_fixt
        self.namespace_cidr = namespace_cidr
        self.id_perms = id_perms
    #end __init__

    def _update_links (self):
        return None
    #end _update_links


    def populate (self):
        self._obj.set_namespace_cidr(self.namespace_cidr or SubnetType.populate())
        self._obj.set_id_perms(self.id_perms or IdPermsType.populate())
    #end populate

    def setUp(self):
        super(NamespaceTestFixtureGen, self).setUp()
        if not self._parent_fixt:
            self._parent_fixt = self.useFixture(DomainTestFixtureGen(self._conn_drv, 'default-domain'))
        self._obj = Namespace(self._name, self._parent_fixt.getObj ())
        try:
            self._obj = self._conn_drv.namespace_read (fq_name=self._obj.get_fq_name())
        except NoIdError:
            self._conn_drv.namespace_create(self._obj)
        self._update_links ()
        self.populate ()
    #end setUp

    def cleanUp(self):
        if not (False):
            self._conn_drv.namespace_delete(id = self._obj.uuid)
            if hasattr(self, 'parent_type'):
                # non config-root child
                super(NamespaceTestFixtureGen, self).cleanUp()
    #end cleanUp

    def getObj(self):
        return self._obj
    #end getObj

#end class NamespaceTestFixtureGen

class PhysicalInterfaceTestFixtureGen(cfixture.ContrailFixture):
    """
    Fixture for :class:`.PhysicalInterface`
    """
    def __init__(self, conn_drv, physical_interface_name = None, parent_fixt = None, id_perms=None):
        '''
        Create PhysicalInterfaceTestFixtureGen object
        
        constructor

        Args:
            conn_drv (:class:`ConnectionDriver`): connection driver (eg. :class:`vnc_api.vnc_api.VncApi`, :class:`novaclient.client.Client`, etc)

        Kwargs:
            physical_interface_name (str): Name of physical_interface
            parent_fixt (:class:`.PhysicalRouterTestFixtureGen`): Parent fixture
            id_perms (instance): instance of :class:`IdPermsType`

        '''
        self._conn_drv = conn_drv
        if not physical_interface_name:
            self._name = 'default-physical-interface'
        else:
            self._name = physical_interface_name
        self._obj = None
        self._parent_fixt = parent_fixt
        self.id_perms = id_perms
    #end __init__

    def _update_links (self):
        return None
    #end _update_links


    def populate (self):
        self._obj.set_id_perms(self.id_perms or IdPermsType.populate())
    #end populate

    def setUp(self):
        super(PhysicalInterfaceTestFixtureGen, self).setUp()
        if not self._parent_fixt:
            self._parent_fixt = self.useFixture(PhysicalRouterTestFixtureGen(self._conn_drv, 'default-physical-router'))
        self._obj = PhysicalInterface(self._name, self._parent_fixt.getObj ())
        try:
            self._obj = self._conn_drv.physical_interface_read (fq_name=self._obj.get_fq_name())
        except NoIdError:
            self._conn_drv.physical_interface_create(self._obj)
        self._update_links ()
        self.populate ()
    #end setUp

    def cleanUp(self):
        if not (self._obj.get_logical_interfaces()):
            self._conn_drv.physical_interface_delete(id = self._obj.uuid)
            if hasattr(self, 'parent_type'):
                # non config-root child
                super(PhysicalInterfaceTestFixtureGen, self).cleanUp()
    #end cleanUp

    def getObj(self):
        return self._obj
    #end getObj

#end class PhysicalInterfaceTestFixtureGen

class AccessControlListTestFixtureGen(cfixture.ContrailFixture):
    """
    Fixture for :class:`.AccessControlList`
    """
    def __init__(self, conn_drv, access_control_list_name = None, parent_fixt = None, access_control_list_entries=None, id_perms=None):
        '''
        Create AccessControlListTestFixtureGen object
        
        constructor

        Args:
            conn_drv (:class:`ConnectionDriver`): connection driver (eg. :class:`vnc_api.vnc_api.VncApi`, :class:`novaclient.client.Client`, etc)

        Kwargs:
            access_control_list_name (str): Name of access_control_list
            parent_fixt (:class:`.VirtualNetworkTestFixtureGen`): Parent fixture
            access_control_list_entries (instance): instance of :class:`AclEntriesType`
            id_perms (instance): instance of :class:`IdPermsType`

        '''
        self._conn_drv = conn_drv
        if not access_control_list_name:
            self._name = 'default-access-control-list'
        else:
            self._name = access_control_list_name
        self._obj = None
        self._parent_fixt = parent_fixt
        self.access_control_list_entries = access_control_list_entries
        self.id_perms = id_perms
    #end __init__

    def _update_links (self):
        return None
    #end _update_links


    def populate (self):
        self._obj.set_access_control_list_entries(self.access_control_list_entries or AclEntriesType.populate())
        self._obj.set_id_perms(self.id_perms or IdPermsType.populate())
    #end populate

    def setUp(self):
        super(AccessControlListTestFixtureGen, self).setUp()
        if not self._parent_fixt:
            self._parent_fixt = self.useFixture(VirtualNetworkTestFixtureGen(self._conn_drv, 'default-virtual-network'))
        self._obj = AccessControlList(self._name, self._parent_fixt.getObj ())
        try:
            self._obj = self._conn_drv.access_control_list_read (fq_name=self._obj.get_fq_name())
        except NoIdError:
            self._conn_drv.access_control_list_create(self._obj)
        self._update_links ()
        self.populate ()
    #end setUp

    def cleanUp(self):
        if not (False):
            self._conn_drv.access_control_list_delete(id = self._obj.uuid)
            if hasattr(self, 'parent_type'):
                # non config-root child
                super(AccessControlListTestFixtureGen, self).cleanUp()
    #end cleanUp

    def getObj(self):
        return self._obj
    #end getObj

#end class AccessControlListTestFixtureGen

class VirtualDnsTestFixtureGen(cfixture.ContrailFixture):
    """
    Fixture for :class:`.VirtualDns`
    """
    def __init__(self, conn_drv, virtual_DNS_name = None, parent_fixt = None, virtual_DNS_data=None, id_perms=None):
        '''
        Create VirtualDnsTestFixtureGen object
        
        constructor

        Args:
            conn_drv (:class:`ConnectionDriver`): connection driver (eg. :class:`vnc_api.vnc_api.VncApi`, :class:`novaclient.client.Client`, etc)

        Kwargs:
            virtual_DNS_name (str): Name of virtual_DNS
            parent_fixt (:class:`.DomainTestFixtureGen`): Parent fixture
            virtual_DNS_data (instance): instance of :class:`VirtualDnsType`
            id_perms (instance): instance of :class:`IdPermsType`

        '''
        self._conn_drv = conn_drv
        if not virtual_DNS_name:
            self._name = 'default-virtual-DNS'
        else:
            self._name = virtual_DNS_name
        self._obj = None
        self._parent_fixt = parent_fixt
        self.virtual_DNS_data = virtual_DNS_data
        self.id_perms = id_perms
    #end __init__

    def _update_links (self):
        return None
    #end _update_links


    def populate (self):
        self._obj.set_virtual_DNS_data(self.virtual_DNS_data or VirtualDnsType.populate())
        self._obj.set_id_perms(self.id_perms or IdPermsType.populate())
    #end populate

    def setUp(self):
        super(VirtualDnsTestFixtureGen, self).setUp()
        if not self._parent_fixt:
            self._parent_fixt = self.useFixture(DomainTestFixtureGen(self._conn_drv, 'default-domain'))
        self._obj = VirtualDns(self._name, self._parent_fixt.getObj ())
        try:
            self._obj = self._conn_drv.virtual_DNS_read (fq_name=self._obj.get_fq_name())
        except NoIdError:
            self._conn_drv.virtual_DNS_create(self._obj)
        self._update_links ()
        self.populate ()
    #end setUp

    def cleanUp(self):
        if not (self._obj.get_virtual_DNS_records()):
            self._conn_drv.virtual_DNS_delete(id = self._obj.uuid)
            if hasattr(self, 'parent_type'):
                # non config-root child
                super(VirtualDnsTestFixtureGen, self).cleanUp()
    #end cleanUp

    def getObj(self):
        return self._obj
    #end getObj

#end class VirtualDnsTestFixtureGen

class CustomerAttachmentTestFixtureGen(cfixture.ContrailFixture):
    """
    Fixture for :class:`.CustomerAttachment`
    """
    def __init__(self, conn_drv, customer_attachment_name = None, virtual_machine_interface_refs = None, floating_ip_refs = None, attachment_address=None, id_perms=None):
        '''
        Create CustomerAttachmentTestFixtureGen object
        
        constructor

        Args:
            conn_drv (:class:`ConnectionDriver`): connection driver (eg. :class:`vnc_api.vnc_api.VncApi`, :class:`novaclient.client.Client`, etc)

        Kwargs:
            %s_name (str): Name of %s
            virtual_machine_interface (list): list of :class:`VirtualMachineInterface` type
            floating_ip (list): list of :class:`FloatingIp` type
            attachment_address (instance): instance of :class:`AttachmentAddressType`
            id_perms (instance): instance of :class:`IdPermsType`

        '''
        self._conn_drv = conn_drv
        if not customer_attachment_name:
            self._name = 'default-customer-attachment'
        else:
            self._name = customer_attachment_name
        self._obj = None
        if virtual_machine_interface_refs:
            for ln in virtual_machine_interface_refs:
                self.add_virtual_machine_interface (ln)
        if floating_ip_refs:
            for ln in floating_ip_refs:
                self.add_floating_ip (ln)
        self.attachment_address = attachment_address
        self.id_perms = id_perms
    #end __init__

    def _update_links (self):
        for ln in self.get_virtual_machine_interfaces ():
            self.add_virtual_machine_interface (ln.fixture ())
        for ln in self.get_floating_ips ():
            self.add_floating_ip (ln.fixture ())
        return None
    #end _update_links

    def add_virtual_machine_interface (self, lo):
        '''
        add :class:`VirtualMachineInterface` link to :class:`CustomerAttachment`
        Args:
            lo (:class:`VirtualMachineInterface`): obj to link
        '''
        if self._obj:
            self._obj.add_virtual_machine_interface (lo)
            self._conn_drv.customer_attachment_update (self._obj)
        return self.add_link('virtual_machine_interface', cfixture.ConrtailLink('virtual_machine_interface', 'customer_attachment', 'virtual_machine_interface', ['ref'], lo))
    #end add_virtual_machine_interface_link

    def get_virtual_machine_interfaces (self):
        return self.get_links ('virtual_machine_interface')
    #end get_virtual_machine_interfaces
    def add_floating_ip (self, lo):
        '''
        add :class:`FloatingIp` link to :class:`CustomerAttachment`
        Args:
            lo (:class:`FloatingIp`): obj to link
        '''
        if self._obj:
            self._obj.add_floating_ip (lo)
            self._conn_drv.customer_attachment_update (self._obj)
        return self.add_link('floating_ip', cfixture.ConrtailLink('floating_ip', 'customer_attachment', 'floating_ip', ['ref'], lo))
    #end add_floating_ip_link

    def get_floating_ips (self):
        return self.get_links ('floating_ip')
    #end get_floating_ips

    def populate (self):
        self._obj.set_attachment_address(self.attachment_address or AttachmentAddressType.populate())
        self._obj.set_id_perms(self.id_perms or IdPermsType.populate())
    #end populate

    def setUp(self):
        super(CustomerAttachmentTestFixtureGen, self).setUp()
        self._obj = CustomerAttachment(self._name)
        try:
            self._obj = self._conn_drv.customer_attachment_read (fq_name=self._obj.get_fq_name())
        except NoIdError:
            self._conn_drv.customer_attachment_create(self._obj)
        self._update_links ()
        self.populate ()
    #end setUp

    def cleanUp(self):
        if not (False):
            self._conn_drv.customer_attachment_delete(id = self._obj.uuid)
    #end cleanUp

    def getObj(self):
        return self._obj
    #end getObj

#end class CustomerAttachmentTestFixtureGen

class VirtualMachineTestFixtureGen(cfixture.ContrailFixture):
    """
    Fixture for :class:`.VirtualMachine`
    """
    def __init__(self, conn_drv, virtual_machine_name = None, security_group_refs = None, service_instance_refs = None, id_perms=None):
        '''
        Create VirtualMachineTestFixtureGen object
        
        constructor

        Args:
            conn_drv (:class:`ConnectionDriver`): connection driver (eg. :class:`vnc_api.vnc_api.VncApi`, :class:`novaclient.client.Client`, etc)

        Kwargs:
            %s_name (str): Name of %s
            security_group (list): list of :class:`SecurityGroup` type
            service_instance (list): list of :class:`ServiceInstance` type
            id_perms (instance): instance of :class:`IdPermsType`

        '''
        self._conn_drv = conn_drv
        if not virtual_machine_name:
            self._name = 'default-virtual-machine'
        else:
            self._name = virtual_machine_name
        self._obj = None
        if security_group_refs:
            for ln in security_group_refs:
                self.add_security_group (ln)
        if service_instance_refs:
            for ln in service_instance_refs:
                self.add_service_instance (ln)
        self.id_perms = id_perms
    #end __init__

    def _update_links (self):
        for ln in self.get_security_groups ():
            self.add_security_group (ln.fixture ())
        for ln in self.get_service_instances ():
            self.add_service_instance (ln.fixture ())
        return None
    #end _update_links

    def add_security_group (self, lo):
        '''
        add :class:`SecurityGroup` link to :class:`VirtualMachine`
        Args:
            lo (:class:`SecurityGroup`): obj to link
        '''
        if self._obj:
            self._obj.add_security_group (lo)
            self._conn_drv.virtual_machine_update (self._obj)
        return self.add_link('security_group', cfixture.ConrtailLink('security_group', 'virtual_machine', 'security_group', ['ref'], lo))
    #end add_security_group_link

    def get_security_groups (self):
        return self.get_links ('security_group')
    #end get_security_groups
    def add_service_instance (self, lo):
        '''
        add :class:`ServiceInstance` link to :class:`VirtualMachine`
        Args:
            lo (:class:`ServiceInstance`): obj to link
        '''
        if self._obj:
            self._obj.add_service_instance (lo)
            self._conn_drv.virtual_machine_update (self._obj)
        return self.add_link('service_instance', cfixture.ConrtailLink('service_instance', 'virtual_machine', 'service_instance', ['ref', 'derived'], lo))
    #end add_service_instance_link

    def get_service_instances (self):
        return self.get_links ('service_instance')
    #end get_service_instances

    def populate (self):
        self._obj.set_id_perms(self.id_perms or IdPermsType.populate())
    #end populate

    def setUp(self):
        super(VirtualMachineTestFixtureGen, self).setUp()
        self._obj = VirtualMachine(self._name)
        try:
            self._obj = self._conn_drv.virtual_machine_read (fq_name=self._obj.get_fq_name())
        except NoIdError:
            self._conn_drv.virtual_machine_create(self._obj)
        self._update_links ()
        self.populate ()
    #end setUp

    def cleanUp(self):
        if not (self._obj.get_virtual_machine_interfaces()):
            self._conn_drv.virtual_machine_delete(id = self._obj.uuid)
    #end cleanUp

    def getObj(self):
        return self._obj
    #end getObj

#end class VirtualMachineTestFixtureGen

class ServiceTemplateTestFixtureGen(cfixture.ContrailFixture):
    """
    Fixture for :class:`.ServiceTemplate`
    """
    def __init__(self, conn_drv, service_template_name = None, parent_fixt = None, service_template_properties=None, id_perms=None):
        '''
        Create ServiceTemplateTestFixtureGen object
        
        constructor

        Args:
            conn_drv (:class:`ConnectionDriver`): connection driver (eg. :class:`vnc_api.vnc_api.VncApi`, :class:`novaclient.client.Client`, etc)

        Kwargs:
            service_template_name (str): Name of service_template
            parent_fixt (:class:`.DomainTestFixtureGen`): Parent fixture
            service_template_properties (instance): instance of :class:`ServiceTemplateType`
            id_perms (instance): instance of :class:`IdPermsType`

        '''
        self._conn_drv = conn_drv
        if not service_template_name:
            self._name = 'default-service-template'
        else:
            self._name = service_template_name
        self._obj = None
        self._parent_fixt = parent_fixt
        self.service_template_properties = service_template_properties
        self.id_perms = id_perms
    #end __init__

    def _update_links (self):
        return None
    #end _update_links


    def populate (self):
        self._obj.set_service_template_properties(self.service_template_properties or ServiceTemplateType.populate())
        self._obj.set_id_perms(self.id_perms or IdPermsType.populate())
    #end populate

    def setUp(self):
        super(ServiceTemplateTestFixtureGen, self).setUp()
        if not self._parent_fixt:
            self._parent_fixt = self.useFixture(DomainTestFixtureGen(self._conn_drv, 'default-domain'))
        self._obj = ServiceTemplate(self._name, self._parent_fixt.getObj ())
        try:
            self._obj = self._conn_drv.service_template_read (fq_name=self._obj.get_fq_name())
        except NoIdError:
            self._conn_drv.service_template_create(self._obj)
        self._update_links ()
        self.populate ()
    #end setUp

    def cleanUp(self):
        if not (False):
            self._conn_drv.service_template_delete(id = self._obj.uuid)
            if hasattr(self, 'parent_type'):
                # non config-root child
                super(ServiceTemplateTestFixtureGen, self).cleanUp()
    #end cleanUp

    def getObj(self):
        return self._obj
    #end getObj

#end class ServiceTemplateTestFixtureGen

class SecurityGroupTestFixtureGen(cfixture.ContrailFixture):
    """
    Fixture for :class:`.SecurityGroup`
    """
    def __init__(self, conn_drv, security_group_name = None, parent_fixt = None, security_group_id=None, security_group_entries=None, id_perms=None):
        '''
        Create SecurityGroupTestFixtureGen object
        
        constructor

        Args:
            conn_drv (:class:`ConnectionDriver`): connection driver (eg. :class:`vnc_api.vnc_api.VncApi`, :class:`novaclient.client.Client`, etc)

        Kwargs:
            security_group_name (str): Name of security_group
            parent_fixt (:class:`.ProjectTestFixtureGen`): Parent fixture
            security_group_id (instance): instance of :class:`xsd:unsignedInt`
            security_group_entries (instance): instance of :class:`PolicyEntriesType`
            id_perms (instance): instance of :class:`IdPermsType`

        '''
        self._conn_drv = conn_drv
        if not security_group_name:
            self._name = 'default-security-group'
        else:
            self._name = security_group_name
        self._obj = None
        self._parent_fixt = parent_fixt
        self.security_group_id = security_group_id
        self.security_group_entries = security_group_entries
        self.id_perms = id_perms
    #end __init__

    def _update_links (self):
        return None
    #end _update_links


    def populate (self):
        self._obj.set_security_group_id(self.security_group_id or GeneratedsSuper.populate_unsignedInt("security_group_id"))
        self._obj.set_security_group_entries(self.security_group_entries or PolicyEntriesType.populate())
        self._obj.set_id_perms(self.id_perms or IdPermsType.populate())
    #end populate

    def setUp(self):
        super(SecurityGroupTestFixtureGen, self).setUp()
        if not self._parent_fixt:
            self._parent_fixt = self.useFixture(ProjectTestFixtureGen(self._conn_drv, 'default-project'))
        self._obj = SecurityGroup(self._name, self._parent_fixt.getObj ())
        try:
            self._obj = self._conn_drv.security_group_read (fq_name=self._obj.get_fq_name())
        except NoIdError:
            self._conn_drv.security_group_create(self._obj)
        self._update_links ()
        self.populate ()
    #end setUp

    def cleanUp(self):
        if not (False):
            self._conn_drv.security_group_delete(id = self._obj.uuid)
            if hasattr(self, 'parent_type'):
                # non config-root child
                super(SecurityGroupTestFixtureGen, self).cleanUp()
    #end cleanUp

    def getObj(self):
        return self._obj
    #end getObj

#end class SecurityGroupTestFixtureGen

class ProviderAttachmentTestFixtureGen(cfixture.ContrailFixture):
    """
    Fixture for :class:`.ProviderAttachment`
    """
    def __init__(self, conn_drv, provider_attachment_name = None, virtual_router_refs = None, id_perms=None):
        '''
        Create ProviderAttachmentTestFixtureGen object
        
        constructor

        Args:
            conn_drv (:class:`ConnectionDriver`): connection driver (eg. :class:`vnc_api.vnc_api.VncApi`, :class:`novaclient.client.Client`, etc)

        Kwargs:
            %s_name (str): Name of %s
            virtual_router (list): list of :class:`VirtualRouter` type
            id_perms (instance): instance of :class:`IdPermsType`

        '''
        self._conn_drv = conn_drv
        if not provider_attachment_name:
            self._name = 'default-provider-attachment'
        else:
            self._name = provider_attachment_name
        self._obj = None
        if virtual_router_refs:
            for ln in virtual_router_refs:
                self.add_virtual_router (ln)
        self.id_perms = id_perms
    #end __init__

    def _update_links (self):
        for ln in self.get_virtual_routers ():
            self.add_virtual_router (ln.fixture ())
        return None
    #end _update_links

    def add_virtual_router (self, lo):
        '''
        add :class:`VirtualRouter` link to :class:`ProviderAttachment`
        Args:
            lo (:class:`VirtualRouter`): obj to link
        '''
        if self._obj:
            self._obj.add_virtual_router (lo)
            self._conn_drv.provider_attachment_update (self._obj)
        return self.add_link('virtual_router', cfixture.ConrtailLink('virtual_router', 'provider_attachment', 'virtual_router', ['ref'], lo))
    #end add_virtual_router_link

    def get_virtual_routers (self):
        return self.get_links ('virtual_router')
    #end get_virtual_routers

    def populate (self):
        self._obj.set_id_perms(self.id_perms or IdPermsType.populate())
    #end populate

    def setUp(self):
        super(ProviderAttachmentTestFixtureGen, self).setUp()
        self._obj = ProviderAttachment(self._name)
        try:
            self._obj = self._conn_drv.provider_attachment_read (fq_name=self._obj.get_fq_name())
        except NoIdError:
            self._conn_drv.provider_attachment_create(self._obj)
        self._update_links ()
        self.populate ()
    #end setUp

    def cleanUp(self):
        if not (False):
            self._conn_drv.provider_attachment_delete(id = self._obj.uuid)
    #end cleanUp

    def getObj(self):
        return self._obj
    #end getObj

#end class ProviderAttachmentTestFixtureGen

class NetworkIpamTestFixtureGen(cfixture.ContrailFixture):
    """
    Fixture for :class:`.NetworkIpam`
    """
    def __init__(self, conn_drv, network_ipam_name = None, parent_fixt = None, virtual_DNS_refs = None, network_ipam_mgmt=None, id_perms=None):
        '''
        Create NetworkIpamTestFixtureGen object
        
        constructor

        Args:
            conn_drv (:class:`ConnectionDriver`): connection driver (eg. :class:`vnc_api.vnc_api.VncApi`, :class:`novaclient.client.Client`, etc)

        Kwargs:
            network_ipam_name (str): Name of network_ipam
            parent_fixt (:class:`.ProjectTestFixtureGen`): Parent fixture
            virtual_DNS (list): list of :class:`VirtualDns` type
            network_ipam_mgmt (instance): instance of :class:`IpamType`
            id_perms (instance): instance of :class:`IdPermsType`

        '''
        self._conn_drv = conn_drv
        if not network_ipam_name:
            self._name = 'default-network-ipam'
        else:
            self._name = network_ipam_name
        self._obj = None
        self._parent_fixt = parent_fixt
        if virtual_DNS_refs:
            for ln in virtual_DNS_refs:
                self.add_virtual_DNS (ln)
        self.network_ipam_mgmt = network_ipam_mgmt
        self.id_perms = id_perms
    #end __init__

    def _update_links (self):
        for ln in self.get_virtual_DNSs ():
            self.add_virtual_DNS (ln.fixture ())
        return None
    #end _update_links

    def add_virtual_DNS (self, lo):
        '''
        add :class:`VirtualDns` link to :class:`NetworkIpam`
        Args:
            lo (:class:`VirtualDns`): obj to link
        '''
        if self._obj:
            self._obj.add_virtual_DNS (lo)
            self._conn_drv.network_ipam_update (self._obj)
        return self.add_link('virtual_DNS', cfixture.ConrtailLink('virtual_DNS', 'network_ipam', 'virtual_DNS', ['ref'], lo))
    #end add_virtual_DNS_link

    def get_virtual_DNSs (self):
        return self.get_links ('virtual_DNS')
    #end get_virtual_DNSs

    def populate (self):
        self._obj.set_network_ipam_mgmt(self.network_ipam_mgmt or IpamType.populate())
        self._obj.set_id_perms(self.id_perms or IdPermsType.populate())
    #end populate

    def setUp(self):
        super(NetworkIpamTestFixtureGen, self).setUp()
        if not self._parent_fixt:
            self._parent_fixt = self.useFixture(ProjectTestFixtureGen(self._conn_drv, 'default-project'))
        self._obj = NetworkIpam(self._name, self._parent_fixt.getObj ())
        try:
            self._obj = self._conn_drv.network_ipam_read (fq_name=self._obj.get_fq_name())
        except NoIdError:
            self._conn_drv.network_ipam_create(self._obj)
        self._update_links ()
        self.populate ()
    #end setUp

    def cleanUp(self):
        if not (False):
            self._conn_drv.network_ipam_delete(id = self._obj.uuid)
            if hasattr(self, 'parent_type'):
                # non config-root child
                super(NetworkIpamTestFixtureGen, self).cleanUp()
    #end cleanUp

    def getObj(self):
        return self._obj
    #end getObj

#end class NetworkIpamTestFixtureGen

class VirtualNetworkTestFixtureGen(cfixture.ContrailFixture):
    """
    Fixture for :class:`.VirtualNetwork`
    """
    def __init__(self, conn_drv, virtual_network_name = None, parent_fixt = None, network_ipam_ref_infos = None, network_policy_ref_infos = None, virtual_network_properties=None, route_target_list=None, route_table=None, id_perms=None):
        '''
        Create VirtualNetworkTestFixtureGen object
        
        constructor

        Args:
            conn_drv (:class:`ConnectionDriver`): connection driver (eg. :class:`vnc_api.vnc_api.VncApi`, :class:`novaclient.client.Client`, etc)

        Kwargs:
            virtual_network_name (str): Name of virtual_network
            parent_fixt (:class:`.ProjectTestFixtureGen`): Parent fixture
            network_ipam (list): list of tuple (:class:`NetworkIpam`, :class: `VnSubnetsType`) type
            network_policy (list): list of tuple (:class:`NetworkPolicy`, :class: `VirtualNetworkPolicyType`) type
            virtual_network_properties (instance): instance of :class:`VirtualNetworkType`
            route_target_list (instance): instance of :class:`RouteTargetList`
            route_table (instance): instance of :class:`RouteTableType`
            id_perms (instance): instance of :class:`IdPermsType`

        '''
        self._conn_drv = conn_drv
        if not virtual_network_name:
            self._name = 'default-virtual-network'
        else:
            self._name = virtual_network_name
        self._obj = None
        self._parent_fixt = parent_fixt
        if network_ipam_ref_infos:
            for ln, ref in network_ipam:
                self.add_network_ipam (ln, ref)
        if network_policy_ref_infos:
            for ln, ref in network_policy:
                self.add_network_policy (ln, ref)
        self.virtual_network_properties = virtual_network_properties
        self.route_target_list = route_target_list
        self.route_table = route_table
        self.id_perms = id_perms
    #end __init__

    def _update_links (self):
        for ln in self.get_network_ipams ():
            self.add_network_ipam (*ln.fixture ())
        for ln in self.get_network_policys ():
            self.add_network_policy (*ln.fixture ())
        return None
    #end _update_links

    def add_network_ipam (self, lo, ref):
        '''
        add :class:`NetworkIpam` link to :class:`VirtualNetwork`
        Args:
            lo (:class:`NetworkIpam`): obj to link
            ref (:class:`VnSubnetsType`): property of the link object
        '''
        if self._obj:
            self._obj.add_network_ipam (lo, ref)
            self._conn_drv.virtual_network_update (self._obj)
        return self.add_link('network_ipam', cfixture.ConrtailLink('network_ipam', 'virtual_network', 'network_ipam', ['ref'], (lo, ref)))
    #end add_network_ipam_link

    def get_network_ipams (self):
        return self.get_links ('network_ipam')
    #end get_network_ipams
    def add_network_policy (self, lo, ref):
        '''
        add :class:`NetworkPolicy` link to :class:`VirtualNetwork`
        Args:
            lo (:class:`NetworkPolicy`): obj to link
            ref (:class:`VirtualNetworkPolicyType`): property of the link object
        '''
        if self._obj:
            self._obj.add_network_policy (lo, ref)
            self._conn_drv.virtual_network_update (self._obj)
        return self.add_link('network_policy', cfixture.ConrtailLink('network_policy', 'virtual_network', 'network_policy', ['ref'], (lo, ref)))
    #end add_network_policy_link

    def get_network_policys (self):
        return self.get_links ('network_policy')
    #end get_network_policys

    def populate (self):
        self._obj.set_virtual_network_properties(self.virtual_network_properties or VirtualNetworkType.populate())
        self._obj.set_route_target_list(self.route_target_list or RouteTargetList.populate())
        self._obj.set_route_table(self.route_table or RouteTableType.populate())
        self._obj.set_id_perms(self.id_perms or IdPermsType.populate())
    #end populate

    def setUp(self):
        super(VirtualNetworkTestFixtureGen, self).setUp()
        if not self._parent_fixt:
            self._parent_fixt = self.useFixture(ProjectTestFixtureGen(self._conn_drv, 'default-project'))
        self._obj = VirtualNetwork(self._name, self._parent_fixt.getObj ())
        try:
            self._obj = self._conn_drv.virtual_network_read (fq_name=self._obj.get_fq_name())
        except NoIdError:
            self._conn_drv.virtual_network_create(self._obj)
        self._update_links ()
        self.populate ()
    #end setUp

    def cleanUp(self):
        if not (self._obj.get_access_control_lists() or self._obj.get_floating_ip_pools() or self._obj.get_routing_instances()):
            self._conn_drv.virtual_network_delete(id = self._obj.uuid)
            if hasattr(self, 'parent_type'):
                # non config-root child
                super(VirtualNetworkTestFixtureGen, self).cleanUp()
    #end cleanUp

    def getObj(self):
        return self._obj
    #end getObj

#end class VirtualNetworkTestFixtureGen

class ProjectTestFixtureGen(cfixture.ContrailFixture):
    """
    Fixture for :class:`.Project`
    """
    def __init__(self, conn_drv, project_name = None, parent_fixt = None, namespace_ref_infos = None, floating_ip_pool_refs = None, id_perms=None):
        '''
        Create ProjectTestFixtureGen object
        
        constructor

        Args:
            conn_drv (:class:`ConnectionDriver`): connection driver (eg. :class:`vnc_api.vnc_api.VncApi`, :class:`novaclient.client.Client`, etc)

        Kwargs:
            project_name (str): Name of project
            parent_fixt (:class:`.DomainTestFixtureGen`): Parent fixture
            namespace (list): list of tuple (:class:`Namespace`, :class: `SubnetType`) type
            floating_ip_pool (list): list of :class:`FloatingIpPool` type
            id_perms (instance): instance of :class:`IdPermsType`

        '''
        self._conn_drv = conn_drv
        if not project_name:
            self._name = 'default-project'
        else:
            self._name = project_name
        self._obj = None
        self._parent_fixt = parent_fixt
        if namespace_ref_infos:
            for ln, ref in namespace:
                self.add_namespace (ln, ref)
        if floating_ip_pool_refs:
            for ln in floating_ip_pool_refs:
                self.add_floating_ip_pool (ln)
        self.id_perms = id_perms
    #end __init__

    def _update_links (self):
        for ln in self.get_namespaces ():
            self.add_namespace (*ln.fixture ())
        for ln in self.get_floating_ip_pools ():
            self.add_floating_ip_pool (ln.fixture ())
        return None
    #end _update_links

    def add_namespace (self, lo, ref):
        '''
        add :class:`Namespace` link to :class:`Project`
        Args:
            lo (:class:`Namespace`): obj to link
            ref (:class:`SubnetType`): property of the link object
        '''
        if self._obj:
            self._obj.add_namespace (lo, ref)
            self._conn_drv.project_update (self._obj)
        return self.add_link('namespace', cfixture.ConrtailLink('namespace', 'project', 'namespace', ['ref'], (lo, ref)))
    #end add_namespace_link

    def get_namespaces (self):
        return self.get_links ('namespace')
    #end get_namespaces
    def add_floating_ip_pool (self, lo):
        '''
        add :class:`FloatingIpPool` link to :class:`Project`
        Args:
            lo (:class:`FloatingIpPool`): obj to link
        '''
        if self._obj:
            self._obj.add_floating_ip_pool (lo)
            self._conn_drv.project_update (self._obj)
        return self.add_link('floating_ip_pool', cfixture.ConrtailLink('floating_ip_pool', 'project', 'floating_ip_pool', ['ref'], lo))
    #end add_floating_ip_pool_link

    def get_floating_ip_pools (self):
        return self.get_links ('floating_ip_pool')
    #end get_floating_ip_pools

    def populate (self):
        self._obj.set_id_perms(self.id_perms or IdPermsType.populate())
    #end populate

    def setUp(self):
        super(ProjectTestFixtureGen, self).setUp()
        if not self._parent_fixt:
            self._parent_fixt = self.useFixture(DomainTestFixtureGen(self._conn_drv, 'default-domain'))
        self._obj = Project(self._name, self._parent_fixt.getObj ())
        try:
            self._obj = self._conn_drv.project_read (fq_name=self._obj.get_fq_name())
        except NoIdError:
            self._conn_drv.project_create(self._obj)
        self._update_links ()
        self.populate ()
    #end setUp

    def cleanUp(self):
        if not (self._obj.get_security_groups() or self._obj.get_virtual_networks() or self._obj.get_network_ipams() or self._obj.get_network_policys() or self._obj.get_service_instances()):
            self._conn_drv.project_delete(id = self._obj.uuid)
            if hasattr(self, 'parent_type'):
                # non config-root child
                super(ProjectTestFixtureGen, self).cleanUp()
    #end cleanUp

    def getObj(self):
        return self._obj
    #end getObj

#end class ProjectTestFixtureGen

class LogicalInterfaceTestFixtureGen(cfixture.ContrailFixture):
    """
    Fixture for :class:`.LogicalInterface`
    """
    def __init__(self, conn_drv, logical_interface_name = None, parent_fixt = None, virtual_network_refs = None, id_perms=None):
        '''
        Create LogicalInterfaceTestFixtureGen object
        
        constructor

        Args:
            conn_drv (:class:`ConnectionDriver`): connection driver (eg. :class:`vnc_api.vnc_api.VncApi`, :class:`novaclient.client.Client`, etc)

        Kwargs:
            logical_interface_name (str): Name of logical_interface
            parent_fixt (:class:`.PhysicalInterfaceTestFixtureGen`): Parent fixture
            virtual_network (list): list of :class:`VirtualNetwork` type
            id_perms (instance): instance of :class:`IdPermsType`

        '''
        self._conn_drv = conn_drv
        if not logical_interface_name:
            self._name = 'default-logical-interface'
        else:
            self._name = logical_interface_name
        self._obj = None
        self._parent_fixt = parent_fixt
        if virtual_network_refs:
            for ln in virtual_network_refs:
                self.add_virtual_network (ln)
        self.id_perms = id_perms
    #end __init__

    def _update_links (self):
        for ln in self.get_virtual_networks ():
            self.add_virtual_network (ln.fixture ())
        return None
    #end _update_links

    def add_virtual_network (self, lo):
        '''
        add :class:`VirtualNetwork` link to :class:`LogicalInterface`
        Args:
            lo (:class:`VirtualNetwork`): obj to link
        '''
        if self._obj:
            self._obj.add_virtual_network (lo)
            self._conn_drv.logical_interface_update (self._obj)
        return self.add_link('virtual_network', cfixture.ConrtailLink('virtual_network', 'logical_interface', 'virtual_network', ['ref'], lo))
    #end add_virtual_network_link

    def get_virtual_networks (self):
        return self.get_links ('virtual_network')
    #end get_virtual_networks

    def populate (self):
        self._obj.set_id_perms(self.id_perms or IdPermsType.populate())
    #end populate

    def setUp(self):
        super(LogicalInterfaceTestFixtureGen, self).setUp()
        if not self._parent_fixt:
            self._parent_fixt = self.useFixture(PhysicalInterfaceTestFixtureGen(self._conn_drv, 'default-physical-interface'))
        self._obj = LogicalInterface(self._name, self._parent_fixt.getObj ())
        try:
            self._obj = self._conn_drv.logical_interface_read (fq_name=self._obj.get_fq_name())
        except NoIdError:
            self._conn_drv.logical_interface_create(self._obj)
        self._update_links ()
        self.populate ()
    #end setUp

    def cleanUp(self):
        if not (False):
            self._conn_drv.logical_interface_delete(id = self._obj.uuid)
            if hasattr(self, 'parent_type'):
                # non config-root child
                super(LogicalInterfaceTestFixtureGen, self).cleanUp()
    #end cleanUp

    def getObj(self):
        return self._obj
    #end getObj

#end class LogicalInterfaceTestFixtureGen

class RoutingInstanceTestFixtureGen(cfixture.ContrailFixture):
    """
    Fixture for :class:`.RoutingInstance`
    """
    def __init__(self, conn_drv, routing_instance_name = None, parent_fixt = None, routing_instance_ref_infos = None, route_target_ref_infos = None, static_route_entries=None, service_chain_information=None, default_ce_protocol=None, id_perms=None):
        '''
        Create RoutingInstanceTestFixtureGen object
        
        constructor

        Args:
            conn_drv (:class:`ConnectionDriver`): connection driver (eg. :class:`vnc_api.vnc_api.VncApi`, :class:`novaclient.client.Client`, etc)

        Kwargs:
            routing_instance_name (str): Name of routing_instance
            parent_fixt (:class:`.VirtualNetworkTestFixtureGen`): Parent fixture
            routing_instance (list): list of tuple (:class:`RoutingInstance`, :class: `ConnectionType`) type
            route_target (list): list of tuple (:class:`RouteTarget`, :class: `InstanceTargetType`) type
            static_route_entries (instance): instance of :class:`StaticRouteEntriesType`
            service_chain_information (instance): instance of :class:`ServiceChainInfo`
            default_ce_protocol (instance): instance of :class:`DefaultProtocolType`
            id_perms (instance): instance of :class:`IdPermsType`

        '''
        self._conn_drv = conn_drv
        if not routing_instance_name:
            self._name = 'default-routing-instance'
        else:
            self._name = routing_instance_name
        self._obj = None
        self._parent_fixt = parent_fixt
        if routing_instance_ref_infos:
            for ln, ref in routing_instance:
                self.add_routing_instance (ln, ref)
        if route_target_ref_infos:
            for ln, ref in route_target:
                self.add_route_target (ln, ref)
        self.static_route_entries = static_route_entries
        self.service_chain_information = service_chain_information
        self.default_ce_protocol = default_ce_protocol
        self.id_perms = id_perms
    #end __init__

    def _update_links (self):
        for ln in self.get_routing_instances ():
            self.add_routing_instance (*ln.fixture ())
        for ln in self.get_route_targets ():
            self.add_route_target (*ln.fixture ())
        return None
    #end _update_links

    def add_routing_instance (self, lo, ref):
        '''
        add :class:`RoutingInstance` link to :class:`RoutingInstance`
        Args:
            lo (:class:`RoutingInstance`): obj to link
            ref (:class:`ConnectionType`): property of the link object
        '''
        if self._obj:
            self._obj.add_routing_instance (lo, ref)
            self._conn_drv.routing_instance_update (self._obj)
        return self.add_link('routing_instance', cfixture.ConrtailLink('routing_instance', 'routing_instance', 'routing_instance', ['ref'], (lo, ref)))
    #end add_routing_instance_link

    def get_routing_instances (self):
        return self.get_links ('routing_instance')
    #end get_routing_instances
    def add_route_target (self, lo, ref):
        '''
        add :class:`RouteTarget` link to :class:`RoutingInstance`
        Args:
            lo (:class:`RouteTarget`): obj to link
            ref (:class:`InstanceTargetType`): property of the link object
        '''
        if self._obj:
            self._obj.add_route_target (lo, ref)
            self._conn_drv.routing_instance_update (self._obj)
        return self.add_link('route_target', cfixture.ConrtailLink('route_target', 'routing_instance', 'route_target', ['ref'], (lo, ref)))
    #end add_route_target_link

    def get_route_targets (self):
        return self.get_links ('route_target')
    #end get_route_targets

    def populate (self):
        self._obj.set_static_route_entries(self.static_route_entries or StaticRouteEntriesType.populate())
        self._obj.set_service_chain_information(self.service_chain_information or ServiceChainInfo.populate())
        self._obj.set_default_ce_protocol(self.default_ce_protocol or DefaultProtocolType.populate())
        self._obj.set_id_perms(self.id_perms or IdPermsType.populate())
    #end populate

    def setUp(self):
        super(RoutingInstanceTestFixtureGen, self).setUp()
        if not self._parent_fixt:
            self._parent_fixt = self.useFixture(VirtualNetworkTestFixtureGen(self._conn_drv, 'default-virtual-network'))
        self._obj = RoutingInstance(self._name, self._parent_fixt.getObj ())
        try:
            self._obj = self._conn_drv.routing_instance_read (fq_name=self._obj.get_fq_name())
        except NoIdError:
            self._conn_drv.routing_instance_create(self._obj)
        self._update_links ()
        self.populate ()
    #end setUp

    def cleanUp(self):
        if not (self._obj.get_bgp_routers()):
            self._conn_drv.routing_instance_delete(id = self._obj.uuid)
            if hasattr(self, 'parent_type'):
                # non config-root child
                super(RoutingInstanceTestFixtureGen, self).cleanUp()
    #end cleanUp

    def getObj(self):
        return self._obj
    #end getObj

#end class RoutingInstanceTestFixtureGen

class VirtualMachineInterfaceTestFixtureGen(cfixture.ContrailFixture):
    """
    Fixture for :class:`.VirtualMachineInterface`
    """
    def __init__(self, conn_drv, virtual_machine_interface_name = None, parent_fixt = None, virtual_network_refs = None, routing_instance_ref_infos = None, virtual_machine_interface_mac_addresses=None, virtual_machine_interface_properties=None, id_perms=None):
        '''
        Create VirtualMachineInterfaceTestFixtureGen object
        
        constructor

        Args:
            conn_drv (:class:`ConnectionDriver`): connection driver (eg. :class:`vnc_api.vnc_api.VncApi`, :class:`novaclient.client.Client`, etc)

        Kwargs:
            virtual_machine_interface_name (str): Name of virtual_machine_interface
            parent_fixt (:class:`.VirtualMachineTestFixtureGen`): Parent fixture
            virtual_network (list): list of :class:`VirtualNetwork` type
            routing_instance (list): list of tuple (:class:`RoutingInstance`, :class: `PolicyBasedForwardingRuleType`) type
            virtual_machine_interface_mac_addresses (instance): instance of :class:`MacAddressesType`
            virtual_machine_interface_properties (instance): instance of :class:`VirtualMachineInterfacePropertiesType`
            id_perms (instance): instance of :class:`IdPermsType`

        '''
        self._conn_drv = conn_drv
        if not virtual_machine_interface_name:
            self._name = 'default-virtual-machine-interface'
        else:
            self._name = virtual_machine_interface_name
        self._obj = None
        self._parent_fixt = parent_fixt
        if virtual_network_refs:
            for ln in virtual_network_refs:
                self.add_virtual_network (ln)
        if routing_instance_ref_infos:
            for ln, ref in routing_instance:
                self.add_routing_instance (ln, ref)
        self.virtual_machine_interface_mac_addresses = virtual_machine_interface_mac_addresses
        self.virtual_machine_interface_properties = virtual_machine_interface_properties
        self.id_perms = id_perms
    #end __init__

    def _update_links (self):
        for ln in self.get_virtual_networks ():
            self.add_virtual_network (ln.fixture ())
        for ln in self.get_routing_instances ():
            self.add_routing_instance (*ln.fixture ())
        return None
    #end _update_links

    def add_virtual_network (self, lo):
        '''
        add :class:`VirtualNetwork` link to :class:`VirtualMachineInterface`
        Args:
            lo (:class:`VirtualNetwork`): obj to link
        '''
        if self._obj:
            self._obj.add_virtual_network (lo)
            self._conn_drv.virtual_machine_interface_update (self._obj)
        return self.add_link('virtual_network', cfixture.ConrtailLink('virtual_network', 'virtual_machine_interface', 'virtual_network', ['ref'], lo))
    #end add_virtual_network_link

    def get_virtual_networks (self):
        return self.get_links ('virtual_network')
    #end get_virtual_networks
    def add_routing_instance (self, lo, ref):
        '''
        add :class:`RoutingInstance` link to :class:`VirtualMachineInterface`
        Args:
            lo (:class:`RoutingInstance`): obj to link
            ref (:class:`PolicyBasedForwardingRuleType`): property of the link object
        '''
        if self._obj:
            self._obj.add_routing_instance (lo, ref)
            self._conn_drv.virtual_machine_interface_update (self._obj)
        return self.add_link('routing_instance', cfixture.ConrtailLink('routing_instance', 'virtual_machine_interface', 'routing_instance', ['ref'], (lo, ref)))
    #end add_routing_instance_link

    def get_routing_instances (self):
        return self.get_links ('routing_instance')
    #end get_routing_instances

    def populate (self):
        self._obj.set_virtual_machine_interface_mac_addresses(self.virtual_machine_interface_mac_addresses or MacAddressesType.populate())
        self._obj.set_virtual_machine_interface_properties(self.virtual_machine_interface_properties or VirtualMachineInterfacePropertiesType.populate())
        self._obj.set_id_perms(self.id_perms or IdPermsType.populate())
    #end populate

    def setUp(self):
        super(VirtualMachineInterfaceTestFixtureGen, self).setUp()
        if not self._parent_fixt:
            self._parent_fixt = self.useFixture(VirtualMachineTestFixtureGen(self._conn_drv, 'default-virtual-machine'))
        self._obj = VirtualMachineInterface(self._name, self._parent_fixt.getObj ())
        try:
            self._obj = self._conn_drv.virtual_machine_interface_read (fq_name=self._obj.get_fq_name())
        except NoIdError:
            self._conn_drv.virtual_machine_interface_create(self._obj)
        self._update_links ()
        self.populate ()
    #end setUp

    def cleanUp(self):
        if not (False):
            self._conn_drv.virtual_machine_interface_delete(id = self._obj.uuid)
            if hasattr(self, 'parent_type'):
                # non config-root child
                super(VirtualMachineInterfaceTestFixtureGen, self).cleanUp()
    #end cleanUp

    def getObj(self):
        return self._obj
    #end getObj

#end class VirtualMachineInterfaceTestFixtureGen


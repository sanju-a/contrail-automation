
# AUTO-GENERATED file from IFMapApiGenerator. Do Not Edit!

"""
This module defines the classes for every configuration element managed by the system
"""

class Domain(object):
    """
    Represents domain configuration representation.

    Child of:
        :class:`.ConfigRoot` object OR

    Properties:
        * domain-limits (:class:`.DomainLimitsType` type)
        * api-access-list (:class:`.ApiAccessListType` type)
        * id-perms (:class:`.IdPermsType` type)

    Children:
        * list of :class:`.Project` objects
        * list of :class:`.Namespace` objects
        * list of :class:`.ServiceTemplate` objects
        * list of :class:`.VirtualDns` objects

    References to:

    Referred by:
    """

    def __init__(self, name = None, parent_obj = None, domain_limits = None, api_access_list = None, id_perms = None, **kwargs):
        # type-independent fields
        self._type = 'domain'
        if not name:
            name = u'default-domain'
        self.name = name
        self.uuid = None
        if parent_obj:
            self.parent_type = parent_obj._type
            # copy parent's fq_name
            fq_name = list(parent_obj.fq_name)
            fq_name.append(name)
            if not parent_obj.get_domains():
                parent_obj.domains = []
            parent_obj.domains.append(self)
        else: # No parent obj specified
            fq_name = [name]
        self.fq_name = fq_name

        # property fields
        if domain_limits:
            self.domain_limits = domain_limits
        if api_access_list:
            self.api_access_list = api_access_list
        if id_perms:
            self.id_perms = id_perms
    #end __init__

    @classmethod
    def factory(cls, **kwargs):
        obj = Domain()
        obj.__dict__.update(kwargs)
        return obj
    #end factory

    def get_type(self):
        """Return object type (domain)."""
        return self._type
    #end get_type

    def get_fq_name(self):
        """Return FQN of domain in list form."""
        return self.fq_name
    #end get_fq_name

    def get_fq_name_str(self):
        """Return FQN of domain as colon delimited string."""
        return ':'.join(self.fq_name)
    #end get_fq_name_str

    @property
    def parent_name(self):
        return self.fq_name[:-1][-1]
    #end parent_name

    def get_parent_fq_name(self):
        """Return FQN of domain's parent in list form."""
        if not hasattr(self, 'parent_type'):
            # child of config-root
            return None

        return self.fq_name[:-1]
    #end get_parent_fq_name

    def get_parent_fq_name_str(self):
        """Return FQN of domain's parent as colon delimted string."""
        if not hasattr(self, 'parent_type'):
            # child of config-root
            return None

        return ':'.join(self.fq_name[:-1])
    #end get_parent_fq_name_str

    def set_domain_limits(self, domain_limits):
        """Set domain-limits for domain.
        
        :param domain_limits: DomainLimitsType object
        
        """
        self.domain_limits = domain_limits
    #end set_domain_limits

    def get_domain_limits(self):
        """Get domain-limits for domain.
        
        :returns: DomainLimitsType object
        
        """
        return getattr(self, 'domain_limits', None)
    #end get_domain_limits

    def set_api_access_list(self, api_access_list):
        """Set api-access-list for domain.
        
        :param api_access_list: ApiAccessListType object
        
        """
        self.api_access_list = api_access_list
    #end set_api_access_list

    def get_api_access_list(self):
        """Get api-access-list for domain.
        
        :returns: ApiAccessListType object
        
        """
        return getattr(self, 'api_access_list', None)
    #end get_api_access_list

    def set_id_perms(self, id_perms):
        """Set id-perms for domain.
        
        :param id_perms: IdPermsType object
        
        """
        self.id_perms = id_perms
    #end set_id_perms

    def get_id_perms(self):
        """Get id-perms for domain.
        
        :returns: IdPermsType object
        
        """
        return getattr(self, 'id_perms', None)
    #end get_id_perms


    def get_projects(self):
        return getattr(self, 'projects', None)
    #end get_projects

    def get_namespaces(self):
        return getattr(self, 'namespaces', None)
    #end get_namespaces

    def get_service_templates(self):
        return getattr(self, 'service_templates', None)
    #end get_service_templates

    def get_virtual_DNSs(self):
        return getattr(self, 'virtual_DNSs', None)
    #end get_virtual_DNSs

    def get_config_root_back_refs(self):
        """Return list of all config-roots using this domain"""
        return getattr(self, 'config_root_back_refs', None)
    #end get_config_root_back_refs

    def dump(self):
        """Display domain object in compact form."""
        print '------------ domain ------------'
        print 'Name = ', self.get_fq_name()
        print 'Uuid = ', self.uuid
        if hasattr(self, 'parent_type'): # non config-root children
            print 'Parent Type = ', self.parent_type
        print 'P domain_limits = ', self.get_domain_limits()
        print 'P api_access_list = ', self.get_api_access_list()
        print 'P id_perms = ', self.get_id_perms()
        print 'HAS project = ', self.get_projects()
        print 'HAS namespace = ', self.get_namespaces()
        print 'HAS service_template = ', self.get_service_templates()
        print 'HAS virtual_DNS = ', self.get_virtual_DNSs()
    #end dump

#end class Domain

class ServiceInstance(object):
    """
    Represents service-instance configuration representation.

    Child of:
        :class:`.Project` object OR

    Properties:
        * service-instance-properties (:class:`.ServiceInstanceType` type)
        * id-perms (:class:`.IdPermsType` type)

    Children:

    References to:
        * list of :class:`.ServiceTemplate` objects

    Referred by:
        * list of :class:`.VirtualMachine` objects
    """

    def __init__(self, name = None, parent_obj = None, service_instance_properties = None, id_perms = None, **kwargs):
        # type-independent fields
        self._type = 'service-instance'
        if not name:
            name = u'default-service-instance'
        self.name = name
        self.uuid = None
        if parent_obj:
            self.parent_type = parent_obj._type
            # copy parent's fq_name
            fq_name = list(parent_obj.fq_name)
            fq_name.append(name)
            if not parent_obj.get_service_instances():
                parent_obj.service_instances = []
            parent_obj.service_instances.append(self)
        else: # No parent obj specified
            self.parent_type = 'project'
            fq_name = [u'default-domain', u'default-project']
            fq_name.append(name)

        self.fq_name = fq_name

        # property fields
        if service_instance_properties:
            self.service_instance_properties = service_instance_properties
        if id_perms:
            self.id_perms = id_perms
    #end __init__

    @classmethod
    def factory(cls, **kwargs):
        obj = ServiceInstance()
        obj.__dict__.update(kwargs)
        return obj
    #end factory

    def get_type(self):
        """Return object type (service-instance)."""
        return self._type
    #end get_type

    def get_fq_name(self):
        """Return FQN of service-instance in list form."""
        return self.fq_name
    #end get_fq_name

    def get_fq_name_str(self):
        """Return FQN of service-instance as colon delimited string."""
        return ':'.join(self.fq_name)
    #end get_fq_name_str

    @property
    def parent_name(self):
        return self.fq_name[:-1][-1]
    #end parent_name

    def get_parent_fq_name(self):
        """Return FQN of service-instance's parent in list form."""
        if not hasattr(self, 'parent_type'):
            # child of config-root
            return None

        return self.fq_name[:-1]
    #end get_parent_fq_name

    def get_parent_fq_name_str(self):
        """Return FQN of service-instance's parent as colon delimted string."""
        if not hasattr(self, 'parent_type'):
            # child of config-root
            return None

        return ':'.join(self.fq_name[:-1])
    #end get_parent_fq_name_str

    def set_service_instance_properties(self, service_instance_properties):
        """Set service-instance-properties for service-instance.
        
        :param service_instance_properties: ServiceInstanceType object
        
        """
        self.service_instance_properties = service_instance_properties
    #end set_service_instance_properties

    def get_service_instance_properties(self):
        """Get service-instance-properties for service-instance.
        
        :returns: ServiceInstanceType object
        
        """
        return getattr(self, 'service_instance_properties', None)
    #end get_service_instance_properties

    def set_id_perms(self, id_perms):
        """Set id-perms for service-instance.
        
        :param id_perms: IdPermsType object
        
        """
        self.id_perms = id_perms
    #end set_id_perms

    def get_id_perms(self):
        """Get id-perms for service-instance.
        
        :returns: IdPermsType object
        
        """
        return getattr(self, 'id_perms', None)
    #end get_id_perms


    def set_service_template(self, ref_obj):
        """Set service-template for service-instance.
        
        :param ref_obj: ServiceTemplate object
        
        """
        self.service_template_refs = [{'to':ref_obj.get_fq_name()}]
        if ref_obj.uuid:
            self.service_template_refs[0]['uuid'] = ref_obj.uuid

    #end set_service_template

    def add_service_template(self, ref_obj):
        """Add service-template to service-instance.
        
        :param ref_obj: ServiceTemplate object
        
        """
        refs = getattr(self, 'service_template_refs', None)
        if not refs:
            self.service_template_refs = []

        ref_info = {'to':ref_obj.get_fq_name()}
        if ref_obj.uuid:
            ref_info['uuid'] = ref_obj.uuid

        self.service_template_refs.append(ref_info)
    #end add_service_template

    def del_service_template(self, ref_obj):
        refs = self.get_service_template_refs()
        if not refs:
            return

        for ref in refs:
            if ref['to'] == ref_obj.get_fq_name():
                self.service_template_refs.remove(ref)
                return
    #end del_service_template

    def set_service_template_list(self, ref_obj_list):
        """Set service-template list for service-instance.
        
        :param ref_obj_list: list of ServiceTemplate object
        
        """
        self.service_template_refs = ref_obj_list
    #end set_service_template_list

    def get_service_template_refs(self):
        """Return service-template list for service-instance.
        
        :returns: list of <ServiceTemplate>
        
        """
        return getattr(self, 'service_template_refs', None)
    #end get_service_template_refs

    def get_project_back_refs(self):
        """Return list of all projects using this service-instance"""
        return getattr(self, 'project_back_refs', None)
    #end get_project_back_refs

    def get_virtual_machine_back_refs(self):
        """Return list of all virtual-machines using this service-instance"""
        return getattr(self, 'virtual_machine_back_refs', None)
    #end get_virtual_machine_back_refs

    def dump(self):
        """Display service-instance object in compact form."""
        print '------------ service-instance ------------'
        print 'Name = ', self.get_fq_name()
        print 'Uuid = ', self.uuid
        if hasattr(self, 'parent_type'): # non config-root children
            print 'Parent Type = ', self.parent_type
        print 'P service_instance_properties = ', self.get_service_instance_properties()
        print 'P id_perms = ', self.get_id_perms()
        print 'REF service_template = ', self.get_service_template_refs()
        print 'BCK virtual_machine = ', self.get_virtual_machine_back_refs()
    #end dump

#end class ServiceInstance

class InstanceIp(object):
    """
    Represents instance-ip configuration representation.

    Properties:
        * instance-ip-address (IpAddressType type)
        * id-perms (:class:`.IdPermsType` type)

    Children:

    References to:
        * list of :class:`.VirtualNetwork` objects
        * list of :class:`.VirtualMachineInterface` objects

    Referred by:
    """

    def __init__(self, name = None, instance_ip_address = None, id_perms = None, **kwargs):
        # type-independent fields
        self._type = 'instance-ip'
        if not name:
            name = u'default-instance-ip'
        self.name = name
        self.uuid = None
        fq_name = [name]
        self.fq_name = fq_name

        # property fields
        if instance_ip_address:
            self.instance_ip_address = instance_ip_address
        if id_perms:
            self.id_perms = id_perms
    #end __init__

    @classmethod
    def factory(cls, **kwargs):
        obj = InstanceIp()
        obj.__dict__.update(kwargs)
        return obj
    #end factory

    def get_type(self):
        """Return object type (instance-ip)."""
        return self._type
    #end get_type

    def get_fq_name(self):
        """Return FQN of instance-ip in list form."""
        return self.fq_name
    #end get_fq_name

    def get_fq_name_str(self):
        """Return FQN of instance-ip as colon delimited string."""
        return ':'.join(self.fq_name)
    #end get_fq_name_str

    def set_instance_ip_address(self, instance_ip_address):
        """Set instance-ip-address for instance-ip.
        
        :param instance_ip_address: IpAddressType object
        
        """
        self.instance_ip_address = instance_ip_address
    #end set_instance_ip_address

    def get_instance_ip_address(self):
        """Get instance-ip-address for instance-ip.
        
        :returns: IpAddressType object
        
        """
        return getattr(self, 'instance_ip_address', None)
    #end get_instance_ip_address

    def set_id_perms(self, id_perms):
        """Set id-perms for instance-ip.
        
        :param id_perms: IdPermsType object
        
        """
        self.id_perms = id_perms
    #end set_id_perms

    def get_id_perms(self):
        """Get id-perms for instance-ip.
        
        :returns: IdPermsType object
        
        """
        return getattr(self, 'id_perms', None)
    #end get_id_perms


    def set_virtual_network(self, ref_obj):
        """Set virtual-network for instance-ip.
        
        :param ref_obj: VirtualNetwork object
        
        """
        self.virtual_network_refs = [{'to':ref_obj.get_fq_name()}]
        if ref_obj.uuid:
            self.virtual_network_refs[0]['uuid'] = ref_obj.uuid

    #end set_virtual_network

    def add_virtual_network(self, ref_obj):
        """Add virtual-network to instance-ip.
        
        :param ref_obj: VirtualNetwork object
        
        """
        refs = getattr(self, 'virtual_network_refs', None)
        if not refs:
            self.virtual_network_refs = []

        ref_info = {'to':ref_obj.get_fq_name()}
        if ref_obj.uuid:
            ref_info['uuid'] = ref_obj.uuid

        self.virtual_network_refs.append(ref_info)
    #end add_virtual_network

    def del_virtual_network(self, ref_obj):
        refs = self.get_virtual_network_refs()
        if not refs:
            return

        for ref in refs:
            if ref['to'] == ref_obj.get_fq_name():
                self.virtual_network_refs.remove(ref)
                return
    #end del_virtual_network

    def set_virtual_network_list(self, ref_obj_list):
        """Set virtual-network list for instance-ip.
        
        :param ref_obj_list: list of VirtualNetwork object
        
        """
        self.virtual_network_refs = ref_obj_list
    #end set_virtual_network_list

    def get_virtual_network_refs(self):
        """Return virtual-network list for instance-ip.
        
        :returns: list of <VirtualNetwork>
        
        """
        return getattr(self, 'virtual_network_refs', None)
    #end get_virtual_network_refs

    def set_virtual_machine_interface(self, ref_obj):
        """Set virtual-machine-interface for instance-ip.
        
        :param ref_obj: VirtualMachineInterface object
        
        """
        self.virtual_machine_interface_refs = [{'to':ref_obj.get_fq_name()}]
        if ref_obj.uuid:
            self.virtual_machine_interface_refs[0]['uuid'] = ref_obj.uuid

    #end set_virtual_machine_interface

    def add_virtual_machine_interface(self, ref_obj):
        """Add virtual-machine-interface to instance-ip.
        
        :param ref_obj: VirtualMachineInterface object
        
        """
        refs = getattr(self, 'virtual_machine_interface_refs', None)
        if not refs:
            self.virtual_machine_interface_refs = []

        ref_info = {'to':ref_obj.get_fq_name()}
        if ref_obj.uuid:
            ref_info['uuid'] = ref_obj.uuid

        self.virtual_machine_interface_refs.append(ref_info)
    #end add_virtual_machine_interface

    def del_virtual_machine_interface(self, ref_obj):
        refs = self.get_virtual_machine_interface_refs()
        if not refs:
            return

        for ref in refs:
            if ref['to'] == ref_obj.get_fq_name():
                self.virtual_machine_interface_refs.remove(ref)
                return
    #end del_virtual_machine_interface

    def set_virtual_machine_interface_list(self, ref_obj_list):
        """Set virtual-machine-interface list for instance-ip.
        
        :param ref_obj_list: list of VirtualMachineInterface object
        
        """
        self.virtual_machine_interface_refs = ref_obj_list
    #end set_virtual_machine_interface_list

    def get_virtual_machine_interface_refs(self):
        """Return virtual-machine-interface list for instance-ip.
        
        :returns: list of <VirtualMachineInterface>
        
        """
        return getattr(self, 'virtual_machine_interface_refs', None)
    #end get_virtual_machine_interface_refs

    def dump(self):
        """Display instance-ip object in compact form."""
        print '------------ instance-ip ------------'
        print 'Name = ', self.get_fq_name()
        print 'Uuid = ', self.uuid
        print 'P instance_ip_address = ', self.get_instance_ip_address()
        print 'P id_perms = ', self.get_id_perms()
        print 'REF virtual_network = ', self.get_virtual_network_refs()
        print 'REF virtual_machine_interface = ', self.get_virtual_machine_interface_refs()
    #end dump

#end class InstanceIp

class NetworkPolicy(object):
    """
    Represents network-policy configuration representation.

    Child of:
        :class:`.Project` object OR

    Properties:
        * network-policy-entries (:class:`.PolicyEntriesType` type)
        * id-perms (:class:`.IdPermsType` type)

    Children:

    References to:

    Referred by:
        * list of :class:`.VirtualNetwork` objects
    """

    def __init__(self, name = None, parent_obj = None, network_policy_entries = None, id_perms = None, **kwargs):
        # type-independent fields
        self._type = 'network-policy'
        if not name:
            name = u'default-network-policy'
        self.name = name
        self.uuid = None
        if parent_obj:
            self.parent_type = parent_obj._type
            # copy parent's fq_name
            fq_name = list(parent_obj.fq_name)
            fq_name.append(name)
            if not parent_obj.get_network_policys():
                parent_obj.network_policys = []
            parent_obj.network_policys.append(self)
        else: # No parent obj specified
            self.parent_type = 'project'
            fq_name = [u'default-domain', u'default-project']
            fq_name.append(name)

        self.fq_name = fq_name

        # property fields
        if network_policy_entries:
            self.network_policy_entries = network_policy_entries
        if id_perms:
            self.id_perms = id_perms
    #end __init__

    @classmethod
    def factory(cls, **kwargs):
        obj = NetworkPolicy()
        obj.__dict__.update(kwargs)
        return obj
    #end factory

    def get_type(self):
        """Return object type (network-policy)."""
        return self._type
    #end get_type

    def get_fq_name(self):
        """Return FQN of network-policy in list form."""
        return self.fq_name
    #end get_fq_name

    def get_fq_name_str(self):
        """Return FQN of network-policy as colon delimited string."""
        return ':'.join(self.fq_name)
    #end get_fq_name_str

    @property
    def parent_name(self):
        return self.fq_name[:-1][-1]
    #end parent_name

    def get_parent_fq_name(self):
        """Return FQN of network-policy's parent in list form."""
        if not hasattr(self, 'parent_type'):
            # child of config-root
            return None

        return self.fq_name[:-1]
    #end get_parent_fq_name

    def get_parent_fq_name_str(self):
        """Return FQN of network-policy's parent as colon delimted string."""
        if not hasattr(self, 'parent_type'):
            # child of config-root
            return None

        return ':'.join(self.fq_name[:-1])
    #end get_parent_fq_name_str

    def set_network_policy_entries(self, network_policy_entries):
        """Set network-policy-entries for network-policy.
        
        :param network_policy_entries: PolicyEntriesType object
        
        """
        self.network_policy_entries = network_policy_entries
    #end set_network_policy_entries

    def get_network_policy_entries(self):
        """Get network-policy-entries for network-policy.
        
        :returns: PolicyEntriesType object
        
        """
        return getattr(self, 'network_policy_entries', None)
    #end get_network_policy_entries

    def set_id_perms(self, id_perms):
        """Set id-perms for network-policy.
        
        :param id_perms: IdPermsType object
        
        """
        self.id_perms = id_perms
    #end set_id_perms

    def get_id_perms(self):
        """Get id-perms for network-policy.
        
        :returns: IdPermsType object
        
        """
        return getattr(self, 'id_perms', None)
    #end get_id_perms


    def get_project_back_refs(self):
        """Return list of all projects using this network-policy"""
        return getattr(self, 'project_back_refs', None)
    #end get_project_back_refs

    def get_virtual_network_back_refs(self):
        """Return list of all virtual-networks using this network-policy"""
        return getattr(self, 'virtual_network_back_refs', None)
    #end get_virtual_network_back_refs

    def dump(self):
        """Display network-policy object in compact form."""
        print '------------ network-policy ------------'
        print 'Name = ', self.get_fq_name()
        print 'Uuid = ', self.uuid
        if hasattr(self, 'parent_type'): # non config-root children
            print 'Parent Type = ', self.parent_type
        print 'P network_policy_entries = ', self.get_network_policy_entries()
        print 'P id_perms = ', self.get_id_perms()
        print 'BCK virtual_network = ', self.get_virtual_network_back_refs()
    #end dump

#end class NetworkPolicy

class VirtualDnsRecord(object):
    """
    Represents virtual-DNS-record configuration representation.

    Child of:
        :class:`.VirtualDns` object OR

    Properties:
        * virtual-DNS-record-data (:class:`.VirtualDnsRecordType` type)
        * id-perms (:class:`.IdPermsType` type)

    Children:

    References to:

    Referred by:
    """

    def __init__(self, name = None, parent_obj = None, virtual_DNS_record_data = None, id_perms = None, **kwargs):
        # type-independent fields
        self._type = 'virtual-DNS-record'
        if not name:
            name = u'default-virtual-DNS-record'
        self.name = name
        self.uuid = None
        if parent_obj:
            self.parent_type = parent_obj._type
            # copy parent's fq_name
            fq_name = list(parent_obj.fq_name)
            fq_name.append(name)
            if not parent_obj.get_virtual_DNS_records():
                parent_obj.virtual_DNS_records = []
            parent_obj.virtual_DNS_records.append(self)
        else: # No parent obj specified
            self.parent_type = 'virtual-DNS'
            fq_name = [u'default-domain', u'default-virtual-DNS']
            fq_name.append(name)

        self.fq_name = fq_name

        # property fields
        if virtual_DNS_record_data:
            self.virtual_DNS_record_data = virtual_DNS_record_data
        if id_perms:
            self.id_perms = id_perms
    #end __init__

    @classmethod
    def factory(cls, **kwargs):
        obj = VirtualDnsRecord()
        obj.__dict__.update(kwargs)
        return obj
    #end factory

    def get_type(self):
        """Return object type (virtual-DNS-record)."""
        return self._type
    #end get_type

    def get_fq_name(self):
        """Return FQN of virtual-DNS-record in list form."""
        return self.fq_name
    #end get_fq_name

    def get_fq_name_str(self):
        """Return FQN of virtual-DNS-record as colon delimited string."""
        return ':'.join(self.fq_name)
    #end get_fq_name_str

    @property
    def parent_name(self):
        return self.fq_name[:-1][-1]
    #end parent_name

    def get_parent_fq_name(self):
        """Return FQN of virtual-DNS-record's parent in list form."""
        if not hasattr(self, 'parent_type'):
            # child of config-root
            return None

        return self.fq_name[:-1]
    #end get_parent_fq_name

    def get_parent_fq_name_str(self):
        """Return FQN of virtual-DNS-record's parent as colon delimted string."""
        if not hasattr(self, 'parent_type'):
            # child of config-root
            return None

        return ':'.join(self.fq_name[:-1])
    #end get_parent_fq_name_str

    def set_virtual_DNS_record_data(self, virtual_DNS_record_data):
        """Set virtual-DNS-record-data for virtual-DNS-record.
        
        :param virtual_DNS_record_data: VirtualDnsRecordType object
        
        """
        self.virtual_DNS_record_data = virtual_DNS_record_data
    #end set_virtual_DNS_record_data

    def get_virtual_DNS_record_data(self):
        """Get virtual-DNS-record-data for virtual-DNS-record.
        
        :returns: VirtualDnsRecordType object
        
        """
        return getattr(self, 'virtual_DNS_record_data', None)
    #end get_virtual_DNS_record_data

    def set_id_perms(self, id_perms):
        """Set id-perms for virtual-DNS-record.
        
        :param id_perms: IdPermsType object
        
        """
        self.id_perms = id_perms
    #end set_id_perms

    def get_id_perms(self):
        """Get id-perms for virtual-DNS-record.
        
        :returns: IdPermsType object
        
        """
        return getattr(self, 'id_perms', None)
    #end get_id_perms


    def get_virtual_DNS_back_refs(self):
        """Return list of all virtual-DNSs using this virtual-DNS-record"""
        return getattr(self, 'virtual_DNS_back_refs', None)
    #end get_virtual_DNS_back_refs

    def dump(self):
        """Display virtual-DNS-record object in compact form."""
        print '------------ virtual-DNS-record ------------'
        print 'Name = ', self.get_fq_name()
        print 'Uuid = ', self.uuid
        if hasattr(self, 'parent_type'): # non config-root children
            print 'Parent Type = ', self.parent_type
        print 'P virtual_DNS_record_data = ', self.get_virtual_DNS_record_data()
        print 'P id_perms = ', self.get_id_perms()
    #end dump

#end class VirtualDnsRecord

class RouteTarget(object):
    """
    Represents route-target configuration representation.

    Properties:
        * id-perms (:class:`.IdPermsType` type)

    Children:

    References to:

    Referred by:
        * list of :class:`.RoutingInstance` objects
    """

    def __init__(self, name = None, id_perms = None, **kwargs):
        # type-independent fields
        self._type = 'route-target'
        if not name:
            name = u'default-route-target'
        self.name = name
        self.uuid = None
        fq_name = [name]
        self.fq_name = fq_name

        # property fields
        if id_perms:
            self.id_perms = id_perms
    #end __init__

    @classmethod
    def factory(cls, **kwargs):
        obj = RouteTarget()
        obj.__dict__.update(kwargs)
        return obj
    #end factory

    def get_type(self):
        """Return object type (route-target)."""
        return self._type
    #end get_type

    def get_fq_name(self):
        """Return FQN of route-target in list form."""
        return self.fq_name
    #end get_fq_name

    def get_fq_name_str(self):
        """Return FQN of route-target as colon delimited string."""
        return ':'.join(self.fq_name)
    #end get_fq_name_str

    def set_id_perms(self, id_perms):
        """Set id-perms for route-target.
        
        :param id_perms: IdPermsType object
        
        """
        self.id_perms = id_perms
    #end set_id_perms

    def get_id_perms(self):
        """Get id-perms for route-target.
        
        :returns: IdPermsType object
        
        """
        return getattr(self, 'id_perms', None)
    #end get_id_perms


    def get_routing_instance_back_refs(self):
        """Return list of all routing-instances using this route-target"""
        return getattr(self, 'routing_instance_back_refs', None)
    #end get_routing_instance_back_refs

    def dump(self):
        """Display route-target object in compact form."""
        print '------------ route-target ------------'
        print 'Name = ', self.get_fq_name()
        print 'Uuid = ', self.uuid
        print 'P id_perms = ', self.get_id_perms()
        print 'BCK routing_instance = ', self.get_routing_instance_back_refs()
    #end dump

#end class RouteTarget

class FloatingIp(object):
    """
    Represents floating-ip configuration representation.

    Child of:
        :class:`.FloatingIpPool` object OR

    Properties:
        * floating-ip-address (IpAddressType type)
        * floating-ip-is-virtual-ip (xsd:boolean type)
        * id-perms (:class:`.IdPermsType` type)

    Children:

    References to:
        * list of :class:`.Project` objects
        * list of :class:`.VirtualMachineInterface` objects

    Referred by:
        * list of :class:`.CustomerAttachment` objects
    """

    def __init__(self, name = None, parent_obj = None, floating_ip_address = None, floating_ip_is_virtual_ip = None, id_perms = None, **kwargs):
        # type-independent fields
        self._type = 'floating-ip'
        if not name:
            name = u'default-floating-ip'
        self.name = name
        self.uuid = None
        if parent_obj:
            self.parent_type = parent_obj._type
            # copy parent's fq_name
            fq_name = list(parent_obj.fq_name)
            fq_name.append(name)
            if not parent_obj.get_floating_ips():
                parent_obj.floating_ips = []
            parent_obj.floating_ips.append(self)
        else: # No parent obj specified
            self.parent_type = 'floating-ip-pool'
            fq_name = [u'default-domain', u'default-project', u'default-virtual-network', u'default-floating-ip-pool']
            fq_name.append(name)

        self.fq_name = fq_name

        # property fields
        if floating_ip_address:
            self.floating_ip_address = floating_ip_address
        if floating_ip_is_virtual_ip:
            self.floating_ip_is_virtual_ip = floating_ip_is_virtual_ip
        if id_perms:
            self.id_perms = id_perms
    #end __init__

    @classmethod
    def factory(cls, **kwargs):
        obj = FloatingIp()
        obj.__dict__.update(kwargs)
        return obj
    #end factory

    def get_type(self):
        """Return object type (floating-ip)."""
        return self._type
    #end get_type

    def get_fq_name(self):
        """Return FQN of floating-ip in list form."""
        return self.fq_name
    #end get_fq_name

    def get_fq_name_str(self):
        """Return FQN of floating-ip as colon delimited string."""
        return ':'.join(self.fq_name)
    #end get_fq_name_str

    @property
    def parent_name(self):
        return self.fq_name[:-1][-1]
    #end parent_name

    def get_parent_fq_name(self):
        """Return FQN of floating-ip's parent in list form."""
        if not hasattr(self, 'parent_type'):
            # child of config-root
            return None

        return self.fq_name[:-1]
    #end get_parent_fq_name

    def get_parent_fq_name_str(self):
        """Return FQN of floating-ip's parent as colon delimted string."""
        if not hasattr(self, 'parent_type'):
            # child of config-root
            return None

        return ':'.join(self.fq_name[:-1])
    #end get_parent_fq_name_str

    def set_floating_ip_address(self, floating_ip_address):
        """Set floating-ip-address for floating-ip.
        
        :param floating_ip_address: IpAddressType object
        
        """
        self.floating_ip_address = floating_ip_address
    #end set_floating_ip_address

    def get_floating_ip_address(self):
        """Get floating-ip-address for floating-ip.
        
        :returns: IpAddressType object
        
        """
        return getattr(self, 'floating_ip_address', None)
    #end get_floating_ip_address

    def set_floating_ip_is_virtual_ip(self, floating_ip_is_virtual_ip):
        """Set floating-ip-is-virtual-ip for floating-ip.
        
        :param floating_ip_is_virtual_ip: xsd:boolean object
        
        """
        self.floating_ip_is_virtual_ip = floating_ip_is_virtual_ip
    #end set_floating_ip_is_virtual_ip

    def get_floating_ip_is_virtual_ip(self):
        """Get floating-ip-is-virtual-ip for floating-ip.
        
        :returns: xsd:boolean object
        
        """
        return getattr(self, 'floating_ip_is_virtual_ip', None)
    #end get_floating_ip_is_virtual_ip

    def set_id_perms(self, id_perms):
        """Set id-perms for floating-ip.
        
        :param id_perms: IdPermsType object
        
        """
        self.id_perms = id_perms
    #end set_id_perms

    def get_id_perms(self):
        """Get id-perms for floating-ip.
        
        :returns: IdPermsType object
        
        """
        return getattr(self, 'id_perms', None)
    #end get_id_perms


    def set_project(self, ref_obj):
        """Set project for floating-ip.
        
        :param ref_obj: Project object
        
        """
        self.project_refs = [{'to':ref_obj.get_fq_name()}]
        if ref_obj.uuid:
            self.project_refs[0]['uuid'] = ref_obj.uuid

    #end set_project

    def add_project(self, ref_obj):
        """Add project to floating-ip.
        
        :param ref_obj: Project object
        
        """
        refs = getattr(self, 'project_refs', None)
        if not refs:
            self.project_refs = []

        ref_info = {'to':ref_obj.get_fq_name()}
        if ref_obj.uuid:
            ref_info['uuid'] = ref_obj.uuid

        self.project_refs.append(ref_info)
    #end add_project

    def del_project(self, ref_obj):
        refs = self.get_project_refs()
        if not refs:
            return

        for ref in refs:
            if ref['to'] == ref_obj.get_fq_name():
                self.project_refs.remove(ref)
                return
    #end del_project

    def set_project_list(self, ref_obj_list):
        """Set project list for floating-ip.
        
        :param ref_obj_list: list of Project object
        
        """
        self.project_refs = ref_obj_list
    #end set_project_list

    def get_project_refs(self):
        """Return project list for floating-ip.
        
        :returns: list of <Project>
        
        """
        return getattr(self, 'project_refs', None)
    #end get_project_refs

    def set_virtual_machine_interface(self, ref_obj):
        """Set virtual-machine-interface for floating-ip.
        
        :param ref_obj: VirtualMachineInterface object
        
        """
        self.virtual_machine_interface_refs = [{'to':ref_obj.get_fq_name()}]
        if ref_obj.uuid:
            self.virtual_machine_interface_refs[0]['uuid'] = ref_obj.uuid

    #end set_virtual_machine_interface

    def add_virtual_machine_interface(self, ref_obj):
        """Add virtual-machine-interface to floating-ip.
        
        :param ref_obj: VirtualMachineInterface object
        
        """
        refs = getattr(self, 'virtual_machine_interface_refs', None)
        if not refs:
            self.virtual_machine_interface_refs = []

        ref_info = {'to':ref_obj.get_fq_name()}
        if ref_obj.uuid:
            ref_info['uuid'] = ref_obj.uuid

        self.virtual_machine_interface_refs.append(ref_info)
    #end add_virtual_machine_interface

    def del_virtual_machine_interface(self, ref_obj):
        refs = self.get_virtual_machine_interface_refs()
        if not refs:
            return

        for ref in refs:
            if ref['to'] == ref_obj.get_fq_name():
                self.virtual_machine_interface_refs.remove(ref)
                return
    #end del_virtual_machine_interface

    def set_virtual_machine_interface_list(self, ref_obj_list):
        """Set virtual-machine-interface list for floating-ip.
        
        :param ref_obj_list: list of VirtualMachineInterface object
        
        """
        self.virtual_machine_interface_refs = ref_obj_list
    #end set_virtual_machine_interface_list

    def get_virtual_machine_interface_refs(self):
        """Return virtual-machine-interface list for floating-ip.
        
        :returns: list of <VirtualMachineInterface>
        
        """
        return getattr(self, 'virtual_machine_interface_refs', None)
    #end get_virtual_machine_interface_refs

    def get_floating_ip_pool_back_refs(self):
        """Return list of all floating-ip-pools using this floating-ip"""
        return getattr(self, 'floating_ip_pool_back_refs', None)
    #end get_floating_ip_pool_back_refs

    def get_customer_attachment_back_refs(self):
        """Return list of all customer-attachments using this floating-ip"""
        return getattr(self, 'customer_attachment_back_refs', None)
    #end get_customer_attachment_back_refs

    def dump(self):
        """Display floating-ip object in compact form."""
        print '------------ floating-ip ------------'
        print 'Name = ', self.get_fq_name()
        print 'Uuid = ', self.uuid
        if hasattr(self, 'parent_type'): # non config-root children
            print 'Parent Type = ', self.parent_type
        print 'P floating_ip_address = ', self.get_floating_ip_address()
        print 'P floating_ip_is_virtual_ip = ', self.get_floating_ip_is_virtual_ip()
        print 'P id_perms = ', self.get_id_perms()
        print 'REF project = ', self.get_project_refs()
        print 'REF virtual_machine_interface = ', self.get_virtual_machine_interface_refs()
        print 'BCK customer_attachment = ', self.get_customer_attachment_back_refs()
    #end dump

#end class FloatingIp

class FloatingIpPool(object):
    """
    Represents floating-ip-pool configuration representation.

    Child of:
        :class:`.VirtualNetwork` object OR

    Properties:
        * floating-ip-pool-prefixes (:class:`.FloatingIpPoolType` type)
        * id-perms (:class:`.IdPermsType` type)

    Children:
        * list of :class:`.FloatingIp` objects

    References to:

    Referred by:
        * list of :class:`.Project` objects
    """

    def __init__(self, name = None, parent_obj = None, floating_ip_pool_prefixes = None, id_perms = None, **kwargs):
        # type-independent fields
        self._type = 'floating-ip-pool'
        if not name:
            name = u'default-floating-ip-pool'
        self.name = name
        self.uuid = None
        if parent_obj:
            self.parent_type = parent_obj._type
            # copy parent's fq_name
            fq_name = list(parent_obj.fq_name)
            fq_name.append(name)
            if not parent_obj.get_floating_ip_pools():
                parent_obj.floating_ip_pools = []
            parent_obj.floating_ip_pools.append(self)
        else: # No parent obj specified
            self.parent_type = 'virtual-network'
            fq_name = [u'default-domain', u'default-project', u'default-virtual-network']
            fq_name.append(name)

        self.fq_name = fq_name

        # property fields
        if floating_ip_pool_prefixes:
            self.floating_ip_pool_prefixes = floating_ip_pool_prefixes
        if id_perms:
            self.id_perms = id_perms
    #end __init__

    @classmethod
    def factory(cls, **kwargs):
        obj = FloatingIpPool()
        obj.__dict__.update(kwargs)
        return obj
    #end factory

    def get_type(self):
        """Return object type (floating-ip-pool)."""
        return self._type
    #end get_type

    def get_fq_name(self):
        """Return FQN of floating-ip-pool in list form."""
        return self.fq_name
    #end get_fq_name

    def get_fq_name_str(self):
        """Return FQN of floating-ip-pool as colon delimited string."""
        return ':'.join(self.fq_name)
    #end get_fq_name_str

    @property
    def parent_name(self):
        return self.fq_name[:-1][-1]
    #end parent_name

    def get_parent_fq_name(self):
        """Return FQN of floating-ip-pool's parent in list form."""
        if not hasattr(self, 'parent_type'):
            # child of config-root
            return None

        return self.fq_name[:-1]
    #end get_parent_fq_name

    def get_parent_fq_name_str(self):
        """Return FQN of floating-ip-pool's parent as colon delimted string."""
        if not hasattr(self, 'parent_type'):
            # child of config-root
            return None

        return ':'.join(self.fq_name[:-1])
    #end get_parent_fq_name_str

    def set_floating_ip_pool_prefixes(self, floating_ip_pool_prefixes):
        """Set floating-ip-pool-prefixes for floating-ip-pool.
        
        :param floating_ip_pool_prefixes: FloatingIpPoolType object
        
        """
        self.floating_ip_pool_prefixes = floating_ip_pool_prefixes
    #end set_floating_ip_pool_prefixes

    def get_floating_ip_pool_prefixes(self):
        """Get floating-ip-pool-prefixes for floating-ip-pool.
        
        :returns: FloatingIpPoolType object
        
        """
        return getattr(self, 'floating_ip_pool_prefixes', None)
    #end get_floating_ip_pool_prefixes

    def set_id_perms(self, id_perms):
        """Set id-perms for floating-ip-pool.
        
        :param id_perms: IdPermsType object
        
        """
        self.id_perms = id_perms
    #end set_id_perms

    def get_id_perms(self):
        """Get id-perms for floating-ip-pool.
        
        :returns: IdPermsType object
        
        """
        return getattr(self, 'id_perms', None)
    #end get_id_perms


    def get_floating_ips(self):
        return getattr(self, 'floating_ips', None)
    #end get_floating_ips

    def get_virtual_network_back_refs(self):
        """Return list of all virtual-networks using this floating-ip-pool"""
        return getattr(self, 'virtual_network_back_refs', None)
    #end get_virtual_network_back_refs

    def get_project_back_refs(self):
        """Return list of all projects using this floating-ip-pool"""
        return getattr(self, 'project_back_refs', None)
    #end get_project_back_refs

    def dump(self):
        """Display floating-ip-pool object in compact form."""
        print '------------ floating-ip-pool ------------'
        print 'Name = ', self.get_fq_name()
        print 'Uuid = ', self.uuid
        if hasattr(self, 'parent_type'): # non config-root children
            print 'Parent Type = ', self.parent_type
        print 'P floating_ip_pool_prefixes = ', self.get_floating_ip_pool_prefixes()
        print 'P id_perms = ', self.get_id_perms()
        print 'HAS floating_ip = ', self.get_floating_ips()
        print 'BCK project = ', self.get_project_back_refs()
    #end dump

#end class FloatingIpPool

class PhysicalRouter(object):
    """
    Represents physical-router configuration representation.

    Child of:
        :class:`.GlobalSystemConfig` object OR

    Properties:
        * id-perms (:class:`.IdPermsType` type)

    Children:
        * list of :class:`.PhysicalInterface` objects

    References to:
        * list of :class:`.BgpRouter` objects

    Referred by:
    """

    def __init__(self, name = None, parent_obj = None, id_perms = None, **kwargs):
        # type-independent fields
        self._type = 'physical-router'
        if not name:
            name = u'default-physical-router'
        self.name = name
        self.uuid = None
        if parent_obj:
            self.parent_type = parent_obj._type
            # copy parent's fq_name
            fq_name = list(parent_obj.fq_name)
            fq_name.append(name)
            if not parent_obj.get_physical_routers():
                parent_obj.physical_routers = []
            parent_obj.physical_routers.append(self)
        else: # No parent obj specified
            self.parent_type = 'global-system-config'
            fq_name = [u'default-global-system-config']
            fq_name.append(name)

        self.fq_name = fq_name

        # property fields
        if id_perms:
            self.id_perms = id_perms
    #end __init__

    @classmethod
    def factory(cls, **kwargs):
        obj = PhysicalRouter()
        obj.__dict__.update(kwargs)
        return obj
    #end factory

    def get_type(self):
        """Return object type (physical-router)."""
        return self._type
    #end get_type

    def get_fq_name(self):
        """Return FQN of physical-router in list form."""
        return self.fq_name
    #end get_fq_name

    def get_fq_name_str(self):
        """Return FQN of physical-router as colon delimited string."""
        return ':'.join(self.fq_name)
    #end get_fq_name_str

    @property
    def parent_name(self):
        return self.fq_name[:-1][-1]
    #end parent_name

    def get_parent_fq_name(self):
        """Return FQN of physical-router's parent in list form."""
        if not hasattr(self, 'parent_type'):
            # child of config-root
            return None

        return self.fq_name[:-1]
    #end get_parent_fq_name

    def get_parent_fq_name_str(self):
        """Return FQN of physical-router's parent as colon delimted string."""
        if not hasattr(self, 'parent_type'):
            # child of config-root
            return None

        return ':'.join(self.fq_name[:-1])
    #end get_parent_fq_name_str

    def set_id_perms(self, id_perms):
        """Set id-perms for physical-router.
        
        :param id_perms: IdPermsType object
        
        """
        self.id_perms = id_perms
    #end set_id_perms

    def get_id_perms(self):
        """Get id-perms for physical-router.
        
        :returns: IdPermsType object
        
        """
        return getattr(self, 'id_perms', None)
    #end get_id_perms


    def get_physical_interfaces(self):
        return getattr(self, 'physical_interfaces', None)
    #end get_physical_interfaces

    def set_bgp_router(self, ref_obj):
        """Set bgp-router for physical-router.
        
        :param ref_obj: BgpRouter object
        
        """
        self.bgp_router_refs = [{'to':ref_obj.get_fq_name()}]
        if ref_obj.uuid:
            self.bgp_router_refs[0]['uuid'] = ref_obj.uuid

    #end set_bgp_router

    def add_bgp_router(self, ref_obj):
        """Add bgp-router to physical-router.
        
        :param ref_obj: BgpRouter object
        
        """
        refs = getattr(self, 'bgp_router_refs', None)
        if not refs:
            self.bgp_router_refs = []

        ref_info = {'to':ref_obj.get_fq_name()}
        if ref_obj.uuid:
            ref_info['uuid'] = ref_obj.uuid

        self.bgp_router_refs.append(ref_info)
    #end add_bgp_router

    def del_bgp_router(self, ref_obj):
        refs = self.get_bgp_router_refs()
        if not refs:
            return

        for ref in refs:
            if ref['to'] == ref_obj.get_fq_name():
                self.bgp_router_refs.remove(ref)
                return
    #end del_bgp_router

    def set_bgp_router_list(self, ref_obj_list):
        """Set bgp-router list for physical-router.
        
        :param ref_obj_list: list of BgpRouter object
        
        """
        self.bgp_router_refs = ref_obj_list
    #end set_bgp_router_list

    def get_bgp_router_refs(self):
        """Return bgp-router list for physical-router.
        
        :returns: list of <BgpRouter>
        
        """
        return getattr(self, 'bgp_router_refs', None)
    #end get_bgp_router_refs

    def get_global_system_config_back_refs(self):
        """Return list of all global-system-configs using this physical-router"""
        return getattr(self, 'global_system_config_back_refs', None)
    #end get_global_system_config_back_refs

    def dump(self):
        """Display physical-router object in compact form."""
        print '------------ physical-router ------------'
        print 'Name = ', self.get_fq_name()
        print 'Uuid = ', self.uuid
        if hasattr(self, 'parent_type'): # non config-root children
            print 'Parent Type = ', self.parent_type
        print 'P id_perms = ', self.get_id_perms()
        print 'REF bgp_router = ', self.get_bgp_router_refs()
        print 'HAS physical_interface = ', self.get_physical_interfaces()
    #end dump

#end class PhysicalRouter

class BgpRouter(object):
    """
    Represents bgp-router configuration representation.

    Child of:
        :class:`.RoutingInstance` object OR

    Properties:
        * bgp-router-parameters (:class:`.BgpRouterParams` type)
        * id-perms (:class:`.IdPermsType` type)

    Children:

    References to:
        * list of (:class:`.BgpRouter` object, :class:`.BgpPeeringAttributes` attribute)

    Referred by:
        * list of :class:`.GlobalSystemConfig` objects
        * list of :class:`.PhysicalRouter` objects
        * list of :class:`.VirtualRouter` objects
        * list of :class:`.BgpRouter` objects
    """

    def __init__(self, name = None, parent_obj = None, bgp_router_parameters = None, id_perms = None, **kwargs):
        # type-independent fields
        self._type = 'bgp-router'
        if not name:
            name = u'default-bgp-router'
        self.name = name
        self.uuid = None
        if parent_obj:
            self.parent_type = parent_obj._type
            # copy parent's fq_name
            fq_name = list(parent_obj.fq_name)
            fq_name.append(name)
            if not parent_obj.get_bgp_routers():
                parent_obj.bgp_routers = []
            parent_obj.bgp_routers.append(self)
        else: # No parent obj specified
            self.parent_type = 'routing-instance'
            fq_name = [u'default-domain', u'default-project', u'default-virtual-network', 'default-routing-instance']
            fq_name.append(name)

        self.fq_name = fq_name

        # property fields
        if bgp_router_parameters:
            self.bgp_router_parameters = bgp_router_parameters
        if id_perms:
            self.id_perms = id_perms
    #end __init__

    @classmethod
    def factory(cls, **kwargs):
        obj = BgpRouter()
        obj.__dict__.update(kwargs)
        return obj
    #end factory

    def get_type(self):
        """Return object type (bgp-router)."""
        return self._type
    #end get_type

    def get_fq_name(self):
        """Return FQN of bgp-router in list form."""
        return self.fq_name
    #end get_fq_name

    def get_fq_name_str(self):
        """Return FQN of bgp-router as colon delimited string."""
        return ':'.join(self.fq_name)
    #end get_fq_name_str

    @property
    def parent_name(self):
        return self.fq_name[:-1][-1]
    #end parent_name

    def get_parent_fq_name(self):
        """Return FQN of bgp-router's parent in list form."""
        if not hasattr(self, 'parent_type'):
            # child of config-root
            return None

        return self.fq_name[:-1]
    #end get_parent_fq_name

    def get_parent_fq_name_str(self):
        """Return FQN of bgp-router's parent as colon delimted string."""
        if not hasattr(self, 'parent_type'):
            # child of config-root
            return None

        return ':'.join(self.fq_name[:-1])
    #end get_parent_fq_name_str

    def set_bgp_router_parameters(self, bgp_router_parameters):
        """Set bgp-router-parameters for bgp-router.
        
        :param bgp_router_parameters: BgpRouterParams object
        
        """
        self.bgp_router_parameters = bgp_router_parameters
    #end set_bgp_router_parameters

    def get_bgp_router_parameters(self):
        """Get bgp-router-parameters for bgp-router.
        
        :returns: BgpRouterParams object
        
        """
        return getattr(self, 'bgp_router_parameters', None)
    #end get_bgp_router_parameters

    def set_id_perms(self, id_perms):
        """Set id-perms for bgp-router.
        
        :param id_perms: IdPermsType object
        
        """
        self.id_perms = id_perms
    #end set_id_perms

    def get_id_perms(self):
        """Get id-perms for bgp-router.
        
        :returns: IdPermsType object
        
        """
        return getattr(self, 'id_perms', None)
    #end get_id_perms


    def set_bgp_router(self, ref_obj, ref_data):
        """Set bgp-router for bgp-router.
        
        :param ref_obj: BgpRouter object
        :param ref_data: BgpPeeringAttributes object
        
        """
        self.bgp_router_refs = [{'to':ref_obj.get_fq_name(), 'attr':ref_data}]
        if ref_obj.uuid:
            self.bgp_router_refs[0]['uuid'] = ref_obj.uuid

    #end set_bgp_router

    def add_bgp_router(self, ref_obj, ref_data):
        """Add bgp-router to bgp-router.
        
        :param ref_obj: BgpRouter object
        :param ref_data: BgpPeeringAttributes object
        
        """
        refs = getattr(self, 'bgp_router_refs', None)
        if not refs:
            self.bgp_router_refs = []

        ref_info = {'to':ref_obj.get_fq_name(), 'attr':ref_data}
        if ref_obj.uuid:
            ref_info['uuid'] = ref_obj.uuid

        self.bgp_router_refs.append(ref_info)
    #end add_bgp_router

    def del_bgp_router(self, ref_obj):
        refs = self.get_bgp_router_refs()
        if not refs:
            return

        for ref in refs:
            if ref['to'] == ref_obj.get_fq_name():
                self.bgp_router_refs.remove(ref)
                return
    #end del_bgp_router

    def set_bgp_router_list(self, ref_obj_list, ref_data_list):
        """Set bgp-router list for bgp-router.
        
        :param ref_obj_list: list of BgpRouter object
        :param ref_data_list: list of BgpPeeringAttributes object
        
        """
        self.bgp_router_refs = [{'to':ref_obj_list[i],                                      'attr':ref_data_list[i]} for i in range(len(ref_obj_list))]
    #end set_bgp_router_list

    def get_bgp_router_refs(self):
        """Return bgp-router list for bgp-router.
        
        :returns: list of tuple <BgpRouter, BgpPeeringAttributes>
        
        """
        return getattr(self, 'bgp_router_refs', None)
    #end get_bgp_router_refs

    def get_global_system_config_back_refs(self):
        """Return list of all global-system-configs using this bgp-router"""
        return getattr(self, 'global_system_config_back_refs', None)
    #end get_global_system_config_back_refs

    def get_physical_router_back_refs(self):
        """Return list of all physical-routers using this bgp-router"""
        return getattr(self, 'physical_router_back_refs', None)
    #end get_physical_router_back_refs

    def get_virtual_router_back_refs(self):
        """Return list of all virtual-routers using this bgp-router"""
        return getattr(self, 'virtual_router_back_refs', None)
    #end get_virtual_router_back_refs

    def get_routing_instance_back_refs(self):
        """Return list of all routing-instances using this bgp-router"""
        return getattr(self, 'routing_instance_back_refs', None)
    #end get_routing_instance_back_refs

    def get_bgp_router_back_refs(self):
        """Return list of all bgp-routers using this bgp-router"""
        return getattr(self, 'bgp_router_back_refs', None)
    #end get_bgp_router_back_refs

    def dump(self):
        """Display bgp-router object in compact form."""
        print '------------ bgp-router ------------'
        print 'Name = ', self.get_fq_name()
        print 'Uuid = ', self.uuid
        if hasattr(self, 'parent_type'): # non config-root children
            print 'Parent Type = ', self.parent_type
        print 'P bgp_router_parameters = ', self.get_bgp_router_parameters()
        print 'P id_perms = ', self.get_id_perms()
        print 'REF bgp_router = ', self.get_bgp_router_refs()
        print 'BCK global_system_config = ', self.get_global_system_config_back_refs()
        print 'BCK physical_router = ', self.get_physical_router_back_refs()
        print 'BCK virtual_router = ', self.get_virtual_router_back_refs()
        print 'BCK bgp_router = ', self.get_bgp_router_back_refs()
    #end dump

#end class BgpRouter

class VirtualRouter(object):
    """
    Represents virtual-router configuration representation.

    Child of:
        :class:`.GlobalSystemConfig` object OR

    Properties:
        * virtual-router-ip-address (IpAddressType type)
        * id-perms (:class:`.IdPermsType` type)

    Children:

    References to:
        * list of :class:`.BgpRouter` objects
        * list of :class:`.VirtualMachine` objects

    Referred by:
        * list of :class:`.ProviderAttachment` objects
    """

    def __init__(self, name = None, parent_obj = None, virtual_router_ip_address = None, id_perms = None, **kwargs):
        # type-independent fields
        self._type = 'virtual-router'
        if not name:
            name = u'default-virtual-router'
        self.name = name
        self.uuid = None
        if parent_obj:
            self.parent_type = parent_obj._type
            # copy parent's fq_name
            fq_name = list(parent_obj.fq_name)
            fq_name.append(name)
            if not parent_obj.get_virtual_routers():
                parent_obj.virtual_routers = []
            parent_obj.virtual_routers.append(self)
        else: # No parent obj specified
            self.parent_type = 'global-system-config'
            fq_name = [u'default-global-system-config']
            fq_name.append(name)

        self.fq_name = fq_name

        # property fields
        if virtual_router_ip_address:
            self.virtual_router_ip_address = virtual_router_ip_address
        if id_perms:
            self.id_perms = id_perms
    #end __init__

    @classmethod
    def factory(cls, **kwargs):
        obj = VirtualRouter()
        obj.__dict__.update(kwargs)
        return obj
    #end factory

    def get_type(self):
        """Return object type (virtual-router)."""
        return self._type
    #end get_type

    def get_fq_name(self):
        """Return FQN of virtual-router in list form."""
        return self.fq_name
    #end get_fq_name

    def get_fq_name_str(self):
        """Return FQN of virtual-router as colon delimited string."""
        return ':'.join(self.fq_name)
    #end get_fq_name_str

    @property
    def parent_name(self):
        return self.fq_name[:-1][-1]
    #end parent_name

    def get_parent_fq_name(self):
        """Return FQN of virtual-router's parent in list form."""
        if not hasattr(self, 'parent_type'):
            # child of config-root
            return None

        return self.fq_name[:-1]
    #end get_parent_fq_name

    def get_parent_fq_name_str(self):
        """Return FQN of virtual-router's parent as colon delimted string."""
        if not hasattr(self, 'parent_type'):
            # child of config-root
            return None

        return ':'.join(self.fq_name[:-1])
    #end get_parent_fq_name_str

    def set_virtual_router_ip_address(self, virtual_router_ip_address):
        """Set virtual-router-ip-address for virtual-router.
        
        :param virtual_router_ip_address: IpAddressType object
        
        """
        self.virtual_router_ip_address = virtual_router_ip_address
    #end set_virtual_router_ip_address

    def get_virtual_router_ip_address(self):
        """Get virtual-router-ip-address for virtual-router.
        
        :returns: IpAddressType object
        
        """
        return getattr(self, 'virtual_router_ip_address', None)
    #end get_virtual_router_ip_address

    def set_id_perms(self, id_perms):
        """Set id-perms for virtual-router.
        
        :param id_perms: IdPermsType object
        
        """
        self.id_perms = id_perms
    #end set_id_perms

    def get_id_perms(self):
        """Get id-perms for virtual-router.
        
        :returns: IdPermsType object
        
        """
        return getattr(self, 'id_perms', None)
    #end get_id_perms


    def set_bgp_router(self, ref_obj):
        """Set bgp-router for virtual-router.
        
        :param ref_obj: BgpRouter object
        
        """
        self.bgp_router_refs = [{'to':ref_obj.get_fq_name()}]
        if ref_obj.uuid:
            self.bgp_router_refs[0]['uuid'] = ref_obj.uuid

    #end set_bgp_router

    def add_bgp_router(self, ref_obj):
        """Add bgp-router to virtual-router.
        
        :param ref_obj: BgpRouter object
        
        """
        refs = getattr(self, 'bgp_router_refs', None)
        if not refs:
            self.bgp_router_refs = []

        ref_info = {'to':ref_obj.get_fq_name()}
        if ref_obj.uuid:
            ref_info['uuid'] = ref_obj.uuid

        self.bgp_router_refs.append(ref_info)
    #end add_bgp_router

    def del_bgp_router(self, ref_obj):
        refs = self.get_bgp_router_refs()
        if not refs:
            return

        for ref in refs:
            if ref['to'] == ref_obj.get_fq_name():
                self.bgp_router_refs.remove(ref)
                return
    #end del_bgp_router

    def set_bgp_router_list(self, ref_obj_list):
        """Set bgp-router list for virtual-router.
        
        :param ref_obj_list: list of BgpRouter object
        
        """
        self.bgp_router_refs = ref_obj_list
    #end set_bgp_router_list

    def get_bgp_router_refs(self):
        """Return bgp-router list for virtual-router.
        
        :returns: list of <BgpRouter>
        
        """
        return getattr(self, 'bgp_router_refs', None)
    #end get_bgp_router_refs

    def set_virtual_machine(self, ref_obj):
        """Set virtual-machine for virtual-router.
        
        :param ref_obj: VirtualMachine object
        
        """
        self.virtual_machine_refs = [{'to':ref_obj.get_fq_name()}]
        if ref_obj.uuid:
            self.virtual_machine_refs[0]['uuid'] = ref_obj.uuid

    #end set_virtual_machine

    def add_virtual_machine(self, ref_obj):
        """Add virtual-machine to virtual-router.
        
        :param ref_obj: VirtualMachine object
        
        """
        refs = getattr(self, 'virtual_machine_refs', None)
        if not refs:
            self.virtual_machine_refs = []

        ref_info = {'to':ref_obj.get_fq_name()}
        if ref_obj.uuid:
            ref_info['uuid'] = ref_obj.uuid

        self.virtual_machine_refs.append(ref_info)
    #end add_virtual_machine

    def del_virtual_machine(self, ref_obj):
        refs = self.get_virtual_machine_refs()
        if not refs:
            return

        for ref in refs:
            if ref['to'] == ref_obj.get_fq_name():
                self.virtual_machine_refs.remove(ref)
                return
    #end del_virtual_machine

    def set_virtual_machine_list(self, ref_obj_list):
        """Set virtual-machine list for virtual-router.
        
        :param ref_obj_list: list of VirtualMachine object
        
        """
        self.virtual_machine_refs = ref_obj_list
    #end set_virtual_machine_list

    def get_virtual_machine_refs(self):
        """Return virtual-machine list for virtual-router.
        
        :returns: list of <VirtualMachine>
        
        """
        return getattr(self, 'virtual_machine_refs', None)
    #end get_virtual_machine_refs

    def get_global_system_config_back_refs(self):
        """Return list of all global-system-configs using this virtual-router"""
        return getattr(self, 'global_system_config_back_refs', None)
    #end get_global_system_config_back_refs

    def get_provider_attachment_back_refs(self):
        """Return list of all provider-attachments using this virtual-router"""
        return getattr(self, 'provider_attachment_back_refs', None)
    #end get_provider_attachment_back_refs

    def dump(self):
        """Display virtual-router object in compact form."""
        print '------------ virtual-router ------------'
        print 'Name = ', self.get_fq_name()
        print 'Uuid = ', self.uuid
        if hasattr(self, 'parent_type'): # non config-root children
            print 'Parent Type = ', self.parent_type
        print 'P virtual_router_ip_address = ', self.get_virtual_router_ip_address()
        print 'P id_perms = ', self.get_id_perms()
        print 'REF bgp_router = ', self.get_bgp_router_refs()
        print 'REF virtual_machine = ', self.get_virtual_machine_refs()
        print 'BCK provider_attachment = ', self.get_provider_attachment_back_refs()
    #end dump

#end class VirtualRouter

class ConfigRoot(object):
    """
    Represents config-root configuration representation.

    Properties:
        * id-perms (:class:`.IdPermsType` type)

    Children:
        * list of :class:`.GlobalSystemConfig` objects
        * list of :class:`.Domain` objects

    References to:

    Referred by:
    """

    def __init__(self, name = None, id_perms = None, **kwargs):
        # type-independent fields
        self._type = 'config-root'
        if not name:
            name = u'default-config-root'
        self.name = name
        self.uuid = None
        fq_name = [name]
        self.fq_name = fq_name

        # property fields
        if id_perms:
            self.id_perms = id_perms
    #end __init__

    @classmethod
    def factory(cls, **kwargs):
        obj = ConfigRoot()
        obj.__dict__.update(kwargs)
        return obj
    #end factory

    def get_type(self):
        """Return object type (config-root)."""
        return self._type
    #end get_type

    def get_fq_name(self):
        """Return FQN of config-root in list form."""
        return self.fq_name
    #end get_fq_name

    def get_fq_name_str(self):
        """Return FQN of config-root as colon delimited string."""
        return ':'.join(self.fq_name)
    #end get_fq_name_str

    def set_id_perms(self, id_perms):
        """Set id-perms for config-root.
        
        :param id_perms: IdPermsType object
        
        """
        self.id_perms = id_perms
    #end set_id_perms

    def get_id_perms(self):
        """Get id-perms for config-root.
        
        :returns: IdPermsType object
        
        """
        return getattr(self, 'id_perms', None)
    #end get_id_perms


    def get_global_system_configs(self):
        return getattr(self, 'global_system_configs', None)
    #end get_global_system_configs

    def get_domains(self):
        return getattr(self, 'domains', None)
    #end get_domains

    def dump(self):
        """Display config-root object in compact form."""
        print '------------ config-root ------------'
        print 'Name = ', self.get_fq_name()
        print 'Uuid = ', self.uuid
        print 'P id_perms = ', self.get_id_perms()
        print 'HAS global_system_config = ', self.get_global_system_configs()
        print 'HAS domain = ', self.get_domains()
    #end dump

#end class ConfigRoot

class GlobalSystemConfig(object):
    """
    Represents global-system-config configuration representation.

    Child of:
        :class:`.ConfigRoot` object OR

    Properties:
        * autonomous-system (AutonomousSystemType type)
        * id-perms (:class:`.IdPermsType` type)

    Children:
        * list of :class:`.PhysicalRouter` objects
        * list of :class:`.VirtualRouter` objects

    References to:
        * list of :class:`.BgpRouter` objects

    Referred by:
    """

    def __init__(self, name = None, parent_obj = None, autonomous_system = None, id_perms = None, **kwargs):
        # type-independent fields
        self._type = 'global-system-config'
        if not name:
            name = u'default-global-system-config'
        self.name = name
        self.uuid = None
        if parent_obj:
            self.parent_type = parent_obj._type
            # copy parent's fq_name
            fq_name = list(parent_obj.fq_name)
            fq_name.append(name)
            if not parent_obj.get_global_system_configs():
                parent_obj.global_system_configs = []
            parent_obj.global_system_configs.append(self)
        else: # No parent obj specified
            fq_name = [name]
        self.fq_name = fq_name

        # property fields
        if autonomous_system:
            self.autonomous_system = autonomous_system
        if id_perms:
            self.id_perms = id_perms
    #end __init__

    @classmethod
    def factory(cls, **kwargs):
        obj = GlobalSystemConfig()
        obj.__dict__.update(kwargs)
        return obj
    #end factory

    def get_type(self):
        """Return object type (global-system-config)."""
        return self._type
    #end get_type

    def get_fq_name(self):
        """Return FQN of global-system-config in list form."""
        return self.fq_name
    #end get_fq_name

    def get_fq_name_str(self):
        """Return FQN of global-system-config as colon delimited string."""
        return ':'.join(self.fq_name)
    #end get_fq_name_str

    @property
    def parent_name(self):
        return self.fq_name[:-1][-1]
    #end parent_name

    def get_parent_fq_name(self):
        """Return FQN of global-system-config's parent in list form."""
        if not hasattr(self, 'parent_type'):
            # child of config-root
            return None

        return self.fq_name[:-1]
    #end get_parent_fq_name

    def get_parent_fq_name_str(self):
        """Return FQN of global-system-config's parent as colon delimted string."""
        if not hasattr(self, 'parent_type'):
            # child of config-root
            return None

        return ':'.join(self.fq_name[:-1])
    #end get_parent_fq_name_str

    def set_autonomous_system(self, autonomous_system):
        """Set autonomous-system for global-system-config.
        
        :param autonomous_system: AutonomousSystemType object
        
        """
        self.autonomous_system = autonomous_system
    #end set_autonomous_system

    def get_autonomous_system(self):
        """Get autonomous-system for global-system-config.
        
        :returns: AutonomousSystemType object
        
        """
        return getattr(self, 'autonomous_system', None)
    #end get_autonomous_system

    def set_id_perms(self, id_perms):
        """Set id-perms for global-system-config.
        
        :param id_perms: IdPermsType object
        
        """
        self.id_perms = id_perms
    #end set_id_perms

    def get_id_perms(self):
        """Get id-perms for global-system-config.
        
        :returns: IdPermsType object
        
        """
        return getattr(self, 'id_perms', None)
    #end get_id_perms


    def get_physical_routers(self):
        return getattr(self, 'physical_routers', None)
    #end get_physical_routers

    def get_virtual_routers(self):
        return getattr(self, 'virtual_routers', None)
    #end get_virtual_routers

    def set_bgp_router(self, ref_obj):
        """Set bgp-router for global-system-config.
        
        :param ref_obj: BgpRouter object
        
        """
        self.bgp_router_refs = [{'to':ref_obj.get_fq_name()}]
        if ref_obj.uuid:
            self.bgp_router_refs[0]['uuid'] = ref_obj.uuid

    #end set_bgp_router

    def add_bgp_router(self, ref_obj):
        """Add bgp-router to global-system-config.
        
        :param ref_obj: BgpRouter object
        
        """
        refs = getattr(self, 'bgp_router_refs', None)
        if not refs:
            self.bgp_router_refs = []

        ref_info = {'to':ref_obj.get_fq_name()}
        if ref_obj.uuid:
            ref_info['uuid'] = ref_obj.uuid

        self.bgp_router_refs.append(ref_info)
    #end add_bgp_router

    def del_bgp_router(self, ref_obj):
        refs = self.get_bgp_router_refs()
        if not refs:
            return

        for ref in refs:
            if ref['to'] == ref_obj.get_fq_name():
                self.bgp_router_refs.remove(ref)
                return
    #end del_bgp_router

    def set_bgp_router_list(self, ref_obj_list):
        """Set bgp-router list for global-system-config.
        
        :param ref_obj_list: list of BgpRouter object
        
        """
        self.bgp_router_refs = ref_obj_list
    #end set_bgp_router_list

    def get_bgp_router_refs(self):
        """Return bgp-router list for global-system-config.
        
        :returns: list of <BgpRouter>
        
        """
        return getattr(self, 'bgp_router_refs', None)
    #end get_bgp_router_refs

    def get_config_root_back_refs(self):
        """Return list of all config-roots using this global-system-config"""
        return getattr(self, 'config_root_back_refs', None)
    #end get_config_root_back_refs

    def dump(self):
        """Display global-system-config object in compact form."""
        print '------------ global-system-config ------------'
        print 'Name = ', self.get_fq_name()
        print 'Uuid = ', self.uuid
        if hasattr(self, 'parent_type'): # non config-root children
            print 'Parent Type = ', self.parent_type
        print 'P autonomous_system = ', self.get_autonomous_system()
        print 'P id_perms = ', self.get_id_perms()
        print 'REF bgp_router = ', self.get_bgp_router_refs()
        print 'HAS physical_router = ', self.get_physical_routers()
        print 'HAS virtual_router = ', self.get_virtual_routers()
    #end dump

#end class GlobalSystemConfig

class Namespace(object):
    """
    Represents namespace configuration representation.

    Child of:
        :class:`.Domain` object OR

    Properties:
        * namespace-cidr (:class:`.SubnetType` type)
        * id-perms (:class:`.IdPermsType` type)

    Children:

    References to:

    Referred by:
        * list of :class:`.Project` objects
    """

    def __init__(self, name = None, parent_obj = None, namespace_cidr = None, id_perms = None, **kwargs):
        # type-independent fields
        self._type = 'namespace'
        if not name:
            name = u'default-namespace'
        self.name = name
        self.uuid = None
        if parent_obj:
            self.parent_type = parent_obj._type
            # copy parent's fq_name
            fq_name = list(parent_obj.fq_name)
            fq_name.append(name)
            if not parent_obj.get_namespaces():
                parent_obj.namespaces = []
            parent_obj.namespaces.append(self)
        else: # No parent obj specified
            self.parent_type = 'domain'
            fq_name = [u'default-domain']
            fq_name.append(name)

        self.fq_name = fq_name

        # property fields
        if namespace_cidr:
            self.namespace_cidr = namespace_cidr
        if id_perms:
            self.id_perms = id_perms
    #end __init__

    @classmethod
    def factory(cls, **kwargs):
        obj = Namespace()
        obj.__dict__.update(kwargs)
        return obj
    #end factory

    def get_type(self):
        """Return object type (namespace)."""
        return self._type
    #end get_type

    def get_fq_name(self):
        """Return FQN of namespace in list form."""
        return self.fq_name
    #end get_fq_name

    def get_fq_name_str(self):
        """Return FQN of namespace as colon delimited string."""
        return ':'.join(self.fq_name)
    #end get_fq_name_str

    @property
    def parent_name(self):
        return self.fq_name[:-1][-1]
    #end parent_name

    def get_parent_fq_name(self):
        """Return FQN of namespace's parent in list form."""
        if not hasattr(self, 'parent_type'):
            # child of config-root
            return None

        return self.fq_name[:-1]
    #end get_parent_fq_name

    def get_parent_fq_name_str(self):
        """Return FQN of namespace's parent as colon delimted string."""
        if not hasattr(self, 'parent_type'):
            # child of config-root
            return None

        return ':'.join(self.fq_name[:-1])
    #end get_parent_fq_name_str

    def set_namespace_cidr(self, namespace_cidr):
        """Set namespace-cidr for namespace.
        
        :param namespace_cidr: SubnetType object
        
        """
        self.namespace_cidr = namespace_cidr
    #end set_namespace_cidr

    def get_namespace_cidr(self):
        """Get namespace-cidr for namespace.
        
        :returns: SubnetType object
        
        """
        return getattr(self, 'namespace_cidr', None)
    #end get_namespace_cidr

    def set_id_perms(self, id_perms):
        """Set id-perms for namespace.
        
        :param id_perms: IdPermsType object
        
        """
        self.id_perms = id_perms
    #end set_id_perms

    def get_id_perms(self):
        """Get id-perms for namespace.
        
        :returns: IdPermsType object
        
        """
        return getattr(self, 'id_perms', None)
    #end get_id_perms


    def get_domain_back_refs(self):
        """Return list of all domains using this namespace"""
        return getattr(self, 'domain_back_refs', None)
    #end get_domain_back_refs

    def get_project_back_refs(self):
        """Return list of all projects using this namespace"""
        return getattr(self, 'project_back_refs', None)
    #end get_project_back_refs

    def dump(self):
        """Display namespace object in compact form."""
        print '------------ namespace ------------'
        print 'Name = ', self.get_fq_name()
        print 'Uuid = ', self.uuid
        if hasattr(self, 'parent_type'): # non config-root children
            print 'Parent Type = ', self.parent_type
        print 'P namespace_cidr = ', self.get_namespace_cidr()
        print 'P id_perms = ', self.get_id_perms()
        print 'BCK project = ', self.get_project_back_refs()
    #end dump

#end class Namespace

class PhysicalInterface(object):
    """
    Represents physical-interface configuration representation.

    Child of:
        :class:`.PhysicalRouter` object OR

    Properties:
        * id-perms (:class:`.IdPermsType` type)

    Children:
        * list of :class:`.LogicalInterface` objects

    References to:

    Referred by:
    """

    def __init__(self, name = None, parent_obj = None, id_perms = None, **kwargs):
        # type-independent fields
        self._type = 'physical-interface'
        if not name:
            name = u'default-physical-interface'
        self.name = name
        self.uuid = None
        if parent_obj:
            self.parent_type = parent_obj._type
            # copy parent's fq_name
            fq_name = list(parent_obj.fq_name)
            fq_name.append(name)
            if not parent_obj.get_physical_interfaces():
                parent_obj.physical_interfaces = []
            parent_obj.physical_interfaces.append(self)
        else: # No parent obj specified
            self.parent_type = 'physical-router'
            fq_name = [u'default-global-system-config', u'default-physical-router']
            fq_name.append(name)

        self.fq_name = fq_name

        # property fields
        if id_perms:
            self.id_perms = id_perms
    #end __init__

    @classmethod
    def factory(cls, **kwargs):
        obj = PhysicalInterface()
        obj.__dict__.update(kwargs)
        return obj
    #end factory

    def get_type(self):
        """Return object type (physical-interface)."""
        return self._type
    #end get_type

    def get_fq_name(self):
        """Return FQN of physical-interface in list form."""
        return self.fq_name
    #end get_fq_name

    def get_fq_name_str(self):
        """Return FQN of physical-interface as colon delimited string."""
        return ':'.join(self.fq_name)
    #end get_fq_name_str

    @property
    def parent_name(self):
        return self.fq_name[:-1][-1]
    #end parent_name

    def get_parent_fq_name(self):
        """Return FQN of physical-interface's parent in list form."""
        if not hasattr(self, 'parent_type'):
            # child of config-root
            return None

        return self.fq_name[:-1]
    #end get_parent_fq_name

    def get_parent_fq_name_str(self):
        """Return FQN of physical-interface's parent as colon delimted string."""
        if not hasattr(self, 'parent_type'):
            # child of config-root
            return None

        return ':'.join(self.fq_name[:-1])
    #end get_parent_fq_name_str

    def set_id_perms(self, id_perms):
        """Set id-perms for physical-interface.
        
        :param id_perms: IdPermsType object
        
        """
        self.id_perms = id_perms
    #end set_id_perms

    def get_id_perms(self):
        """Get id-perms for physical-interface.
        
        :returns: IdPermsType object
        
        """
        return getattr(self, 'id_perms', None)
    #end get_id_perms


    def get_logical_interfaces(self):
        return getattr(self, 'logical_interfaces', None)
    #end get_logical_interfaces

    def get_physical_router_back_refs(self):
        """Return list of all physical-routers using this physical-interface"""
        return getattr(self, 'physical_router_back_refs', None)
    #end get_physical_router_back_refs

    def dump(self):
        """Display physical-interface object in compact form."""
        print '------------ physical-interface ------------'
        print 'Name = ', self.get_fq_name()
        print 'Uuid = ', self.uuid
        if hasattr(self, 'parent_type'): # non config-root children
            print 'Parent Type = ', self.parent_type
        print 'P id_perms = ', self.get_id_perms()
        print 'HAS logical_interface = ', self.get_logical_interfaces()
    #end dump

#end class PhysicalInterface

class AccessControlList(object):
    """
    Represents access-control-list configuration representation.

    Child of:
        :class:`.VirtualNetwork` object OR

    Properties:
        * access-control-list-entries (:class:`.AclEntriesType` type)
        * id-perms (:class:`.IdPermsType` type)

    Children:

    References to:

    Referred by:
    """

    def __init__(self, name = None, parent_obj = None, access_control_list_entries = None, id_perms = None, **kwargs):
        # type-independent fields
        self._type = 'access-control-list'
        if not name:
            name = u'default-access-control-list'
        self.name = name
        self.uuid = None
        if parent_obj:
            self.parent_type = parent_obj._type
            # copy parent's fq_name
            fq_name = list(parent_obj.fq_name)
            fq_name.append(name)
            if not parent_obj.get_access_control_lists():
                parent_obj.access_control_lists = []
            parent_obj.access_control_lists.append(self)
        else: # No parent obj specified
            self.parent_type = 'virtual-network'
            fq_name = [u'default-domain', u'default-project', u'default-virtual-network']
            fq_name.append(name)

        self.fq_name = fq_name

        # property fields
        if access_control_list_entries:
            self.access_control_list_entries = access_control_list_entries
        if id_perms:
            self.id_perms = id_perms
    #end __init__

    @classmethod
    def factory(cls, **kwargs):
        obj = AccessControlList()
        obj.__dict__.update(kwargs)
        return obj
    #end factory

    def get_type(self):
        """Return object type (access-control-list)."""
        return self._type
    #end get_type

    def get_fq_name(self):
        """Return FQN of access-control-list in list form."""
        return self.fq_name
    #end get_fq_name

    def get_fq_name_str(self):
        """Return FQN of access-control-list as colon delimited string."""
        return ':'.join(self.fq_name)
    #end get_fq_name_str

    @property
    def parent_name(self):
        return self.fq_name[:-1][-1]
    #end parent_name

    def get_parent_fq_name(self):
        """Return FQN of access-control-list's parent in list form."""
        if not hasattr(self, 'parent_type'):
            # child of config-root
            return None

        return self.fq_name[:-1]
    #end get_parent_fq_name

    def get_parent_fq_name_str(self):
        """Return FQN of access-control-list's parent as colon delimted string."""
        if not hasattr(self, 'parent_type'):
            # child of config-root
            return None

        return ':'.join(self.fq_name[:-1])
    #end get_parent_fq_name_str

    def set_access_control_list_entries(self, access_control_list_entries):
        """Set access-control-list-entries for access-control-list.
        
        :param access_control_list_entries: AclEntriesType object
        
        """
        self.access_control_list_entries = access_control_list_entries
    #end set_access_control_list_entries

    def get_access_control_list_entries(self):
        """Get access-control-list-entries for access-control-list.
        
        :returns: AclEntriesType object
        
        """
        return getattr(self, 'access_control_list_entries', None)
    #end get_access_control_list_entries

    def set_id_perms(self, id_perms):
        """Set id-perms for access-control-list.
        
        :param id_perms: IdPermsType object
        
        """
        self.id_perms = id_perms
    #end set_id_perms

    def get_id_perms(self):
        """Get id-perms for access-control-list.
        
        :returns: IdPermsType object
        
        """
        return getattr(self, 'id_perms', None)
    #end get_id_perms


    def get_virtual_network_back_refs(self):
        """Return list of all virtual-networks using this access-control-list"""
        return getattr(self, 'virtual_network_back_refs', None)
    #end get_virtual_network_back_refs

    def dump(self):
        """Display access-control-list object in compact form."""
        print '------------ access-control-list ------------'
        print 'Name = ', self.get_fq_name()
        print 'Uuid = ', self.uuid
        if hasattr(self, 'parent_type'): # non config-root children
            print 'Parent Type = ', self.parent_type
        print 'P access_control_list_entries = ', self.get_access_control_list_entries()
        print 'P id_perms = ', self.get_id_perms()
    #end dump

#end class AccessControlList

class VirtualDns(object):
    """
    Represents virtual-DNS configuration representation.

    Child of:
        :class:`.Domain` object OR

    Properties:
        * virtual-DNS-data (:class:`.VirtualDnsType` type)
        * id-perms (:class:`.IdPermsType` type)

    Children:
        * list of :class:`.VirtualDnsRecord` objects

    References to:

    Referred by:
        * list of :class:`.NetworkIpam` objects
    """

    def __init__(self, name = None, parent_obj = None, virtual_DNS_data = None, id_perms = None, **kwargs):
        # type-independent fields
        self._type = 'virtual-DNS'
        if not name:
            name = u'default-virtual-DNS'
        self.name = name
        self.uuid = None
        if parent_obj:
            self.parent_type = parent_obj._type
            # copy parent's fq_name
            fq_name = list(parent_obj.fq_name)
            fq_name.append(name)
            if not parent_obj.get_virtual_DNSs():
                parent_obj.virtual_DNSs = []
            parent_obj.virtual_DNSs.append(self)
        else: # No parent obj specified
            self.parent_type = 'domain'
            fq_name = [u'default-domain']
            fq_name.append(name)

        self.fq_name = fq_name

        # property fields
        if virtual_DNS_data:
            self.virtual_DNS_data = virtual_DNS_data
        if id_perms:
            self.id_perms = id_perms
    #end __init__

    @classmethod
    def factory(cls, **kwargs):
        obj = VirtualDns()
        obj.__dict__.update(kwargs)
        return obj
    #end factory

    def get_type(self):
        """Return object type (virtual-DNS)."""
        return self._type
    #end get_type

    def get_fq_name(self):
        """Return FQN of virtual-DNS in list form."""
        return self.fq_name
    #end get_fq_name

    def get_fq_name_str(self):
        """Return FQN of virtual-DNS as colon delimited string."""
        return ':'.join(self.fq_name)
    #end get_fq_name_str

    @property
    def parent_name(self):
        return self.fq_name[:-1][-1]
    #end parent_name

    def get_parent_fq_name(self):
        """Return FQN of virtual-DNS's parent in list form."""
        if not hasattr(self, 'parent_type'):
            # child of config-root
            return None

        return self.fq_name[:-1]
    #end get_parent_fq_name

    def get_parent_fq_name_str(self):
        """Return FQN of virtual-DNS's parent as colon delimted string."""
        if not hasattr(self, 'parent_type'):
            # child of config-root
            return None

        return ':'.join(self.fq_name[:-1])
    #end get_parent_fq_name_str

    def set_virtual_DNS_data(self, virtual_DNS_data):
        """Set virtual-DNS-data for virtual-DNS.
        
        :param virtual_DNS_data: VirtualDnsType object
        
        """
        self.virtual_DNS_data = virtual_DNS_data
    #end set_virtual_DNS_data

    def get_virtual_DNS_data(self):
        """Get virtual-DNS-data for virtual-DNS.
        
        :returns: VirtualDnsType object
        
        """
        return getattr(self, 'virtual_DNS_data', None)
    #end get_virtual_DNS_data

    def set_id_perms(self, id_perms):
        """Set id-perms for virtual-DNS.
        
        :param id_perms: IdPermsType object
        
        """
        self.id_perms = id_perms
    #end set_id_perms

    def get_id_perms(self):
        """Get id-perms for virtual-DNS.
        
        :returns: IdPermsType object
        
        """
        return getattr(self, 'id_perms', None)
    #end get_id_perms


    def get_virtual_DNS_records(self):
        return getattr(self, 'virtual_DNS_records', None)
    #end get_virtual_DNS_records

    def get_domain_back_refs(self):
        """Return list of all domains using this virtual-DNS"""
        return getattr(self, 'domain_back_refs', None)
    #end get_domain_back_refs

    def get_network_ipam_back_refs(self):
        """Return list of all network-ipams using this virtual-DNS"""
        return getattr(self, 'network_ipam_back_refs', None)
    #end get_network_ipam_back_refs

    def dump(self):
        """Display virtual-DNS object in compact form."""
        print '------------ virtual-DNS ------------'
        print 'Name = ', self.get_fq_name()
        print 'Uuid = ', self.uuid
        if hasattr(self, 'parent_type'): # non config-root children
            print 'Parent Type = ', self.parent_type
        print 'P virtual_DNS_data = ', self.get_virtual_DNS_data()
        print 'P id_perms = ', self.get_id_perms()
        print 'HAS virtual_DNS_record = ', self.get_virtual_DNS_records()
        print 'BCK network_ipam = ', self.get_network_ipam_back_refs()
    #end dump

#end class VirtualDns

class CustomerAttachment(object):
    """
    Represents customer-attachment configuration representation.

    Properties:
        * attachment-address (:class:`.AttachmentAddressType` type)
        * id-perms (:class:`.IdPermsType` type)

    Children:

    References to:
        * list of :class:`.VirtualMachineInterface` objects
        * list of :class:`.FloatingIp` objects

    Referred by:
    """

    def __init__(self, name = None, attachment_address = None, id_perms = None, **kwargs):
        # type-independent fields
        self._type = 'customer-attachment'
        if not name:
            name = u'default-customer-attachment'
        self.name = name
        self.uuid = None
        fq_name = [name]
        self.fq_name = fq_name

        # property fields
        if attachment_address:
            self.attachment_address = attachment_address
        if id_perms:
            self.id_perms = id_perms
    #end __init__

    @classmethod
    def factory(cls, **kwargs):
        obj = CustomerAttachment()
        obj.__dict__.update(kwargs)
        return obj
    #end factory

    def get_type(self):
        """Return object type (customer-attachment)."""
        return self._type
    #end get_type

    def get_fq_name(self):
        """Return FQN of customer-attachment in list form."""
        return self.fq_name
    #end get_fq_name

    def get_fq_name_str(self):
        """Return FQN of customer-attachment as colon delimited string."""
        return ':'.join(self.fq_name)
    #end get_fq_name_str

    def set_attachment_address(self, attachment_address):
        """Set attachment-address for customer-attachment.
        
        :param attachment_address: AttachmentAddressType object
        
        """
        self.attachment_address = attachment_address
    #end set_attachment_address

    def get_attachment_address(self):
        """Get attachment-address for customer-attachment.
        
        :returns: AttachmentAddressType object
        
        """
        return getattr(self, 'attachment_address', None)
    #end get_attachment_address

    def set_id_perms(self, id_perms):
        """Set id-perms for customer-attachment.
        
        :param id_perms: IdPermsType object
        
        """
        self.id_perms = id_perms
    #end set_id_perms

    def get_id_perms(self):
        """Get id-perms for customer-attachment.
        
        :returns: IdPermsType object
        
        """
        return getattr(self, 'id_perms', None)
    #end get_id_perms


    def set_virtual_machine_interface(self, ref_obj):
        """Set virtual-machine-interface for customer-attachment.
        
        :param ref_obj: VirtualMachineInterface object
        
        """
        self.virtual_machine_interface_refs = [{'to':ref_obj.get_fq_name()}]
        if ref_obj.uuid:
            self.virtual_machine_interface_refs[0]['uuid'] = ref_obj.uuid

    #end set_virtual_machine_interface

    def add_virtual_machine_interface(self, ref_obj):
        """Add virtual-machine-interface to customer-attachment.
        
        :param ref_obj: VirtualMachineInterface object
        
        """
        refs = getattr(self, 'virtual_machine_interface_refs', None)
        if not refs:
            self.virtual_machine_interface_refs = []

        ref_info = {'to':ref_obj.get_fq_name()}
        if ref_obj.uuid:
            ref_info['uuid'] = ref_obj.uuid

        self.virtual_machine_interface_refs.append(ref_info)
    #end add_virtual_machine_interface

    def del_virtual_machine_interface(self, ref_obj):
        refs = self.get_virtual_machine_interface_refs()
        if not refs:
            return

        for ref in refs:
            if ref['to'] == ref_obj.get_fq_name():
                self.virtual_machine_interface_refs.remove(ref)
                return
    #end del_virtual_machine_interface

    def set_virtual_machine_interface_list(self, ref_obj_list):
        """Set virtual-machine-interface list for customer-attachment.
        
        :param ref_obj_list: list of VirtualMachineInterface object
        
        """
        self.virtual_machine_interface_refs = ref_obj_list
    #end set_virtual_machine_interface_list

    def get_virtual_machine_interface_refs(self):
        """Return virtual-machine-interface list for customer-attachment.
        
        :returns: list of <VirtualMachineInterface>
        
        """
        return getattr(self, 'virtual_machine_interface_refs', None)
    #end get_virtual_machine_interface_refs

    def set_floating_ip(self, ref_obj):
        """Set floating-ip for customer-attachment.
        
        :param ref_obj: FloatingIp object
        
        """
        self.floating_ip_refs = [{'to':ref_obj.get_fq_name()}]
        if ref_obj.uuid:
            self.floating_ip_refs[0]['uuid'] = ref_obj.uuid

    #end set_floating_ip

    def add_floating_ip(self, ref_obj):
        """Add floating-ip to customer-attachment.
        
        :param ref_obj: FloatingIp object
        
        """
        refs = getattr(self, 'floating_ip_refs', None)
        if not refs:
            self.floating_ip_refs = []

        ref_info = {'to':ref_obj.get_fq_name()}
        if ref_obj.uuid:
            ref_info['uuid'] = ref_obj.uuid

        self.floating_ip_refs.append(ref_info)
    #end add_floating_ip

    def del_floating_ip(self, ref_obj):
        refs = self.get_floating_ip_refs()
        if not refs:
            return

        for ref in refs:
            if ref['to'] == ref_obj.get_fq_name():
                self.floating_ip_refs.remove(ref)
                return
    #end del_floating_ip

    def set_floating_ip_list(self, ref_obj_list):
        """Set floating-ip list for customer-attachment.
        
        :param ref_obj_list: list of FloatingIp object
        
        """
        self.floating_ip_refs = ref_obj_list
    #end set_floating_ip_list

    def get_floating_ip_refs(self):
        """Return floating-ip list for customer-attachment.
        
        :returns: list of <FloatingIp>
        
        """
        return getattr(self, 'floating_ip_refs', None)
    #end get_floating_ip_refs

    def dump(self):
        """Display customer-attachment object in compact form."""
        print '------------ customer-attachment ------------'
        print 'Name = ', self.get_fq_name()
        print 'Uuid = ', self.uuid
        print 'P attachment_address = ', self.get_attachment_address()
        print 'P id_perms = ', self.get_id_perms()
        print 'REF virtual_machine_interface = ', self.get_virtual_machine_interface_refs()
        print 'REF floating_ip = ', self.get_floating_ip_refs()
        print 'HAS routing_instance = ', self.get_routing_instances()
        print 'HAS provider_attachment = ', self.get_provider_attachments()
    #end dump

#end class CustomerAttachment

class VirtualMachine(object):
    """
    Represents virtual-machine configuration representation.

    Properties:
        * id-perms (:class:`.IdPermsType` type)

    Children:
        * list of :class:`.VirtualMachineInterface` objects

    References to:
        * list of :class:`.SecurityGroup` objects
        * list of :class:`.ServiceInstance` objects

    Referred by:
        * list of :class:`.VirtualRouter` objects
    """

    def __init__(self, name = None, id_perms = None, **kwargs):
        # type-independent fields
        self._type = 'virtual-machine'
        if not name:
            name = u'default-virtual-machine'
        self.name = name
        self.uuid = None
        fq_name = [name]
        self.fq_name = fq_name

        # property fields
        if id_perms:
            self.id_perms = id_perms
    #end __init__

    @classmethod
    def factory(cls, **kwargs):
        obj = VirtualMachine()
        obj.__dict__.update(kwargs)
        return obj
    #end factory

    def get_type(self):
        """Return object type (virtual-machine)."""
        return self._type
    #end get_type

    def get_fq_name(self):
        """Return FQN of virtual-machine in list form."""
        return self.fq_name
    #end get_fq_name

    def get_fq_name_str(self):
        """Return FQN of virtual-machine as colon delimited string."""
        return ':'.join(self.fq_name)
    #end get_fq_name_str

    def set_id_perms(self, id_perms):
        """Set id-perms for virtual-machine.
        
        :param id_perms: IdPermsType object
        
        """
        self.id_perms = id_perms
    #end set_id_perms

    def get_id_perms(self):
        """Get id-perms for virtual-machine.
        
        :returns: IdPermsType object
        
        """
        return getattr(self, 'id_perms', None)
    #end get_id_perms


    def get_virtual_machine_interfaces(self):
        return getattr(self, 'virtual_machine_interfaces', None)
    #end get_virtual_machine_interfaces

    def set_security_group(self, ref_obj):
        """Set security-group for virtual-machine.
        
        :param ref_obj: SecurityGroup object
        
        """
        self.security_group_refs = [{'to':ref_obj.get_fq_name()}]
        if ref_obj.uuid:
            self.security_group_refs[0]['uuid'] = ref_obj.uuid

    #end set_security_group

    def add_security_group(self, ref_obj):
        """Add security-group to virtual-machine.
        
        :param ref_obj: SecurityGroup object
        
        """
        refs = getattr(self, 'security_group_refs', None)
        if not refs:
            self.security_group_refs = []

        ref_info = {'to':ref_obj.get_fq_name()}
        if ref_obj.uuid:
            ref_info['uuid'] = ref_obj.uuid

        self.security_group_refs.append(ref_info)
    #end add_security_group

    def del_security_group(self, ref_obj):
        refs = self.get_security_group_refs()
        if not refs:
            return

        for ref in refs:
            if ref['to'] == ref_obj.get_fq_name():
                self.security_group_refs.remove(ref)
                return
    #end del_security_group

    def set_security_group_list(self, ref_obj_list):
        """Set security-group list for virtual-machine.
        
        :param ref_obj_list: list of SecurityGroup object
        
        """
        self.security_group_refs = ref_obj_list
    #end set_security_group_list

    def get_security_group_refs(self):
        """Return security-group list for virtual-machine.
        
        :returns: list of <SecurityGroup>
        
        """
        return getattr(self, 'security_group_refs', None)
    #end get_security_group_refs

    def set_service_instance(self, ref_obj):
        """Set service-instance for virtual-machine.
        
        :param ref_obj: ServiceInstance object
        
        """
        self.service_instance_refs = [{'to':ref_obj.get_fq_name()}]
        if ref_obj.uuid:
            self.service_instance_refs[0]['uuid'] = ref_obj.uuid

    #end set_service_instance

    def add_service_instance(self, ref_obj):
        """Add service-instance to virtual-machine.
        
        :param ref_obj: ServiceInstance object
        
        """
        refs = getattr(self, 'service_instance_refs', None)
        if not refs:
            self.service_instance_refs = []

        ref_info = {'to':ref_obj.get_fq_name()}
        if ref_obj.uuid:
            ref_info['uuid'] = ref_obj.uuid

        self.service_instance_refs.append(ref_info)
    #end add_service_instance

    def del_service_instance(self, ref_obj):
        refs = self.get_service_instance_refs()
        if not refs:
            return

        for ref in refs:
            if ref['to'] == ref_obj.get_fq_name():
                self.service_instance_refs.remove(ref)
                return
    #end del_service_instance

    def set_service_instance_list(self, ref_obj_list):
        """Set service-instance list for virtual-machine.
        
        :param ref_obj_list: list of ServiceInstance object
        
        """
        self.service_instance_refs = ref_obj_list
    #end set_service_instance_list

    def get_service_instance_refs(self):
        """Return service-instance list for virtual-machine.
        
        :returns: list of <ServiceInstance>
        
        """
        return getattr(self, 'service_instance_refs', None)
    #end get_service_instance_refs

    def get_virtual_router_back_refs(self):
        """Return list of all virtual-routers using this virtual-machine"""
        return getattr(self, 'virtual_router_back_refs', None)
    #end get_virtual_router_back_refs

    def dump(self):
        """Display virtual-machine object in compact form."""
        print '------------ virtual-machine ------------'
        print 'Name = ', self.get_fq_name()
        print 'Uuid = ', self.uuid
        print 'P id_perms = ', self.get_id_perms()
        print 'REF security_group = ', self.get_security_group_refs()
        print 'HAS virtual_machine_interface = ', self.get_virtual_machine_interfaces()
        print 'REF service_instance = ', self.get_service_instance_refs()
        print 'BCK virtual_router = ', self.get_virtual_router_back_refs()
    #end dump

#end class VirtualMachine

class ServiceTemplate(object):
    """
    Represents service-template configuration representation.

    Child of:
        :class:`.Domain` object OR

    Properties:
        * service-template-properties (:class:`.ServiceTemplateType` type)
        * id-perms (:class:`.IdPermsType` type)

    Children:

    References to:

    Referred by:
        * list of :class:`.ServiceInstance` objects
    """

    def __init__(self, name = None, parent_obj = None, service_template_properties = None, id_perms = None, **kwargs):
        # type-independent fields
        self._type = 'service-template'
        if not name:
            name = u'default-service-template'
        self.name = name
        self.uuid = None
        if parent_obj:
            self.parent_type = parent_obj._type
            # copy parent's fq_name
            fq_name = list(parent_obj.fq_name)
            fq_name.append(name)
            if not parent_obj.get_service_templates():
                parent_obj.service_templates = []
            parent_obj.service_templates.append(self)
        else: # No parent obj specified
            self.parent_type = 'domain'
            fq_name = [u'default-domain']
            fq_name.append(name)

        self.fq_name = fq_name

        # property fields
        if service_template_properties:
            self.service_template_properties = service_template_properties
        if id_perms:
            self.id_perms = id_perms
    #end __init__

    @classmethod
    def factory(cls, **kwargs):
        obj = ServiceTemplate()
        obj.__dict__.update(kwargs)
        return obj
    #end factory

    def get_type(self):
        """Return object type (service-template)."""
        return self._type
    #end get_type

    def get_fq_name(self):
        """Return FQN of service-template in list form."""
        return self.fq_name
    #end get_fq_name

    def get_fq_name_str(self):
        """Return FQN of service-template as colon delimited string."""
        return ':'.join(self.fq_name)
    #end get_fq_name_str

    @property
    def parent_name(self):
        return self.fq_name[:-1][-1]
    #end parent_name

    def get_parent_fq_name(self):
        """Return FQN of service-template's parent in list form."""
        if not hasattr(self, 'parent_type'):
            # child of config-root
            return None

        return self.fq_name[:-1]
    #end get_parent_fq_name

    def get_parent_fq_name_str(self):
        """Return FQN of service-template's parent as colon delimted string."""
        if not hasattr(self, 'parent_type'):
            # child of config-root
            return None

        return ':'.join(self.fq_name[:-1])
    #end get_parent_fq_name_str

    def set_service_template_properties(self, service_template_properties):
        """Set service-template-properties for service-template.
        
        :param service_template_properties: ServiceTemplateType object
        
        """
        self.service_template_properties = service_template_properties
    #end set_service_template_properties

    def get_service_template_properties(self):
        """Get service-template-properties for service-template.
        
        :returns: ServiceTemplateType object
        
        """
        return getattr(self, 'service_template_properties', None)
    #end get_service_template_properties

    def set_id_perms(self, id_perms):
        """Set id-perms for service-template.
        
        :param id_perms: IdPermsType object
        
        """
        self.id_perms = id_perms
    #end set_id_perms

    def get_id_perms(self):
        """Get id-perms for service-template.
        
        :returns: IdPermsType object
        
        """
        return getattr(self, 'id_perms', None)
    #end get_id_perms


    def get_domain_back_refs(self):
        """Return list of all domains using this service-template"""
        return getattr(self, 'domain_back_refs', None)
    #end get_domain_back_refs

    def get_service_instance_back_refs(self):
        """Return list of all service-instances using this service-template"""
        return getattr(self, 'service_instance_back_refs', None)
    #end get_service_instance_back_refs

    def dump(self):
        """Display service-template object in compact form."""
        print '------------ service-template ------------'
        print 'Name = ', self.get_fq_name()
        print 'Uuid = ', self.uuid
        if hasattr(self, 'parent_type'): # non config-root children
            print 'Parent Type = ', self.parent_type
        print 'P service_template_properties = ', self.get_service_template_properties()
        print 'P id_perms = ', self.get_id_perms()
        print 'BCK service_instance = ', self.get_service_instance_back_refs()
    #end dump

#end class ServiceTemplate

class SecurityGroup(object):
    """
    Represents security-group configuration representation.

    Child of:
        :class:`.Project` object OR

    Properties:
        * security-group-id (xsd:unsignedInt type)
        * security-group-entries (:class:`.PolicyEntriesType` type)
        * id-perms (:class:`.IdPermsType` type)

    Children:

    References to:

    Referred by:
        * list of :class:`.VirtualMachine` objects
    """

    def __init__(self, name = None, parent_obj = None, security_group_id = None, security_group_entries = None, id_perms = None, **kwargs):
        # type-independent fields
        self._type = 'security-group'
        if not name:
            name = u'default-security-group'
        self.name = name
        self.uuid = None
        if parent_obj:
            self.parent_type = parent_obj._type
            # copy parent's fq_name
            fq_name = list(parent_obj.fq_name)
            fq_name.append(name)
            if not parent_obj.get_security_groups():
                parent_obj.security_groups = []
            parent_obj.security_groups.append(self)
        else: # No parent obj specified
            self.parent_type = 'project'
            fq_name = [u'default-domain', u'default-project']
            fq_name.append(name)

        self.fq_name = fq_name

        # property fields
        if security_group_id:
            self.security_group_id = security_group_id
        if security_group_entries:
            self.security_group_entries = security_group_entries
        if id_perms:
            self.id_perms = id_perms
    #end __init__

    @classmethod
    def factory(cls, **kwargs):
        obj = SecurityGroup()
        obj.__dict__.update(kwargs)
        return obj
    #end factory

    def get_type(self):
        """Return object type (security-group)."""
        return self._type
    #end get_type

    def get_fq_name(self):
        """Return FQN of security-group in list form."""
        return self.fq_name
    #end get_fq_name

    def get_fq_name_str(self):
        """Return FQN of security-group as colon delimited string."""
        return ':'.join(self.fq_name)
    #end get_fq_name_str

    @property
    def parent_name(self):
        return self.fq_name[:-1][-1]
    #end parent_name

    def get_parent_fq_name(self):
        """Return FQN of security-group's parent in list form."""
        if not hasattr(self, 'parent_type'):
            # child of config-root
            return None

        return self.fq_name[:-1]
    #end get_parent_fq_name

    def get_parent_fq_name_str(self):
        """Return FQN of security-group's parent as colon delimted string."""
        if not hasattr(self, 'parent_type'):
            # child of config-root
            return None

        return ':'.join(self.fq_name[:-1])
    #end get_parent_fq_name_str

    def set_security_group_id(self, security_group_id):
        """Set security-group-id for security-group.
        
        :param security_group_id: xsd:unsignedInt object
        
        """
        self.security_group_id = security_group_id
    #end set_security_group_id

    def get_security_group_id(self):
        """Get security-group-id for security-group.
        
        :returns: xsd:unsignedInt object
        
        """
        return getattr(self, 'security_group_id', None)
    #end get_security_group_id

    def set_security_group_entries(self, security_group_entries):
        """Set security-group-entries for security-group.
        
        :param security_group_entries: PolicyEntriesType object
        
        """
        self.security_group_entries = security_group_entries
    #end set_security_group_entries

    def get_security_group_entries(self):
        """Get security-group-entries for security-group.
        
        :returns: PolicyEntriesType object
        
        """
        return getattr(self, 'security_group_entries', None)
    #end get_security_group_entries

    def set_id_perms(self, id_perms):
        """Set id-perms for security-group.
        
        :param id_perms: IdPermsType object
        
        """
        self.id_perms = id_perms
    #end set_id_perms

    def get_id_perms(self):
        """Get id-perms for security-group.
        
        :returns: IdPermsType object
        
        """
        return getattr(self, 'id_perms', None)
    #end get_id_perms


    def get_project_back_refs(self):
        """Return list of all projects using this security-group"""
        return getattr(self, 'project_back_refs', None)
    #end get_project_back_refs

    def get_virtual_machine_back_refs(self):
        """Return list of all virtual-machines using this security-group"""
        return getattr(self, 'virtual_machine_back_refs', None)
    #end get_virtual_machine_back_refs

    def dump(self):
        """Display security-group object in compact form."""
        print '------------ security-group ------------'
        print 'Name = ', self.get_fq_name()
        print 'Uuid = ', self.uuid
        if hasattr(self, 'parent_type'): # non config-root children
            print 'Parent Type = ', self.parent_type
        print 'P security_group_id = ', self.get_security_group_id()
        print 'P security_group_entries = ', self.get_security_group_entries()
        print 'P id_perms = ', self.get_id_perms()
        print 'BCK virtual_machine = ', self.get_virtual_machine_back_refs()
    #end dump

#end class SecurityGroup

class ProviderAttachment(object):
    """
    Represents provider-attachment configuration representation.

    Properties:
        * id-perms (:class:`.IdPermsType` type)

    Children:

    References to:
        * list of :class:`.VirtualRouter` objects

    Referred by:
    """

    def __init__(self, name = None, id_perms = None, **kwargs):
        # type-independent fields
        self._type = 'provider-attachment'
        if not name:
            name = u'default-provider-attachment'
        self.name = name
        self.uuid = None
        fq_name = [name]
        self.fq_name = fq_name

        # property fields
        if id_perms:
            self.id_perms = id_perms
    #end __init__

    @classmethod
    def factory(cls, **kwargs):
        obj = ProviderAttachment()
        obj.__dict__.update(kwargs)
        return obj
    #end factory

    def get_type(self):
        """Return object type (provider-attachment)."""
        return self._type
    #end get_type

    def get_fq_name(self):
        """Return FQN of provider-attachment in list form."""
        return self.fq_name
    #end get_fq_name

    def get_fq_name_str(self):
        """Return FQN of provider-attachment as colon delimited string."""
        return ':'.join(self.fq_name)
    #end get_fq_name_str

    def set_id_perms(self, id_perms):
        """Set id-perms for provider-attachment.
        
        :param id_perms: IdPermsType object
        
        """
        self.id_perms = id_perms
    #end set_id_perms

    def get_id_perms(self):
        """Get id-perms for provider-attachment.
        
        :returns: IdPermsType object
        
        """
        return getattr(self, 'id_perms', None)
    #end get_id_perms


    def set_virtual_router(self, ref_obj):
        """Set virtual-router for provider-attachment.
        
        :param ref_obj: VirtualRouter object
        
        """
        self.virtual_router_refs = [{'to':ref_obj.get_fq_name()}]
        if ref_obj.uuid:
            self.virtual_router_refs[0]['uuid'] = ref_obj.uuid

    #end set_virtual_router

    def add_virtual_router(self, ref_obj):
        """Add virtual-router to provider-attachment.
        
        :param ref_obj: VirtualRouter object
        
        """
        refs = getattr(self, 'virtual_router_refs', None)
        if not refs:
            self.virtual_router_refs = []

        ref_info = {'to':ref_obj.get_fq_name()}
        if ref_obj.uuid:
            ref_info['uuid'] = ref_obj.uuid

        self.virtual_router_refs.append(ref_info)
    #end add_virtual_router

    def del_virtual_router(self, ref_obj):
        refs = self.get_virtual_router_refs()
        if not refs:
            return

        for ref in refs:
            if ref['to'] == ref_obj.get_fq_name():
                self.virtual_router_refs.remove(ref)
                return
    #end del_virtual_router

    def set_virtual_router_list(self, ref_obj_list):
        """Set virtual-router list for provider-attachment.
        
        :param ref_obj_list: list of VirtualRouter object
        
        """
        self.virtual_router_refs = ref_obj_list
    #end set_virtual_router_list

    def get_virtual_router_refs(self):
        """Return virtual-router list for provider-attachment.
        
        :returns: list of <VirtualRouter>
        
        """
        return getattr(self, 'virtual_router_refs', None)
    #end get_virtual_router_refs

    def get_customer_attachment_back_refs(self):
        """Return list of all customer-attachments using this provider-attachment"""
        return getattr(self, 'customer_attachment_back_refs', None)
    #end get_customer_attachment_back_refs

    def dump(self):
        """Display provider-attachment object in compact form."""
        print '------------ provider-attachment ------------'
        print 'Name = ', self.get_fq_name()
        print 'Uuid = ', self.uuid
        print 'P id_perms = ', self.get_id_perms()
        print 'REF virtual_router = ', self.get_virtual_router_refs()
    #end dump

#end class ProviderAttachment

class NetworkIpam(object):
    """
    Represents network-ipam configuration representation.

    Child of:
        :class:`.Project` object OR

    Properties:
        * network-ipam-mgmt (:class:`.IpamType` type)
        * id-perms (:class:`.IdPermsType` type)

    Children:

    References to:
        * list of :class:`.VirtualDns` objects

    Referred by:
        * list of :class:`.VirtualNetwork` objects
    """

    def __init__(self, name = None, parent_obj = None, network_ipam_mgmt = None, id_perms = None, **kwargs):
        # type-independent fields
        self._type = 'network-ipam'
        if not name:
            name = u'default-network-ipam'
        self.name = name
        self.uuid = None
        if parent_obj:
            self.parent_type = parent_obj._type
            # copy parent's fq_name
            fq_name = list(parent_obj.fq_name)
            fq_name.append(name)
            if not parent_obj.get_network_ipams():
                parent_obj.network_ipams = []
            parent_obj.network_ipams.append(self)
        else: # No parent obj specified
            self.parent_type = 'project'
            fq_name = [u'default-domain', u'default-project']
            fq_name.append(name)

        self.fq_name = fq_name

        # property fields
        if network_ipam_mgmt:
            self.network_ipam_mgmt = network_ipam_mgmt
        if id_perms:
            self.id_perms = id_perms
    #end __init__

    @classmethod
    def factory(cls, **kwargs):
        obj = NetworkIpam()
        obj.__dict__.update(kwargs)
        return obj
    #end factory

    def get_type(self):
        """Return object type (network-ipam)."""
        return self._type
    #end get_type

    def get_fq_name(self):
        """Return FQN of network-ipam in list form."""
        return self.fq_name
    #end get_fq_name

    def get_fq_name_str(self):
        """Return FQN of network-ipam as colon delimited string."""
        return ':'.join(self.fq_name)
    #end get_fq_name_str

    @property
    def parent_name(self):
        return self.fq_name[:-1][-1]
    #end parent_name

    def get_parent_fq_name(self):
        """Return FQN of network-ipam's parent in list form."""
        if not hasattr(self, 'parent_type'):
            # child of config-root
            return None

        return self.fq_name[:-1]
    #end get_parent_fq_name

    def get_parent_fq_name_str(self):
        """Return FQN of network-ipam's parent as colon delimted string."""
        if not hasattr(self, 'parent_type'):
            # child of config-root
            return None

        return ':'.join(self.fq_name[:-1])
    #end get_parent_fq_name_str

    def set_network_ipam_mgmt(self, network_ipam_mgmt):
        """Set network-ipam-mgmt for network-ipam.
        
        :param network_ipam_mgmt: IpamType object
        
        """
        self.network_ipam_mgmt = network_ipam_mgmt
    #end set_network_ipam_mgmt

    def get_network_ipam_mgmt(self):
        """Get network-ipam-mgmt for network-ipam.
        
        :returns: IpamType object
        
        """
        return getattr(self, 'network_ipam_mgmt', None)
    #end get_network_ipam_mgmt

    def set_id_perms(self, id_perms):
        """Set id-perms for network-ipam.
        
        :param id_perms: IdPermsType object
        
        """
        self.id_perms = id_perms
    #end set_id_perms

    def get_id_perms(self):
        """Get id-perms for network-ipam.
        
        :returns: IdPermsType object
        
        """
        return getattr(self, 'id_perms', None)
    #end get_id_perms


    def set_virtual_DNS(self, ref_obj):
        """Set virtual-DNS for network-ipam.
        
        :param ref_obj: VirtualDns object
        
        """
        self.virtual_DNS_refs = [{'to':ref_obj.get_fq_name()}]
        if ref_obj.uuid:
            self.virtual_DNS_refs[0]['uuid'] = ref_obj.uuid

    #end set_virtual_DNS

    def add_virtual_DNS(self, ref_obj):
        """Add virtual-DNS to network-ipam.
        
        :param ref_obj: VirtualDns object
        
        """
        refs = getattr(self, 'virtual_DNS_refs', None)
        if not refs:
            self.virtual_DNS_refs = []

        ref_info = {'to':ref_obj.get_fq_name()}
        if ref_obj.uuid:
            ref_info['uuid'] = ref_obj.uuid

        self.virtual_DNS_refs.append(ref_info)
    #end add_virtual_DNS

    def del_virtual_DNS(self, ref_obj):
        refs = self.get_virtual_DNS_refs()
        if not refs:
            return

        for ref in refs:
            if ref['to'] == ref_obj.get_fq_name():
                self.virtual_DNS_refs.remove(ref)
                return
    #end del_virtual_DNS

    def set_virtual_DNS_list(self, ref_obj_list):
        """Set virtual-DNS list for network-ipam.
        
        :param ref_obj_list: list of VirtualDns object
        
        """
        self.virtual_DNS_refs = ref_obj_list
    #end set_virtual_DNS_list

    def get_virtual_DNS_refs(self):
        """Return virtual-DNS list for network-ipam.
        
        :returns: list of <VirtualDns>
        
        """
        return getattr(self, 'virtual_DNS_refs', None)
    #end get_virtual_DNS_refs

    def get_project_back_refs(self):
        """Return list of all projects using this network-ipam"""
        return getattr(self, 'project_back_refs', None)
    #end get_project_back_refs

    def get_virtual_network_back_refs(self):
        """Return list of all virtual-networks using this network-ipam"""
        return getattr(self, 'virtual_network_back_refs', None)
    #end get_virtual_network_back_refs

    def dump(self):
        """Display network-ipam object in compact form."""
        print '------------ network-ipam ------------'
        print 'Name = ', self.get_fq_name()
        print 'Uuid = ', self.uuid
        if hasattr(self, 'parent_type'): # non config-root children
            print 'Parent Type = ', self.parent_type
        print 'P network_ipam_mgmt = ', self.get_network_ipam_mgmt()
        print 'P id_perms = ', self.get_id_perms()
        print 'REF virtual_DNS = ', self.get_virtual_DNS_refs()
        print 'BCK virtual_network = ', self.get_virtual_network_back_refs()
    #end dump

#end class NetworkIpam

class VirtualNetwork(object):
    """
    Represents virtual-network configuration representation.

    Child of:
        :class:`.Project` object OR

    Properties:
        * virtual-network-properties (:class:`.VirtualNetworkType` type)
        * route-target-list (:class:`.RouteTargetList` type)
        * route-table (:class:`.RouteTableType` type)
        * id-perms (:class:`.IdPermsType` type)

    Children:
        * list of :class:`.AccessControlList` objects
        * list of :class:`.FloatingIpPool` objects
        * list of :class:`.RoutingInstance` objects

    References to:
        * list of (:class:`.NetworkIpam` object, :class:`.VnSubnetsType` attribute)
        * list of (:class:`.NetworkPolicy` object, :class:`.VirtualNetworkPolicyType` attribute)

    Referred by:
        * list of :class:`.VirtualMachineInterface` objects
        * list of :class:`.InstanceIp` objects
        * list of :class:`.LogicalInterface` objects
    """

    def __init__(self, name = None, parent_obj = None, virtual_network_properties = None, route_target_list = None, route_table = None, id_perms = None, **kwargs):
        # type-independent fields
        self._type = 'virtual-network'
        if not name:
            name = u'default-virtual-network'
        self.name = name
        self.uuid = None
        if parent_obj:
            self.parent_type = parent_obj._type
            # copy parent's fq_name
            fq_name = list(parent_obj.fq_name)
            fq_name.append(name)
            if not parent_obj.get_virtual_networks():
                parent_obj.virtual_networks = []
            parent_obj.virtual_networks.append(self)
        else: # No parent obj specified
            self.parent_type = 'project'
            fq_name = [u'default-domain', u'default-project']
            fq_name.append(name)

        self.fq_name = fq_name

        # property fields
        if virtual_network_properties:
            self.virtual_network_properties = virtual_network_properties
        if route_target_list:
            self.route_target_list = route_target_list
        if route_table:
            self.route_table = route_table
        if id_perms:
            self.id_perms = id_perms
    #end __init__

    @classmethod
    def factory(cls, **kwargs):
        obj = VirtualNetwork()
        obj.__dict__.update(kwargs)
        return obj
    #end factory

    def get_type(self):
        """Return object type (virtual-network)."""
        return self._type
    #end get_type

    def get_fq_name(self):
        """Return FQN of virtual-network in list form."""
        return self.fq_name
    #end get_fq_name

    def get_fq_name_str(self):
        """Return FQN of virtual-network as colon delimited string."""
        return ':'.join(self.fq_name)
    #end get_fq_name_str

    @property
    def parent_name(self):
        return self.fq_name[:-1][-1]
    #end parent_name

    def get_parent_fq_name(self):
        """Return FQN of virtual-network's parent in list form."""
        if not hasattr(self, 'parent_type'):
            # child of config-root
            return None

        return self.fq_name[:-1]
    #end get_parent_fq_name

    def get_parent_fq_name_str(self):
        """Return FQN of virtual-network's parent as colon delimted string."""
        if not hasattr(self, 'parent_type'):
            # child of config-root
            return None

        return ':'.join(self.fq_name[:-1])
    #end get_parent_fq_name_str

    def set_virtual_network_properties(self, virtual_network_properties):
        """Set virtual-network-properties for virtual-network.
        
        :param virtual_network_properties: VirtualNetworkType object
        
        """
        self.virtual_network_properties = virtual_network_properties
    #end set_virtual_network_properties

    def get_virtual_network_properties(self):
        """Get virtual-network-properties for virtual-network.
        
        :returns: VirtualNetworkType object
        
        """
        return getattr(self, 'virtual_network_properties', None)
    #end get_virtual_network_properties

    def set_route_target_list(self, route_target_list):
        """Set route-target-list for virtual-network.
        
        :param route_target_list: RouteTargetList object
        
        """
        self.route_target_list = route_target_list
    #end set_route_target_list

    def get_route_target_list(self):
        """Get route-target-list for virtual-network.
        
        :returns: RouteTargetList object
        
        """
        return getattr(self, 'route_target_list', None)
    #end get_route_target_list

    def set_route_table(self, route_table):
        """Set route-table for virtual-network.
        
        :param route_table: RouteTableType object
        
        """
        self.route_table = route_table
    #end set_route_table

    def get_route_table(self):
        """Get route-table for virtual-network.
        
        :returns: RouteTableType object
        
        """
        return getattr(self, 'route_table', None)
    #end get_route_table

    def set_id_perms(self, id_perms):
        """Set id-perms for virtual-network.
        
        :param id_perms: IdPermsType object
        
        """
        self.id_perms = id_perms
    #end set_id_perms

    def get_id_perms(self):
        """Get id-perms for virtual-network.
        
        :returns: IdPermsType object
        
        """
        return getattr(self, 'id_perms', None)
    #end get_id_perms


    def get_access_control_lists(self):
        return getattr(self, 'access_control_lists', None)
    #end get_access_control_lists

    def get_floating_ip_pools(self):
        return getattr(self, 'floating_ip_pools', None)
    #end get_floating_ip_pools

    def get_routing_instances(self):
        return getattr(self, 'routing_instances', None)
    #end get_routing_instances

    def set_network_ipam(self, ref_obj, ref_data):
        """Set network-ipam for virtual-network.
        
        :param ref_obj: NetworkIpam object
        :param ref_data: VnSubnetsType object
        
        """
        self.network_ipam_refs = [{'to':ref_obj.get_fq_name(), 'attr':ref_data}]
        if ref_obj.uuid:
            self.network_ipam_refs[0]['uuid'] = ref_obj.uuid

    #end set_network_ipam

    def add_network_ipam(self, ref_obj, ref_data):
        """Add network-ipam to virtual-network.
        
        :param ref_obj: NetworkIpam object
        :param ref_data: VnSubnetsType object
        
        """
        refs = getattr(self, 'network_ipam_refs', None)
        if not refs:
            self.network_ipam_refs = []

        ref_info = {'to':ref_obj.get_fq_name(), 'attr':ref_data}
        if ref_obj.uuid:
            ref_info['uuid'] = ref_obj.uuid

        self.network_ipam_refs.append(ref_info)
    #end add_network_ipam

    def del_network_ipam(self, ref_obj):
        refs = self.get_network_ipam_refs()
        if not refs:
            return

        for ref in refs:
            if ref['to'] == ref_obj.get_fq_name():
                self.network_ipam_refs.remove(ref)
                return
    #end del_network_ipam

    def set_network_ipam_list(self, ref_obj_list, ref_data_list):
        """Set network-ipam list for virtual-network.
        
        :param ref_obj_list: list of NetworkIpam object
        :param ref_data_list: list of VnSubnetsType object
        
        """
        self.network_ipam_refs = [{'to':ref_obj_list[i],                                      'attr':ref_data_list[i]} for i in range(len(ref_obj_list))]
    #end set_network_ipam_list

    def get_network_ipam_refs(self):
        """Return network-ipam list for virtual-network.
        
        :returns: list of tuple <NetworkIpam, VnSubnetsType>
        
        """
        return getattr(self, 'network_ipam_refs', None)
    #end get_network_ipam_refs

    def set_network_policy(self, ref_obj, ref_data):
        """Set network-policy for virtual-network.
        
        :param ref_obj: NetworkPolicy object
        :param ref_data: VirtualNetworkPolicyType object
        
        """
        self.network_policy_refs = [{'to':ref_obj.get_fq_name(), 'attr':ref_data}]
        if ref_obj.uuid:
            self.network_policy_refs[0]['uuid'] = ref_obj.uuid

    #end set_network_policy

    def add_network_policy(self, ref_obj, ref_data):
        """Add network-policy to virtual-network.
        
        :param ref_obj: NetworkPolicy object
        :param ref_data: VirtualNetworkPolicyType object
        
        """
        refs = getattr(self, 'network_policy_refs', None)
        if not refs:
            self.network_policy_refs = []

        ref_info = {'to':ref_obj.get_fq_name(), 'attr':ref_data}
        if ref_obj.uuid:
            ref_info['uuid'] = ref_obj.uuid

        self.network_policy_refs.append(ref_info)
    #end add_network_policy

    def del_network_policy(self, ref_obj):
        refs = self.get_network_policy_refs()
        if not refs:
            return

        for ref in refs:
            if ref['to'] == ref_obj.get_fq_name():
                self.network_policy_refs.remove(ref)
                return
    #end del_network_policy

    def set_network_policy_list(self, ref_obj_list, ref_data_list):
        """Set network-policy list for virtual-network.
        
        :param ref_obj_list: list of NetworkPolicy object
        :param ref_data_list: list of VirtualNetworkPolicyType object
        
        """
        self.network_policy_refs = [{'to':ref_obj_list[i],                                      'attr':ref_data_list[i]} for i in range(len(ref_obj_list))]
    #end set_network_policy_list

    def get_network_policy_refs(self):
        """Return network-policy list for virtual-network.
        
        :returns: list of tuple <NetworkPolicy, VirtualNetworkPolicyType>
        
        """
        return getattr(self, 'network_policy_refs', None)
    #end get_network_policy_refs

    def get_project_back_refs(self):
        """Return list of all projects using this virtual-network"""
        return getattr(self, 'project_back_refs', None)
    #end get_project_back_refs

    def get_virtual_machine_interface_back_refs(self):
        """Return list of all virtual-machine-interfaces using this virtual-network"""
        return getattr(self, 'virtual_machine_interface_back_refs', None)
    #end get_virtual_machine_interface_back_refs

    def get_instance_ip_back_refs(self):
        """Return list of all instance-ips using this virtual-network"""
        return getattr(self, 'instance_ip_back_refs', None)
    #end get_instance_ip_back_refs

    def get_logical_interface_back_refs(self):
        """Return list of all logical-interfaces using this virtual-network"""
        return getattr(self, 'logical_interface_back_refs', None)
    #end get_logical_interface_back_refs

    def dump(self):
        """Display virtual-network object in compact form."""
        print '------------ virtual-network ------------'
        print 'Name = ', self.get_fq_name()
        print 'Uuid = ', self.uuid
        if hasattr(self, 'parent_type'): # non config-root children
            print 'Parent Type = ', self.parent_type
        print 'P virtual_network_properties = ', self.get_virtual_network_properties()
        print 'P route_target_list = ', self.get_route_target_list()
        print 'P route_table = ', self.get_route_table()
        print 'P id_perms = ', self.get_id_perms()
        print 'REF network_ipam = ', self.get_network_ipam_refs()
        print 'REF network_policy = ', self.get_network_policy_refs()
        print 'HAS access_control_list = ', self.get_access_control_lists()
        print 'HAS floating_ip_pool = ', self.get_floating_ip_pools()
        print 'HAS routing_instance = ', self.get_routing_instances()
        print 'BCK virtual_machine_interface = ', self.get_virtual_machine_interface_back_refs()
        print 'BCK instance_ip = ', self.get_instance_ip_back_refs()
        print 'BCK logical_interface = ', self.get_logical_interface_back_refs()
    #end dump

#end class VirtualNetwork

class Project(object):
    """
    Represents project configuration representation.

    Child of:
        :class:`.Domain` object OR

    Properties:
        * id-perms (:class:`.IdPermsType` type)

    Children:
        * list of :class:`.SecurityGroup` objects
        * list of :class:`.VirtualNetwork` objects
        * list of :class:`.NetworkIpam` objects
        * list of :class:`.NetworkPolicy` objects
        * list of :class:`.ServiceInstance` objects

    References to:
        * list of (:class:`.Namespace` object, :class:`.SubnetType` attribute)
        * list of :class:`.FloatingIpPool` objects

    Referred by:
        * list of :class:`.FloatingIp` objects
    """

    def __init__(self, name = None, parent_obj = None, id_perms = None, **kwargs):
        # type-independent fields
        self._type = 'project'
        if not name:
            name = u'default-project'
        self.name = name
        self.uuid = None
        if parent_obj:
            self.parent_type = parent_obj._type
            # copy parent's fq_name
            fq_name = list(parent_obj.fq_name)
            fq_name.append(name)
            if not parent_obj.get_projects():
                parent_obj.projects = []
            parent_obj.projects.append(self)
        else: # No parent obj specified
            self.parent_type = 'domain'
            fq_name = [u'default-domain']
            fq_name.append(name)

        self.fq_name = fq_name

        # property fields
        if id_perms:
            self.id_perms = id_perms
    #end __init__

    @classmethod
    def factory(cls, **kwargs):
        obj = Project()
        obj.__dict__.update(kwargs)
        return obj
    #end factory

    def get_type(self):
        """Return object type (project)."""
        return self._type
    #end get_type

    def get_fq_name(self):
        """Return FQN of project in list form."""
        return self.fq_name
    #end get_fq_name

    def get_fq_name_str(self):
        """Return FQN of project as colon delimited string."""
        return ':'.join(self.fq_name)
    #end get_fq_name_str

    @property
    def parent_name(self):
        return self.fq_name[:-1][-1]
    #end parent_name

    def get_parent_fq_name(self):
        """Return FQN of project's parent in list form."""
        if not hasattr(self, 'parent_type'):
            # child of config-root
            return None

        return self.fq_name[:-1]
    #end get_parent_fq_name

    def get_parent_fq_name_str(self):
        """Return FQN of project's parent as colon delimted string."""
        if not hasattr(self, 'parent_type'):
            # child of config-root
            return None

        return ':'.join(self.fq_name[:-1])
    #end get_parent_fq_name_str

    def set_id_perms(self, id_perms):
        """Set id-perms for project.
        
        :param id_perms: IdPermsType object
        
        """
        self.id_perms = id_perms
    #end set_id_perms

    def get_id_perms(self):
        """Get id-perms for project.
        
        :returns: IdPermsType object
        
        """
        return getattr(self, 'id_perms', None)
    #end get_id_perms


    def get_security_groups(self):
        return getattr(self, 'security_groups', None)
    #end get_security_groups

    def get_virtual_networks(self):
        return getattr(self, 'virtual_networks', None)
    #end get_virtual_networks

    def get_network_ipams(self):
        return getattr(self, 'network_ipams', None)
    #end get_network_ipams

    def get_network_policys(self):
        return getattr(self, 'network_policys', None)
    #end get_network_policys

    def get_service_instances(self):
        return getattr(self, 'service_instances', None)
    #end get_service_instances

    def set_namespace(self, ref_obj, ref_data):
        """Set namespace for project.
        
        :param ref_obj: Namespace object
        :param ref_data: SubnetType object
        
        """
        self.namespace_refs = [{'to':ref_obj.get_fq_name(), 'attr':ref_data}]
        if ref_obj.uuid:
            self.namespace_refs[0]['uuid'] = ref_obj.uuid

    #end set_namespace

    def add_namespace(self, ref_obj, ref_data):
        """Add namespace to project.
        
        :param ref_obj: Namespace object
        :param ref_data: SubnetType object
        
        """
        refs = getattr(self, 'namespace_refs', None)
        if not refs:
            self.namespace_refs = []

        ref_info = {'to':ref_obj.get_fq_name(), 'attr':ref_data}
        if ref_obj.uuid:
            ref_info['uuid'] = ref_obj.uuid

        self.namespace_refs.append(ref_info)
    #end add_namespace

    def del_namespace(self, ref_obj):
        refs = self.get_namespace_refs()
        if not refs:
            return

        for ref in refs:
            if ref['to'] == ref_obj.get_fq_name():
                self.namespace_refs.remove(ref)
                return
    #end del_namespace

    def set_namespace_list(self, ref_obj_list, ref_data_list):
        """Set namespace list for project.
        
        :param ref_obj_list: list of Namespace object
        :param ref_data_list: list of SubnetType object
        
        """
        self.namespace_refs = [{'to':ref_obj_list[i],                                      'attr':ref_data_list[i]} for i in range(len(ref_obj_list))]
    #end set_namespace_list

    def get_namespace_refs(self):
        """Return namespace list for project.
        
        :returns: list of tuple <Namespace, SubnetType>
        
        """
        return getattr(self, 'namespace_refs', None)
    #end get_namespace_refs

    def set_floating_ip_pool(self, ref_obj):
        """Set floating-ip-pool for project.
        
        :param ref_obj: FloatingIpPool object
        
        """
        self.floating_ip_pool_refs = [{'to':ref_obj.get_fq_name()}]
        if ref_obj.uuid:
            self.floating_ip_pool_refs[0]['uuid'] = ref_obj.uuid

    #end set_floating_ip_pool

    def add_floating_ip_pool(self, ref_obj):
        """Add floating-ip-pool to project.
        
        :param ref_obj: FloatingIpPool object
        
        """
        refs = getattr(self, 'floating_ip_pool_refs', None)
        if not refs:
            self.floating_ip_pool_refs = []

        ref_info = {'to':ref_obj.get_fq_name()}
        if ref_obj.uuid:
            ref_info['uuid'] = ref_obj.uuid

        self.floating_ip_pool_refs.append(ref_info)
    #end add_floating_ip_pool

    def del_floating_ip_pool(self, ref_obj):
        refs = self.get_floating_ip_pool_refs()
        if not refs:
            return

        for ref in refs:
            if ref['to'] == ref_obj.get_fq_name():
                self.floating_ip_pool_refs.remove(ref)
                return
    #end del_floating_ip_pool

    def set_floating_ip_pool_list(self, ref_obj_list):
        """Set floating-ip-pool list for project.
        
        :param ref_obj_list: list of FloatingIpPool object
        
        """
        self.floating_ip_pool_refs = ref_obj_list
    #end set_floating_ip_pool_list

    def get_floating_ip_pool_refs(self):
        """Return floating-ip-pool list for project.
        
        :returns: list of <FloatingIpPool>
        
        """
        return getattr(self, 'floating_ip_pool_refs', None)
    #end get_floating_ip_pool_refs

    def get_domain_back_refs(self):
        """Return list of all domains using this project"""
        return getattr(self, 'domain_back_refs', None)
    #end get_domain_back_refs

    def get_floating_ip_back_refs(self):
        """Return list of all floating-ips using this project"""
        return getattr(self, 'floating_ip_back_refs', None)
    #end get_floating_ip_back_refs

    def dump(self):
        """Display project object in compact form."""
        print '------------ project ------------'
        print 'Name = ', self.get_fq_name()
        print 'Uuid = ', self.uuid
        if hasattr(self, 'parent_type'): # non config-root children
            print 'Parent Type = ', self.parent_type
        print 'P id_perms = ', self.get_id_perms()
        print 'REF namespace = ', self.get_namespace_refs()
        print 'HAS security_group = ', self.get_security_groups()
        print 'HAS virtual_network = ', self.get_virtual_networks()
        print 'HAS network_ipam = ', self.get_network_ipams()
        print 'HAS network_policy = ', self.get_network_policys()
        print 'REF floating_ip_pool = ', self.get_floating_ip_pool_refs()
        print 'HAS service_instance = ', self.get_service_instances()
        print 'BCK floating_ip = ', self.get_floating_ip_back_refs()
    #end dump

#end class Project

class LogicalInterface(object):
    """
    Represents logical-interface configuration representation.

    Child of:
        :class:`.PhysicalInterface` object OR

    Properties:
        * id-perms (:class:`.IdPermsType` type)

    Children:

    References to:
        * list of :class:`.VirtualNetwork` objects

    Referred by:
    """

    def __init__(self, name = None, parent_obj = None, id_perms = None, **kwargs):
        # type-independent fields
        self._type = 'logical-interface'
        if not name:
            name = u'default-logical-interface'
        self.name = name
        self.uuid = None
        if parent_obj:
            self.parent_type = parent_obj._type
            # copy parent's fq_name
            fq_name = list(parent_obj.fq_name)
            fq_name.append(name)
            if not parent_obj.get_logical_interfaces():
                parent_obj.logical_interfaces = []
            parent_obj.logical_interfaces.append(self)
        else: # No parent obj specified
            self.parent_type = 'physical-interface'
            fq_name = [u'default-global-system-config', u'default-physical-router', u'default-physical-interface']
            fq_name.append(name)

        self.fq_name = fq_name

        # property fields
        if id_perms:
            self.id_perms = id_perms
    #end __init__

    @classmethod
    def factory(cls, **kwargs):
        obj = LogicalInterface()
        obj.__dict__.update(kwargs)
        return obj
    #end factory

    def get_type(self):
        """Return object type (logical-interface)."""
        return self._type
    #end get_type

    def get_fq_name(self):
        """Return FQN of logical-interface in list form."""
        return self.fq_name
    #end get_fq_name

    def get_fq_name_str(self):
        """Return FQN of logical-interface as colon delimited string."""
        return ':'.join(self.fq_name)
    #end get_fq_name_str

    @property
    def parent_name(self):
        return self.fq_name[:-1][-1]
    #end parent_name

    def get_parent_fq_name(self):
        """Return FQN of logical-interface's parent in list form."""
        if not hasattr(self, 'parent_type'):
            # child of config-root
            return None

        return self.fq_name[:-1]
    #end get_parent_fq_name

    def get_parent_fq_name_str(self):
        """Return FQN of logical-interface's parent as colon delimted string."""
        if not hasattr(self, 'parent_type'):
            # child of config-root
            return None

        return ':'.join(self.fq_name[:-1])
    #end get_parent_fq_name_str

    def set_id_perms(self, id_perms):
        """Set id-perms for logical-interface.
        
        :param id_perms: IdPermsType object
        
        """
        self.id_perms = id_perms
    #end set_id_perms

    def get_id_perms(self):
        """Get id-perms for logical-interface.
        
        :returns: IdPermsType object
        
        """
        return getattr(self, 'id_perms', None)
    #end get_id_perms


    def set_virtual_network(self, ref_obj):
        """Set virtual-network for logical-interface.
        
        :param ref_obj: VirtualNetwork object
        
        """
        self.virtual_network_refs = [{'to':ref_obj.get_fq_name()}]
        if ref_obj.uuid:
            self.virtual_network_refs[0]['uuid'] = ref_obj.uuid

    #end set_virtual_network

    def add_virtual_network(self, ref_obj):
        """Add virtual-network to logical-interface.
        
        :param ref_obj: VirtualNetwork object
        
        """
        refs = getattr(self, 'virtual_network_refs', None)
        if not refs:
            self.virtual_network_refs = []

        ref_info = {'to':ref_obj.get_fq_name()}
        if ref_obj.uuid:
            ref_info['uuid'] = ref_obj.uuid

        self.virtual_network_refs.append(ref_info)
    #end add_virtual_network

    def del_virtual_network(self, ref_obj):
        refs = self.get_virtual_network_refs()
        if not refs:
            return

        for ref in refs:
            if ref['to'] == ref_obj.get_fq_name():
                self.virtual_network_refs.remove(ref)
                return
    #end del_virtual_network

    def set_virtual_network_list(self, ref_obj_list):
        """Set virtual-network list for logical-interface.
        
        :param ref_obj_list: list of VirtualNetwork object
        
        """
        self.virtual_network_refs = ref_obj_list
    #end set_virtual_network_list

    def get_virtual_network_refs(self):
        """Return virtual-network list for logical-interface.
        
        :returns: list of <VirtualNetwork>
        
        """
        return getattr(self, 'virtual_network_refs', None)
    #end get_virtual_network_refs

    def get_physical_interface_back_refs(self):
        """Return list of all physical-interfaces using this logical-interface"""
        return getattr(self, 'physical_interface_back_refs', None)
    #end get_physical_interface_back_refs

    def dump(self):
        """Display logical-interface object in compact form."""
        print '------------ logical-interface ------------'
        print 'Name = ', self.get_fq_name()
        print 'Uuid = ', self.uuid
        if hasattr(self, 'parent_type'): # non config-root children
            print 'Parent Type = ', self.parent_type
        print 'P id_perms = ', self.get_id_perms()
        print 'REF virtual_network = ', self.get_virtual_network_refs()
    #end dump

#end class LogicalInterface

class RoutingInstance(object):
    """
    Represents routing-instance configuration representation.

    Child of:
        :class:`.VirtualNetwork` object OR

    Properties:
        * static-route-entries (:class:`.StaticRouteEntriesType` type)
        * service-chain-information (:class:`.ServiceChainInfo` type)
        * default-ce-protocol (:class:`.DefaultProtocolType` type)
        * id-perms (:class:`.IdPermsType` type)

    Children:
        * list of :class:`.BgpRouter` objects

    References to:
        * list of (:class:`.RoutingInstance` object, :class:`.ConnectionType` attribute)
        * list of (:class:`.RouteTarget` object, :class:`.InstanceTargetType` attribute)

    Referred by:
        * list of :class:`.VirtualMachineInterface` objects
        * list of :class:`.RoutingInstance` objects
    """

    def __init__(self, name = None, parent_obj = None, static_route_entries = None, service_chain_information = None, default_ce_protocol = None, id_perms = None, **kwargs):
        # type-independent fields
        self._type = 'routing-instance'
        if not name:
            name = u'default-routing-instance'
        self.name = name
        self.uuid = None
        if parent_obj:
            self.parent_type = parent_obj._type
            # copy parent's fq_name
            fq_name = list(parent_obj.fq_name)
            fq_name.append(name)
            if not parent_obj.get_routing_instances():
                parent_obj.routing_instances = []
            parent_obj.routing_instances.append(self)
        else: # No parent obj specified
            self.parent_type = 'virtual-network'
            fq_name = [u'default-domain', u'default-project', u'default-virtual-network']
            fq_name.append(name)

        self.fq_name = fq_name

        # property fields
        if static_route_entries:
            self.static_route_entries = static_route_entries
        if service_chain_information:
            self.service_chain_information = service_chain_information
        if default_ce_protocol:
            self.default_ce_protocol = default_ce_protocol
        if id_perms:
            self.id_perms = id_perms
    #end __init__

    @classmethod
    def factory(cls, **kwargs):
        obj = RoutingInstance()
        obj.__dict__.update(kwargs)
        return obj
    #end factory

    def get_type(self):
        """Return object type (routing-instance)."""
        return self._type
    #end get_type

    def get_fq_name(self):
        """Return FQN of routing-instance in list form."""
        return self.fq_name
    #end get_fq_name

    def get_fq_name_str(self):
        """Return FQN of routing-instance as colon delimited string."""
        return ':'.join(self.fq_name)
    #end get_fq_name_str

    @property
    def parent_name(self):
        return self.fq_name[:-1][-1]
    #end parent_name

    def get_parent_fq_name(self):
        """Return FQN of routing-instance's parent in list form."""
        if not hasattr(self, 'parent_type'):
            # child of config-root
            return None

        return self.fq_name[:-1]
    #end get_parent_fq_name

    def get_parent_fq_name_str(self):
        """Return FQN of routing-instance's parent as colon delimted string."""
        if not hasattr(self, 'parent_type'):
            # child of config-root
            return None

        return ':'.join(self.fq_name[:-1])
    #end get_parent_fq_name_str

    def set_static_route_entries(self, static_route_entries):
        """Set static-route-entries for routing-instance.
        
        :param static_route_entries: StaticRouteEntriesType object
        
        """
        self.static_route_entries = static_route_entries
    #end set_static_route_entries

    def get_static_route_entries(self):
        """Get static-route-entries for routing-instance.
        
        :returns: StaticRouteEntriesType object
        
        """
        return getattr(self, 'static_route_entries', None)
    #end get_static_route_entries

    def set_service_chain_information(self, service_chain_information):
        """Set service-chain-information for routing-instance.
        
        :param service_chain_information: ServiceChainInfo object
        
        """
        self.service_chain_information = service_chain_information
    #end set_service_chain_information

    def get_service_chain_information(self):
        """Get service-chain-information for routing-instance.
        
        :returns: ServiceChainInfo object
        
        """
        return getattr(self, 'service_chain_information', None)
    #end get_service_chain_information

    def set_default_ce_protocol(self, default_ce_protocol):
        """Set default-ce-protocol for routing-instance.
        
        :param default_ce_protocol: DefaultProtocolType object
        
        """
        self.default_ce_protocol = default_ce_protocol
    #end set_default_ce_protocol

    def get_default_ce_protocol(self):
        """Get default-ce-protocol for routing-instance.
        
        :returns: DefaultProtocolType object
        
        """
        return getattr(self, 'default_ce_protocol', None)
    #end get_default_ce_protocol

    def set_id_perms(self, id_perms):
        """Set id-perms for routing-instance.
        
        :param id_perms: IdPermsType object
        
        """
        self.id_perms = id_perms
    #end set_id_perms

    def get_id_perms(self):
        """Get id-perms for routing-instance.
        
        :returns: IdPermsType object
        
        """
        return getattr(self, 'id_perms', None)
    #end get_id_perms


    def get_bgp_routers(self):
        return getattr(self, 'bgp_routers', None)
    #end get_bgp_routers

    def set_routing_instance(self, ref_obj, ref_data):
        """Set routing-instance for routing-instance.
        
        :param ref_obj: RoutingInstance object
        :param ref_data: ConnectionType object
        
        """
        self.routing_instance_refs = [{'to':ref_obj.get_fq_name(), 'attr':ref_data}]
        if ref_obj.uuid:
            self.routing_instance_refs[0]['uuid'] = ref_obj.uuid

    #end set_routing_instance

    def add_routing_instance(self, ref_obj, ref_data):
        """Add routing-instance to routing-instance.
        
        :param ref_obj: RoutingInstance object
        :param ref_data: ConnectionType object
        
        """
        refs = getattr(self, 'routing_instance_refs', None)
        if not refs:
            self.routing_instance_refs = []

        ref_info = {'to':ref_obj.get_fq_name(), 'attr':ref_data}
        if ref_obj.uuid:
            ref_info['uuid'] = ref_obj.uuid

        self.routing_instance_refs.append(ref_info)
    #end add_routing_instance

    def del_routing_instance(self, ref_obj):
        refs = self.get_routing_instance_refs()
        if not refs:
            return

        for ref in refs:
            if ref['to'] == ref_obj.get_fq_name():
                self.routing_instance_refs.remove(ref)
                return
    #end del_routing_instance

    def set_routing_instance_list(self, ref_obj_list, ref_data_list):
        """Set routing-instance list for routing-instance.
        
        :param ref_obj_list: list of RoutingInstance object
        :param ref_data_list: list of ConnectionType object
        
        """
        self.routing_instance_refs = [{'to':ref_obj_list[i],                                      'attr':ref_data_list[i]} for i in range(len(ref_obj_list))]
    #end set_routing_instance_list

    def get_routing_instance_refs(self):
        """Return routing-instance list for routing-instance.
        
        :returns: list of tuple <RoutingInstance, ConnectionType>
        
        """
        return getattr(self, 'routing_instance_refs', None)
    #end get_routing_instance_refs

    def set_route_target(self, ref_obj, ref_data):
        """Set route-target for routing-instance.
        
        :param ref_obj: RouteTarget object
        :param ref_data: InstanceTargetType object
        
        """
        self.route_target_refs = [{'to':ref_obj.get_fq_name(), 'attr':ref_data}]
        if ref_obj.uuid:
            self.route_target_refs[0]['uuid'] = ref_obj.uuid

    #end set_route_target

    def add_route_target(self, ref_obj, ref_data):
        """Add route-target to routing-instance.
        
        :param ref_obj: RouteTarget object
        :param ref_data: InstanceTargetType object
        
        """
        refs = getattr(self, 'route_target_refs', None)
        if not refs:
            self.route_target_refs = []

        ref_info = {'to':ref_obj.get_fq_name(), 'attr':ref_data}
        if ref_obj.uuid:
            ref_info['uuid'] = ref_obj.uuid

        self.route_target_refs.append(ref_info)
    #end add_route_target

    def del_route_target(self, ref_obj):
        refs = self.get_route_target_refs()
        if not refs:
            return

        for ref in refs:
            if ref['to'] == ref_obj.get_fq_name():
                self.route_target_refs.remove(ref)
                return
    #end del_route_target

    def set_route_target_list(self, ref_obj_list, ref_data_list):
        """Set route-target list for routing-instance.
        
        :param ref_obj_list: list of RouteTarget object
        :param ref_data_list: list of InstanceTargetType object
        
        """
        self.route_target_refs = [{'to':ref_obj_list[i],                                      'attr':ref_data_list[i]} for i in range(len(ref_obj_list))]
    #end set_route_target_list

    def get_route_target_refs(self):
        """Return route-target list for routing-instance.
        
        :returns: list of tuple <RouteTarget, InstanceTargetType>
        
        """
        return getattr(self, 'route_target_refs', None)
    #end get_route_target_refs

    def get_virtual_machine_interface_back_refs(self):
        """Return list of all virtual-machine-interfaces using this routing-instance"""
        return getattr(self, 'virtual_machine_interface_back_refs', None)
    #end get_virtual_machine_interface_back_refs

    def get_virtual_network_back_refs(self):
        """Return list of all virtual-networks using this routing-instance"""
        return getattr(self, 'virtual_network_back_refs', None)
    #end get_virtual_network_back_refs

    def get_routing_instance_back_refs(self):
        """Return list of all routing-instances using this routing-instance"""
        return getattr(self, 'routing_instance_back_refs', None)
    #end get_routing_instance_back_refs

    def get_customer_attachment_back_refs(self):
        """Return list of all customer-attachments using this routing-instance"""
        return getattr(self, 'customer_attachment_back_refs', None)
    #end get_customer_attachment_back_refs

    def dump(self):
        """Display routing-instance object in compact form."""
        print '------------ routing-instance ------------'
        print 'Name = ', self.get_fq_name()
        print 'Uuid = ', self.uuid
        if hasattr(self, 'parent_type'): # non config-root children
            print 'Parent Type = ', self.parent_type
        print 'P static_route_entries = ', self.get_static_route_entries()
        print 'P service_chain_information = ', self.get_service_chain_information()
        print 'P default_ce_protocol = ', self.get_default_ce_protocol()
        print 'P id_perms = ', self.get_id_perms()
        print 'HAS bgp_router = ', self.get_bgp_routers()
        print 'REF routing_instance = ', self.get_routing_instance_refs()
        print 'REF route_target = ', self.get_route_target_refs()
        print 'BCK virtual_machine_interface = ', self.get_virtual_machine_interface_back_refs()
        print 'BCK routing_instance = ', self.get_routing_instance_back_refs()
    #end dump

#end class RoutingInstance

class VirtualMachineInterface(object):
    """
    Represents virtual-machine-interface configuration representation.

    Child of:
        :class:`.VirtualMachine` object OR

    Properties:
        * virtual-machine-interface-mac-addresses (:class:`.MacAddressesType` type)
        * virtual-machine-interface-properties (:class:`.VirtualMachineInterfacePropertiesType` type)
        * id-perms (:class:`.IdPermsType` type)

    Children:

    References to:
        * list of :class:`.VirtualNetwork` objects
        * list of (:class:`.RoutingInstance` object, :class:`.PolicyBasedForwardingRuleType` attribute)

    Referred by:
        * list of :class:`.InstanceIp` objects
        * list of :class:`.FloatingIp` objects
        * list of :class:`.CustomerAttachment` objects
    """

    def __init__(self, name = None, parent_obj = None, virtual_machine_interface_mac_addresses = None, virtual_machine_interface_properties = None, id_perms = None, **kwargs):
        # type-independent fields
        self._type = 'virtual-machine-interface'
        if not name:
            name = u'default-virtual-machine-interface'
        self.name = name
        self.uuid = None
        if parent_obj:
            self.parent_type = parent_obj._type
            # copy parent's fq_name
            fq_name = list(parent_obj.fq_name)
            fq_name.append(name)
            if not parent_obj.get_virtual_machine_interfaces():
                parent_obj.virtual_machine_interfaces = []
            parent_obj.virtual_machine_interfaces.append(self)
        else: # No parent obj specified
            self.parent_type = 'virtual-machine'
            fq_name = [u'default-virtual-machine']
            fq_name.append(name)

        self.fq_name = fq_name

        # property fields
        if virtual_machine_interface_mac_addresses:
            self.virtual_machine_interface_mac_addresses = virtual_machine_interface_mac_addresses
        if virtual_machine_interface_properties:
            self.virtual_machine_interface_properties = virtual_machine_interface_properties
        if id_perms:
            self.id_perms = id_perms
    #end __init__

    @classmethod
    def factory(cls, **kwargs):
        obj = VirtualMachineInterface()
        obj.__dict__.update(kwargs)
        return obj
    #end factory

    def get_type(self):
        """Return object type (virtual-machine-interface)."""
        return self._type
    #end get_type

    def get_fq_name(self):
        """Return FQN of virtual-machine-interface in list form."""
        return self.fq_name
    #end get_fq_name

    def get_fq_name_str(self):
        """Return FQN of virtual-machine-interface as colon delimited string."""
        return ':'.join(self.fq_name)
    #end get_fq_name_str

    @property
    def parent_name(self):
        return self.fq_name[:-1][-1]
    #end parent_name

    def get_parent_fq_name(self):
        """Return FQN of virtual-machine-interface's parent in list form."""
        if not hasattr(self, 'parent_type'):
            # child of config-root
            return None

        return self.fq_name[:-1]
    #end get_parent_fq_name

    def get_parent_fq_name_str(self):
        """Return FQN of virtual-machine-interface's parent as colon delimted string."""
        if not hasattr(self, 'parent_type'):
            # child of config-root
            return None

        return ':'.join(self.fq_name[:-1])
    #end get_parent_fq_name_str

    def set_virtual_machine_interface_mac_addresses(self, virtual_machine_interface_mac_addresses):
        """Set virtual-machine-interface-mac-addresses for virtual-machine-interface.
        
        :param virtual_machine_interface_mac_addresses: MacAddressesType object
        
        """
        self.virtual_machine_interface_mac_addresses = virtual_machine_interface_mac_addresses
    #end set_virtual_machine_interface_mac_addresses

    def get_virtual_machine_interface_mac_addresses(self):
        """Get virtual-machine-interface-mac-addresses for virtual-machine-interface.
        
        :returns: MacAddressesType object
        
        """
        return getattr(self, 'virtual_machine_interface_mac_addresses', None)
    #end get_virtual_machine_interface_mac_addresses

    def set_virtual_machine_interface_properties(self, virtual_machine_interface_properties):
        """Set virtual-machine-interface-properties for virtual-machine-interface.
        
        :param virtual_machine_interface_properties: VirtualMachineInterfacePropertiesType object
        
        """
        self.virtual_machine_interface_properties = virtual_machine_interface_properties
    #end set_virtual_machine_interface_properties

    def get_virtual_machine_interface_properties(self):
        """Get virtual-machine-interface-properties for virtual-machine-interface.
        
        :returns: VirtualMachineInterfacePropertiesType object
        
        """
        return getattr(self, 'virtual_machine_interface_properties', None)
    #end get_virtual_machine_interface_properties

    def set_id_perms(self, id_perms):
        """Set id-perms for virtual-machine-interface.
        
        :param id_perms: IdPermsType object
        
        """
        self.id_perms = id_perms
    #end set_id_perms

    def get_id_perms(self):
        """Get id-perms for virtual-machine-interface.
        
        :returns: IdPermsType object
        
        """
        return getattr(self, 'id_perms', None)
    #end get_id_perms


    def set_virtual_network(self, ref_obj):
        """Set virtual-network for virtual-machine-interface.
        
        :param ref_obj: VirtualNetwork object
        
        """
        self.virtual_network_refs = [{'to':ref_obj.get_fq_name()}]
        if ref_obj.uuid:
            self.virtual_network_refs[0]['uuid'] = ref_obj.uuid

    #end set_virtual_network

    def add_virtual_network(self, ref_obj):
        """Add virtual-network to virtual-machine-interface.
        
        :param ref_obj: VirtualNetwork object
        
        """
        refs = getattr(self, 'virtual_network_refs', None)
        if not refs:
            self.virtual_network_refs = []

        ref_info = {'to':ref_obj.get_fq_name()}
        if ref_obj.uuid:
            ref_info['uuid'] = ref_obj.uuid

        self.virtual_network_refs.append(ref_info)
    #end add_virtual_network

    def del_virtual_network(self, ref_obj):
        refs = self.get_virtual_network_refs()
        if not refs:
            return

        for ref in refs:
            if ref['to'] == ref_obj.get_fq_name():
                self.virtual_network_refs.remove(ref)
                return
    #end del_virtual_network

    def set_virtual_network_list(self, ref_obj_list):
        """Set virtual-network list for virtual-machine-interface.
        
        :param ref_obj_list: list of VirtualNetwork object
        
        """
        self.virtual_network_refs = ref_obj_list
    #end set_virtual_network_list

    def get_virtual_network_refs(self):
        """Return virtual-network list for virtual-machine-interface.
        
        :returns: list of <VirtualNetwork>
        
        """
        return getattr(self, 'virtual_network_refs', None)
    #end get_virtual_network_refs

    def set_routing_instance(self, ref_obj, ref_data):
        """Set routing-instance for virtual-machine-interface.
        
        :param ref_obj: RoutingInstance object
        :param ref_data: PolicyBasedForwardingRuleType object
        
        """
        self.routing_instance_refs = [{'to':ref_obj.get_fq_name(), 'attr':ref_data}]
        if ref_obj.uuid:
            self.routing_instance_refs[0]['uuid'] = ref_obj.uuid

    #end set_routing_instance

    def add_routing_instance(self, ref_obj, ref_data):
        """Add routing-instance to virtual-machine-interface.
        
        :param ref_obj: RoutingInstance object
        :param ref_data: PolicyBasedForwardingRuleType object
        
        """
        refs = getattr(self, 'routing_instance_refs', None)
        if not refs:
            self.routing_instance_refs = []

        ref_info = {'to':ref_obj.get_fq_name(), 'attr':ref_data}
        if ref_obj.uuid:
            ref_info['uuid'] = ref_obj.uuid

        self.routing_instance_refs.append(ref_info)
    #end add_routing_instance

    def del_routing_instance(self, ref_obj):
        refs = self.get_routing_instance_refs()
        if not refs:
            return

        for ref in refs:
            if ref['to'] == ref_obj.get_fq_name():
                self.routing_instance_refs.remove(ref)
                return
    #end del_routing_instance

    def set_routing_instance_list(self, ref_obj_list, ref_data_list):
        """Set routing-instance list for virtual-machine-interface.
        
        :param ref_obj_list: list of RoutingInstance object
        :param ref_data_list: list of PolicyBasedForwardingRuleType object
        
        """
        self.routing_instance_refs = [{'to':ref_obj_list[i],                                      'attr':ref_data_list[i]} for i in range(len(ref_obj_list))]
    #end set_routing_instance_list

    def get_routing_instance_refs(self):
        """Return routing-instance list for virtual-machine-interface.
        
        :returns: list of tuple <RoutingInstance, PolicyBasedForwardingRuleType>
        
        """
        return getattr(self, 'routing_instance_refs', None)
    #end get_routing_instance_refs

    def get_virtual_machine_back_refs(self):
        """Return list of all virtual-machines using this virtual-machine-interface"""
        return getattr(self, 'virtual_machine_back_refs', None)
    #end get_virtual_machine_back_refs

    def get_instance_ip_back_refs(self):
        """Return list of all instance-ips using this virtual-machine-interface"""
        return getattr(self, 'instance_ip_back_refs', None)
    #end get_instance_ip_back_refs

    def get_floating_ip_back_refs(self):
        """Return list of all floating-ips using this virtual-machine-interface"""
        return getattr(self, 'floating_ip_back_refs', None)
    #end get_floating_ip_back_refs

    def get_customer_attachment_back_refs(self):
        """Return list of all customer-attachments using this virtual-machine-interface"""
        return getattr(self, 'customer_attachment_back_refs', None)
    #end get_customer_attachment_back_refs

    def dump(self):
        """Display virtual-machine-interface object in compact form."""
        print '------------ virtual-machine-interface ------------'
        print 'Name = ', self.get_fq_name()
        print 'Uuid = ', self.uuid
        if hasattr(self, 'parent_type'): # non config-root children
            print 'Parent Type = ', self.parent_type
        print 'P virtual_machine_interface_mac_addresses = ', self.get_virtual_machine_interface_mac_addresses()
        print 'P virtual_machine_interface_properties = ', self.get_virtual_machine_interface_properties()
        print 'P id_perms = ', self.get_id_perms()
        print 'REF virtual_network = ', self.get_virtual_network_refs()
        print 'REF routing_instance = ', self.get_routing_instance_refs()
        print 'BCK instance_ip = ', self.get_instance_ip_back_refs()
        print 'BCK floating_ip = ', self.get_floating_ip_back_refs()
        print 'BCK customer_attachment = ', self.get_customer_attachment_back_refs()
    #end dump

#end class VirtualMachineInterface


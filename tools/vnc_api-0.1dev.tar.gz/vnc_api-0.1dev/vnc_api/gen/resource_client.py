
# AUTO-GENERATED file from IFMapApiGenerator. Do Not Edit!

from vnc_api.gen.resource_common import *

class DomainClientGen(Domain):
    create_uri = ''
    resource_uri_base = {}
    def __init__(self):
        pass
    #end __init__
#end class DomainClientGen

class ServiceInstanceClientGen(ServiceInstance):
    create_uri = ''
    resource_uri_base = {}
    def __init__(self):
        pass
    #end __init__
#end class ServiceInstanceClientGen

class InstanceIpClientGen(InstanceIp):
    create_uri = ''
    resource_uri_base = {}
    def __init__(self):
        pass
    #end __init__
#end class InstanceIpClientGen

class NetworkPolicyClientGen(NetworkPolicy):
    create_uri = ''
    resource_uri_base = {}
    def __init__(self):
        pass
    #end __init__
#end class NetworkPolicyClientGen

class VirtualDnsRecordClientGen(VirtualDnsRecord):
    create_uri = ''
    resource_uri_base = {}
    def __init__(self):
        pass
    #end __init__
#end class VirtualDnsRecordClientGen

class RouteTargetClientGen(RouteTarget):
    create_uri = ''
    resource_uri_base = {}
    def __init__(self):
        pass
    #end __init__
#end class RouteTargetClientGen

class FloatingIpClientGen(FloatingIp):
    create_uri = ''
    resource_uri_base = {}
    def __init__(self):
        pass
    #end __init__
#end class FloatingIpClientGen

class FloatingIpPoolClientGen(FloatingIpPool):
    create_uri = ''
    resource_uri_base = {}
    def __init__(self):
        pass
    #end __init__
#end class FloatingIpPoolClientGen

class PhysicalRouterClientGen(PhysicalRouter):
    create_uri = ''
    resource_uri_base = {}
    def __init__(self):
        pass
    #end __init__
#end class PhysicalRouterClientGen

class BgpRouterClientGen(BgpRouter):
    create_uri = ''
    resource_uri_base = {}
    def __init__(self):
        pass
    #end __init__
#end class BgpRouterClientGen

class VirtualRouterClientGen(VirtualRouter):
    create_uri = ''
    resource_uri_base = {}
    def __init__(self):
        pass
    #end __init__
#end class VirtualRouterClientGen

class ConfigRootClientGen(ConfigRoot):
    create_uri = ''
    resource_uri_base = {}
    def __init__(self):
        pass
    #end __init__
#end class ConfigRootClientGen

class GlobalSystemConfigClientGen(GlobalSystemConfig):
    create_uri = ''
    resource_uri_base = {}
    def __init__(self):
        pass
    #end __init__
#end class GlobalSystemConfigClientGen

class NamespaceClientGen(Namespace):
    create_uri = ''
    resource_uri_base = {}
    def __init__(self):
        pass
    #end __init__
#end class NamespaceClientGen

class PhysicalInterfaceClientGen(PhysicalInterface):
    create_uri = ''
    resource_uri_base = {}
    def __init__(self):
        pass
    #end __init__
#end class PhysicalInterfaceClientGen

class AccessControlListClientGen(AccessControlList):
    create_uri = ''
    resource_uri_base = {}
    def __init__(self):
        pass
    #end __init__
#end class AccessControlListClientGen

class VirtualDnsClientGen(VirtualDns):
    create_uri = ''
    resource_uri_base = {}
    def __init__(self):
        pass
    #end __init__
#end class VirtualDnsClientGen

class CustomerAttachmentClientGen(CustomerAttachment):
    create_uri = ''
    resource_uri_base = {}
    def __init__(self):
        pass
    #end __init__
#end class CustomerAttachmentClientGen

class VirtualMachineClientGen(VirtualMachine):
    create_uri = ''
    resource_uri_base = {}
    def __init__(self):
        pass
    #end __init__
#end class VirtualMachineClientGen

class ServiceTemplateClientGen(ServiceTemplate):
    create_uri = ''
    resource_uri_base = {}
    def __init__(self):
        pass
    #end __init__
#end class ServiceTemplateClientGen

class SecurityGroupClientGen(SecurityGroup):
    create_uri = ''
    resource_uri_base = {}
    def __init__(self):
        pass
    #end __init__
#end class SecurityGroupClientGen

class ProviderAttachmentClientGen(ProviderAttachment):
    create_uri = ''
    resource_uri_base = {}
    def __init__(self):
        pass
    #end __init__
#end class ProviderAttachmentClientGen

class NetworkIpamClientGen(NetworkIpam):
    create_uri = ''
    resource_uri_base = {}
    def __init__(self):
        pass
    #end __init__
#end class NetworkIpamClientGen

class VirtualNetworkClientGen(VirtualNetwork):
    create_uri = ''
    resource_uri_base = {}
    def __init__(self):
        pass
    #end __init__
#end class VirtualNetworkClientGen

class ProjectClientGen(Project):
    create_uri = ''
    resource_uri_base = {}
    def __init__(self):
        pass
    #end __init__
#end class ProjectClientGen

class LogicalInterfaceClientGen(LogicalInterface):
    create_uri = ''
    resource_uri_base = {}
    def __init__(self):
        pass
    #end __init__
#end class LogicalInterfaceClientGen

class RoutingInstanceClientGen(RoutingInstance):
    create_uri = ''
    resource_uri_base = {}
    def __init__(self):
        pass
    #end __init__
#end class RoutingInstanceClientGen

class VirtualMachineInterfaceClientGen(VirtualMachineInterface):
    create_uri = ''
    resource_uri_base = {}
    def __init__(self):
        pass
    #end __init__
#end class VirtualMachineInterfaceClientGen


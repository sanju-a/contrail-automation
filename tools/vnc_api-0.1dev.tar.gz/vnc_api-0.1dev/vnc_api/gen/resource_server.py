
# AUTO-GENERATED file from IFMapApiGenerator. Do Not Edit!

from gen.resource_common import *

class DomainServerGen(Domain):
    generate_default_instance = True

    def __init__(self):
        pass
    #end __init__

    @classmethod
    def http_get(cls, id):
        return True, ''
    #end http_get

    @classmethod
    def http_put(cls, id, obj):
        return True, ''
    #end http_put

    @classmethod
    def http_post(cls, tenant_name, obj):
        return True, ''
    #end http_post

    @classmethod
    def http_delete(cls, id, obj):
        return True, ''
    #end http_delete

    @classmethod
    def http_post_collection(cls, tenant_name, obj):
        return True, ''
    #end http_post

    @classmethod
    def _db_read(cls, id):
        pass
    #end _db_read

    @classmethod
    def _db_create(cls, tenant_name, obj):
        pass
    #end _db_create

#end class DomainServerGen

class ServiceInstanceServerGen(ServiceInstance):
    generate_default_instance = True

    def __init__(self):
        pass
    #end __init__

    @classmethod
    def http_get(cls, id):
        return True, ''
    #end http_get

    @classmethod
    def http_put(cls, id, obj):
        return True, ''
    #end http_put

    @classmethod
    def http_post(cls, tenant_name, obj):
        return True, ''
    #end http_post

    @classmethod
    def http_delete(cls, id, obj):
        return True, ''
    #end http_delete

    @classmethod
    def http_post_collection(cls, tenant_name, obj):
        return True, ''
    #end http_post

    @classmethod
    def _db_read(cls, id):
        pass
    #end _db_read

    @classmethod
    def _db_create(cls, tenant_name, obj):
        pass
    #end _db_create

#end class ServiceInstanceServerGen

class InstanceIpServerGen(InstanceIp):
    generate_default_instance = True

    def __init__(self):
        pass
    #end __init__

    @classmethod
    def http_get(cls, id):
        return True, ''
    #end http_get

    @classmethod
    def http_put(cls, id, obj):
        return True, ''
    #end http_put

    @classmethod
    def http_post(cls, tenant_name, obj):
        return True, ''
    #end http_post

    @classmethod
    def http_delete(cls, id, obj):
        return True, ''
    #end http_delete

    @classmethod
    def http_post_collection(cls, tenant_name, obj):
        return True, ''
    #end http_post

    @classmethod
    def _db_read(cls, id):
        pass
    #end _db_read

    @classmethod
    def _db_create(cls, tenant_name, obj):
        pass
    #end _db_create

#end class InstanceIpServerGen

class NetworkPolicyServerGen(NetworkPolicy):
    generate_default_instance = True

    def __init__(self):
        pass
    #end __init__

    @classmethod
    def http_get(cls, id):
        return True, ''
    #end http_get

    @classmethod
    def http_put(cls, id, obj):
        return True, ''
    #end http_put

    @classmethod
    def http_post(cls, tenant_name, obj):
        return True, ''
    #end http_post

    @classmethod
    def http_delete(cls, id, obj):
        return True, ''
    #end http_delete

    @classmethod
    def http_post_collection(cls, tenant_name, obj):
        return True, ''
    #end http_post

    @classmethod
    def _db_read(cls, id):
        pass
    #end _db_read

    @classmethod
    def _db_create(cls, tenant_name, obj):
        pass
    #end _db_create

#end class NetworkPolicyServerGen

class VirtualDnsRecordServerGen(VirtualDnsRecord):
    generate_default_instance = True

    def __init__(self):
        pass
    #end __init__

    @classmethod
    def http_get(cls, id):
        return True, ''
    #end http_get

    @classmethod
    def http_put(cls, id, obj):
        return True, ''
    #end http_put

    @classmethod
    def http_post(cls, tenant_name, obj):
        return True, ''
    #end http_post

    @classmethod
    def http_delete(cls, id, obj):
        return True, ''
    #end http_delete

    @classmethod
    def http_post_collection(cls, tenant_name, obj):
        return True, ''
    #end http_post

    @classmethod
    def _db_read(cls, id):
        pass
    #end _db_read

    @classmethod
    def _db_create(cls, tenant_name, obj):
        pass
    #end _db_create

#end class VirtualDnsRecordServerGen

class RouteTargetServerGen(RouteTarget):
    generate_default_instance = True

    def __init__(self):
        pass
    #end __init__

    @classmethod
    def http_get(cls, id):
        return True, ''
    #end http_get

    @classmethod
    def http_put(cls, id, obj):
        return True, ''
    #end http_put

    @classmethod
    def http_post(cls, tenant_name, obj):
        return True, ''
    #end http_post

    @classmethod
    def http_delete(cls, id, obj):
        return True, ''
    #end http_delete

    @classmethod
    def http_post_collection(cls, tenant_name, obj):
        return True, ''
    #end http_post

    @classmethod
    def _db_read(cls, id):
        pass
    #end _db_read

    @classmethod
    def _db_create(cls, tenant_name, obj):
        pass
    #end _db_create

#end class RouteTargetServerGen

class FloatingIpServerGen(FloatingIp):
    generate_default_instance = True

    def __init__(self):
        pass
    #end __init__

    @classmethod
    def http_get(cls, id):
        return True, ''
    #end http_get

    @classmethod
    def http_put(cls, id, obj):
        return True, ''
    #end http_put

    @classmethod
    def http_post(cls, tenant_name, obj):
        return True, ''
    #end http_post

    @classmethod
    def http_delete(cls, id, obj):
        return True, ''
    #end http_delete

    @classmethod
    def http_post_collection(cls, tenant_name, obj):
        return True, ''
    #end http_post

    @classmethod
    def _db_read(cls, id):
        pass
    #end _db_read

    @classmethod
    def _db_create(cls, tenant_name, obj):
        pass
    #end _db_create

#end class FloatingIpServerGen

class FloatingIpPoolServerGen(FloatingIpPool):
    generate_default_instance = True

    def __init__(self):
        pass
    #end __init__

    @classmethod
    def http_get(cls, id):
        return True, ''
    #end http_get

    @classmethod
    def http_put(cls, id, obj):
        return True, ''
    #end http_put

    @classmethod
    def http_post(cls, tenant_name, obj):
        return True, ''
    #end http_post

    @classmethod
    def http_delete(cls, id, obj):
        return True, ''
    #end http_delete

    @classmethod
    def http_post_collection(cls, tenant_name, obj):
        return True, ''
    #end http_post

    @classmethod
    def _db_read(cls, id):
        pass
    #end _db_read

    @classmethod
    def _db_create(cls, tenant_name, obj):
        pass
    #end _db_create

#end class FloatingIpPoolServerGen

class PhysicalRouterServerGen(PhysicalRouter):
    generate_default_instance = True

    def __init__(self):
        pass
    #end __init__

    @classmethod
    def http_get(cls, id):
        return True, ''
    #end http_get

    @classmethod
    def http_put(cls, id, obj):
        return True, ''
    #end http_put

    @classmethod
    def http_post(cls, tenant_name, obj):
        return True, ''
    #end http_post

    @classmethod
    def http_delete(cls, id, obj):
        return True, ''
    #end http_delete

    @classmethod
    def http_post_collection(cls, tenant_name, obj):
        return True, ''
    #end http_post

    @classmethod
    def _db_read(cls, id):
        pass
    #end _db_read

    @classmethod
    def _db_create(cls, tenant_name, obj):
        pass
    #end _db_create

#end class PhysicalRouterServerGen

class BgpRouterServerGen(BgpRouter):
    generate_default_instance = True

    def __init__(self):
        pass
    #end __init__

    @classmethod
    def http_get(cls, id):
        return True, ''
    #end http_get

    @classmethod
    def http_put(cls, id, obj):
        return True, ''
    #end http_put

    @classmethod
    def http_post(cls, tenant_name, obj):
        return True, ''
    #end http_post

    @classmethod
    def http_delete(cls, id, obj):
        return True, ''
    #end http_delete

    @classmethod
    def http_post_collection(cls, tenant_name, obj):
        return True, ''
    #end http_post

    @classmethod
    def _db_read(cls, id):
        pass
    #end _db_read

    @classmethod
    def _db_create(cls, tenant_name, obj):
        pass
    #end _db_create

#end class BgpRouterServerGen

class VirtualRouterServerGen(VirtualRouter):
    generate_default_instance = True

    def __init__(self):
        pass
    #end __init__

    @classmethod
    def http_get(cls, id):
        return True, ''
    #end http_get

    @classmethod
    def http_put(cls, id, obj):
        return True, ''
    #end http_put

    @classmethod
    def http_post(cls, tenant_name, obj):
        return True, ''
    #end http_post

    @classmethod
    def http_delete(cls, id, obj):
        return True, ''
    #end http_delete

    @classmethod
    def http_post_collection(cls, tenant_name, obj):
        return True, ''
    #end http_post

    @classmethod
    def _db_read(cls, id):
        pass
    #end _db_read

    @classmethod
    def _db_create(cls, tenant_name, obj):
        pass
    #end _db_create

#end class VirtualRouterServerGen

class ConfigRootServerGen(ConfigRoot):
    generate_default_instance = True

    def __init__(self):
        pass
    #end __init__

    @classmethod
    def http_get(cls, id):
        return True, ''
    #end http_get

    @classmethod
    def http_put(cls, id, obj):
        return True, ''
    #end http_put

    @classmethod
    def http_post(cls, tenant_name, obj):
        return True, ''
    #end http_post

    @classmethod
    def http_delete(cls, id, obj):
        return True, ''
    #end http_delete

    @classmethod
    def http_post_collection(cls, tenant_name, obj):
        return True, ''
    #end http_post

    @classmethod
    def _db_read(cls, id):
        pass
    #end _db_read

    @classmethod
    def _db_create(cls, tenant_name, obj):
        pass
    #end _db_create

#end class ConfigRootServerGen

class GlobalSystemConfigServerGen(GlobalSystemConfig):
    generate_default_instance = True

    def __init__(self):
        pass
    #end __init__

    @classmethod
    def http_get(cls, id):
        return True, ''
    #end http_get

    @classmethod
    def http_put(cls, id, obj):
        return True, ''
    #end http_put

    @classmethod
    def http_post(cls, tenant_name, obj):
        return True, ''
    #end http_post

    @classmethod
    def http_delete(cls, id, obj):
        return True, ''
    #end http_delete

    @classmethod
    def http_post_collection(cls, tenant_name, obj):
        return True, ''
    #end http_post

    @classmethod
    def _db_read(cls, id):
        pass
    #end _db_read

    @classmethod
    def _db_create(cls, tenant_name, obj):
        pass
    #end _db_create

#end class GlobalSystemConfigServerGen

class NamespaceServerGen(Namespace):
    generate_default_instance = True

    def __init__(self):
        pass
    #end __init__

    @classmethod
    def http_get(cls, id):
        return True, ''
    #end http_get

    @classmethod
    def http_put(cls, id, obj):
        return True, ''
    #end http_put

    @classmethod
    def http_post(cls, tenant_name, obj):
        return True, ''
    #end http_post

    @classmethod
    def http_delete(cls, id, obj):
        return True, ''
    #end http_delete

    @classmethod
    def http_post_collection(cls, tenant_name, obj):
        return True, ''
    #end http_post

    @classmethod
    def _db_read(cls, id):
        pass
    #end _db_read

    @classmethod
    def _db_create(cls, tenant_name, obj):
        pass
    #end _db_create

#end class NamespaceServerGen

class PhysicalInterfaceServerGen(PhysicalInterface):
    generate_default_instance = True

    def __init__(self):
        pass
    #end __init__

    @classmethod
    def http_get(cls, id):
        return True, ''
    #end http_get

    @classmethod
    def http_put(cls, id, obj):
        return True, ''
    #end http_put

    @classmethod
    def http_post(cls, tenant_name, obj):
        return True, ''
    #end http_post

    @classmethod
    def http_delete(cls, id, obj):
        return True, ''
    #end http_delete

    @classmethod
    def http_post_collection(cls, tenant_name, obj):
        return True, ''
    #end http_post

    @classmethod
    def _db_read(cls, id):
        pass
    #end _db_read

    @classmethod
    def _db_create(cls, tenant_name, obj):
        pass
    #end _db_create

#end class PhysicalInterfaceServerGen

class AccessControlListServerGen(AccessControlList):
    generate_default_instance = True

    def __init__(self):
        pass
    #end __init__

    @classmethod
    def http_get(cls, id):
        return True, ''
    #end http_get

    @classmethod
    def http_put(cls, id, obj):
        return True, ''
    #end http_put

    @classmethod
    def http_post(cls, tenant_name, obj):
        return True, ''
    #end http_post

    @classmethod
    def http_delete(cls, id, obj):
        return True, ''
    #end http_delete

    @classmethod
    def http_post_collection(cls, tenant_name, obj):
        return True, ''
    #end http_post

    @classmethod
    def _db_read(cls, id):
        pass
    #end _db_read

    @classmethod
    def _db_create(cls, tenant_name, obj):
        pass
    #end _db_create

#end class AccessControlListServerGen

class VirtualDnsServerGen(VirtualDns):
    generate_default_instance = True

    def __init__(self):
        pass
    #end __init__

    @classmethod
    def http_get(cls, id):
        return True, ''
    #end http_get

    @classmethod
    def http_put(cls, id, obj):
        return True, ''
    #end http_put

    @classmethod
    def http_post(cls, tenant_name, obj):
        return True, ''
    #end http_post

    @classmethod
    def http_delete(cls, id, obj):
        return True, ''
    #end http_delete

    @classmethod
    def http_post_collection(cls, tenant_name, obj):
        return True, ''
    #end http_post

    @classmethod
    def _db_read(cls, id):
        pass
    #end _db_read

    @classmethod
    def _db_create(cls, tenant_name, obj):
        pass
    #end _db_create

#end class VirtualDnsServerGen

class CustomerAttachmentServerGen(CustomerAttachment):
    generate_default_instance = True

    def __init__(self):
        pass
    #end __init__

    @classmethod
    def http_get(cls, id):
        return True, ''
    #end http_get

    @classmethod
    def http_put(cls, id, obj):
        return True, ''
    #end http_put

    @classmethod
    def http_post(cls, tenant_name, obj):
        return True, ''
    #end http_post

    @classmethod
    def http_delete(cls, id, obj):
        return True, ''
    #end http_delete

    @classmethod
    def http_post_collection(cls, tenant_name, obj):
        return True, ''
    #end http_post

    @classmethod
    def _db_read(cls, id):
        pass
    #end _db_read

    @classmethod
    def _db_create(cls, tenant_name, obj):
        pass
    #end _db_create

#end class CustomerAttachmentServerGen

class VirtualMachineServerGen(VirtualMachine):
    generate_default_instance = True

    def __init__(self):
        pass
    #end __init__

    @classmethod
    def http_get(cls, id):
        return True, ''
    #end http_get

    @classmethod
    def http_put(cls, id, obj):
        return True, ''
    #end http_put

    @classmethod
    def http_post(cls, tenant_name, obj):
        return True, ''
    #end http_post

    @classmethod
    def http_delete(cls, id, obj):
        return True, ''
    #end http_delete

    @classmethod
    def http_post_collection(cls, tenant_name, obj):
        return True, ''
    #end http_post

    @classmethod
    def _db_read(cls, id):
        pass
    #end _db_read

    @classmethod
    def _db_create(cls, tenant_name, obj):
        pass
    #end _db_create

#end class VirtualMachineServerGen

class ServiceTemplateServerGen(ServiceTemplate):
    generate_default_instance = True

    def __init__(self):
        pass
    #end __init__

    @classmethod
    def http_get(cls, id):
        return True, ''
    #end http_get

    @classmethod
    def http_put(cls, id, obj):
        return True, ''
    #end http_put

    @classmethod
    def http_post(cls, tenant_name, obj):
        return True, ''
    #end http_post

    @classmethod
    def http_delete(cls, id, obj):
        return True, ''
    #end http_delete

    @classmethod
    def http_post_collection(cls, tenant_name, obj):
        return True, ''
    #end http_post

    @classmethod
    def _db_read(cls, id):
        pass
    #end _db_read

    @classmethod
    def _db_create(cls, tenant_name, obj):
        pass
    #end _db_create

#end class ServiceTemplateServerGen

class SecurityGroupServerGen(SecurityGroup):
    generate_default_instance = True

    def __init__(self):
        pass
    #end __init__

    @classmethod
    def http_get(cls, id):
        return True, ''
    #end http_get

    @classmethod
    def http_put(cls, id, obj):
        return True, ''
    #end http_put

    @classmethod
    def http_post(cls, tenant_name, obj):
        return True, ''
    #end http_post

    @classmethod
    def http_delete(cls, id, obj):
        return True, ''
    #end http_delete

    @classmethod
    def http_post_collection(cls, tenant_name, obj):
        return True, ''
    #end http_post

    @classmethod
    def _db_read(cls, id):
        pass
    #end _db_read

    @classmethod
    def _db_create(cls, tenant_name, obj):
        pass
    #end _db_create

#end class SecurityGroupServerGen

class ProviderAttachmentServerGen(ProviderAttachment):
    generate_default_instance = True

    def __init__(self):
        pass
    #end __init__

    @classmethod
    def http_get(cls, id):
        return True, ''
    #end http_get

    @classmethod
    def http_put(cls, id, obj):
        return True, ''
    #end http_put

    @classmethod
    def http_post(cls, tenant_name, obj):
        return True, ''
    #end http_post

    @classmethod
    def http_delete(cls, id, obj):
        return True, ''
    #end http_delete

    @classmethod
    def http_post_collection(cls, tenant_name, obj):
        return True, ''
    #end http_post

    @classmethod
    def _db_read(cls, id):
        pass
    #end _db_read

    @classmethod
    def _db_create(cls, tenant_name, obj):
        pass
    #end _db_create

#end class ProviderAttachmentServerGen

class NetworkIpamServerGen(NetworkIpam):
    generate_default_instance = True

    def __init__(self):
        pass
    #end __init__

    @classmethod
    def http_get(cls, id):
        return True, ''
    #end http_get

    @classmethod
    def http_put(cls, id, obj):
        return True, ''
    #end http_put

    @classmethod
    def http_post(cls, tenant_name, obj):
        return True, ''
    #end http_post

    @classmethod
    def http_delete(cls, id, obj):
        return True, ''
    #end http_delete

    @classmethod
    def http_post_collection(cls, tenant_name, obj):
        return True, ''
    #end http_post

    @classmethod
    def _db_read(cls, id):
        pass
    #end _db_read

    @classmethod
    def _db_create(cls, tenant_name, obj):
        pass
    #end _db_create

#end class NetworkIpamServerGen

class VirtualNetworkServerGen(VirtualNetwork):
    generate_default_instance = True

    def __init__(self):
        pass
    #end __init__

    @classmethod
    def http_get(cls, id):
        return True, ''
    #end http_get

    @classmethod
    def http_put(cls, id, obj):
        return True, ''
    #end http_put

    @classmethod
    def http_post(cls, tenant_name, obj):
        return True, ''
    #end http_post

    @classmethod
    def http_delete(cls, id, obj):
        return True, ''
    #end http_delete

    @classmethod
    def http_post_collection(cls, tenant_name, obj):
        return True, ''
    #end http_post

    @classmethod
    def _db_read(cls, id):
        pass
    #end _db_read

    @classmethod
    def _db_create(cls, tenant_name, obj):
        pass
    #end _db_create

#end class VirtualNetworkServerGen

class ProjectServerGen(Project):
    generate_default_instance = True

    def __init__(self):
        pass
    #end __init__

    @classmethod
    def http_get(cls, id):
        return True, ''
    #end http_get

    @classmethod
    def http_put(cls, id, obj):
        return True, ''
    #end http_put

    @classmethod
    def http_post(cls, tenant_name, obj):
        return True, ''
    #end http_post

    @classmethod
    def http_delete(cls, id, obj):
        return True, ''
    #end http_delete

    @classmethod
    def http_post_collection(cls, tenant_name, obj):
        return True, ''
    #end http_post

    @classmethod
    def _db_read(cls, id):
        pass
    #end _db_read

    @classmethod
    def _db_create(cls, tenant_name, obj):
        pass
    #end _db_create

#end class ProjectServerGen

class LogicalInterfaceServerGen(LogicalInterface):
    generate_default_instance = True

    def __init__(self):
        pass
    #end __init__

    @classmethod
    def http_get(cls, id):
        return True, ''
    #end http_get

    @classmethod
    def http_put(cls, id, obj):
        return True, ''
    #end http_put

    @classmethod
    def http_post(cls, tenant_name, obj):
        return True, ''
    #end http_post

    @classmethod
    def http_delete(cls, id, obj):
        return True, ''
    #end http_delete

    @classmethod
    def http_post_collection(cls, tenant_name, obj):
        return True, ''
    #end http_post

    @classmethod
    def _db_read(cls, id):
        pass
    #end _db_read

    @classmethod
    def _db_create(cls, tenant_name, obj):
        pass
    #end _db_create

#end class LogicalInterfaceServerGen

class RoutingInstanceServerGen(RoutingInstance):
    generate_default_instance = True

    def __init__(self):
        pass
    #end __init__

    @classmethod
    def http_get(cls, id):
        return True, ''
    #end http_get

    @classmethod
    def http_put(cls, id, obj):
        return True, ''
    #end http_put

    @classmethod
    def http_post(cls, tenant_name, obj):
        return True, ''
    #end http_post

    @classmethod
    def http_delete(cls, id, obj):
        return True, ''
    #end http_delete

    @classmethod
    def http_post_collection(cls, tenant_name, obj):
        return True, ''
    #end http_post

    @classmethod
    def _db_read(cls, id):
        pass
    #end _db_read

    @classmethod
    def _db_create(cls, tenant_name, obj):
        pass
    #end _db_create

#end class RoutingInstanceServerGen

class VirtualMachineInterfaceServerGen(VirtualMachineInterface):
    generate_default_instance = True

    def __init__(self):
        pass
    #end __init__

    @classmethod
    def http_get(cls, id):
        return True, ''
    #end http_get

    @classmethod
    def http_put(cls, id, obj):
        return True, ''
    #end http_put

    @classmethod
    def http_post(cls, tenant_name, obj):
        return True, ''
    #end http_post

    @classmethod
    def http_delete(cls, id, obj):
        return True, ''
    #end http_delete

    @classmethod
    def http_post_collection(cls, tenant_name, obj):
        return True, ''
    #end http_post

    @classmethod
    def _db_read(cls, id):
        pass
    #end _db_read

    @classmethod
    def _db_create(cls, tenant_name, obj):
        pass
    #end _db_create

#end class VirtualMachineInterfaceServerGen



# AUTO-GENERATED file from IFMapApiGenerator. Do Not Edit!

import re
import json
import cStringIO
from lxml import etree

from ifmap.client import client, namespaces
from ifmap.request import NewSessionRequest, RenewSessionRequest
from ifmap.request import EndSessionRequest, PublishRequest
from ifmap.request import SearchRequest, SubscribeRequest, PurgeRequest, PollRequest
from ifmap.id import IPAddress, MACAddress, Device, AccessRequest, Identity, CustomIdentity
from ifmap.operations import PublishUpdateOperation, PublishNotifyOperation
from ifmap.operations import PublishDeleteOperation, SubscribeUpdateOperation, SubscribeDeleteOperation
from ifmap.util import attr, link_ids
from ifmap.response import Response, newSessionResult
from ifmap.metadata import Metadata

import common.imid
import common.exceptions
from resource_xsd import *

class VncIfmapClientGen(object):
    def __init__(self):
        self._db_client_mgr = None
        self._parent_metas = {}
        self._parent_metas['domain'] = {}
        self._parent_metas['domain']['project'] = 'domain-project'
        self._parent_metas['domain']['namespace'] = 'domain-namespace'
        self._parent_metas['domain']['service-template'] = 'domain-service-template'
        self._parent_metas['domain']['virtual-DNS'] = 'domain-virtual-DNS'
        self._parent_metas['service-instance'] = {}
        self._parent_metas['instance-ip'] = {}
        self._parent_metas['network-policy'] = {}
        self._parent_metas['virtual-DNS-record'] = {}
        self._parent_metas['route-target'] = {}
        self._parent_metas['floating-ip'] = {}
        self._parent_metas['floating-ip-pool'] = {}
        self._parent_metas['floating-ip-pool']['floating-ip'] = 'floating-ip-pool-floating-ip'
        self._parent_metas['physical-router'] = {}
        self._parent_metas['physical-router']['physical-interface'] = 'physical-router-physical-interface'
        self._parent_metas['bgp-router'] = {}
        self._parent_metas['virtual-router'] = {}
        self._parent_metas['config-root'] = {}
        self._parent_metas['config-root']['global-system-config'] = 'config-root-global-system-config'
        self._parent_metas['config-root']['domain'] = 'config-root-domain'
        self._parent_metas['global-system-config'] = {}
        self._parent_metas['global-system-config']['physical-router'] = 'global-system-config-physical-router'
        self._parent_metas['global-system-config']['virtual-router'] = 'global-system-config-virtual-router'
        self._parent_metas['namespace'] = {}
        self._parent_metas['physical-interface'] = {}
        self._parent_metas['physical-interface']['logical-interface'] = 'physical-interface-logical-interface'
        self._parent_metas['access-control-list'] = {}
        self._parent_metas['virtual-DNS'] = {}
        self._parent_metas['virtual-DNS']['virtual-DNS-record'] = 'virtual-DNS-virtual-DNS-record'
        self._parent_metas['customer-attachment'] = {}
        self._parent_metas['virtual-machine'] = {}
        self._parent_metas['virtual-machine']['virtual-machine-interface'] = 'virtual-machine-virtual-machine-interface'
        self._parent_metas['service-template'] = {}
        self._parent_metas['security-group'] = {}
        self._parent_metas['provider-attachment'] = {}
        self._parent_metas['network-ipam'] = {}
        self._parent_metas['virtual-network'] = {}
        self._parent_metas['virtual-network']['access-control-list'] = 'access-control-list-link'
        self._parent_metas['virtual-network']['floating-ip-pool'] = 'virtual-network-floating-ip-pool'
        self._parent_metas['virtual-network']['routing-instance'] = 'virtual-network-routing-instance'
        self._parent_metas['project'] = {}
        self._parent_metas['project']['security-group'] = 'project-security-group'
        self._parent_metas['project']['virtual-network'] = 'project-virtual-network'
        self._parent_metas['project']['network-ipam'] = 'project-network-ipam'
        self._parent_metas['project']['network-policy'] = 'project-network-policy'
        self._parent_metas['project']['service-instance'] = 'project-service-instance'
        self._parent_metas['logical-interface'] = {}
        self._parent_metas['routing-instance'] = {}
        self._parent_metas['routing-instance']['bgp-router'] = 'instance-bgp-router'
        self._parent_metas['virtual-machine-interface'] = {}
    #end __init__

    def _ifmap_domain_alloc(self, parent_type, fq_name):
        imid = self._imid_handler
        (my_imid, parent_imid) = \
            imid.domain_alloc_ifmap_id(parent_type, fq_name)
        return (True, (my_imid, parent_imid))
    #end _ifmap_domain_alloc

    def _ifmap_domain_set(self, my_imid, obj_dict):
        # Properties Meta
        field = obj_dict.get('domain_limits', None)
        if field:
            # construct object of xsd-type and get its xml repr
            field = obj_dict['domain_limits']
            buf = cStringIO.StringIO()
            # perms might be inserted at server as obj.
            # obj construction diff from dict construction.
            if isinstance(field, dict):
                DomainLimitsType(**field).exportChildren(buf, level = 1, name_ = 'domain-limits', pretty_print = False)
            else: # object
                field.exportChildren(buf, level = 1, name_ = 'domain-limits', pretty_print = False)
            domain_limits_xml = buf.getvalue()
            buf.close()
            meta = str(Metadata('domain-limits' , '',
                   {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail',
                   elements = domain_limits_xml))
            self._publish_id_self_meta(my_imid, meta)

        field = obj_dict.get('api_access_list', None)
        if field:
            # construct object of xsd-type and get its xml repr
            field = obj_dict['api_access_list']
            buf = cStringIO.StringIO()
            # perms might be inserted at server as obj.
            # obj construction diff from dict construction.
            if isinstance(field, dict):
                ApiAccessListType(**field).exportChildren(buf, level = 1, name_ = 'api-access-list', pretty_print = False)
            else: # object
                field.exportChildren(buf, level = 1, name_ = 'api-access-list', pretty_print = False)
            api_access_list_xml = buf.getvalue()
            buf.close()
            meta = str(Metadata('api-access-list' , '',
                   {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail',
                   elements = api_access_list_xml))
            self._publish_id_self_meta(my_imid, meta)

        field = obj_dict.get('id_perms', None)
        if field:
            # construct object of xsd-type and get its xml repr
            field = obj_dict['id_perms']
            buf = cStringIO.StringIO()
            # perms might be inserted at server as obj.
            # obj construction diff from dict construction.
            if isinstance(field, dict):
                IdPermsType(**field).exportChildren(buf, level = 1, name_ = 'id-perms', pretty_print = False)
            else: # object
                field.exportChildren(buf, level = 1, name_ = 'id-perms', pretty_print = False)
            id_perms_xml = buf.getvalue()
            buf.close()
            meta = str(Metadata('id-perms' , '',
                   {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail',
                   elements = id_perms_xml))
            self._publish_id_self_meta(my_imid, meta)

        # Ref Link Metas
        imid = self._imid_handler

        # construct object of xsd-type and get its xml repr
        refs = obj_dict.get('project_refs', None)
        if refs:
            for ref in refs:
                ref_fq_name = ref['to']
                obj_type = 'project'
                to_imid = common.imid.get_ifmap_id_from_fq_name(obj_type, ref_fq_name)
                domain_project_xml = ''
                meta = str(Metadata('domain-project' , '',
                       {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail',
                       elements = domain_project_xml))
                self._publish_id_pair_meta(my_imid, to_imid, meta)

        # construct object of xsd-type and get its xml repr
        refs = obj_dict.get('namespace_refs', None)
        if refs:
            for ref in refs:
                ref_fq_name = ref['to']
                obj_type = 'namespace'
                to_imid = common.imid.get_ifmap_id_from_fq_name(obj_type, ref_fq_name)
                domain_namespace_xml = ''
                meta = str(Metadata('domain-namespace' , '',
                       {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail',
                       elements = domain_namespace_xml))
                self._publish_id_pair_meta(my_imid, to_imid, meta)

        # construct object of xsd-type and get its xml repr
        refs = obj_dict.get('service_template_refs', None)
        if refs:
            for ref in refs:
                ref_fq_name = ref['to']
                obj_type = 'service-template'
                to_imid = common.imid.get_ifmap_id_from_fq_name(obj_type, ref_fq_name)
                domain_service_template_xml = ''
                meta = str(Metadata('domain-service-template' , '',
                       {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail',
                       elements = domain_service_template_xml))
                self._publish_id_pair_meta(my_imid, to_imid, meta)

        # construct object of xsd-type and get its xml repr
        refs = obj_dict.get('virtual_DNS_refs', None)
        if refs:
            for ref in refs:
                ref_fq_name = ref['to']
                obj_type = 'virtual-DNS'
                to_imid = common.imid.get_ifmap_id_from_fq_name(obj_type, ref_fq_name)
                domain_virtual_DNS_xml = ''
                meta = str(Metadata('domain-virtual-DNS' , '',
                       {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail',
                       elements = domain_virtual_DNS_xml))
                self._publish_id_pair_meta(my_imid, to_imid, meta)


        return (True, '')
    #end _ifmap_domain_set

    def _ifmap_domain_create(self, obj_ids, obj_dict):
        if not 'parent_type' in obj_dict:
            # parent is config-root
            parent_type = 'config-root'
            parent_imid = 'contrail:config-root:root'
        else:
            parent_type = obj_dict['parent_type']
            parent_imid = obj_ids.get('parent_imid', None)

        # Parent Link Meta
        parent_link_meta = self._parent_metas[parent_type]['domain']
        meta = str(Metadata(parent_link_meta, '',
                   {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail'))
        self._publish_id_pair_meta(parent_imid, obj_ids['imid'], meta)

        (ok, result) = self._ifmap_domain_set(obj_ids['imid'], obj_dict)
        return (ok, result)
    #end _ifmap_domain_create

    def _ifmap_domain_read(self, ifmap_id, field_names = None):
        # field_names = None means all fields will be read
        imid = self._imid_handler
        mapclient = self._mapclient
        start_id = str(Identity(name = ifmap_id, type = 'other',
                        other_type = 'extended'))
        # if id-perms missing, identity doesn't exist

        all_metas = [u'contrail:domain-limits', u'contrail:api-access-list', u'contrail:id-perms', u'contrail:domain-project', u'contrail:domain-namespace', u'contrail:domain-service-template', u'contrail:domain-virtual-DNS']
        if not field_names:
            metas_to_read = all_metas
        else: # read only requested fields
            req_metas = []
            if field_names.has_key('domain_limits'):
                req_metas.append('contrail:domain-limits')
            if field_names.has_key('api_access_list'):
                req_metas.append('contrail:api-access-list')
            if field_names.has_key('id_perms'):
                req_metas.append('contrail:id-perms')
            if field_names.has_key('domain_project'):
                req_metas.append('contrail:domain-project')
            if field_names.has_key('domain_namespace'):
                req_metas.append('contrail:domain-namespace')
            if field_names.has_key('domain_service_template'):
                req_metas.append('contrail:domain-service-template')
            if field_names.has_key('domain_virtual_DNS'):
                req_metas.append('contrail:domain-virtual-DNS')

            metas_to_read = set(all_metas) & set(req_metas)

        srch_meta = ' or '.join(metas_to_read)
        srch_result = self._search(start_id, srch_meta)

        result_list = self.parse_result_items(srch_result, ifmap_id)
        if (len(result_list) == 1 and 
            result_list[0][2] == None):
            return (False, 'domain ' + ifmap_id + 'does not exist')

        # metas is a dict where key is meta-name and val is list of tuples
        # of form (ident1, ident2, meta)
        metas = {}
        for r_elem in result_list:
            r_meta = r_elem[2]
            # create contrail:<tag>
            meta_name = r_meta.prefix + ':' + re.sub('{.*}', '', r_meta.tag)

            if (
                (meta_name == 'contrail:domain-limits') or
                (meta_name == 'contrail:api-access-list') or
                (meta_name == 'contrail:id-perms') or
                (meta_name == 'contrail:domain-project') or
                (meta_name == 'contrail:domain-namespace') or
                (meta_name == 'contrail:domain-service-template') or
                (meta_name == 'contrail:domain-virtual-DNS')
               ):
                if metas.has_key(meta_name):
                    metas[meta_name].append(r_elem)
                else: # first ident for this link-type
                    metas[meta_name] = [r_elem]

         # Construct dicts from xml
        result = {}
        result['_type'] = 'domain'
        fq_name = self._db_client_mgr.ifmap_id_to_fq_name(ifmap_id)
        result['fq_name'] = fq_name
        result['name'] = fq_name[-1]
        if metas.has_key('contrail:domain-limits'):
            result_elems = metas['contrail:domain-limits']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                # need to preserve type eg. int for prefix-len
                # for now, xml -> obj -> json -> dict
                # TODO TypeGenerator.py should have xml to dict method
                obj = DomainLimitsType()
                obj.build(meta)
                obj_json = ''
                obj_json = json.dumps(obj,
                    default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
                obj_val = json.loads(obj_json)
                result['domain_limits'] = obj_val

        if metas.has_key('contrail:api-access-list'):
            result_elems = metas['contrail:api-access-list']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                # need to preserve type eg. int for prefix-len
                # for now, xml -> obj -> json -> dict
                # TODO TypeGenerator.py should have xml to dict method
                obj = ApiAccessListType()
                obj.build(meta)
                obj_json = ''
                obj_json = json.dumps(obj,
                    default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
                obj_val = json.loads(obj_json)
                result['api_access_list'] = obj_val

        if metas.has_key('contrail:id-perms'):
            result_elems = metas['contrail:id-perms']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                # need to preserve type eg. int for prefix-len
                # for now, xml -> obj -> json -> dict
                # TODO TypeGenerator.py should have xml to dict method
                obj = IdPermsType()
                obj.build(meta)
                obj_json = ''
                obj_json = json.dumps(obj,
                    default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
                obj_val = json.loads(obj_json)
                result['id_perms'] = obj_val

        if metas.has_key('contrail:domain-project'):
            result['projects'] = []
            result_elems = metas['contrail:domain-project']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                obj_val = {}
                has_ifmap_id = r_elem[1].attrib['name']

                try:
                    has_fq_name = self._db_client_mgr.ifmap_id_to_fq_name(has_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown fq_name for child ' + has_ifmap_id
                    return (False, err_msg)
                try:
                    has_uuid = self._db_client_mgr.ifmap_id_to_uuid(has_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown uuid for child ' + has_ifmap_id
                    return (False, err_msg)

                has_url = self._db_client_mgr.generate_url('project', has_uuid)
                has_info = {}
                has_info['to'] = has_fq_name
                has_info['attr'] = obj_val
                has_info['href'] = has_url
                has_info['uuid'] = has_uuid
                result['projects'].append(has_info)


        if metas.has_key('contrail:domain-namespace'):
            result['namespaces'] = []
            result_elems = metas['contrail:domain-namespace']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                obj_val = {}
                has_ifmap_id = r_elem[1].attrib['name']

                try:
                    has_fq_name = self._db_client_mgr.ifmap_id_to_fq_name(has_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown fq_name for child ' + has_ifmap_id
                    return (False, err_msg)
                try:
                    has_uuid = self._db_client_mgr.ifmap_id_to_uuid(has_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown uuid for child ' + has_ifmap_id
                    return (False, err_msg)

                has_url = self._db_client_mgr.generate_url('namespace', has_uuid)
                has_info = {}
                has_info['to'] = has_fq_name
                has_info['attr'] = obj_val
                has_info['href'] = has_url
                has_info['uuid'] = has_uuid
                result['namespaces'].append(has_info)


        if metas.has_key('contrail:domain-service-template'):
            result['service_templates'] = []
            result_elems = metas['contrail:domain-service-template']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                obj_val = {}
                has_ifmap_id = r_elem[1].attrib['name']

                try:
                    has_fq_name = self._db_client_mgr.ifmap_id_to_fq_name(has_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown fq_name for child ' + has_ifmap_id
                    return (False, err_msg)
                try:
                    has_uuid = self._db_client_mgr.ifmap_id_to_uuid(has_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown uuid for child ' + has_ifmap_id
                    return (False, err_msg)

                has_url = self._db_client_mgr.generate_url('service_template', has_uuid)
                has_info = {}
                has_info['to'] = has_fq_name
                has_info['attr'] = obj_val
                has_info['href'] = has_url
                has_info['uuid'] = has_uuid
                result['service_templates'].append(has_info)


        if metas.has_key('contrail:domain-virtual-DNS'):
            result['virtual_DNSs'] = []
            result_elems = metas['contrail:domain-virtual-DNS']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                obj_val = {}
                has_ifmap_id = r_elem[1].attrib['name']

                try:
                    has_fq_name = self._db_client_mgr.ifmap_id_to_fq_name(has_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown fq_name for child ' + has_ifmap_id
                    return (False, err_msg)
                try:
                    has_uuid = self._db_client_mgr.ifmap_id_to_uuid(has_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown uuid for child ' + has_ifmap_id
                    return (False, err_msg)

                has_url = self._db_client_mgr.generate_url('virtual_DNS', has_uuid)
                has_info = {}
                has_info['to'] = has_fq_name
                has_info['attr'] = obj_val
                has_info['href'] = has_url
                has_info['uuid'] = has_uuid
                result['virtual_DNSs'].append(has_info)


        return (True, result)
    #end _ifmap_domain_read

    def _ifmap_domain_update(self, ifmap_id, old_obj_dict, new_obj_dict):
        # remove properties that are no longer active
        if ('domain_limits' in new_obj_dict) and (new_obj_dict['domain_limits'] == None):
            self._delete_id_self_meta(ifmap_id, 'domain-limits')

        if ('api_access_list' in new_obj_dict) and (new_obj_dict['api_access_list'] == None):
            self._delete_id_self_meta(ifmap_id, 'api-access-list')

        if ('id_perms' in new_obj_dict) and (new_obj_dict['id_perms'] == None):
            self._delete_id_self_meta(ifmap_id, 'id-perms')

        # remove refs that are no longer active
        (ok, result) = self._ifmap_domain_set(ifmap_id, new_obj_dict)
        return (ok, result)
    #end _ifmap_domain_update

    def _ifmap_domain_list(self, parent_type, parent_fq_name):
        children_fq_names = []
        mapclient = self._mapclient
        parent_imid = common.imid.get_ifmap_id_from_fq_name(parent_type, parent_fq_name)
        start_id = str(Identity(name = parent_imid, type = 'other',
                        other_type = 'extended'))
        # if id-perms missing, identity doesn't exist
        parent_link_meta = self._parent_metas[parent_type]['domain']
        srch_meta = 'contrail:' + parent_link_meta
        srch_result = self._search(start_id, srch_meta)

        result_list = self.parse_result_items(srch_result, parent_imid)
        for r_elem in result_list:
            child_ident = r_elem[1]
            if child_ident is None:
                continue
            child_imid = child_ident.attrib['name']
            fq_name = self._db_client_mgr.ifmap_id_to_fq_name(child_imid)
            children_fq_names.append(fq_name)


        return (True, children_fq_names)
    #end _ifmap_domain_list

    def _ifmap_domain_delete(self, obj_ids):
        ifmap_id = obj_ids['imid']
        parent_imid = obj_ids.get('parent_imid', None)
        start_id = str(Identity(name = ifmap_id, type = 'other',
                        other_type = 'extended'))

        if parent_imid:
            # Remove link from parent
            self._delete_id_pair_meta(parent_imid, ifmap_id, None)

        # Remove all property metadata associated with this ident
        self._delete_id_self_meta(ifmap_id, None)

        return (True, '')
    #end _ifmap_domain_delete

    def _ifmap_service_instance_alloc(self, parent_type, fq_name):
        imid = self._imid_handler
        (my_imid, parent_imid) = \
            imid.service_instance_alloc_ifmap_id(parent_type, fq_name)
        return (True, (my_imid, parent_imid))
    #end _ifmap_service_instance_alloc

    def _ifmap_service_instance_set(self, my_imid, obj_dict):
        # Properties Meta
        field = obj_dict.get('service_instance_properties', None)
        if field:
            # construct object of xsd-type and get its xml repr
            field = obj_dict['service_instance_properties']
            buf = cStringIO.StringIO()
            # perms might be inserted at server as obj.
            # obj construction diff from dict construction.
            if isinstance(field, dict):
                ServiceInstanceType(**field).exportChildren(buf, level = 1, name_ = 'service-instance-properties', pretty_print = False)
            else: # object
                field.exportChildren(buf, level = 1, name_ = 'service-instance-properties', pretty_print = False)
            service_instance_properties_xml = buf.getvalue()
            buf.close()
            meta = str(Metadata('service-instance-properties' , '',
                   {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail',
                   elements = service_instance_properties_xml))
            self._publish_id_self_meta(my_imid, meta)

        field = obj_dict.get('id_perms', None)
        if field:
            # construct object of xsd-type and get its xml repr
            field = obj_dict['id_perms']
            buf = cStringIO.StringIO()
            # perms might be inserted at server as obj.
            # obj construction diff from dict construction.
            if isinstance(field, dict):
                IdPermsType(**field).exportChildren(buf, level = 1, name_ = 'id-perms', pretty_print = False)
            else: # object
                field.exportChildren(buf, level = 1, name_ = 'id-perms', pretty_print = False)
            id_perms_xml = buf.getvalue()
            buf.close()
            meta = str(Metadata('id-perms' , '',
                   {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail',
                   elements = id_perms_xml))
            self._publish_id_self_meta(my_imid, meta)

        # Ref Link Metas
        imid = self._imid_handler

        # construct object of xsd-type and get its xml repr
        refs = obj_dict.get('service_template_refs', None)
        if refs:
            for ref in refs:
                ref_fq_name = ref['to']
                obj_type = 'service-template'
                to_imid = common.imid.get_ifmap_id_from_fq_name(obj_type, ref_fq_name)
                service_instance_service_template_xml = ''
                meta = str(Metadata('service-instance-service-template' , '',
                       {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail',
                       elements = service_instance_service_template_xml))
                self._publish_id_pair_meta(my_imid, to_imid, meta)


        return (True, '')
    #end _ifmap_service_instance_set

    def _ifmap_service_instance_create(self, obj_ids, obj_dict):
        if not 'parent_type' in obj_dict:
            # parent is config-root
            parent_type = 'config-root'
            parent_imid = 'contrail:config-root:root'
        else:
            parent_type = obj_dict['parent_type']
            parent_imid = obj_ids.get('parent_imid', None)

        # Parent Link Meta
        parent_link_meta = self._parent_metas[parent_type]['service-instance']
        meta = str(Metadata(parent_link_meta, '',
                   {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail'))
        self._publish_id_pair_meta(parent_imid, obj_ids['imid'], meta)

        (ok, result) = self._ifmap_service_instance_set(obj_ids['imid'], obj_dict)
        return (ok, result)
    #end _ifmap_service_instance_create

    def _ifmap_service_instance_read(self, ifmap_id, field_names = None):
        # field_names = None means all fields will be read
        imid = self._imid_handler
        mapclient = self._mapclient
        start_id = str(Identity(name = ifmap_id, type = 'other',
                        other_type = 'extended'))
        # if id-perms missing, identity doesn't exist

        all_metas = [u'contrail:service-instance-service-template', u'contrail:virtual-machine-service-instance', u'contrail:service-instance-properties', u'contrail:id-perms']
        if not field_names:
            metas_to_read = all_metas
        else: # read only requested fields
            req_metas = []
            if field_names.has_key('service_template_refs'):
                req_metas.append('contrail:service-instance-service-template')
            if field_names.has_key('virtual_machine_back_refs'):
                req_metas.append('contrail:virtual-machine-service-instance')
            if field_names.has_key('service_instance_properties'):
                req_metas.append('contrail:service-instance-properties')
            if field_names.has_key('id_perms'):
                req_metas.append('contrail:id-perms')

            metas_to_read = set(all_metas) & set(req_metas)

        srch_meta = ' or '.join(metas_to_read)
        srch_result = self._search(start_id, srch_meta)

        result_list = self.parse_result_items(srch_result, ifmap_id)
        if (len(result_list) == 1 and 
            result_list[0][2] == None):
            return (False, 'service-instance ' + ifmap_id + 'does not exist')

        # metas is a dict where key is meta-name and val is list of tuples
        # of form (ident1, ident2, meta)
        metas = {}
        for r_elem in result_list:
            r_meta = r_elem[2]
            # create contrail:<tag>
            meta_name = r_meta.prefix + ':' + re.sub('{.*}', '', r_meta.tag)

            if (
                (meta_name == 'contrail:service-instance-service-template') or
                (meta_name == 'contrail:virtual-machine-service-instance') or
                (meta_name == 'contrail:service-instance-properties') or
                (meta_name == 'contrail:id-perms')
               ):
                if metas.has_key(meta_name):
                    metas[meta_name].append(r_elem)
                else: # first ident for this link-type
                    metas[meta_name] = [r_elem]

         # Construct dicts from xml
        result = {}
        result['_type'] = 'service-instance'
        fq_name = self._db_client_mgr.ifmap_id_to_fq_name(ifmap_id)
        result['fq_name'] = fq_name
        result['name'] = fq_name[-1]
        if metas.has_key('contrail:service-instance-service-template'):
            result['service_template_refs'] = []
            result_elems = metas['contrail:service-instance-service-template']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                obj_val = {}
                # in case of refs between same types of identifiers,
                # the referred ident could appears at idx 0 or 1
                if ifmap_id == r_elem[0].attrib['name']:
                    ref_ifmap_id = r_elem[1].attrib['name']
                else:
                    ref_ifmap_id = r_elem[0].attrib['name']

                try:
                    ref_fq_name = self._db_client_mgr.ifmap_id_to_fq_name(ref_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown fq_name for ref ' + ref_ifmap_id
                    return (False, err_msg)
                try:
                    ref_uuid = self._db_client_mgr.ifmap_id_to_uuid(ref_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown uuid for ref ' + ref_ifmap_id
                    return (False, err_msg)

                ref_url = self._db_client_mgr.generate_url('service_template', ref_uuid)
                ref_info = {}
                ref_info['to'] = ref_fq_name
                ref_info['attr'] = obj_val
                ref_info['href'] = ref_url
                ref_info['uuid'] = ref_uuid
                result['service_template_refs'].append(ref_info)


        if metas.has_key('contrail:virtual-machine-service-instance'):
            result['virtual_machine_back_refs'] = []
            result_elems = metas['contrail:virtual-machine-service-instance']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                obj_val = {}
                back_ref_ifmap_id = r_elem[0].attrib['name']

                try:
                    back_ref_fq_name = self._db_client_mgr.ifmap_id_to_fq_name(back_ref_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown fq_name for backref ' + back_ref_ifmap_id
                    return (False, err_msg)
                try:
                    back_ref_uuid = self._db_client_mgr.ifmap_id_to_uuid(back_ref_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown uuid for backref ' + back_ref_ifmap_id
                    return (False, err_msg)

                back_ref_url = self._db_client_mgr.generate_url('virtual_machine', back_ref_uuid)
                back_ref_info = {}
                back_ref_info['to'] = back_ref_fq_name
                back_ref_info['attr'] = obj_val
                back_ref_info['href'] = back_ref_url
                back_ref_info['uuid'] = back_ref_uuid
                result['virtual_machine_back_refs'].append(back_ref_info)


        if metas.has_key('contrail:service-instance-properties'):
            result_elems = metas['contrail:service-instance-properties']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                # need to preserve type eg. int for prefix-len
                # for now, xml -> obj -> json -> dict
                # TODO TypeGenerator.py should have xml to dict method
                obj = ServiceInstanceType()
                obj.build(meta)
                obj_json = ''
                obj_json = json.dumps(obj,
                    default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
                obj_val = json.loads(obj_json)
                result['service_instance_properties'] = obj_val

        if metas.has_key('contrail:id-perms'):
            result_elems = metas['contrail:id-perms']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                # need to preserve type eg. int for prefix-len
                # for now, xml -> obj -> json -> dict
                # TODO TypeGenerator.py should have xml to dict method
                obj = IdPermsType()
                obj.build(meta)
                obj_json = ''
                obj_json = json.dumps(obj,
                    default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
                obj_val = json.loads(obj_json)
                result['id_perms'] = obj_val

        return (True, result)
    #end _ifmap_service_instance_read

    def _ifmap_service_instance_update(self, ifmap_id, old_obj_dict, new_obj_dict):
        # remove properties that are no longer active
        if ('service_instance_properties' in new_obj_dict) and (new_obj_dict['service_instance_properties'] == None):
            self._delete_id_self_meta(ifmap_id, 'service-instance-properties')

        if ('id_perms' in new_obj_dict) and (new_obj_dict['id_perms'] == None):
            self._delete_id_self_meta(ifmap_id, 'id-perms')

        # remove refs that are no longer active
        if ('service_template_refs' in old_obj_dict):
            old_refs = [tuple(ref['to']) for ref in old_obj_dict['service_template_refs']]
        else:
            old_refs = []
        if ('service_template_refs' in new_obj_dict):
            if new_obj_dict['service_template_refs'] == None:
                new_refs = []
            else:
                new_refs = [tuple(ref['to']) for ref in new_obj_dict['service_template_refs']]
        else: # no ref key in new_obj
            new_refs = old_refs

        old_set = set(old_refs)
        new_set = set(new_refs)
        inact_refs = old_set - new_set
        for inact_ref in inact_refs:
            to_imid = self.fq_name_to_ifmap_id('service-template', inact_ref)
            self._delete_id_pair_meta(ifmap_id, to_imid, 'contrail:service-instance-service-template')

        (ok, result) = self._ifmap_service_instance_set(ifmap_id, new_obj_dict)
        return (ok, result)
    #end _ifmap_service_instance_update

    def _ifmap_service_instance_list(self, parent_type, parent_fq_name):
        children_fq_names = []
        mapclient = self._mapclient
        parent_imid = common.imid.get_ifmap_id_from_fq_name(parent_type, parent_fq_name)
        start_id = str(Identity(name = parent_imid, type = 'other',
                        other_type = 'extended'))
        # if id-perms missing, identity doesn't exist
        parent_link_meta = self._parent_metas[parent_type]['service-instance']
        srch_meta = 'contrail:' + parent_link_meta
        srch_result = self._search(start_id, srch_meta)

        result_list = self.parse_result_items(srch_result, parent_imid)
        for r_elem in result_list:
            child_ident = r_elem[1]
            if child_ident is None:
                continue
            child_imid = child_ident.attrib['name']
            fq_name = self._db_client_mgr.ifmap_id_to_fq_name(child_imid)
            children_fq_names.append(fq_name)


        return (True, children_fq_names)
    #end _ifmap_service_instance_list

    def _ifmap_service_instance_delete(self, obj_ids):
        ifmap_id = obj_ids['imid']
        parent_imid = obj_ids.get('parent_imid', None)
        start_id = str(Identity(name = ifmap_id, type = 'other',
                        other_type = 'extended'))
        # Delete links to our references, first find them
        srch_meta = ' or '.join([u'contrail:service-instance-service-template'])
        srch_result = self._search(start_id, srch_meta)

        result_list = self.parse_result_items(srch_result, ifmap_id)
        for r_elem in result_list:
            to_ident = r_elem[1]
            if to_ident is None:
                continue
            to_imid = to_ident.attrib['name']
            r_meta = r_elem[2]
            # create contrail:<tag>
            meta_name = r_meta.prefix + ':' + re.sub('{.*}', '', r_meta.tag)
            self._delete_id_pair_meta(ifmap_id, to_imid, meta_name)


        if parent_imid:
            # Remove link from parent
            self._delete_id_pair_meta(parent_imid, ifmap_id, None)

        # Remove all property metadata associated with this ident
        self._delete_id_self_meta(ifmap_id, None)

        return (True, '')
    #end _ifmap_service_instance_delete

    def _ifmap_instance_ip_alloc(self, parent_type, fq_name):
        imid = self._imid_handler
        (my_imid, parent_imid) = \
            imid.instance_ip_alloc_ifmap_id(parent_type, fq_name)
        return (True, (my_imid, parent_imid))
    #end _ifmap_instance_ip_alloc

    def _ifmap_instance_ip_set(self, my_imid, obj_dict):
        # Properties Meta
        field = obj_dict.get('instance_ip_address', None)
        if field:
            meta = str(Metadata('instance-ip-address' , str(obj_dict['instance_ip_address']),
                   {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail'))
            self._publish_id_self_meta(my_imid, meta)

        field = obj_dict.get('id_perms', None)
        if field:
            # construct object of xsd-type and get its xml repr
            field = obj_dict['id_perms']
            buf = cStringIO.StringIO()
            # perms might be inserted at server as obj.
            # obj construction diff from dict construction.
            if isinstance(field, dict):
                IdPermsType(**field).exportChildren(buf, level = 1, name_ = 'id-perms', pretty_print = False)
            else: # object
                field.exportChildren(buf, level = 1, name_ = 'id-perms', pretty_print = False)
            id_perms_xml = buf.getvalue()
            buf.close()
            meta = str(Metadata('id-perms' , '',
                   {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail',
                   elements = id_perms_xml))
            self._publish_id_self_meta(my_imid, meta)

        # Ref Link Metas
        imid = self._imid_handler

        # construct object of xsd-type and get its xml repr
        refs = obj_dict.get('virtual_network_refs', None)
        if refs:
            for ref in refs:
                ref_fq_name = ref['to']
                obj_type = 'virtual-network'
                to_imid = common.imid.get_ifmap_id_from_fq_name(obj_type, ref_fq_name)
                instance_ip_virtual_network_xml = ''
                meta = str(Metadata('instance-ip-virtual-network' , '',
                       {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail',
                       elements = instance_ip_virtual_network_xml))
                self._publish_id_pair_meta(my_imid, to_imid, meta)

        # construct object of xsd-type and get its xml repr
        refs = obj_dict.get('virtual_machine_interface_refs', None)
        if refs:
            for ref in refs:
                ref_fq_name = ref['to']
                obj_type = 'virtual-machine-interface'
                to_imid = common.imid.get_ifmap_id_from_fq_name(obj_type, ref_fq_name)
                instance_ip_virtual_machine_interface_xml = ''
                meta = str(Metadata('instance-ip-virtual-machine-interface' , '',
                       {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail',
                       elements = instance_ip_virtual_machine_interface_xml))
                self._publish_id_pair_meta(my_imid, to_imid, meta)


        return (True, '')
    #end _ifmap_instance_ip_set

    def _ifmap_instance_ip_create(self, obj_ids, obj_dict):
        (ok, result) = self._ifmap_instance_ip_set(obj_ids['imid'], obj_dict)
        return (ok, result)
    #end _ifmap_instance_ip_create

    def _ifmap_instance_ip_read(self, ifmap_id, field_names = None):
        # field_names = None means all fields will be read
        imid = self._imid_handler
        mapclient = self._mapclient
        start_id = str(Identity(name = ifmap_id, type = 'other',
                        other_type = 'extended'))
        # if id-perms missing, identity doesn't exist

        all_metas = [u'contrail:instance-ip-virtual-network', u'contrail:instance-ip-virtual-machine-interface', u'contrail:instance-ip-address', u'contrail:id-perms']
        if not field_names:
            metas_to_read = all_metas
        else: # read only requested fields
            req_metas = []
            if field_names.has_key('virtual_network_refs'):
                req_metas.append('contrail:instance-ip-virtual-network')
            if field_names.has_key('virtual_machine_interface_refs'):
                req_metas.append('contrail:instance-ip-virtual-machine-interface')
            if field_names.has_key('instance_ip_address'):
                req_metas.append('contrail:instance-ip-address')
            if field_names.has_key('id_perms'):
                req_metas.append('contrail:id-perms')

            metas_to_read = set(all_metas) & set(req_metas)

        srch_meta = ' or '.join(metas_to_read)
        srch_result = self._search(start_id, srch_meta)

        result_list = self.parse_result_items(srch_result, ifmap_id)
        if (len(result_list) == 1 and 
            result_list[0][2] == None):
            return (False, 'instance-ip ' + ifmap_id + 'does not exist')

        # metas is a dict where key is meta-name and val is list of tuples
        # of form (ident1, ident2, meta)
        metas = {}
        for r_elem in result_list:
            r_meta = r_elem[2]
            # create contrail:<tag>
            meta_name = r_meta.prefix + ':' + re.sub('{.*}', '', r_meta.tag)

            if (
                (meta_name == 'contrail:instance-ip-virtual-network') or
                (meta_name == 'contrail:instance-ip-virtual-machine-interface') or
                (meta_name == 'contrail:instance-ip-address') or
                (meta_name == 'contrail:id-perms')
               ):
                if metas.has_key(meta_name):
                    metas[meta_name].append(r_elem)
                else: # first ident for this link-type
                    metas[meta_name] = [r_elem]

         # Construct dicts from xml
        result = {}
        result['_type'] = 'instance-ip'
        fq_name = self._db_client_mgr.ifmap_id_to_fq_name(ifmap_id)
        result['fq_name'] = fq_name
        result['name'] = fq_name[-1]
        if metas.has_key('contrail:instance-ip-virtual-network'):
            result['virtual_network_refs'] = []
            result_elems = metas['contrail:instance-ip-virtual-network']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                obj_val = {}
                # in case of refs between same types of identifiers,
                # the referred ident could appears at idx 0 or 1
                if ifmap_id == r_elem[0].attrib['name']:
                    ref_ifmap_id = r_elem[1].attrib['name']
                else:
                    ref_ifmap_id = r_elem[0].attrib['name']

                try:
                    ref_fq_name = self._db_client_mgr.ifmap_id_to_fq_name(ref_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown fq_name for ref ' + ref_ifmap_id
                    return (False, err_msg)
                try:
                    ref_uuid = self._db_client_mgr.ifmap_id_to_uuid(ref_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown uuid for ref ' + ref_ifmap_id
                    return (False, err_msg)

                ref_url = self._db_client_mgr.generate_url('virtual_network', ref_uuid)
                ref_info = {}
                ref_info['to'] = ref_fq_name
                ref_info['attr'] = obj_val
                ref_info['href'] = ref_url
                ref_info['uuid'] = ref_uuid
                result['virtual_network_refs'].append(ref_info)


        if metas.has_key('contrail:instance-ip-virtual-machine-interface'):
            result['virtual_machine_interface_refs'] = []
            result_elems = metas['contrail:instance-ip-virtual-machine-interface']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                obj_val = {}
                # in case of refs between same types of identifiers,
                # the referred ident could appears at idx 0 or 1
                if ifmap_id == r_elem[0].attrib['name']:
                    ref_ifmap_id = r_elem[1].attrib['name']
                else:
                    ref_ifmap_id = r_elem[0].attrib['name']

                try:
                    ref_fq_name = self._db_client_mgr.ifmap_id_to_fq_name(ref_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown fq_name for ref ' + ref_ifmap_id
                    return (False, err_msg)
                try:
                    ref_uuid = self._db_client_mgr.ifmap_id_to_uuid(ref_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown uuid for ref ' + ref_ifmap_id
                    return (False, err_msg)

                ref_url = self._db_client_mgr.generate_url('virtual_machine_interface', ref_uuid)
                ref_info = {}
                ref_info['to'] = ref_fq_name
                ref_info['attr'] = obj_val
                ref_info['href'] = ref_url
                ref_info['uuid'] = ref_uuid
                result['virtual_machine_interface_refs'].append(ref_info)


        if metas.has_key('contrail:instance-ip-address'):
            result_elems = metas['contrail:instance-ip-address']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                obj_val = meta.text
                result['instance_ip_address'] = obj_val

        if metas.has_key('contrail:id-perms'):
            result_elems = metas['contrail:id-perms']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                # need to preserve type eg. int for prefix-len
                # for now, xml -> obj -> json -> dict
                # TODO TypeGenerator.py should have xml to dict method
                obj = IdPermsType()
                obj.build(meta)
                obj_json = ''
                obj_json = json.dumps(obj,
                    default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
                obj_val = json.loads(obj_json)
                result['id_perms'] = obj_val

        return (True, result)
    #end _ifmap_instance_ip_read

    def _ifmap_instance_ip_update(self, ifmap_id, old_obj_dict, new_obj_dict):
        # remove properties that are no longer active
        if ('instance_ip_address' in new_obj_dict) and (new_obj_dict['instance_ip_address'] == None):
            self._delete_id_self_meta(ifmap_id, 'instance-ip-address')

        if ('id_perms' in new_obj_dict) and (new_obj_dict['id_perms'] == None):
            self._delete_id_self_meta(ifmap_id, 'id-perms')

        # remove refs that are no longer active
        if ('virtual_network_refs' in old_obj_dict):
            old_refs = [tuple(ref['to']) for ref in old_obj_dict['virtual_network_refs']]
        else:
            old_refs = []
        if ('virtual_network_refs' in new_obj_dict):
            if new_obj_dict['virtual_network_refs'] == None:
                new_refs = []
            else:
                new_refs = [tuple(ref['to']) for ref in new_obj_dict['virtual_network_refs']]
        else: # no ref key in new_obj
            new_refs = old_refs

        old_set = set(old_refs)
        new_set = set(new_refs)
        inact_refs = old_set - new_set
        for inact_ref in inact_refs:
            to_imid = self.fq_name_to_ifmap_id('virtual-network', inact_ref)
            self._delete_id_pair_meta(ifmap_id, to_imid, 'contrail:instance-ip-virtual-network')

        if ('virtual_machine_interface_refs' in old_obj_dict):
            old_refs = [tuple(ref['to']) for ref in old_obj_dict['virtual_machine_interface_refs']]
        else:
            old_refs = []
        if ('virtual_machine_interface_refs' in new_obj_dict):
            if new_obj_dict['virtual_machine_interface_refs'] == None:
                new_refs = []
            else:
                new_refs = [tuple(ref['to']) for ref in new_obj_dict['virtual_machine_interface_refs']]
        else: # no ref key in new_obj
            new_refs = old_refs

        old_set = set(old_refs)
        new_set = set(new_refs)
        inact_refs = old_set - new_set
        for inact_ref in inact_refs:
            to_imid = self.fq_name_to_ifmap_id('virtual-machine-interface', inact_ref)
            self._delete_id_pair_meta(ifmap_id, to_imid, 'contrail:instance-ip-virtual-machine-interface')

        (ok, result) = self._ifmap_instance_ip_set(ifmap_id, new_obj_dict)
        return (ok, result)
    #end _ifmap_instance_ip_update

    def _ifmap_instance_ip_list(self, parent_type, parent_fq_name):
        children_fq_names = []
        return (True, children_fq_names)
    #end _ifmap_instance_ip_list

    def _ifmap_instance_ip_delete(self, obj_ids):
        ifmap_id = obj_ids['imid']
        parent_imid = obj_ids.get('parent_imid', None)
        start_id = str(Identity(name = ifmap_id, type = 'other',
                        other_type = 'extended'))
        # Delete links to our references, first find them
        srch_meta = ' or '.join([u'contrail:instance-ip-virtual-network', u'contrail:instance-ip-virtual-machine-interface'])
        srch_result = self._search(start_id, srch_meta)

        result_list = self.parse_result_items(srch_result, ifmap_id)
        for r_elem in result_list:
            to_ident = r_elem[1]
            if to_ident is None:
                continue
            to_imid = to_ident.attrib['name']
            r_meta = r_elem[2]
            # create contrail:<tag>
            meta_name = r_meta.prefix + ':' + re.sub('{.*}', '', r_meta.tag)
            self._delete_id_pair_meta(ifmap_id, to_imid, meta_name)


        if parent_imid:
            # Remove link from parent
            self._delete_id_pair_meta(parent_imid, ifmap_id, None)

        # Remove all property metadata associated with this ident
        self._delete_id_self_meta(ifmap_id, None)

        return (True, '')
    #end _ifmap_instance_ip_delete

    def _ifmap_network_policy_alloc(self, parent_type, fq_name):
        imid = self._imid_handler
        (my_imid, parent_imid) = \
            imid.network_policy_alloc_ifmap_id(parent_type, fq_name)
        return (True, (my_imid, parent_imid))
    #end _ifmap_network_policy_alloc

    def _ifmap_network_policy_set(self, my_imid, obj_dict):
        # Properties Meta
        field = obj_dict.get('network_policy_entries', None)
        if field:
            # construct object of xsd-type and get its xml repr
            field = obj_dict['network_policy_entries']
            buf = cStringIO.StringIO()
            # perms might be inserted at server as obj.
            # obj construction diff from dict construction.
            if isinstance(field, dict):
                PolicyEntriesType(**field).exportChildren(buf, level = 1, name_ = 'network-policy-entries', pretty_print = False)
            else: # object
                field.exportChildren(buf, level = 1, name_ = 'network-policy-entries', pretty_print = False)
            network_policy_entries_xml = buf.getvalue()
            buf.close()
            meta = str(Metadata('network-policy-entries' , '',
                   {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail',
                   elements = network_policy_entries_xml))
            self._publish_id_self_meta(my_imid, meta)

        field = obj_dict.get('id_perms', None)
        if field:
            # construct object of xsd-type and get its xml repr
            field = obj_dict['id_perms']
            buf = cStringIO.StringIO()
            # perms might be inserted at server as obj.
            # obj construction diff from dict construction.
            if isinstance(field, dict):
                IdPermsType(**field).exportChildren(buf, level = 1, name_ = 'id-perms', pretty_print = False)
            else: # object
                field.exportChildren(buf, level = 1, name_ = 'id-perms', pretty_print = False)
            id_perms_xml = buf.getvalue()
            buf.close()
            meta = str(Metadata('id-perms' , '',
                   {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail',
                   elements = id_perms_xml))
            self._publish_id_self_meta(my_imid, meta)

        # Ref Link Metas
        imid = self._imid_handler


        return (True, '')
    #end _ifmap_network_policy_set

    def _ifmap_network_policy_create(self, obj_ids, obj_dict):
        if not 'parent_type' in obj_dict:
            # parent is config-root
            parent_type = 'config-root'
            parent_imid = 'contrail:config-root:root'
        else:
            parent_type = obj_dict['parent_type']
            parent_imid = obj_ids.get('parent_imid', None)

        # Parent Link Meta
        parent_link_meta = self._parent_metas[parent_type]['network-policy']
        meta = str(Metadata(parent_link_meta, '',
                   {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail'))
        self._publish_id_pair_meta(parent_imid, obj_ids['imid'], meta)

        (ok, result) = self._ifmap_network_policy_set(obj_ids['imid'], obj_dict)
        return (ok, result)
    #end _ifmap_network_policy_create

    def _ifmap_network_policy_read(self, ifmap_id, field_names = None):
        # field_names = None means all fields will be read
        imid = self._imid_handler
        mapclient = self._mapclient
        start_id = str(Identity(name = ifmap_id, type = 'other',
                        other_type = 'extended'))
        # if id-perms missing, identity doesn't exist

        all_metas = [u'contrail:virtual-network-network-policy', u'contrail:network-policy-entries', u'contrail:id-perms']
        if not field_names:
            metas_to_read = all_metas
        else: # read only requested fields
            req_metas = []
            if field_names.has_key('virtual_network_back_refs'):
                req_metas.append('contrail:virtual-network-network-policy')
            if field_names.has_key('network_policy_entries'):
                req_metas.append('contrail:network-policy-entries')
            if field_names.has_key('id_perms'):
                req_metas.append('contrail:id-perms')

            metas_to_read = set(all_metas) & set(req_metas)

        srch_meta = ' or '.join(metas_to_read)
        srch_result = self._search(start_id, srch_meta)

        result_list = self.parse_result_items(srch_result, ifmap_id)
        if (len(result_list) == 1 and 
            result_list[0][2] == None):
            return (False, 'network-policy ' + ifmap_id + 'does not exist')

        # metas is a dict where key is meta-name and val is list of tuples
        # of form (ident1, ident2, meta)
        metas = {}
        for r_elem in result_list:
            r_meta = r_elem[2]
            # create contrail:<tag>
            meta_name = r_meta.prefix + ':' + re.sub('{.*}', '', r_meta.tag)

            if (
                (meta_name == 'contrail:virtual-network-network-policy') or
                (meta_name == 'contrail:network-policy-entries') or
                (meta_name == 'contrail:id-perms')
               ):
                if metas.has_key(meta_name):
                    metas[meta_name].append(r_elem)
                else: # first ident for this link-type
                    metas[meta_name] = [r_elem]

         # Construct dicts from xml
        result = {}
        result['_type'] = 'network-policy'
        fq_name = self._db_client_mgr.ifmap_id_to_fq_name(ifmap_id)
        result['fq_name'] = fq_name
        result['name'] = fq_name[-1]
        if metas.has_key('contrail:virtual-network-network-policy'):
            result['virtual_network_back_refs'] = []
            result_elems = metas['contrail:virtual-network-network-policy']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                # need to preserve type eg. int for prefix-len
                # for now, xml -> obj -> json -> dict
                # TODO TypeGenerator.py should have xml to dict method
                obj = VirtualNetworkPolicyType()
                obj.build(meta)
                obj_json = ''
                obj_json = json.dumps(obj,
                    default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
                obj_val = json.loads(obj_json)
                back_ref_ifmap_id = r_elem[0].attrib['name']

                try:
                    back_ref_fq_name = self._db_client_mgr.ifmap_id_to_fq_name(back_ref_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown fq_name for backref ' + back_ref_ifmap_id
                    return (False, err_msg)
                try:
                    back_ref_uuid = self._db_client_mgr.ifmap_id_to_uuid(back_ref_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown uuid for backref ' + back_ref_ifmap_id
                    return (False, err_msg)

                back_ref_url = self._db_client_mgr.generate_url('virtual_network', back_ref_uuid)
                back_ref_info = {}
                back_ref_info['to'] = back_ref_fq_name
                back_ref_info['attr'] = obj_val
                back_ref_info['href'] = back_ref_url
                back_ref_info['uuid'] = back_ref_uuid
                result['virtual_network_back_refs'].append(back_ref_info)


        if metas.has_key('contrail:network-policy-entries'):
            result_elems = metas['contrail:network-policy-entries']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                # need to preserve type eg. int for prefix-len
                # for now, xml -> obj -> json -> dict
                # TODO TypeGenerator.py should have xml to dict method
                obj = PolicyEntriesType()
                obj.build(meta)
                obj_json = ''
                obj_json = json.dumps(obj,
                    default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
                obj_val = json.loads(obj_json)
                result['network_policy_entries'] = obj_val

        if metas.has_key('contrail:id-perms'):
            result_elems = metas['contrail:id-perms']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                # need to preserve type eg. int for prefix-len
                # for now, xml -> obj -> json -> dict
                # TODO TypeGenerator.py should have xml to dict method
                obj = IdPermsType()
                obj.build(meta)
                obj_json = ''
                obj_json = json.dumps(obj,
                    default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
                obj_val = json.loads(obj_json)
                result['id_perms'] = obj_val

        return (True, result)
    #end _ifmap_network_policy_read

    def _ifmap_network_policy_update(self, ifmap_id, old_obj_dict, new_obj_dict):
        # remove properties that are no longer active
        if ('network_policy_entries' in new_obj_dict) and (new_obj_dict['network_policy_entries'] == None):
            self._delete_id_self_meta(ifmap_id, 'network-policy-entries')

        if ('id_perms' in new_obj_dict) and (new_obj_dict['id_perms'] == None):
            self._delete_id_self_meta(ifmap_id, 'id-perms')

        # remove refs that are no longer active
        (ok, result) = self._ifmap_network_policy_set(ifmap_id, new_obj_dict)
        return (ok, result)
    #end _ifmap_network_policy_update

    def _ifmap_network_policy_list(self, parent_type, parent_fq_name):
        children_fq_names = []
        mapclient = self._mapclient
        parent_imid = common.imid.get_ifmap_id_from_fq_name(parent_type, parent_fq_name)
        start_id = str(Identity(name = parent_imid, type = 'other',
                        other_type = 'extended'))
        # if id-perms missing, identity doesn't exist
        parent_link_meta = self._parent_metas[parent_type]['network-policy']
        srch_meta = 'contrail:' + parent_link_meta
        srch_result = self._search(start_id, srch_meta)

        result_list = self.parse_result_items(srch_result, parent_imid)
        for r_elem in result_list:
            child_ident = r_elem[1]
            if child_ident is None:
                continue
            child_imid = child_ident.attrib['name']
            fq_name = self._db_client_mgr.ifmap_id_to_fq_name(child_imid)
            children_fq_names.append(fq_name)


        return (True, children_fq_names)
    #end _ifmap_network_policy_list

    def _ifmap_network_policy_delete(self, obj_ids):
        ifmap_id = obj_ids['imid']
        parent_imid = obj_ids.get('parent_imid', None)
        start_id = str(Identity(name = ifmap_id, type = 'other',
                        other_type = 'extended'))

        if parent_imid:
            # Remove link from parent
            self._delete_id_pair_meta(parent_imid, ifmap_id, None)

        # Remove all property metadata associated with this ident
        self._delete_id_self_meta(ifmap_id, None)

        return (True, '')
    #end _ifmap_network_policy_delete

    def _ifmap_virtual_DNS_record_alloc(self, parent_type, fq_name):
        imid = self._imid_handler
        (my_imid, parent_imid) = \
            imid.virtual_DNS_record_alloc_ifmap_id(parent_type, fq_name)
        return (True, (my_imid, parent_imid))
    #end _ifmap_virtual_DNS_record_alloc

    def _ifmap_virtual_DNS_record_set(self, my_imid, obj_dict):
        # Properties Meta
        field = obj_dict.get('virtual_DNS_record_data', None)
        if field:
            # construct object of xsd-type and get its xml repr
            field = obj_dict['virtual_DNS_record_data']
            buf = cStringIO.StringIO()
            # perms might be inserted at server as obj.
            # obj construction diff from dict construction.
            if isinstance(field, dict):
                VirtualDnsRecordType(**field).exportChildren(buf, level = 1, name_ = 'virtual-DNS-record-data', pretty_print = False)
            else: # object
                field.exportChildren(buf, level = 1, name_ = 'virtual-DNS-record-data', pretty_print = False)
            virtual_DNS_record_data_xml = buf.getvalue()
            buf.close()
            meta = str(Metadata('virtual-DNS-record-data' , '',
                   {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail',
                   elements = virtual_DNS_record_data_xml))
            self._publish_id_self_meta(my_imid, meta)

        field = obj_dict.get('id_perms', None)
        if field:
            # construct object of xsd-type and get its xml repr
            field = obj_dict['id_perms']
            buf = cStringIO.StringIO()
            # perms might be inserted at server as obj.
            # obj construction diff from dict construction.
            if isinstance(field, dict):
                IdPermsType(**field).exportChildren(buf, level = 1, name_ = 'id-perms', pretty_print = False)
            else: # object
                field.exportChildren(buf, level = 1, name_ = 'id-perms', pretty_print = False)
            id_perms_xml = buf.getvalue()
            buf.close()
            meta = str(Metadata('id-perms' , '',
                   {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail',
                   elements = id_perms_xml))
            self._publish_id_self_meta(my_imid, meta)

        # Ref Link Metas
        imid = self._imid_handler


        return (True, '')
    #end _ifmap_virtual_DNS_record_set

    def _ifmap_virtual_DNS_record_create(self, obj_ids, obj_dict):
        if not 'parent_type' in obj_dict:
            # parent is config-root
            parent_type = 'config-root'
            parent_imid = 'contrail:config-root:root'
        else:
            parent_type = obj_dict['parent_type']
            parent_imid = obj_ids.get('parent_imid', None)

        # Parent Link Meta
        parent_link_meta = self._parent_metas[parent_type]['virtual-DNS-record']
        meta = str(Metadata(parent_link_meta, '',
                   {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail'))
        self._publish_id_pair_meta(parent_imid, obj_ids['imid'], meta)

        (ok, result) = self._ifmap_virtual_DNS_record_set(obj_ids['imid'], obj_dict)
        return (ok, result)
    #end _ifmap_virtual_DNS_record_create

    def _ifmap_virtual_DNS_record_read(self, ifmap_id, field_names = None):
        # field_names = None means all fields will be read
        imid = self._imid_handler
        mapclient = self._mapclient
        start_id = str(Identity(name = ifmap_id, type = 'other',
                        other_type = 'extended'))
        # if id-perms missing, identity doesn't exist

        all_metas = [u'contrail:virtual-DNS-record-data', u'contrail:id-perms']
        if not field_names:
            metas_to_read = all_metas
        else: # read only requested fields
            req_metas = []
            if field_names.has_key('virtual_DNS_record_data'):
                req_metas.append('contrail:virtual-DNS-record-data')
            if field_names.has_key('id_perms'):
                req_metas.append('contrail:id-perms')

            metas_to_read = set(all_metas) & set(req_metas)

        srch_meta = ' or '.join(metas_to_read)
        srch_result = self._search(start_id, srch_meta)

        result_list = self.parse_result_items(srch_result, ifmap_id)
        if (len(result_list) == 1 and 
            result_list[0][2] == None):
            return (False, 'virtual-DNS-record ' + ifmap_id + 'does not exist')

        # metas is a dict where key is meta-name and val is list of tuples
        # of form (ident1, ident2, meta)
        metas = {}
        for r_elem in result_list:
            r_meta = r_elem[2]
            # create contrail:<tag>
            meta_name = r_meta.prefix + ':' + re.sub('{.*}', '', r_meta.tag)

            if (
                (meta_name == 'contrail:virtual-DNS-record-data') or
                (meta_name == 'contrail:id-perms')
               ):
                if metas.has_key(meta_name):
                    metas[meta_name].append(r_elem)
                else: # first ident for this link-type
                    metas[meta_name] = [r_elem]

         # Construct dicts from xml
        result = {}
        result['_type'] = 'virtual-DNS-record'
        fq_name = self._db_client_mgr.ifmap_id_to_fq_name(ifmap_id)
        result['fq_name'] = fq_name
        result['name'] = fq_name[-1]
        if metas.has_key('contrail:virtual-DNS-record-data'):
            result_elems = metas['contrail:virtual-DNS-record-data']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                # need to preserve type eg. int for prefix-len
                # for now, xml -> obj -> json -> dict
                # TODO TypeGenerator.py should have xml to dict method
                obj = VirtualDnsRecordType()
                obj.build(meta)
                obj_json = ''
                obj_json = json.dumps(obj,
                    default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
                obj_val = json.loads(obj_json)
                result['virtual_DNS_record_data'] = obj_val

        if metas.has_key('contrail:id-perms'):
            result_elems = metas['contrail:id-perms']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                # need to preserve type eg. int for prefix-len
                # for now, xml -> obj -> json -> dict
                # TODO TypeGenerator.py should have xml to dict method
                obj = IdPermsType()
                obj.build(meta)
                obj_json = ''
                obj_json = json.dumps(obj,
                    default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
                obj_val = json.loads(obj_json)
                result['id_perms'] = obj_val

        return (True, result)
    #end _ifmap_virtual_DNS_record_read

    def _ifmap_virtual_DNS_record_update(self, ifmap_id, old_obj_dict, new_obj_dict):
        # remove properties that are no longer active
        if ('virtual_DNS_record_data' in new_obj_dict) and (new_obj_dict['virtual_DNS_record_data'] == None):
            self._delete_id_self_meta(ifmap_id, 'virtual-DNS-record-data')

        if ('id_perms' in new_obj_dict) and (new_obj_dict['id_perms'] == None):
            self._delete_id_self_meta(ifmap_id, 'id-perms')

        # remove refs that are no longer active
        (ok, result) = self._ifmap_virtual_DNS_record_set(ifmap_id, new_obj_dict)
        return (ok, result)
    #end _ifmap_virtual_DNS_record_update

    def _ifmap_virtual_DNS_record_list(self, parent_type, parent_fq_name):
        children_fq_names = []
        mapclient = self._mapclient
        parent_imid = common.imid.get_ifmap_id_from_fq_name(parent_type, parent_fq_name)
        start_id = str(Identity(name = parent_imid, type = 'other',
                        other_type = 'extended'))
        # if id-perms missing, identity doesn't exist
        parent_link_meta = self._parent_metas[parent_type]['virtual-DNS-record']
        srch_meta = 'contrail:' + parent_link_meta
        srch_result = self._search(start_id, srch_meta)

        result_list = self.parse_result_items(srch_result, parent_imid)
        for r_elem in result_list:
            child_ident = r_elem[1]
            if child_ident is None:
                continue
            child_imid = child_ident.attrib['name']
            fq_name = self._db_client_mgr.ifmap_id_to_fq_name(child_imid)
            children_fq_names.append(fq_name)


        return (True, children_fq_names)
    #end _ifmap_virtual_DNS_record_list

    def _ifmap_virtual_DNS_record_delete(self, obj_ids):
        ifmap_id = obj_ids['imid']
        parent_imid = obj_ids.get('parent_imid', None)
        start_id = str(Identity(name = ifmap_id, type = 'other',
                        other_type = 'extended'))

        if parent_imid:
            # Remove link from parent
            self._delete_id_pair_meta(parent_imid, ifmap_id, None)

        # Remove all property metadata associated with this ident
        self._delete_id_self_meta(ifmap_id, None)

        return (True, '')
    #end _ifmap_virtual_DNS_record_delete

    def _ifmap_route_target_alloc(self, parent_type, fq_name):
        imid = self._imid_handler
        (my_imid, parent_imid) = \
            imid.route_target_alloc_ifmap_id(parent_type, fq_name)
        return (True, (my_imid, parent_imid))
    #end _ifmap_route_target_alloc

    def _ifmap_route_target_set(self, my_imid, obj_dict):
        # Properties Meta
        field = obj_dict.get('id_perms', None)
        if field:
            # construct object of xsd-type and get its xml repr
            field = obj_dict['id_perms']
            buf = cStringIO.StringIO()
            # perms might be inserted at server as obj.
            # obj construction diff from dict construction.
            if isinstance(field, dict):
                IdPermsType(**field).exportChildren(buf, level = 1, name_ = 'id-perms', pretty_print = False)
            else: # object
                field.exportChildren(buf, level = 1, name_ = 'id-perms', pretty_print = False)
            id_perms_xml = buf.getvalue()
            buf.close()
            meta = str(Metadata('id-perms' , '',
                   {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail',
                   elements = id_perms_xml))
            self._publish_id_self_meta(my_imid, meta)

        # Ref Link Metas
        imid = self._imid_handler


        return (True, '')
    #end _ifmap_route_target_set

    def _ifmap_route_target_create(self, obj_ids, obj_dict):
        (ok, result) = self._ifmap_route_target_set(obj_ids['imid'], obj_dict)
        return (ok, result)
    #end _ifmap_route_target_create

    def _ifmap_route_target_read(self, ifmap_id, field_names = None):
        # field_names = None means all fields will be read
        imid = self._imid_handler
        mapclient = self._mapclient
        start_id = str(Identity(name = ifmap_id, type = 'other',
                        other_type = 'extended'))
        # if id-perms missing, identity doesn't exist

        all_metas = [u'contrail:instance-target', u'contrail:id-perms']
        if not field_names:
            metas_to_read = all_metas
        else: # read only requested fields
            req_metas = []
            if field_names.has_key('routing_instance_back_refs'):
                req_metas.append('contrail:instance-target')
            if field_names.has_key('id_perms'):
                req_metas.append('contrail:id-perms')

            metas_to_read = set(all_metas) & set(req_metas)

        srch_meta = ' or '.join(metas_to_read)
        srch_result = self._search(start_id, srch_meta)

        result_list = self.parse_result_items(srch_result, ifmap_id)
        if (len(result_list) == 1 and 
            result_list[0][2] == None):
            return (False, 'route-target ' + ifmap_id + 'does not exist')

        # metas is a dict where key is meta-name and val is list of tuples
        # of form (ident1, ident2, meta)
        metas = {}
        for r_elem in result_list:
            r_meta = r_elem[2]
            # create contrail:<tag>
            meta_name = r_meta.prefix + ':' + re.sub('{.*}', '', r_meta.tag)

            if (
                (meta_name == 'contrail:instance-target') or
                (meta_name == 'contrail:id-perms')
               ):
                if metas.has_key(meta_name):
                    metas[meta_name].append(r_elem)
                else: # first ident for this link-type
                    metas[meta_name] = [r_elem]

         # Construct dicts from xml
        result = {}
        result['_type'] = 'route-target'
        fq_name = self._db_client_mgr.ifmap_id_to_fq_name(ifmap_id)
        result['fq_name'] = fq_name
        result['name'] = fq_name[-1]
        if metas.has_key('contrail:instance-target'):
            result['routing_instance_back_refs'] = []
            result_elems = metas['contrail:instance-target']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                # need to preserve type eg. int for prefix-len
                # for now, xml -> obj -> json -> dict
                # TODO TypeGenerator.py should have xml to dict method
                obj = InstanceTargetType()
                obj.build(meta)
                obj_json = ''
                obj_json = json.dumps(obj,
                    default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
                obj_val = json.loads(obj_json)
                back_ref_ifmap_id = r_elem[0].attrib['name']

                try:
                    back_ref_fq_name = self._db_client_mgr.ifmap_id_to_fq_name(back_ref_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown fq_name for backref ' + back_ref_ifmap_id
                    return (False, err_msg)
                try:
                    back_ref_uuid = self._db_client_mgr.ifmap_id_to_uuid(back_ref_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown uuid for backref ' + back_ref_ifmap_id
                    return (False, err_msg)

                back_ref_url = self._db_client_mgr.generate_url('routing_instance', back_ref_uuid)
                back_ref_info = {}
                back_ref_info['to'] = back_ref_fq_name
                back_ref_info['attr'] = obj_val
                back_ref_info['href'] = back_ref_url
                back_ref_info['uuid'] = back_ref_uuid
                result['routing_instance_back_refs'].append(back_ref_info)


        if metas.has_key('contrail:id-perms'):
            result_elems = metas['contrail:id-perms']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                # need to preserve type eg. int for prefix-len
                # for now, xml -> obj -> json -> dict
                # TODO TypeGenerator.py should have xml to dict method
                obj = IdPermsType()
                obj.build(meta)
                obj_json = ''
                obj_json = json.dumps(obj,
                    default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
                obj_val = json.loads(obj_json)
                result['id_perms'] = obj_val

        return (True, result)
    #end _ifmap_route_target_read

    def _ifmap_route_target_update(self, ifmap_id, old_obj_dict, new_obj_dict):
        # remove properties that are no longer active
        if ('id_perms' in new_obj_dict) and (new_obj_dict['id_perms'] == None):
            self._delete_id_self_meta(ifmap_id, 'id-perms')

        # remove refs that are no longer active
        (ok, result) = self._ifmap_route_target_set(ifmap_id, new_obj_dict)
        return (ok, result)
    #end _ifmap_route_target_update

    def _ifmap_route_target_list(self, parent_type, parent_fq_name):
        children_fq_names = []
        return (True, children_fq_names)
    #end _ifmap_route_target_list

    def _ifmap_route_target_delete(self, obj_ids):
        ifmap_id = obj_ids['imid']
        parent_imid = obj_ids.get('parent_imid', None)
        start_id = str(Identity(name = ifmap_id, type = 'other',
                        other_type = 'extended'))

        if parent_imid:
            # Remove link from parent
            self._delete_id_pair_meta(parent_imid, ifmap_id, None)

        # Remove all property metadata associated with this ident
        self._delete_id_self_meta(ifmap_id, None)

        return (True, '')
    #end _ifmap_route_target_delete

    def _ifmap_floating_ip_alloc(self, parent_type, fq_name):
        imid = self._imid_handler
        (my_imid, parent_imid) = \
            imid.floating_ip_alloc_ifmap_id(parent_type, fq_name)
        return (True, (my_imid, parent_imid))
    #end _ifmap_floating_ip_alloc

    def _ifmap_floating_ip_set(self, my_imid, obj_dict):
        # Properties Meta
        field = obj_dict.get('floating_ip_address', None)
        if field:
            meta = str(Metadata('floating-ip-address' , str(obj_dict['floating_ip_address']),
                   {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail'))
            self._publish_id_self_meta(my_imid, meta)

        field = obj_dict.get('floating_ip_is_virtual_ip', None)
        if field:
            meta = str(Metadata('floating-ip-is-virtual-ip' , str(obj_dict['floating_ip_is_virtual_ip']),
                   {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail'))
            self._publish_id_self_meta(my_imid, meta)

        field = obj_dict.get('id_perms', None)
        if field:
            # construct object of xsd-type and get its xml repr
            field = obj_dict['id_perms']
            buf = cStringIO.StringIO()
            # perms might be inserted at server as obj.
            # obj construction diff from dict construction.
            if isinstance(field, dict):
                IdPermsType(**field).exportChildren(buf, level = 1, name_ = 'id-perms', pretty_print = False)
            else: # object
                field.exportChildren(buf, level = 1, name_ = 'id-perms', pretty_print = False)
            id_perms_xml = buf.getvalue()
            buf.close()
            meta = str(Metadata('id-perms' , '',
                   {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail',
                   elements = id_perms_xml))
            self._publish_id_self_meta(my_imid, meta)

        # Ref Link Metas
        imid = self._imid_handler

        # construct object of xsd-type and get its xml repr
        refs = obj_dict.get('project_refs', None)
        if refs:
            for ref in refs:
                ref_fq_name = ref['to']
                obj_type = 'project'
                to_imid = common.imid.get_ifmap_id_from_fq_name(obj_type, ref_fq_name)
                floating_ip_project_xml = ''
                meta = str(Metadata('floating-ip-project' , '',
                       {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail',
                       elements = floating_ip_project_xml))
                self._publish_id_pair_meta(my_imid, to_imid, meta)

        # construct object of xsd-type and get its xml repr
        refs = obj_dict.get('virtual_machine_interface_refs', None)
        if refs:
            for ref in refs:
                ref_fq_name = ref['to']
                obj_type = 'virtual-machine-interface'
                to_imid = common.imid.get_ifmap_id_from_fq_name(obj_type, ref_fq_name)
                floating_ip_virtual_machine_interface_xml = ''
                meta = str(Metadata('floating-ip-virtual-machine-interface' , '',
                       {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail',
                       elements = floating_ip_virtual_machine_interface_xml))
                self._publish_id_pair_meta(my_imid, to_imid, meta)


        return (True, '')
    #end _ifmap_floating_ip_set

    def _ifmap_floating_ip_create(self, obj_ids, obj_dict):
        if not 'parent_type' in obj_dict:
            # parent is config-root
            parent_type = 'config-root'
            parent_imid = 'contrail:config-root:root'
        else:
            parent_type = obj_dict['parent_type']
            parent_imid = obj_ids.get('parent_imid', None)

        # Parent Link Meta
        parent_link_meta = self._parent_metas[parent_type]['floating-ip']
        meta = str(Metadata(parent_link_meta, '',
                   {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail'))
        self._publish_id_pair_meta(parent_imid, obj_ids['imid'], meta)

        (ok, result) = self._ifmap_floating_ip_set(obj_ids['imid'], obj_dict)
        return (ok, result)
    #end _ifmap_floating_ip_create

    def _ifmap_floating_ip_read(self, ifmap_id, field_names = None):
        # field_names = None means all fields will be read
        imid = self._imid_handler
        mapclient = self._mapclient
        start_id = str(Identity(name = ifmap_id, type = 'other',
                        other_type = 'extended'))
        # if id-perms missing, identity doesn't exist

        all_metas = [u'contrail:floating-ip-project', u'contrail:floating-ip-virtual-machine-interface', u'contrail:customer-attachment-floating-ip', u'contrail:floating-ip-address', u'contrail:floating-ip-is-virtual-ip', u'contrail:id-perms']
        if not field_names:
            metas_to_read = all_metas
        else: # read only requested fields
            req_metas = []
            if field_names.has_key('project_refs'):
                req_metas.append('contrail:floating-ip-project')
            if field_names.has_key('virtual_machine_interface_refs'):
                req_metas.append('contrail:floating-ip-virtual-machine-interface')
            if field_names.has_key('customer_attachment_back_refs'):
                req_metas.append('contrail:customer-attachment-floating-ip')
            if field_names.has_key('floating_ip_address'):
                req_metas.append('contrail:floating-ip-address')
            if field_names.has_key('floating_ip_is_virtual_ip'):
                req_metas.append('contrail:floating-ip-is-virtual-ip')
            if field_names.has_key('id_perms'):
                req_metas.append('contrail:id-perms')

            metas_to_read = set(all_metas) & set(req_metas)

        srch_meta = ' or '.join(metas_to_read)
        srch_result = self._search(start_id, srch_meta)

        result_list = self.parse_result_items(srch_result, ifmap_id)
        if (len(result_list) == 1 and 
            result_list[0][2] == None):
            return (False, 'floating-ip ' + ifmap_id + 'does not exist')

        # metas is a dict where key is meta-name and val is list of tuples
        # of form (ident1, ident2, meta)
        metas = {}
        for r_elem in result_list:
            r_meta = r_elem[2]
            # create contrail:<tag>
            meta_name = r_meta.prefix + ':' + re.sub('{.*}', '', r_meta.tag)

            if (
                (meta_name == 'contrail:floating-ip-project') or
                (meta_name == 'contrail:floating-ip-virtual-machine-interface') or
                (meta_name == 'contrail:customer-attachment-floating-ip') or
                (meta_name == 'contrail:floating-ip-address') or
                (meta_name == 'contrail:floating-ip-is-virtual-ip') or
                (meta_name == 'contrail:id-perms')
               ):
                if metas.has_key(meta_name):
                    metas[meta_name].append(r_elem)
                else: # first ident for this link-type
                    metas[meta_name] = [r_elem]

         # Construct dicts from xml
        result = {}
        result['_type'] = 'floating-ip'
        fq_name = self._db_client_mgr.ifmap_id_to_fq_name(ifmap_id)
        result['fq_name'] = fq_name
        result['name'] = fq_name[-1]
        if metas.has_key('contrail:floating-ip-project'):
            result['project_refs'] = []
            result_elems = metas['contrail:floating-ip-project']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                obj_val = {}
                # in case of refs between same types of identifiers,
                # the referred ident could appears at idx 0 or 1
                if ifmap_id == r_elem[0].attrib['name']:
                    ref_ifmap_id = r_elem[1].attrib['name']
                else:
                    ref_ifmap_id = r_elem[0].attrib['name']

                try:
                    ref_fq_name = self._db_client_mgr.ifmap_id_to_fq_name(ref_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown fq_name for ref ' + ref_ifmap_id
                    return (False, err_msg)
                try:
                    ref_uuid = self._db_client_mgr.ifmap_id_to_uuid(ref_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown uuid for ref ' + ref_ifmap_id
                    return (False, err_msg)

                ref_url = self._db_client_mgr.generate_url('project', ref_uuid)
                ref_info = {}
                ref_info['to'] = ref_fq_name
                ref_info['attr'] = obj_val
                ref_info['href'] = ref_url
                ref_info['uuid'] = ref_uuid
                result['project_refs'].append(ref_info)


        if metas.has_key('contrail:floating-ip-virtual-machine-interface'):
            result['virtual_machine_interface_refs'] = []
            result_elems = metas['contrail:floating-ip-virtual-machine-interface']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                obj_val = {}
                # in case of refs between same types of identifiers,
                # the referred ident could appears at idx 0 or 1
                if ifmap_id == r_elem[0].attrib['name']:
                    ref_ifmap_id = r_elem[1].attrib['name']
                else:
                    ref_ifmap_id = r_elem[0].attrib['name']

                try:
                    ref_fq_name = self._db_client_mgr.ifmap_id_to_fq_name(ref_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown fq_name for ref ' + ref_ifmap_id
                    return (False, err_msg)
                try:
                    ref_uuid = self._db_client_mgr.ifmap_id_to_uuid(ref_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown uuid for ref ' + ref_ifmap_id
                    return (False, err_msg)

                ref_url = self._db_client_mgr.generate_url('virtual_machine_interface', ref_uuid)
                ref_info = {}
                ref_info['to'] = ref_fq_name
                ref_info['attr'] = obj_val
                ref_info['href'] = ref_url
                ref_info['uuid'] = ref_uuid
                result['virtual_machine_interface_refs'].append(ref_info)


        if metas.has_key('contrail:customer-attachment-floating-ip'):
            result['customer_attachment_back_refs'] = []
            result_elems = metas['contrail:customer-attachment-floating-ip']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                obj_val = {}
                back_ref_ifmap_id = r_elem[0].attrib['name']

                try:
                    back_ref_fq_name = self._db_client_mgr.ifmap_id_to_fq_name(back_ref_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown fq_name for backref ' + back_ref_ifmap_id
                    return (False, err_msg)
                try:
                    back_ref_uuid = self._db_client_mgr.ifmap_id_to_uuid(back_ref_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown uuid for backref ' + back_ref_ifmap_id
                    return (False, err_msg)

                back_ref_url = self._db_client_mgr.generate_url('customer_attachment', back_ref_uuid)
                back_ref_info = {}
                back_ref_info['to'] = back_ref_fq_name
                back_ref_info['attr'] = obj_val
                back_ref_info['href'] = back_ref_url
                back_ref_info['uuid'] = back_ref_uuid
                result['customer_attachment_back_refs'].append(back_ref_info)


        if metas.has_key('contrail:floating-ip-address'):
            result_elems = metas['contrail:floating-ip-address']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                obj_val = meta.text
                result['floating_ip_address'] = obj_val

        if metas.has_key('contrail:floating-ip-is-virtual-ip'):
            result_elems = metas['contrail:floating-ip-is-virtual-ip']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                obj_val = meta.text
                result['floating_ip_is_virtual_ip'] = obj_val

        if metas.has_key('contrail:id-perms'):
            result_elems = metas['contrail:id-perms']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                # need to preserve type eg. int for prefix-len
                # for now, xml -> obj -> json -> dict
                # TODO TypeGenerator.py should have xml to dict method
                obj = IdPermsType()
                obj.build(meta)
                obj_json = ''
                obj_json = json.dumps(obj,
                    default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
                obj_val = json.loads(obj_json)
                result['id_perms'] = obj_val

        return (True, result)
    #end _ifmap_floating_ip_read

    def _ifmap_floating_ip_update(self, ifmap_id, old_obj_dict, new_obj_dict):
        # remove properties that are no longer active
        if ('floating_ip_address' in new_obj_dict) and (new_obj_dict['floating_ip_address'] == None):
            self._delete_id_self_meta(ifmap_id, 'floating-ip-address')

        if ('floating_ip_is_virtual_ip' in new_obj_dict) and (new_obj_dict['floating_ip_is_virtual_ip'] == None):
            self._delete_id_self_meta(ifmap_id, 'floating-ip-is-virtual-ip')

        if ('id_perms' in new_obj_dict) and (new_obj_dict['id_perms'] == None):
            self._delete_id_self_meta(ifmap_id, 'id-perms')

        # remove refs that are no longer active
        if ('project_refs' in old_obj_dict):
            old_refs = [tuple(ref['to']) for ref in old_obj_dict['project_refs']]
        else:
            old_refs = []
        if ('project_refs' in new_obj_dict):
            if new_obj_dict['project_refs'] == None:
                new_refs = []
            else:
                new_refs = [tuple(ref['to']) for ref in new_obj_dict['project_refs']]
        else: # no ref key in new_obj
            new_refs = old_refs

        old_set = set(old_refs)
        new_set = set(new_refs)
        inact_refs = old_set - new_set
        for inact_ref in inact_refs:
            to_imid = self.fq_name_to_ifmap_id('project', inact_ref)
            self._delete_id_pair_meta(ifmap_id, to_imid, 'contrail:floating-ip-project')

        if ('virtual_machine_interface_refs' in old_obj_dict):
            old_refs = [tuple(ref['to']) for ref in old_obj_dict['virtual_machine_interface_refs']]
        else:
            old_refs = []
        if ('virtual_machine_interface_refs' in new_obj_dict):
            if new_obj_dict['virtual_machine_interface_refs'] == None:
                new_refs = []
            else:
                new_refs = [tuple(ref['to']) for ref in new_obj_dict['virtual_machine_interface_refs']]
        else: # no ref key in new_obj
            new_refs = old_refs

        old_set = set(old_refs)
        new_set = set(new_refs)
        inact_refs = old_set - new_set
        for inact_ref in inact_refs:
            to_imid = self.fq_name_to_ifmap_id('virtual-machine-interface', inact_ref)
            self._delete_id_pair_meta(ifmap_id, to_imid, 'contrail:floating-ip-virtual-machine-interface')

        (ok, result) = self._ifmap_floating_ip_set(ifmap_id, new_obj_dict)
        return (ok, result)
    #end _ifmap_floating_ip_update

    def _ifmap_floating_ip_list(self, parent_type, parent_fq_name):
        children_fq_names = []
        mapclient = self._mapclient
        parent_imid = common.imid.get_ifmap_id_from_fq_name(parent_type, parent_fq_name)
        start_id = str(Identity(name = parent_imid, type = 'other',
                        other_type = 'extended'))
        # if id-perms missing, identity doesn't exist
        parent_link_meta = self._parent_metas[parent_type]['floating-ip']
        srch_meta = 'contrail:' + parent_link_meta
        srch_result = self._search(start_id, srch_meta)

        result_list = self.parse_result_items(srch_result, parent_imid)
        for r_elem in result_list:
            child_ident = r_elem[1]
            if child_ident is None:
                continue
            child_imid = child_ident.attrib['name']
            fq_name = self._db_client_mgr.ifmap_id_to_fq_name(child_imid)
            children_fq_names.append(fq_name)


        return (True, children_fq_names)
    #end _ifmap_floating_ip_list

    def _ifmap_floating_ip_delete(self, obj_ids):
        ifmap_id = obj_ids['imid']
        parent_imid = obj_ids.get('parent_imid', None)
        start_id = str(Identity(name = ifmap_id, type = 'other',
                        other_type = 'extended'))
        # Delete links to our references, first find them
        srch_meta = ' or '.join([u'contrail:floating-ip-project', u'contrail:floating-ip-virtual-machine-interface'])
        srch_result = self._search(start_id, srch_meta)

        result_list = self.parse_result_items(srch_result, ifmap_id)
        for r_elem in result_list:
            to_ident = r_elem[1]
            if to_ident is None:
                continue
            to_imid = to_ident.attrib['name']
            r_meta = r_elem[2]
            # create contrail:<tag>
            meta_name = r_meta.prefix + ':' + re.sub('{.*}', '', r_meta.tag)
            self._delete_id_pair_meta(ifmap_id, to_imid, meta_name)


        if parent_imid:
            # Remove link from parent
            self._delete_id_pair_meta(parent_imid, ifmap_id, None)

        # Remove all property metadata associated with this ident
        self._delete_id_self_meta(ifmap_id, None)

        return (True, '')
    #end _ifmap_floating_ip_delete

    def _ifmap_floating_ip_pool_alloc(self, parent_type, fq_name):
        imid = self._imid_handler
        (my_imid, parent_imid) = \
            imid.floating_ip_pool_alloc_ifmap_id(parent_type, fq_name)
        return (True, (my_imid, parent_imid))
    #end _ifmap_floating_ip_pool_alloc

    def _ifmap_floating_ip_pool_set(self, my_imid, obj_dict):
        # Properties Meta
        field = obj_dict.get('floating_ip_pool_prefixes', None)
        if field:
            # construct object of xsd-type and get its xml repr
            field = obj_dict['floating_ip_pool_prefixes']
            buf = cStringIO.StringIO()
            # perms might be inserted at server as obj.
            # obj construction diff from dict construction.
            if isinstance(field, dict):
                FloatingIpPoolType(**field).exportChildren(buf, level = 1, name_ = 'floating-ip-pool-prefixes', pretty_print = False)
            else: # object
                field.exportChildren(buf, level = 1, name_ = 'floating-ip-pool-prefixes', pretty_print = False)
            floating_ip_pool_prefixes_xml = buf.getvalue()
            buf.close()
            meta = str(Metadata('floating-ip-pool-prefixes' , '',
                   {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail',
                   elements = floating_ip_pool_prefixes_xml))
            self._publish_id_self_meta(my_imid, meta)

        field = obj_dict.get('id_perms', None)
        if field:
            # construct object of xsd-type and get its xml repr
            field = obj_dict['id_perms']
            buf = cStringIO.StringIO()
            # perms might be inserted at server as obj.
            # obj construction diff from dict construction.
            if isinstance(field, dict):
                IdPermsType(**field).exportChildren(buf, level = 1, name_ = 'id-perms', pretty_print = False)
            else: # object
                field.exportChildren(buf, level = 1, name_ = 'id-perms', pretty_print = False)
            id_perms_xml = buf.getvalue()
            buf.close()
            meta = str(Metadata('id-perms' , '',
                   {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail',
                   elements = id_perms_xml))
            self._publish_id_self_meta(my_imid, meta)

        # Ref Link Metas
        imid = self._imid_handler

        # construct object of xsd-type and get its xml repr
        refs = obj_dict.get('floating_ip_refs', None)
        if refs:
            for ref in refs:
                ref_fq_name = ref['to']
                obj_type = 'floating-ip'
                to_imid = common.imid.get_ifmap_id_from_fq_name(obj_type, ref_fq_name)
                floating_ip_pool_floating_ip_xml = ''
                meta = str(Metadata('floating-ip-pool-floating-ip' , '',
                       {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail',
                       elements = floating_ip_pool_floating_ip_xml))
                self._publish_id_pair_meta(my_imid, to_imid, meta)


        return (True, '')
    #end _ifmap_floating_ip_pool_set

    def _ifmap_floating_ip_pool_create(self, obj_ids, obj_dict):
        if not 'parent_type' in obj_dict:
            # parent is config-root
            parent_type = 'config-root'
            parent_imid = 'contrail:config-root:root'
        else:
            parent_type = obj_dict['parent_type']
            parent_imid = obj_ids.get('parent_imid', None)

        # Parent Link Meta
        parent_link_meta = self._parent_metas[parent_type]['floating-ip-pool']
        meta = str(Metadata(parent_link_meta, '',
                   {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail'))
        self._publish_id_pair_meta(parent_imid, obj_ids['imid'], meta)

        (ok, result) = self._ifmap_floating_ip_pool_set(obj_ids['imid'], obj_dict)
        return (ok, result)
    #end _ifmap_floating_ip_pool_create

    def _ifmap_floating_ip_pool_read(self, ifmap_id, field_names = None):
        # field_names = None means all fields will be read
        imid = self._imid_handler
        mapclient = self._mapclient
        start_id = str(Identity(name = ifmap_id, type = 'other',
                        other_type = 'extended'))
        # if id-perms missing, identity doesn't exist

        all_metas = [u'contrail:project-floating-ip-pool', u'contrail:floating-ip-pool-prefixes', u'contrail:id-perms', u'contrail:floating-ip-pool-floating-ip']
        if not field_names:
            metas_to_read = all_metas
        else: # read only requested fields
            req_metas = []
            if field_names.has_key('project_back_refs'):
                req_metas.append('contrail:project-floating-ip-pool')
            if field_names.has_key('floating_ip_pool_prefixes'):
                req_metas.append('contrail:floating-ip-pool-prefixes')
            if field_names.has_key('id_perms'):
                req_metas.append('contrail:id-perms')
            if field_names.has_key('floating_ip_pool_floating_ip'):
                req_metas.append('contrail:floating-ip-pool-floating-ip')

            metas_to_read = set(all_metas) & set(req_metas)

        srch_meta = ' or '.join(metas_to_read)
        srch_result = self._search(start_id, srch_meta)

        result_list = self.parse_result_items(srch_result, ifmap_id)
        if (len(result_list) == 1 and 
            result_list[0][2] == None):
            return (False, 'floating-ip-pool ' + ifmap_id + 'does not exist')

        # metas is a dict where key is meta-name and val is list of tuples
        # of form (ident1, ident2, meta)
        metas = {}
        for r_elem in result_list:
            r_meta = r_elem[2]
            # create contrail:<tag>
            meta_name = r_meta.prefix + ':' + re.sub('{.*}', '', r_meta.tag)

            if (
                (meta_name == 'contrail:project-floating-ip-pool') or
                (meta_name == 'contrail:floating-ip-pool-prefixes') or
                (meta_name == 'contrail:id-perms') or
                (meta_name == 'contrail:floating-ip-pool-floating-ip')
               ):
                if metas.has_key(meta_name):
                    metas[meta_name].append(r_elem)
                else: # first ident for this link-type
                    metas[meta_name] = [r_elem]

         # Construct dicts from xml
        result = {}
        result['_type'] = 'floating-ip-pool'
        fq_name = self._db_client_mgr.ifmap_id_to_fq_name(ifmap_id)
        result['fq_name'] = fq_name
        result['name'] = fq_name[-1]
        if metas.has_key('contrail:project-floating-ip-pool'):
            result['project_back_refs'] = []
            result_elems = metas['contrail:project-floating-ip-pool']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                obj_val = {}
                back_ref_ifmap_id = r_elem[0].attrib['name']

                try:
                    back_ref_fq_name = self._db_client_mgr.ifmap_id_to_fq_name(back_ref_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown fq_name for backref ' + back_ref_ifmap_id
                    return (False, err_msg)
                try:
                    back_ref_uuid = self._db_client_mgr.ifmap_id_to_uuid(back_ref_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown uuid for backref ' + back_ref_ifmap_id
                    return (False, err_msg)

                back_ref_url = self._db_client_mgr.generate_url('project', back_ref_uuid)
                back_ref_info = {}
                back_ref_info['to'] = back_ref_fq_name
                back_ref_info['attr'] = obj_val
                back_ref_info['href'] = back_ref_url
                back_ref_info['uuid'] = back_ref_uuid
                result['project_back_refs'].append(back_ref_info)


        if metas.has_key('contrail:floating-ip-pool-prefixes'):
            result_elems = metas['contrail:floating-ip-pool-prefixes']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                # need to preserve type eg. int for prefix-len
                # for now, xml -> obj -> json -> dict
                # TODO TypeGenerator.py should have xml to dict method
                obj = FloatingIpPoolType()
                obj.build(meta)
                obj_json = ''
                obj_json = json.dumps(obj,
                    default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
                obj_val = json.loads(obj_json)
                result['floating_ip_pool_prefixes'] = obj_val

        if metas.has_key('contrail:id-perms'):
            result_elems = metas['contrail:id-perms']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                # need to preserve type eg. int for prefix-len
                # for now, xml -> obj -> json -> dict
                # TODO TypeGenerator.py should have xml to dict method
                obj = IdPermsType()
                obj.build(meta)
                obj_json = ''
                obj_json = json.dumps(obj,
                    default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
                obj_val = json.loads(obj_json)
                result['id_perms'] = obj_val

        if metas.has_key('contrail:floating-ip-pool-floating-ip'):
            result['floating_ips'] = []
            result_elems = metas['contrail:floating-ip-pool-floating-ip']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                obj_val = {}
                has_ifmap_id = r_elem[1].attrib['name']

                try:
                    has_fq_name = self._db_client_mgr.ifmap_id_to_fq_name(has_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown fq_name for child ' + has_ifmap_id
                    return (False, err_msg)
                try:
                    has_uuid = self._db_client_mgr.ifmap_id_to_uuid(has_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown uuid for child ' + has_ifmap_id
                    return (False, err_msg)

                has_url = self._db_client_mgr.generate_url('floating_ip', has_uuid)
                has_info = {}
                has_info['to'] = has_fq_name
                has_info['attr'] = obj_val
                has_info['href'] = has_url
                has_info['uuid'] = has_uuid
                result['floating_ips'].append(has_info)


        return (True, result)
    #end _ifmap_floating_ip_pool_read

    def _ifmap_floating_ip_pool_update(self, ifmap_id, old_obj_dict, new_obj_dict):
        # remove properties that are no longer active
        if ('floating_ip_pool_prefixes' in new_obj_dict) and (new_obj_dict['floating_ip_pool_prefixes'] == None):
            self._delete_id_self_meta(ifmap_id, 'floating-ip-pool-prefixes')

        if ('id_perms' in new_obj_dict) and (new_obj_dict['id_perms'] == None):
            self._delete_id_self_meta(ifmap_id, 'id-perms')

        # remove refs that are no longer active
        (ok, result) = self._ifmap_floating_ip_pool_set(ifmap_id, new_obj_dict)
        return (ok, result)
    #end _ifmap_floating_ip_pool_update

    def _ifmap_floating_ip_pool_list(self, parent_type, parent_fq_name):
        children_fq_names = []
        mapclient = self._mapclient
        parent_imid = common.imid.get_ifmap_id_from_fq_name(parent_type, parent_fq_name)
        start_id = str(Identity(name = parent_imid, type = 'other',
                        other_type = 'extended'))
        # if id-perms missing, identity doesn't exist
        parent_link_meta = self._parent_metas[parent_type]['floating-ip-pool']
        srch_meta = 'contrail:' + parent_link_meta
        srch_result = self._search(start_id, srch_meta)

        result_list = self.parse_result_items(srch_result, parent_imid)
        for r_elem in result_list:
            child_ident = r_elem[1]
            if child_ident is None:
                continue
            child_imid = child_ident.attrib['name']
            fq_name = self._db_client_mgr.ifmap_id_to_fq_name(child_imid)
            children_fq_names.append(fq_name)


        return (True, children_fq_names)
    #end _ifmap_floating_ip_pool_list

    def _ifmap_floating_ip_pool_delete(self, obj_ids):
        ifmap_id = obj_ids['imid']
        parent_imid = obj_ids.get('parent_imid', None)
        start_id = str(Identity(name = ifmap_id, type = 'other',
                        other_type = 'extended'))

        if parent_imid:
            # Remove link from parent
            self._delete_id_pair_meta(parent_imid, ifmap_id, None)

        # Remove all property metadata associated with this ident
        self._delete_id_self_meta(ifmap_id, None)

        return (True, '')
    #end _ifmap_floating_ip_pool_delete

    def _ifmap_physical_router_alloc(self, parent_type, fq_name):
        imid = self._imid_handler
        (my_imid, parent_imid) = \
            imid.physical_router_alloc_ifmap_id(parent_type, fq_name)
        return (True, (my_imid, parent_imid))
    #end _ifmap_physical_router_alloc

    def _ifmap_physical_router_set(self, my_imid, obj_dict):
        # Properties Meta
        field = obj_dict.get('id_perms', None)
        if field:
            # construct object of xsd-type and get its xml repr
            field = obj_dict['id_perms']
            buf = cStringIO.StringIO()
            # perms might be inserted at server as obj.
            # obj construction diff from dict construction.
            if isinstance(field, dict):
                IdPermsType(**field).exportChildren(buf, level = 1, name_ = 'id-perms', pretty_print = False)
            else: # object
                field.exportChildren(buf, level = 1, name_ = 'id-perms', pretty_print = False)
            id_perms_xml = buf.getvalue()
            buf.close()
            meta = str(Metadata('id-perms' , '',
                   {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail',
                   elements = id_perms_xml))
            self._publish_id_self_meta(my_imid, meta)

        # Ref Link Metas
        imid = self._imid_handler

        # construct object of xsd-type and get its xml repr
        refs = obj_dict.get('bgp_router_refs', None)
        if refs:
            for ref in refs:
                ref_fq_name = ref['to']
                obj_type = 'bgp-router'
                to_imid = common.imid.get_ifmap_id_from_fq_name(obj_type, ref_fq_name)
                physical_router_bgp_router_xml = ''
                meta = str(Metadata('physical-router-bgp-router' , '',
                       {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail',
                       elements = physical_router_bgp_router_xml))
                self._publish_id_pair_meta(my_imid, to_imid, meta)

        # construct object of xsd-type and get its xml repr
        refs = obj_dict.get('physical_interface_refs', None)
        if refs:
            for ref in refs:
                ref_fq_name = ref['to']
                obj_type = 'physical-interface'
                to_imid = common.imid.get_ifmap_id_from_fq_name(obj_type, ref_fq_name)
                physical_router_physical_interface_xml = ''
                meta = str(Metadata('physical-router-physical-interface' , '',
                       {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail',
                       elements = physical_router_physical_interface_xml))
                self._publish_id_pair_meta(my_imid, to_imid, meta)


        return (True, '')
    #end _ifmap_physical_router_set

    def _ifmap_physical_router_create(self, obj_ids, obj_dict):
        if not 'parent_type' in obj_dict:
            # parent is config-root
            parent_type = 'config-root'
            parent_imid = 'contrail:config-root:root'
        else:
            parent_type = obj_dict['parent_type']
            parent_imid = obj_ids.get('parent_imid', None)

        # Parent Link Meta
        parent_link_meta = self._parent_metas[parent_type]['physical-router']
        meta = str(Metadata(parent_link_meta, '',
                   {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail'))
        self._publish_id_pair_meta(parent_imid, obj_ids['imid'], meta)

        (ok, result) = self._ifmap_physical_router_set(obj_ids['imid'], obj_dict)
        return (ok, result)
    #end _ifmap_physical_router_create

    def _ifmap_physical_router_read(self, ifmap_id, field_names = None):
        # field_names = None means all fields will be read
        imid = self._imid_handler
        mapclient = self._mapclient
        start_id = str(Identity(name = ifmap_id, type = 'other',
                        other_type = 'extended'))
        # if id-perms missing, identity doesn't exist

        all_metas = [u'contrail:physical-router-bgp-router', u'contrail:id-perms', u'contrail:physical-router-physical-interface']
        if not field_names:
            metas_to_read = all_metas
        else: # read only requested fields
            req_metas = []
            if field_names.has_key('bgp_router_refs'):
                req_metas.append('contrail:physical-router-bgp-router')
            if field_names.has_key('id_perms'):
                req_metas.append('contrail:id-perms')
            if field_names.has_key('physical_router_physical_interface'):
                req_metas.append('contrail:physical-router-physical-interface')

            metas_to_read = set(all_metas) & set(req_metas)

        srch_meta = ' or '.join(metas_to_read)
        srch_result = self._search(start_id, srch_meta)

        result_list = self.parse_result_items(srch_result, ifmap_id)
        if (len(result_list) == 1 and 
            result_list[0][2] == None):
            return (False, 'physical-router ' + ifmap_id + 'does not exist')

        # metas is a dict where key is meta-name and val is list of tuples
        # of form (ident1, ident2, meta)
        metas = {}
        for r_elem in result_list:
            r_meta = r_elem[2]
            # create contrail:<tag>
            meta_name = r_meta.prefix + ':' + re.sub('{.*}', '', r_meta.tag)

            if (
                (meta_name == 'contrail:physical-router-bgp-router') or
                (meta_name == 'contrail:id-perms') or
                (meta_name == 'contrail:physical-router-physical-interface')
               ):
                if metas.has_key(meta_name):
                    metas[meta_name].append(r_elem)
                else: # first ident for this link-type
                    metas[meta_name] = [r_elem]

         # Construct dicts from xml
        result = {}
        result['_type'] = 'physical-router'
        fq_name = self._db_client_mgr.ifmap_id_to_fq_name(ifmap_id)
        result['fq_name'] = fq_name
        result['name'] = fq_name[-1]
        if metas.has_key('contrail:physical-router-bgp-router'):
            result['bgp_router_refs'] = []
            result_elems = metas['contrail:physical-router-bgp-router']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                obj_val = {}
                # in case of refs between same types of identifiers,
                # the referred ident could appears at idx 0 or 1
                if ifmap_id == r_elem[0].attrib['name']:
                    ref_ifmap_id = r_elem[1].attrib['name']
                else:
                    ref_ifmap_id = r_elem[0].attrib['name']

                try:
                    ref_fq_name = self._db_client_mgr.ifmap_id_to_fq_name(ref_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown fq_name for ref ' + ref_ifmap_id
                    return (False, err_msg)
                try:
                    ref_uuid = self._db_client_mgr.ifmap_id_to_uuid(ref_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown uuid for ref ' + ref_ifmap_id
                    return (False, err_msg)

                ref_url = self._db_client_mgr.generate_url('bgp_router', ref_uuid)
                ref_info = {}
                ref_info['to'] = ref_fq_name
                ref_info['attr'] = obj_val
                ref_info['href'] = ref_url
                ref_info['uuid'] = ref_uuid
                result['bgp_router_refs'].append(ref_info)


        if metas.has_key('contrail:id-perms'):
            result_elems = metas['contrail:id-perms']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                # need to preserve type eg. int for prefix-len
                # for now, xml -> obj -> json -> dict
                # TODO TypeGenerator.py should have xml to dict method
                obj = IdPermsType()
                obj.build(meta)
                obj_json = ''
                obj_json = json.dumps(obj,
                    default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
                obj_val = json.loads(obj_json)
                result['id_perms'] = obj_val

        if metas.has_key('contrail:physical-router-physical-interface'):
            result['physical_interfaces'] = []
            result_elems = metas['contrail:physical-router-physical-interface']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                obj_val = {}
                has_ifmap_id = r_elem[1].attrib['name']

                try:
                    has_fq_name = self._db_client_mgr.ifmap_id_to_fq_name(has_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown fq_name for child ' + has_ifmap_id
                    return (False, err_msg)
                try:
                    has_uuid = self._db_client_mgr.ifmap_id_to_uuid(has_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown uuid for child ' + has_ifmap_id
                    return (False, err_msg)

                has_url = self._db_client_mgr.generate_url('physical_interface', has_uuid)
                has_info = {}
                has_info['to'] = has_fq_name
                has_info['attr'] = obj_val
                has_info['href'] = has_url
                has_info['uuid'] = has_uuid
                result['physical_interfaces'].append(has_info)


        return (True, result)
    #end _ifmap_physical_router_read

    def _ifmap_physical_router_update(self, ifmap_id, old_obj_dict, new_obj_dict):
        # remove properties that are no longer active
        if ('id_perms' in new_obj_dict) and (new_obj_dict['id_perms'] == None):
            self._delete_id_self_meta(ifmap_id, 'id-perms')

        # remove refs that are no longer active
        if ('bgp_router_refs' in old_obj_dict):
            old_refs = [tuple(ref['to']) for ref in old_obj_dict['bgp_router_refs']]
        else:
            old_refs = []
        if ('bgp_router_refs' in new_obj_dict):
            if new_obj_dict['bgp_router_refs'] == None:
                new_refs = []
            else:
                new_refs = [tuple(ref['to']) for ref in new_obj_dict['bgp_router_refs']]
        else: # no ref key in new_obj
            new_refs = old_refs

        old_set = set(old_refs)
        new_set = set(new_refs)
        inact_refs = old_set - new_set
        for inact_ref in inact_refs:
            to_imid = self.fq_name_to_ifmap_id('bgp-router', inact_ref)
            self._delete_id_pair_meta(ifmap_id, to_imid, 'contrail:physical-router-bgp-router')

        (ok, result) = self._ifmap_physical_router_set(ifmap_id, new_obj_dict)
        return (ok, result)
    #end _ifmap_physical_router_update

    def _ifmap_physical_router_list(self, parent_type, parent_fq_name):
        children_fq_names = []
        mapclient = self._mapclient
        parent_imid = common.imid.get_ifmap_id_from_fq_name(parent_type, parent_fq_name)
        start_id = str(Identity(name = parent_imid, type = 'other',
                        other_type = 'extended'))
        # if id-perms missing, identity doesn't exist
        parent_link_meta = self._parent_metas[parent_type]['physical-router']
        srch_meta = 'contrail:' + parent_link_meta
        srch_result = self._search(start_id, srch_meta)

        result_list = self.parse_result_items(srch_result, parent_imid)
        for r_elem in result_list:
            child_ident = r_elem[1]
            if child_ident is None:
                continue
            child_imid = child_ident.attrib['name']
            fq_name = self._db_client_mgr.ifmap_id_to_fq_name(child_imid)
            children_fq_names.append(fq_name)


        return (True, children_fq_names)
    #end _ifmap_physical_router_list

    def _ifmap_physical_router_delete(self, obj_ids):
        ifmap_id = obj_ids['imid']
        parent_imid = obj_ids.get('parent_imid', None)
        start_id = str(Identity(name = ifmap_id, type = 'other',
                        other_type = 'extended'))
        # Delete links to our references, first find them
        srch_meta = ' or '.join([u'contrail:physical-router-bgp-router'])
        srch_result = self._search(start_id, srch_meta)

        result_list = self.parse_result_items(srch_result, ifmap_id)
        for r_elem in result_list:
            to_ident = r_elem[1]
            if to_ident is None:
                continue
            to_imid = to_ident.attrib['name']
            r_meta = r_elem[2]
            # create contrail:<tag>
            meta_name = r_meta.prefix + ':' + re.sub('{.*}', '', r_meta.tag)
            self._delete_id_pair_meta(ifmap_id, to_imid, meta_name)


        if parent_imid:
            # Remove link from parent
            self._delete_id_pair_meta(parent_imid, ifmap_id, None)

        # Remove all property metadata associated with this ident
        self._delete_id_self_meta(ifmap_id, None)

        return (True, '')
    #end _ifmap_physical_router_delete

    def _ifmap_bgp_router_alloc(self, parent_type, fq_name):
        imid = self._imid_handler
        (my_imid, parent_imid) = \
            imid.bgp_router_alloc_ifmap_id(parent_type, fq_name)
        return (True, (my_imid, parent_imid))
    #end _ifmap_bgp_router_alloc

    def _ifmap_bgp_router_set(self, my_imid, obj_dict):
        # Properties Meta
        field = obj_dict.get('bgp_router_parameters', None)
        if field:
            # construct object of xsd-type and get its xml repr
            field = obj_dict['bgp_router_parameters']
            buf = cStringIO.StringIO()
            # perms might be inserted at server as obj.
            # obj construction diff from dict construction.
            if isinstance(field, dict):
                BgpRouterParams(**field).exportChildren(buf, level = 1, name_ = 'bgp-router-parameters', pretty_print = False)
            else: # object
                field.exportChildren(buf, level = 1, name_ = 'bgp-router-parameters', pretty_print = False)
            bgp_router_parameters_xml = buf.getvalue()
            buf.close()
            meta = str(Metadata('bgp-router-parameters' , '',
                   {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail',
                   elements = bgp_router_parameters_xml))
            self._publish_id_self_meta(my_imid, meta)

        field = obj_dict.get('id_perms', None)
        if field:
            # construct object of xsd-type and get its xml repr
            field = obj_dict['id_perms']
            buf = cStringIO.StringIO()
            # perms might be inserted at server as obj.
            # obj construction diff from dict construction.
            if isinstance(field, dict):
                IdPermsType(**field).exportChildren(buf, level = 1, name_ = 'id-perms', pretty_print = False)
            else: # object
                field.exportChildren(buf, level = 1, name_ = 'id-perms', pretty_print = False)
            id_perms_xml = buf.getvalue()
            buf.close()
            meta = str(Metadata('id-perms' , '',
                   {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail',
                   elements = id_perms_xml))
            self._publish_id_self_meta(my_imid, meta)

        # Ref Link Metas
        imid = self._imid_handler

        # construct object of xsd-type and get its xml repr
        refs = obj_dict.get('bgp_router_refs', None)
        if refs:
            for ref in refs:
                ref_fq_name = ref['to']
                obj_type = 'bgp-router'
                to_imid = common.imid.get_ifmap_id_from_fq_name(obj_type, ref_fq_name)
                bgp_peering_xml = ''
                ref_data = ref['attr']
                if ref_data:
                    buf = cStringIO.StringIO()
                    BgpPeeringAttributes(**ref_data).exportChildren(buf, level = 1, name_ = 'bgp-peering', pretty_print = False)
                    bgp_peering_xml = bgp_peering_xml + buf.getvalue()
                    buf.close()
                meta = str(Metadata('bgp-peering' , '',
                       {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail',
                       elements = bgp_peering_xml))
                self._publish_id_pair_meta(my_imid, to_imid, meta)


        return (True, '')
    #end _ifmap_bgp_router_set

    def _ifmap_bgp_router_create(self, obj_ids, obj_dict):
        if not 'parent_type' in obj_dict:
            # parent is config-root
            parent_type = 'config-root'
            parent_imid = 'contrail:config-root:root'
        else:
            parent_type = obj_dict['parent_type']
            parent_imid = obj_ids.get('parent_imid', None)

        # Parent Link Meta
        parent_link_meta = self._parent_metas[parent_type]['bgp-router']
        meta = str(Metadata(parent_link_meta, '',
                   {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail'))
        self._publish_id_pair_meta(parent_imid, obj_ids['imid'], meta)

        (ok, result) = self._ifmap_bgp_router_set(obj_ids['imid'], obj_dict)
        return (ok, result)
    #end _ifmap_bgp_router_create

    def _ifmap_bgp_router_read(self, ifmap_id, field_names = None):
        # field_names = None means all fields will be read
        imid = self._imid_handler
        mapclient = self._mapclient
        start_id = str(Identity(name = ifmap_id, type = 'other',
                        other_type = 'extended'))
        # if id-perms missing, identity doesn't exist

        all_metas = [u'contrail:bgp-peering', u'contrail:global-system-config-bgp-router', u'contrail:physical-router-bgp-router', u'contrail:virtual-router-bgp-router', u'contrail:bgp-peering', u'contrail:bgp-router-parameters', u'contrail:id-perms']
        if not field_names:
            metas_to_read = all_metas
        else: # read only requested fields
            req_metas = []
            if field_names.has_key('bgp_router_refs'):
                req_metas.append('contrail:bgp-peering')
            if field_names.has_key('global_system_config_back_refs'):
                req_metas.append('contrail:global-system-config-bgp-router')
            if field_names.has_key('physical_router_back_refs'):
                req_metas.append('contrail:physical-router-bgp-router')
            if field_names.has_key('virtual_router_back_refs'):
                req_metas.append('contrail:virtual-router-bgp-router')
            if field_names.has_key('bgp_router_refs'):
                req_metas.append('contrail:bgp-peering')
            if field_names.has_key('bgp_router_parameters'):
                req_metas.append('contrail:bgp-router-parameters')
            if field_names.has_key('id_perms'):
                req_metas.append('contrail:id-perms')

            metas_to_read = set(all_metas) & set(req_metas)

        srch_meta = ' or '.join(metas_to_read)
        srch_result = self._search(start_id, srch_meta)

        result_list = self.parse_result_items(srch_result, ifmap_id)
        if (len(result_list) == 1 and 
            result_list[0][2] == None):
            return (False, 'bgp-router ' + ifmap_id + 'does not exist')

        # metas is a dict where key is meta-name and val is list of tuples
        # of form (ident1, ident2, meta)
        metas = {}
        for r_elem in result_list:
            r_meta = r_elem[2]
            # create contrail:<tag>
            meta_name = r_meta.prefix + ':' + re.sub('{.*}', '', r_meta.tag)

            if (
                (meta_name == 'contrail:bgp-peering') or
                (meta_name == 'contrail:global-system-config-bgp-router') or
                (meta_name == 'contrail:physical-router-bgp-router') or
                (meta_name == 'contrail:virtual-router-bgp-router') or
                (meta_name == 'contrail:bgp-peering') or
                (meta_name == 'contrail:bgp-router-parameters') or
                (meta_name == 'contrail:id-perms')
               ):
                if metas.has_key(meta_name):
                    metas[meta_name].append(r_elem)
                else: # first ident for this link-type
                    metas[meta_name] = [r_elem]

         # Construct dicts from xml
        result = {}
        result['_type'] = 'bgp-router'
        fq_name = self._db_client_mgr.ifmap_id_to_fq_name(ifmap_id)
        result['fq_name'] = fq_name
        result['name'] = fq_name[-1]
        if metas.has_key('contrail:bgp-peering'):
            result['bgp_router_refs'] = []
            result_elems = metas['contrail:bgp-peering']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                # need to preserve type eg. int for prefix-len
                # for now, xml -> obj -> json -> dict
                # TODO TypeGenerator.py should have xml to dict method
                obj = BgpPeeringAttributes()
                obj.build(meta)
                obj_json = ''
                obj_json = json.dumps(obj,
                    default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
                obj_val = json.loads(obj_json)
                # in case of refs between same types of identifiers,
                # the referred ident could appears at idx 0 or 1
                if ifmap_id == r_elem[0].attrib['name']:
                    ref_ifmap_id = r_elem[1].attrib['name']
                else:
                    ref_ifmap_id = r_elem[0].attrib['name']

                try:
                    ref_fq_name = self._db_client_mgr.ifmap_id_to_fq_name(ref_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown fq_name for ref ' + ref_ifmap_id
                    return (False, err_msg)
                try:
                    ref_uuid = self._db_client_mgr.ifmap_id_to_uuid(ref_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown uuid for ref ' + ref_ifmap_id
                    return (False, err_msg)

                ref_url = self._db_client_mgr.generate_url('bgp_router', ref_uuid)
                ref_info = {}
                ref_info['to'] = ref_fq_name
                ref_info['attr'] = obj_val
                ref_info['href'] = ref_url
                ref_info['uuid'] = ref_uuid
                result['bgp_router_refs'].append(ref_info)


        if metas.has_key('contrail:global-system-config-bgp-router'):
            result['global_system_config_back_refs'] = []
            result_elems = metas['contrail:global-system-config-bgp-router']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                obj_val = {}
                back_ref_ifmap_id = r_elem[0].attrib['name']

                try:
                    back_ref_fq_name = self._db_client_mgr.ifmap_id_to_fq_name(back_ref_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown fq_name for backref ' + back_ref_ifmap_id
                    return (False, err_msg)
                try:
                    back_ref_uuid = self._db_client_mgr.ifmap_id_to_uuid(back_ref_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown uuid for backref ' + back_ref_ifmap_id
                    return (False, err_msg)

                back_ref_url = self._db_client_mgr.generate_url('global_system_config', back_ref_uuid)
                back_ref_info = {}
                back_ref_info['to'] = back_ref_fq_name
                back_ref_info['attr'] = obj_val
                back_ref_info['href'] = back_ref_url
                back_ref_info['uuid'] = back_ref_uuid
                result['global_system_config_back_refs'].append(back_ref_info)


        if metas.has_key('contrail:physical-router-bgp-router'):
            result['physical_router_back_refs'] = []
            result_elems = metas['contrail:physical-router-bgp-router']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                obj_val = {}
                back_ref_ifmap_id = r_elem[0].attrib['name']

                try:
                    back_ref_fq_name = self._db_client_mgr.ifmap_id_to_fq_name(back_ref_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown fq_name for backref ' + back_ref_ifmap_id
                    return (False, err_msg)
                try:
                    back_ref_uuid = self._db_client_mgr.ifmap_id_to_uuid(back_ref_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown uuid for backref ' + back_ref_ifmap_id
                    return (False, err_msg)

                back_ref_url = self._db_client_mgr.generate_url('physical_router', back_ref_uuid)
                back_ref_info = {}
                back_ref_info['to'] = back_ref_fq_name
                back_ref_info['attr'] = obj_val
                back_ref_info['href'] = back_ref_url
                back_ref_info['uuid'] = back_ref_uuid
                result['physical_router_back_refs'].append(back_ref_info)


        if metas.has_key('contrail:virtual-router-bgp-router'):
            result['virtual_router_back_refs'] = []
            result_elems = metas['contrail:virtual-router-bgp-router']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                obj_val = {}
                back_ref_ifmap_id = r_elem[0].attrib['name']

                try:
                    back_ref_fq_name = self._db_client_mgr.ifmap_id_to_fq_name(back_ref_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown fq_name for backref ' + back_ref_ifmap_id
                    return (False, err_msg)
                try:
                    back_ref_uuid = self._db_client_mgr.ifmap_id_to_uuid(back_ref_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown uuid for backref ' + back_ref_ifmap_id
                    return (False, err_msg)

                back_ref_url = self._db_client_mgr.generate_url('virtual_router', back_ref_uuid)
                back_ref_info = {}
                back_ref_info['to'] = back_ref_fq_name
                back_ref_info['attr'] = obj_val
                back_ref_info['href'] = back_ref_url
                back_ref_info['uuid'] = back_ref_uuid
                result['virtual_router_back_refs'].append(back_ref_info)


        if metas.has_key('contrail:bgp-peering'):
            result['bgp_router_refs'] = []
            result_elems = metas['contrail:bgp-peering']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                # need to preserve type eg. int for prefix-len
                # for now, xml -> obj -> json -> dict
                # TODO TypeGenerator.py should have xml to dict method
                obj = BgpPeeringAttributes()
                obj.build(meta)
                obj_json = ''
                obj_json = json.dumps(obj,
                    default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
                obj_val = json.loads(obj_json)
                # in case of refs between same types of identifiers,
                # the referred ident could appears at idx 0 or 1
                if ifmap_id == r_elem[0].attrib['name']:
                    ref_ifmap_id = r_elem[1].attrib['name']
                else:
                    ref_ifmap_id = r_elem[0].attrib['name']

                try:
                    ref_fq_name = self._db_client_mgr.ifmap_id_to_fq_name(ref_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown fq_name for ref ' + ref_ifmap_id
                    return (False, err_msg)
                try:
                    ref_uuid = self._db_client_mgr.ifmap_id_to_uuid(ref_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown uuid for ref ' + ref_ifmap_id
                    return (False, err_msg)

                ref_url = self._db_client_mgr.generate_url('bgp_router', ref_uuid)
                ref_info = {}
                ref_info['to'] = ref_fq_name
                ref_info['attr'] = obj_val
                ref_info['href'] = ref_url
                ref_info['uuid'] = ref_uuid
                result['bgp_router_refs'].append(ref_info)


        if metas.has_key('contrail:bgp-router-parameters'):
            result_elems = metas['contrail:bgp-router-parameters']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                # need to preserve type eg. int for prefix-len
                # for now, xml -> obj -> json -> dict
                # TODO TypeGenerator.py should have xml to dict method
                obj = BgpRouterParams()
                obj.build(meta)
                obj_json = ''
                obj_json = json.dumps(obj,
                    default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
                obj_val = json.loads(obj_json)
                result['bgp_router_parameters'] = obj_val

        if metas.has_key('contrail:id-perms'):
            result_elems = metas['contrail:id-perms']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                # need to preserve type eg. int for prefix-len
                # for now, xml -> obj -> json -> dict
                # TODO TypeGenerator.py should have xml to dict method
                obj = IdPermsType()
                obj.build(meta)
                obj_json = ''
                obj_json = json.dumps(obj,
                    default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
                obj_val = json.loads(obj_json)
                result['id_perms'] = obj_val

        return (True, result)
    #end _ifmap_bgp_router_read

    def _ifmap_bgp_router_update(self, ifmap_id, old_obj_dict, new_obj_dict):
        # remove properties that are no longer active
        if ('bgp_router_parameters' in new_obj_dict) and (new_obj_dict['bgp_router_parameters'] == None):
            self._delete_id_self_meta(ifmap_id, 'bgp-router-parameters')

        if ('id_perms' in new_obj_dict) and (new_obj_dict['id_perms'] == None):
            self._delete_id_self_meta(ifmap_id, 'id-perms')

        # remove refs that are no longer active
        if ('bgp_router_refs' in old_obj_dict):
            old_refs = [tuple(ref['to']) for ref in old_obj_dict['bgp_router_refs']]
        else:
            old_refs = []
        if ('bgp_router_refs' in new_obj_dict):
            if new_obj_dict['bgp_router_refs'] == None:
                new_refs = []
            else:
                new_refs = [tuple(ref['to']) for ref in new_obj_dict['bgp_router_refs']]
        else: # no ref key in new_obj
            new_refs = old_refs

        old_set = set(old_refs)
        new_set = set(new_refs)
        inact_refs = old_set - new_set
        for inact_ref in inact_refs:
            to_imid = self.fq_name_to_ifmap_id('bgp-router', inact_ref)
            self._delete_id_pair_meta(ifmap_id, to_imid, 'contrail:bgp-peering')

        (ok, result) = self._ifmap_bgp_router_set(ifmap_id, new_obj_dict)
        return (ok, result)
    #end _ifmap_bgp_router_update

    def _ifmap_bgp_router_list(self, parent_type, parent_fq_name):
        children_fq_names = []
        mapclient = self._mapclient
        parent_imid = common.imid.get_ifmap_id_from_fq_name(parent_type, parent_fq_name)
        start_id = str(Identity(name = parent_imid, type = 'other',
                        other_type = 'extended'))
        # if id-perms missing, identity doesn't exist
        parent_link_meta = self._parent_metas[parent_type]['bgp-router']
        srch_meta = 'contrail:' + parent_link_meta
        srch_result = self._search(start_id, srch_meta)

        result_list = self.parse_result_items(srch_result, parent_imid)
        for r_elem in result_list:
            child_ident = r_elem[1]
            if child_ident is None:
                continue
            child_imid = child_ident.attrib['name']
            fq_name = self._db_client_mgr.ifmap_id_to_fq_name(child_imid)
            children_fq_names.append(fq_name)


        return (True, children_fq_names)
    #end _ifmap_bgp_router_list

    def _ifmap_bgp_router_delete(self, obj_ids):
        ifmap_id = obj_ids['imid']
        parent_imid = obj_ids.get('parent_imid', None)
        start_id = str(Identity(name = ifmap_id, type = 'other',
                        other_type = 'extended'))
        # Delete links to our references, first find them
        srch_meta = ' or '.join([u'contrail:bgp-peering'])
        srch_result = self._search(start_id, srch_meta)

        result_list = self.parse_result_items(srch_result, ifmap_id)
        for r_elem in result_list:
            to_ident = r_elem[1]
            if to_ident is None:
                continue
            to_imid = to_ident.attrib['name']
            r_meta = r_elem[2]
            # create contrail:<tag>
            meta_name = r_meta.prefix + ':' + re.sub('{.*}', '', r_meta.tag)
            self._delete_id_pair_meta(ifmap_id, to_imid, meta_name)


        if parent_imid:
            # Remove link from parent
            self._delete_id_pair_meta(parent_imid, ifmap_id, None)

        # Remove all property metadata associated with this ident
        self._delete_id_self_meta(ifmap_id, None)

        return (True, '')
    #end _ifmap_bgp_router_delete

    def _ifmap_virtual_router_alloc(self, parent_type, fq_name):
        imid = self._imid_handler
        (my_imid, parent_imid) = \
            imid.virtual_router_alloc_ifmap_id(parent_type, fq_name)
        return (True, (my_imid, parent_imid))
    #end _ifmap_virtual_router_alloc

    def _ifmap_virtual_router_set(self, my_imid, obj_dict):
        # Properties Meta
        field = obj_dict.get('virtual_router_ip_address', None)
        if field:
            meta = str(Metadata('virtual-router-ip-address' , str(obj_dict['virtual_router_ip_address']),
                   {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail'))
            self._publish_id_self_meta(my_imid, meta)

        field = obj_dict.get('id_perms', None)
        if field:
            # construct object of xsd-type and get its xml repr
            field = obj_dict['id_perms']
            buf = cStringIO.StringIO()
            # perms might be inserted at server as obj.
            # obj construction diff from dict construction.
            if isinstance(field, dict):
                IdPermsType(**field).exportChildren(buf, level = 1, name_ = 'id-perms', pretty_print = False)
            else: # object
                field.exportChildren(buf, level = 1, name_ = 'id-perms', pretty_print = False)
            id_perms_xml = buf.getvalue()
            buf.close()
            meta = str(Metadata('id-perms' , '',
                   {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail',
                   elements = id_perms_xml))
            self._publish_id_self_meta(my_imid, meta)

        # Ref Link Metas
        imid = self._imid_handler

        # construct object of xsd-type and get its xml repr
        refs = obj_dict.get('bgp_router_refs', None)
        if refs:
            for ref in refs:
                ref_fq_name = ref['to']
                obj_type = 'bgp-router'
                to_imid = common.imid.get_ifmap_id_from_fq_name(obj_type, ref_fq_name)
                virtual_router_bgp_router_xml = ''
                meta = str(Metadata('virtual-router-bgp-router' , '',
                       {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail',
                       elements = virtual_router_bgp_router_xml))
                self._publish_id_pair_meta(my_imid, to_imid, meta)

        # construct object of xsd-type and get its xml repr
        refs = obj_dict.get('virtual_machine_refs', None)
        if refs:
            for ref in refs:
                ref_fq_name = ref['to']
                obj_type = 'virtual-machine'
                to_imid = common.imid.get_ifmap_id_from_fq_name(obj_type, ref_fq_name)
                virtual_router_virtual_machine_xml = ''
                meta = str(Metadata('virtual-router-virtual-machine' , '',
                       {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail',
                       elements = virtual_router_virtual_machine_xml))
                self._publish_id_pair_meta(my_imid, to_imid, meta)


        return (True, '')
    #end _ifmap_virtual_router_set

    def _ifmap_virtual_router_create(self, obj_ids, obj_dict):
        if not 'parent_type' in obj_dict:
            # parent is config-root
            parent_type = 'config-root'
            parent_imid = 'contrail:config-root:root'
        else:
            parent_type = obj_dict['parent_type']
            parent_imid = obj_ids.get('parent_imid', None)

        # Parent Link Meta
        parent_link_meta = self._parent_metas[parent_type]['virtual-router']
        meta = str(Metadata(parent_link_meta, '',
                   {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail'))
        self._publish_id_pair_meta(parent_imid, obj_ids['imid'], meta)

        (ok, result) = self._ifmap_virtual_router_set(obj_ids['imid'], obj_dict)
        return (ok, result)
    #end _ifmap_virtual_router_create

    def _ifmap_virtual_router_read(self, ifmap_id, field_names = None):
        # field_names = None means all fields will be read
        imid = self._imid_handler
        mapclient = self._mapclient
        start_id = str(Identity(name = ifmap_id, type = 'other',
                        other_type = 'extended'))
        # if id-perms missing, identity doesn't exist

        all_metas = [u'contrail:virtual-router-bgp-router', u'contrail:virtual-router-virtual-machine', u'contrail:provider-attachment-virtual-router', u'contrail:virtual-router-ip-address', u'contrail:id-perms']
        if not field_names:
            metas_to_read = all_metas
        else: # read only requested fields
            req_metas = []
            if field_names.has_key('bgp_router_refs'):
                req_metas.append('contrail:virtual-router-bgp-router')
            if field_names.has_key('virtual_machine_refs'):
                req_metas.append('contrail:virtual-router-virtual-machine')
            if field_names.has_key('provider_attachment_back_refs'):
                req_metas.append('contrail:provider-attachment-virtual-router')
            if field_names.has_key('virtual_router_ip_address'):
                req_metas.append('contrail:virtual-router-ip-address')
            if field_names.has_key('id_perms'):
                req_metas.append('contrail:id-perms')

            metas_to_read = set(all_metas) & set(req_metas)

        srch_meta = ' or '.join(metas_to_read)
        srch_result = self._search(start_id, srch_meta)

        result_list = self.parse_result_items(srch_result, ifmap_id)
        if (len(result_list) == 1 and 
            result_list[0][2] == None):
            return (False, 'virtual-router ' + ifmap_id + 'does not exist')

        # metas is a dict where key is meta-name and val is list of tuples
        # of form (ident1, ident2, meta)
        metas = {}
        for r_elem in result_list:
            r_meta = r_elem[2]
            # create contrail:<tag>
            meta_name = r_meta.prefix + ':' + re.sub('{.*}', '', r_meta.tag)

            if (
                (meta_name == 'contrail:virtual-router-bgp-router') or
                (meta_name == 'contrail:virtual-router-virtual-machine') or
                (meta_name == 'contrail:provider-attachment-virtual-router') or
                (meta_name == 'contrail:virtual-router-ip-address') or
                (meta_name == 'contrail:id-perms')
               ):
                if metas.has_key(meta_name):
                    metas[meta_name].append(r_elem)
                else: # first ident for this link-type
                    metas[meta_name] = [r_elem]

         # Construct dicts from xml
        result = {}
        result['_type'] = 'virtual-router'
        fq_name = self._db_client_mgr.ifmap_id_to_fq_name(ifmap_id)
        result['fq_name'] = fq_name
        result['name'] = fq_name[-1]
        if metas.has_key('contrail:virtual-router-bgp-router'):
            result['bgp_router_refs'] = []
            result_elems = metas['contrail:virtual-router-bgp-router']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                obj_val = {}
                # in case of refs between same types of identifiers,
                # the referred ident could appears at idx 0 or 1
                if ifmap_id == r_elem[0].attrib['name']:
                    ref_ifmap_id = r_elem[1].attrib['name']
                else:
                    ref_ifmap_id = r_elem[0].attrib['name']

                try:
                    ref_fq_name = self._db_client_mgr.ifmap_id_to_fq_name(ref_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown fq_name for ref ' + ref_ifmap_id
                    return (False, err_msg)
                try:
                    ref_uuid = self._db_client_mgr.ifmap_id_to_uuid(ref_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown uuid for ref ' + ref_ifmap_id
                    return (False, err_msg)

                ref_url = self._db_client_mgr.generate_url('bgp_router', ref_uuid)
                ref_info = {}
                ref_info['to'] = ref_fq_name
                ref_info['attr'] = obj_val
                ref_info['href'] = ref_url
                ref_info['uuid'] = ref_uuid
                result['bgp_router_refs'].append(ref_info)


        if metas.has_key('contrail:virtual-router-virtual-machine'):
            result['virtual_machine_refs'] = []
            result_elems = metas['contrail:virtual-router-virtual-machine']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                obj_val = {}
                # in case of refs between same types of identifiers,
                # the referred ident could appears at idx 0 or 1
                if ifmap_id == r_elem[0].attrib['name']:
                    ref_ifmap_id = r_elem[1].attrib['name']
                else:
                    ref_ifmap_id = r_elem[0].attrib['name']

                try:
                    ref_fq_name = self._db_client_mgr.ifmap_id_to_fq_name(ref_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown fq_name for ref ' + ref_ifmap_id
                    return (False, err_msg)
                try:
                    ref_uuid = self._db_client_mgr.ifmap_id_to_uuid(ref_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown uuid for ref ' + ref_ifmap_id
                    return (False, err_msg)

                ref_url = self._db_client_mgr.generate_url('virtual_machine', ref_uuid)
                ref_info = {}
                ref_info['to'] = ref_fq_name
                ref_info['attr'] = obj_val
                ref_info['href'] = ref_url
                ref_info['uuid'] = ref_uuid
                result['virtual_machine_refs'].append(ref_info)


        if metas.has_key('contrail:provider-attachment-virtual-router'):
            result['provider_attachment_back_refs'] = []
            result_elems = metas['contrail:provider-attachment-virtual-router']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                obj_val = {}
                back_ref_ifmap_id = r_elem[0].attrib['name']

                try:
                    back_ref_fq_name = self._db_client_mgr.ifmap_id_to_fq_name(back_ref_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown fq_name for backref ' + back_ref_ifmap_id
                    return (False, err_msg)
                try:
                    back_ref_uuid = self._db_client_mgr.ifmap_id_to_uuid(back_ref_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown uuid for backref ' + back_ref_ifmap_id
                    return (False, err_msg)

                back_ref_url = self._db_client_mgr.generate_url('provider_attachment', back_ref_uuid)
                back_ref_info = {}
                back_ref_info['to'] = back_ref_fq_name
                back_ref_info['attr'] = obj_val
                back_ref_info['href'] = back_ref_url
                back_ref_info['uuid'] = back_ref_uuid
                result['provider_attachment_back_refs'].append(back_ref_info)


        if metas.has_key('contrail:virtual-router-ip-address'):
            result_elems = metas['contrail:virtual-router-ip-address']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                obj_val = meta.text
                result['virtual_router_ip_address'] = obj_val

        if metas.has_key('contrail:id-perms'):
            result_elems = metas['contrail:id-perms']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                # need to preserve type eg. int for prefix-len
                # for now, xml -> obj -> json -> dict
                # TODO TypeGenerator.py should have xml to dict method
                obj = IdPermsType()
                obj.build(meta)
                obj_json = ''
                obj_json = json.dumps(obj,
                    default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
                obj_val = json.loads(obj_json)
                result['id_perms'] = obj_val

        return (True, result)
    #end _ifmap_virtual_router_read

    def _ifmap_virtual_router_update(self, ifmap_id, old_obj_dict, new_obj_dict):
        # remove properties that are no longer active
        if ('virtual_router_ip_address' in new_obj_dict) and (new_obj_dict['virtual_router_ip_address'] == None):
            self._delete_id_self_meta(ifmap_id, 'virtual-router-ip-address')

        if ('id_perms' in new_obj_dict) and (new_obj_dict['id_perms'] == None):
            self._delete_id_self_meta(ifmap_id, 'id-perms')

        # remove refs that are no longer active
        if ('bgp_router_refs' in old_obj_dict):
            old_refs = [tuple(ref['to']) for ref in old_obj_dict['bgp_router_refs']]
        else:
            old_refs = []
        if ('bgp_router_refs' in new_obj_dict):
            if new_obj_dict['bgp_router_refs'] == None:
                new_refs = []
            else:
                new_refs = [tuple(ref['to']) for ref in new_obj_dict['bgp_router_refs']]
        else: # no ref key in new_obj
            new_refs = old_refs

        old_set = set(old_refs)
        new_set = set(new_refs)
        inact_refs = old_set - new_set
        for inact_ref in inact_refs:
            to_imid = self.fq_name_to_ifmap_id('bgp-router', inact_ref)
            self._delete_id_pair_meta(ifmap_id, to_imid, 'contrail:virtual-router-bgp-router')

        if ('virtual_machine_refs' in old_obj_dict):
            old_refs = [tuple(ref['to']) for ref in old_obj_dict['virtual_machine_refs']]
        else:
            old_refs = []
        if ('virtual_machine_refs' in new_obj_dict):
            if new_obj_dict['virtual_machine_refs'] == None:
                new_refs = []
            else:
                new_refs = [tuple(ref['to']) for ref in new_obj_dict['virtual_machine_refs']]
        else: # no ref key in new_obj
            new_refs = old_refs

        old_set = set(old_refs)
        new_set = set(new_refs)
        inact_refs = old_set - new_set
        for inact_ref in inact_refs:
            to_imid = self.fq_name_to_ifmap_id('virtual-machine', inact_ref)
            self._delete_id_pair_meta(ifmap_id, to_imid, 'contrail:virtual-router-virtual-machine')

        (ok, result) = self._ifmap_virtual_router_set(ifmap_id, new_obj_dict)
        return (ok, result)
    #end _ifmap_virtual_router_update

    def _ifmap_virtual_router_list(self, parent_type, parent_fq_name):
        children_fq_names = []
        mapclient = self._mapclient
        parent_imid = common.imid.get_ifmap_id_from_fq_name(parent_type, parent_fq_name)
        start_id = str(Identity(name = parent_imid, type = 'other',
                        other_type = 'extended'))
        # if id-perms missing, identity doesn't exist
        parent_link_meta = self._parent_metas[parent_type]['virtual-router']
        srch_meta = 'contrail:' + parent_link_meta
        srch_result = self._search(start_id, srch_meta)

        result_list = self.parse_result_items(srch_result, parent_imid)
        for r_elem in result_list:
            child_ident = r_elem[1]
            if child_ident is None:
                continue
            child_imid = child_ident.attrib['name']
            fq_name = self._db_client_mgr.ifmap_id_to_fq_name(child_imid)
            children_fq_names.append(fq_name)


        return (True, children_fq_names)
    #end _ifmap_virtual_router_list

    def _ifmap_virtual_router_delete(self, obj_ids):
        ifmap_id = obj_ids['imid']
        parent_imid = obj_ids.get('parent_imid', None)
        start_id = str(Identity(name = ifmap_id, type = 'other',
                        other_type = 'extended'))
        # Delete links to our references, first find them
        srch_meta = ' or '.join([u'contrail:virtual-router-bgp-router', u'contrail:virtual-router-virtual-machine'])
        srch_result = self._search(start_id, srch_meta)

        result_list = self.parse_result_items(srch_result, ifmap_id)
        for r_elem in result_list:
            to_ident = r_elem[1]
            if to_ident is None:
                continue
            to_imid = to_ident.attrib['name']
            r_meta = r_elem[2]
            # create contrail:<tag>
            meta_name = r_meta.prefix + ':' + re.sub('{.*}', '', r_meta.tag)
            self._delete_id_pair_meta(ifmap_id, to_imid, meta_name)


        if parent_imid:
            # Remove link from parent
            self._delete_id_pair_meta(parent_imid, ifmap_id, None)

        # Remove all property metadata associated with this ident
        self._delete_id_self_meta(ifmap_id, None)

        return (True, '')
    #end _ifmap_virtual_router_delete

    def _ifmap_config_root_alloc(self, parent_type, fq_name):
        imid = self._imid_handler
        (my_imid, parent_imid) = \
            imid.config_root_alloc_ifmap_id(parent_type, fq_name)
        return (True, (my_imid, parent_imid))
    #end _ifmap_config_root_alloc

    def _ifmap_config_root_set(self, my_imid, obj_dict):
        # Properties Meta
        field = obj_dict.get('id_perms', None)
        if field:
            # construct object of xsd-type and get its xml repr
            field = obj_dict['id_perms']
            buf = cStringIO.StringIO()
            # perms might be inserted at server as obj.
            # obj construction diff from dict construction.
            if isinstance(field, dict):
                IdPermsType(**field).exportChildren(buf, level = 1, name_ = 'id-perms', pretty_print = False)
            else: # object
                field.exportChildren(buf, level = 1, name_ = 'id-perms', pretty_print = False)
            id_perms_xml = buf.getvalue()
            buf.close()
            meta = str(Metadata('id-perms' , '',
                   {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail',
                   elements = id_perms_xml))
            self._publish_id_self_meta(my_imid, meta)

        # Ref Link Metas
        imid = self._imid_handler

        # construct object of xsd-type and get its xml repr
        refs = obj_dict.get('global_system_config_refs', None)
        if refs:
            for ref in refs:
                ref_fq_name = ref['to']
                obj_type = 'global-system-config'
                to_imid = common.imid.get_ifmap_id_from_fq_name(obj_type, ref_fq_name)
                config_root_global_system_config_xml = ''
                meta = str(Metadata('config-root-global-system-config' , '',
                       {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail',
                       elements = config_root_global_system_config_xml))
                self._publish_id_pair_meta(my_imid, to_imid, meta)

        # construct object of xsd-type and get its xml repr
        refs = obj_dict.get('domain_refs', None)
        if refs:
            for ref in refs:
                ref_fq_name = ref['to']
                obj_type = 'domain'
                to_imid = common.imid.get_ifmap_id_from_fq_name(obj_type, ref_fq_name)
                config_root_domain_xml = ''
                meta = str(Metadata('config-root-domain' , '',
                       {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail',
                       elements = config_root_domain_xml))
                self._publish_id_pair_meta(my_imid, to_imid, meta)


        return (True, '')
    #end _ifmap_config_root_set

    def _ifmap_config_root_create(self, obj_ids, obj_dict):
        (ok, result) = self._ifmap_config_root_set(obj_ids['imid'], obj_dict)
        return (ok, result)
    #end _ifmap_config_root_create

    def _ifmap_config_root_read(self, ifmap_id, field_names = None):
        # field_names = None means all fields will be read
        imid = self._imid_handler
        mapclient = self._mapclient
        start_id = str(Identity(name = ifmap_id, type = 'other',
                        other_type = 'extended'))
        # if id-perms missing, identity doesn't exist

        all_metas = [u'contrail:id-perms', u'contrail:config-root-global-system-config', u'contrail:config-root-domain']
        if not field_names:
            metas_to_read = all_metas
        else: # read only requested fields
            req_metas = []
            if field_names.has_key('id_perms'):
                req_metas.append('contrail:id-perms')
            if field_names.has_key('config_root_global_system_config'):
                req_metas.append('contrail:config-root-global-system-config')
            if field_names.has_key('config_root_domain'):
                req_metas.append('contrail:config-root-domain')

            metas_to_read = set(all_metas) & set(req_metas)

        srch_meta = ' or '.join(metas_to_read)
        srch_result = self._search(start_id, srch_meta)

        result_list = self.parse_result_items(srch_result, ifmap_id)
        if (len(result_list) == 1 and 
            result_list[0][2] == None):
            return (False, 'config-root ' + ifmap_id + 'does not exist')

        # metas is a dict where key is meta-name and val is list of tuples
        # of form (ident1, ident2, meta)
        metas = {}
        for r_elem in result_list:
            r_meta = r_elem[2]
            # create contrail:<tag>
            meta_name = r_meta.prefix + ':' + re.sub('{.*}', '', r_meta.tag)

            if (
                (meta_name == 'contrail:id-perms') or
                (meta_name == 'contrail:config-root-global-system-config') or
                (meta_name == 'contrail:config-root-domain')
               ):
                if metas.has_key(meta_name):
                    metas[meta_name].append(r_elem)
                else: # first ident for this link-type
                    metas[meta_name] = [r_elem]

         # Construct dicts from xml
        result = {}
        result['_type'] = 'config-root'
        fq_name = self._db_client_mgr.ifmap_id_to_fq_name(ifmap_id)
        result['fq_name'] = fq_name
        result['name'] = fq_name[-1]
        if metas.has_key('contrail:id-perms'):
            result_elems = metas['contrail:id-perms']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                # need to preserve type eg. int for prefix-len
                # for now, xml -> obj -> json -> dict
                # TODO TypeGenerator.py should have xml to dict method
                obj = IdPermsType()
                obj.build(meta)
                obj_json = ''
                obj_json = json.dumps(obj,
                    default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
                obj_val = json.loads(obj_json)
                result['id_perms'] = obj_val

        if metas.has_key('contrail:config-root-global-system-config'):
            result['global_system_configs'] = []
            result_elems = metas['contrail:config-root-global-system-config']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                obj_val = {}
                has_ifmap_id = r_elem[1].attrib['name']

                try:
                    has_fq_name = self._db_client_mgr.ifmap_id_to_fq_name(has_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown fq_name for child ' + has_ifmap_id
                    return (False, err_msg)
                try:
                    has_uuid = self._db_client_mgr.ifmap_id_to_uuid(has_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown uuid for child ' + has_ifmap_id
                    return (False, err_msg)

                has_url = self._db_client_mgr.generate_url('global_system_config', has_uuid)
                has_info = {}
                has_info['to'] = has_fq_name
                has_info['attr'] = obj_val
                has_info['href'] = has_url
                has_info['uuid'] = has_uuid
                result['global_system_configs'].append(has_info)


        if metas.has_key('contrail:config-root-domain'):
            result['domains'] = []
            result_elems = metas['contrail:config-root-domain']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                obj_val = {}
                has_ifmap_id = r_elem[1].attrib['name']

                try:
                    has_fq_name = self._db_client_mgr.ifmap_id_to_fq_name(has_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown fq_name for child ' + has_ifmap_id
                    return (False, err_msg)
                try:
                    has_uuid = self._db_client_mgr.ifmap_id_to_uuid(has_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown uuid for child ' + has_ifmap_id
                    return (False, err_msg)

                has_url = self._db_client_mgr.generate_url('domain', has_uuid)
                has_info = {}
                has_info['to'] = has_fq_name
                has_info['attr'] = obj_val
                has_info['href'] = has_url
                has_info['uuid'] = has_uuid
                result['domains'].append(has_info)


        return (True, result)
    #end _ifmap_config_root_read

    def _ifmap_config_root_update(self, ifmap_id, old_obj_dict, new_obj_dict):
        # remove properties that are no longer active
        if ('id_perms' in new_obj_dict) and (new_obj_dict['id_perms'] == None):
            self._delete_id_self_meta(ifmap_id, 'id-perms')

        # remove refs that are no longer active
        (ok, result) = self._ifmap_config_root_set(ifmap_id, new_obj_dict)
        return (ok, result)
    #end _ifmap_config_root_update

    def _ifmap_config_root_list(self, parent_type, parent_fq_name):
        children_fq_names = []
        return (True, children_fq_names)
    #end _ifmap_config_root_list

    def _ifmap_config_root_delete(self, obj_ids):
        ifmap_id = obj_ids['imid']
        parent_imid = obj_ids.get('parent_imid', None)
        start_id = str(Identity(name = ifmap_id, type = 'other',
                        other_type = 'extended'))

        if parent_imid:
            # Remove link from parent
            self._delete_id_pair_meta(parent_imid, ifmap_id, None)

        # Remove all property metadata associated with this ident
        self._delete_id_self_meta(ifmap_id, None)

        return (True, '')
    #end _ifmap_config_root_delete

    def _ifmap_global_system_config_alloc(self, parent_type, fq_name):
        imid = self._imid_handler
        (my_imid, parent_imid) = \
            imid.global_system_config_alloc_ifmap_id(parent_type, fq_name)
        return (True, (my_imid, parent_imid))
    #end _ifmap_global_system_config_alloc

    def _ifmap_global_system_config_set(self, my_imid, obj_dict):
        # Properties Meta
        field = obj_dict.get('autonomous_system', None)
        if field:
            meta = str(Metadata('autonomous-system' , str(obj_dict['autonomous_system']),
                   {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail'))
            self._publish_id_self_meta(my_imid, meta)

        field = obj_dict.get('id_perms', None)
        if field:
            # construct object of xsd-type and get its xml repr
            field = obj_dict['id_perms']
            buf = cStringIO.StringIO()
            # perms might be inserted at server as obj.
            # obj construction diff from dict construction.
            if isinstance(field, dict):
                IdPermsType(**field).exportChildren(buf, level = 1, name_ = 'id-perms', pretty_print = False)
            else: # object
                field.exportChildren(buf, level = 1, name_ = 'id-perms', pretty_print = False)
            id_perms_xml = buf.getvalue()
            buf.close()
            meta = str(Metadata('id-perms' , '',
                   {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail',
                   elements = id_perms_xml))
            self._publish_id_self_meta(my_imid, meta)

        # Ref Link Metas
        imid = self._imid_handler

        # construct object of xsd-type and get its xml repr
        refs = obj_dict.get('bgp_router_refs', None)
        if refs:
            for ref in refs:
                ref_fq_name = ref['to']
                obj_type = 'bgp-router'
                to_imid = common.imid.get_ifmap_id_from_fq_name(obj_type, ref_fq_name)
                global_system_config_bgp_router_xml = ''
                meta = str(Metadata('global-system-config-bgp-router' , '',
                       {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail',
                       elements = global_system_config_bgp_router_xml))
                self._publish_id_pair_meta(my_imid, to_imid, meta)

        # construct object of xsd-type and get its xml repr
        refs = obj_dict.get('physical_router_refs', None)
        if refs:
            for ref in refs:
                ref_fq_name = ref['to']
                obj_type = 'physical-router'
                to_imid = common.imid.get_ifmap_id_from_fq_name(obj_type, ref_fq_name)
                global_system_config_physical_router_xml = ''
                meta = str(Metadata('global-system-config-physical-router' , '',
                       {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail',
                       elements = global_system_config_physical_router_xml))
                self._publish_id_pair_meta(my_imid, to_imid, meta)

        # construct object of xsd-type and get its xml repr
        refs = obj_dict.get('virtual_router_refs', None)
        if refs:
            for ref in refs:
                ref_fq_name = ref['to']
                obj_type = 'virtual-router'
                to_imid = common.imid.get_ifmap_id_from_fq_name(obj_type, ref_fq_name)
                global_system_config_virtual_router_xml = ''
                meta = str(Metadata('global-system-config-virtual-router' , '',
                       {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail',
                       elements = global_system_config_virtual_router_xml))
                self._publish_id_pair_meta(my_imid, to_imid, meta)


        return (True, '')
    #end _ifmap_global_system_config_set

    def _ifmap_global_system_config_create(self, obj_ids, obj_dict):
        if not 'parent_type' in obj_dict:
            # parent is config-root
            parent_type = 'config-root'
            parent_imid = 'contrail:config-root:root'
        else:
            parent_type = obj_dict['parent_type']
            parent_imid = obj_ids.get('parent_imid', None)

        # Parent Link Meta
        parent_link_meta = self._parent_metas[parent_type]['global-system-config']
        meta = str(Metadata(parent_link_meta, '',
                   {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail'))
        self._publish_id_pair_meta(parent_imid, obj_ids['imid'], meta)

        (ok, result) = self._ifmap_global_system_config_set(obj_ids['imid'], obj_dict)
        return (ok, result)
    #end _ifmap_global_system_config_create

    def _ifmap_global_system_config_read(self, ifmap_id, field_names = None):
        # field_names = None means all fields will be read
        imid = self._imid_handler
        mapclient = self._mapclient
        start_id = str(Identity(name = ifmap_id, type = 'other',
                        other_type = 'extended'))
        # if id-perms missing, identity doesn't exist

        all_metas = [u'contrail:global-system-config-bgp-router', u'contrail:autonomous-system', u'contrail:id-perms', u'contrail:global-system-config-physical-router', u'contrail:global-system-config-virtual-router']
        if not field_names:
            metas_to_read = all_metas
        else: # read only requested fields
            req_metas = []
            if field_names.has_key('bgp_router_refs'):
                req_metas.append('contrail:global-system-config-bgp-router')
            if field_names.has_key('autonomous_system'):
                req_metas.append('contrail:autonomous-system')
            if field_names.has_key('id_perms'):
                req_metas.append('contrail:id-perms')
            if field_names.has_key('global_system_config_physical_router'):
                req_metas.append('contrail:global-system-config-physical-router')
            if field_names.has_key('global_system_config_virtual_router'):
                req_metas.append('contrail:global-system-config-virtual-router')

            metas_to_read = set(all_metas) & set(req_metas)

        srch_meta = ' or '.join(metas_to_read)
        srch_result = self._search(start_id, srch_meta)

        result_list = self.parse_result_items(srch_result, ifmap_id)
        if (len(result_list) == 1 and 
            result_list[0][2] == None):
            return (False, 'global-system-config ' + ifmap_id + 'does not exist')

        # metas is a dict where key is meta-name and val is list of tuples
        # of form (ident1, ident2, meta)
        metas = {}
        for r_elem in result_list:
            r_meta = r_elem[2]
            # create contrail:<tag>
            meta_name = r_meta.prefix + ':' + re.sub('{.*}', '', r_meta.tag)

            if (
                (meta_name == 'contrail:global-system-config-bgp-router') or
                (meta_name == 'contrail:autonomous-system') or
                (meta_name == 'contrail:id-perms') or
                (meta_name == 'contrail:global-system-config-physical-router') or
                (meta_name == 'contrail:global-system-config-virtual-router')
               ):
                if metas.has_key(meta_name):
                    metas[meta_name].append(r_elem)
                else: # first ident for this link-type
                    metas[meta_name] = [r_elem]

         # Construct dicts from xml
        result = {}
        result['_type'] = 'global-system-config'
        fq_name = self._db_client_mgr.ifmap_id_to_fq_name(ifmap_id)
        result['fq_name'] = fq_name
        result['name'] = fq_name[-1]
        if metas.has_key('contrail:global-system-config-bgp-router'):
            result['bgp_router_refs'] = []
            result_elems = metas['contrail:global-system-config-bgp-router']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                obj_val = {}
                # in case of refs between same types of identifiers,
                # the referred ident could appears at idx 0 or 1
                if ifmap_id == r_elem[0].attrib['name']:
                    ref_ifmap_id = r_elem[1].attrib['name']
                else:
                    ref_ifmap_id = r_elem[0].attrib['name']

                try:
                    ref_fq_name = self._db_client_mgr.ifmap_id_to_fq_name(ref_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown fq_name for ref ' + ref_ifmap_id
                    return (False, err_msg)
                try:
                    ref_uuid = self._db_client_mgr.ifmap_id_to_uuid(ref_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown uuid for ref ' + ref_ifmap_id
                    return (False, err_msg)

                ref_url = self._db_client_mgr.generate_url('bgp_router', ref_uuid)
                ref_info = {}
                ref_info['to'] = ref_fq_name
                ref_info['attr'] = obj_val
                ref_info['href'] = ref_url
                ref_info['uuid'] = ref_uuid
                result['bgp_router_refs'].append(ref_info)


        if metas.has_key('contrail:autonomous-system'):
            result_elems = metas['contrail:autonomous-system']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                obj_val = meta.text
                result['autonomous_system'] = obj_val

        if metas.has_key('contrail:id-perms'):
            result_elems = metas['contrail:id-perms']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                # need to preserve type eg. int for prefix-len
                # for now, xml -> obj -> json -> dict
                # TODO TypeGenerator.py should have xml to dict method
                obj = IdPermsType()
                obj.build(meta)
                obj_json = ''
                obj_json = json.dumps(obj,
                    default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
                obj_val = json.loads(obj_json)
                result['id_perms'] = obj_val

        if metas.has_key('contrail:global-system-config-physical-router'):
            result['physical_routers'] = []
            result_elems = metas['contrail:global-system-config-physical-router']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                obj_val = {}
                has_ifmap_id = r_elem[1].attrib['name']

                try:
                    has_fq_name = self._db_client_mgr.ifmap_id_to_fq_name(has_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown fq_name for child ' + has_ifmap_id
                    return (False, err_msg)
                try:
                    has_uuid = self._db_client_mgr.ifmap_id_to_uuid(has_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown uuid for child ' + has_ifmap_id
                    return (False, err_msg)

                has_url = self._db_client_mgr.generate_url('physical_router', has_uuid)
                has_info = {}
                has_info['to'] = has_fq_name
                has_info['attr'] = obj_val
                has_info['href'] = has_url
                has_info['uuid'] = has_uuid
                result['physical_routers'].append(has_info)


        if metas.has_key('contrail:global-system-config-virtual-router'):
            result['virtual_routers'] = []
            result_elems = metas['contrail:global-system-config-virtual-router']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                obj_val = {}
                has_ifmap_id = r_elem[1].attrib['name']

                try:
                    has_fq_name = self._db_client_mgr.ifmap_id_to_fq_name(has_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown fq_name for child ' + has_ifmap_id
                    return (False, err_msg)
                try:
                    has_uuid = self._db_client_mgr.ifmap_id_to_uuid(has_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown uuid for child ' + has_ifmap_id
                    return (False, err_msg)

                has_url = self._db_client_mgr.generate_url('virtual_router', has_uuid)
                has_info = {}
                has_info['to'] = has_fq_name
                has_info['attr'] = obj_val
                has_info['href'] = has_url
                has_info['uuid'] = has_uuid
                result['virtual_routers'].append(has_info)


        return (True, result)
    #end _ifmap_global_system_config_read

    def _ifmap_global_system_config_update(self, ifmap_id, old_obj_dict, new_obj_dict):
        # remove properties that are no longer active
        if ('autonomous_system' in new_obj_dict) and (new_obj_dict['autonomous_system'] == None):
            self._delete_id_self_meta(ifmap_id, 'autonomous-system')

        if ('id_perms' in new_obj_dict) and (new_obj_dict['id_perms'] == None):
            self._delete_id_self_meta(ifmap_id, 'id-perms')

        # remove refs that are no longer active
        if ('bgp_router_refs' in old_obj_dict):
            old_refs = [tuple(ref['to']) for ref in old_obj_dict['bgp_router_refs']]
        else:
            old_refs = []
        if ('bgp_router_refs' in new_obj_dict):
            if new_obj_dict['bgp_router_refs'] == None:
                new_refs = []
            else:
                new_refs = [tuple(ref['to']) for ref in new_obj_dict['bgp_router_refs']]
        else: # no ref key in new_obj
            new_refs = old_refs

        old_set = set(old_refs)
        new_set = set(new_refs)
        inact_refs = old_set - new_set
        for inact_ref in inact_refs:
            to_imid = self.fq_name_to_ifmap_id('bgp-router', inact_ref)
            self._delete_id_pair_meta(ifmap_id, to_imid, 'contrail:global-system-config-bgp-router')

        (ok, result) = self._ifmap_global_system_config_set(ifmap_id, new_obj_dict)
        return (ok, result)
    #end _ifmap_global_system_config_update

    def _ifmap_global_system_config_list(self, parent_type, parent_fq_name):
        children_fq_names = []
        mapclient = self._mapclient
        parent_imid = common.imid.get_ifmap_id_from_fq_name(parent_type, parent_fq_name)
        start_id = str(Identity(name = parent_imid, type = 'other',
                        other_type = 'extended'))
        # if id-perms missing, identity doesn't exist
        parent_link_meta = self._parent_metas[parent_type]['global-system-config']
        srch_meta = 'contrail:' + parent_link_meta
        srch_result = self._search(start_id, srch_meta)

        result_list = self.parse_result_items(srch_result, parent_imid)
        for r_elem in result_list:
            child_ident = r_elem[1]
            if child_ident is None:
                continue
            child_imid = child_ident.attrib['name']
            fq_name = self._db_client_mgr.ifmap_id_to_fq_name(child_imid)
            children_fq_names.append(fq_name)


        return (True, children_fq_names)
    #end _ifmap_global_system_config_list

    def _ifmap_global_system_config_delete(self, obj_ids):
        ifmap_id = obj_ids['imid']
        parent_imid = obj_ids.get('parent_imid', None)
        start_id = str(Identity(name = ifmap_id, type = 'other',
                        other_type = 'extended'))
        # Delete links to our references, first find them
        srch_meta = ' or '.join([u'contrail:global-system-config-bgp-router'])
        srch_result = self._search(start_id, srch_meta)

        result_list = self.parse_result_items(srch_result, ifmap_id)
        for r_elem in result_list:
            to_ident = r_elem[1]
            if to_ident is None:
                continue
            to_imid = to_ident.attrib['name']
            r_meta = r_elem[2]
            # create contrail:<tag>
            meta_name = r_meta.prefix + ':' + re.sub('{.*}', '', r_meta.tag)
            self._delete_id_pair_meta(ifmap_id, to_imid, meta_name)


        if parent_imid:
            # Remove link from parent
            self._delete_id_pair_meta(parent_imid, ifmap_id, None)

        # Remove all property metadata associated with this ident
        self._delete_id_self_meta(ifmap_id, None)

        return (True, '')
    #end _ifmap_global_system_config_delete

    def _ifmap_namespace_alloc(self, parent_type, fq_name):
        imid = self._imid_handler
        (my_imid, parent_imid) = \
            imid.namespace_alloc_ifmap_id(parent_type, fq_name)
        return (True, (my_imid, parent_imid))
    #end _ifmap_namespace_alloc

    def _ifmap_namespace_set(self, my_imid, obj_dict):
        # Properties Meta
        field = obj_dict.get('namespace_cidr', None)
        if field:
            # construct object of xsd-type and get its xml repr
            field = obj_dict['namespace_cidr']
            buf = cStringIO.StringIO()
            # perms might be inserted at server as obj.
            # obj construction diff from dict construction.
            if isinstance(field, dict):
                SubnetType(**field).exportChildren(buf, level = 1, name_ = 'namespace-cidr', pretty_print = False)
            else: # object
                field.exportChildren(buf, level = 1, name_ = 'namespace-cidr', pretty_print = False)
            namespace_cidr_xml = buf.getvalue()
            buf.close()
            meta = str(Metadata('namespace-cidr' , '',
                   {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail',
                   elements = namespace_cidr_xml))
            self._publish_id_self_meta(my_imid, meta)

        field = obj_dict.get('id_perms', None)
        if field:
            # construct object of xsd-type and get its xml repr
            field = obj_dict['id_perms']
            buf = cStringIO.StringIO()
            # perms might be inserted at server as obj.
            # obj construction diff from dict construction.
            if isinstance(field, dict):
                IdPermsType(**field).exportChildren(buf, level = 1, name_ = 'id-perms', pretty_print = False)
            else: # object
                field.exportChildren(buf, level = 1, name_ = 'id-perms', pretty_print = False)
            id_perms_xml = buf.getvalue()
            buf.close()
            meta = str(Metadata('id-perms' , '',
                   {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail',
                   elements = id_perms_xml))
            self._publish_id_self_meta(my_imid, meta)

        # Ref Link Metas
        imid = self._imid_handler


        return (True, '')
    #end _ifmap_namespace_set

    def _ifmap_namespace_create(self, obj_ids, obj_dict):
        if not 'parent_type' in obj_dict:
            # parent is config-root
            parent_type = 'config-root'
            parent_imid = 'contrail:config-root:root'
        else:
            parent_type = obj_dict['parent_type']
            parent_imid = obj_ids.get('parent_imid', None)

        # Parent Link Meta
        parent_link_meta = self._parent_metas[parent_type]['namespace']
        meta = str(Metadata(parent_link_meta, '',
                   {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail'))
        self._publish_id_pair_meta(parent_imid, obj_ids['imid'], meta)

        (ok, result) = self._ifmap_namespace_set(obj_ids['imid'], obj_dict)
        return (ok, result)
    #end _ifmap_namespace_create

    def _ifmap_namespace_read(self, ifmap_id, field_names = None):
        # field_names = None means all fields will be read
        imid = self._imid_handler
        mapclient = self._mapclient
        start_id = str(Identity(name = ifmap_id, type = 'other',
                        other_type = 'extended'))
        # if id-perms missing, identity doesn't exist

        all_metas = [u'contrail:project-namespace', u'contrail:namespace-cidr', u'contrail:id-perms']
        if not field_names:
            metas_to_read = all_metas
        else: # read only requested fields
            req_metas = []
            if field_names.has_key('project_back_refs'):
                req_metas.append('contrail:project-namespace')
            if field_names.has_key('namespace_cidr'):
                req_metas.append('contrail:namespace-cidr')
            if field_names.has_key('id_perms'):
                req_metas.append('contrail:id-perms')

            metas_to_read = set(all_metas) & set(req_metas)

        srch_meta = ' or '.join(metas_to_read)
        srch_result = self._search(start_id, srch_meta)

        result_list = self.parse_result_items(srch_result, ifmap_id)
        if (len(result_list) == 1 and 
            result_list[0][2] == None):
            return (False, 'namespace ' + ifmap_id + 'does not exist')

        # metas is a dict where key is meta-name and val is list of tuples
        # of form (ident1, ident2, meta)
        metas = {}
        for r_elem in result_list:
            r_meta = r_elem[2]
            # create contrail:<tag>
            meta_name = r_meta.prefix + ':' + re.sub('{.*}', '', r_meta.tag)

            if (
                (meta_name == 'contrail:project-namespace') or
                (meta_name == 'contrail:namespace-cidr') or
                (meta_name == 'contrail:id-perms')
               ):
                if metas.has_key(meta_name):
                    metas[meta_name].append(r_elem)
                else: # first ident for this link-type
                    metas[meta_name] = [r_elem]

         # Construct dicts from xml
        result = {}
        result['_type'] = 'namespace'
        fq_name = self._db_client_mgr.ifmap_id_to_fq_name(ifmap_id)
        result['fq_name'] = fq_name
        result['name'] = fq_name[-1]
        if metas.has_key('contrail:project-namespace'):
            result['project_back_refs'] = []
            result_elems = metas['contrail:project-namespace']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                # need to preserve type eg. int for prefix-len
                # for now, xml -> obj -> json -> dict
                # TODO TypeGenerator.py should have xml to dict method
                obj = SubnetType()
                obj.build(meta)
                obj_json = ''
                obj_json = json.dumps(obj,
                    default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
                obj_val = json.loads(obj_json)
                back_ref_ifmap_id = r_elem[0].attrib['name']

                try:
                    back_ref_fq_name = self._db_client_mgr.ifmap_id_to_fq_name(back_ref_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown fq_name for backref ' + back_ref_ifmap_id
                    return (False, err_msg)
                try:
                    back_ref_uuid = self._db_client_mgr.ifmap_id_to_uuid(back_ref_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown uuid for backref ' + back_ref_ifmap_id
                    return (False, err_msg)

                back_ref_url = self._db_client_mgr.generate_url('project', back_ref_uuid)
                back_ref_info = {}
                back_ref_info['to'] = back_ref_fq_name
                back_ref_info['attr'] = obj_val
                back_ref_info['href'] = back_ref_url
                back_ref_info['uuid'] = back_ref_uuid
                result['project_back_refs'].append(back_ref_info)


        if metas.has_key('contrail:namespace-cidr'):
            result_elems = metas['contrail:namespace-cidr']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                # need to preserve type eg. int for prefix-len
                # for now, xml -> obj -> json -> dict
                # TODO TypeGenerator.py should have xml to dict method
                obj = SubnetType()
                obj.build(meta)
                obj_json = ''
                obj_json = json.dumps(obj,
                    default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
                obj_val = json.loads(obj_json)
                result['namespace_cidr'] = obj_val

        if metas.has_key('contrail:id-perms'):
            result_elems = metas['contrail:id-perms']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                # need to preserve type eg. int for prefix-len
                # for now, xml -> obj -> json -> dict
                # TODO TypeGenerator.py should have xml to dict method
                obj = IdPermsType()
                obj.build(meta)
                obj_json = ''
                obj_json = json.dumps(obj,
                    default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
                obj_val = json.loads(obj_json)
                result['id_perms'] = obj_val

        return (True, result)
    #end _ifmap_namespace_read

    def _ifmap_namespace_update(self, ifmap_id, old_obj_dict, new_obj_dict):
        # remove properties that are no longer active
        if ('namespace_cidr' in new_obj_dict) and (new_obj_dict['namespace_cidr'] == None):
            self._delete_id_self_meta(ifmap_id, 'namespace-cidr')

        if ('id_perms' in new_obj_dict) and (new_obj_dict['id_perms'] == None):
            self._delete_id_self_meta(ifmap_id, 'id-perms')

        # remove refs that are no longer active
        (ok, result) = self._ifmap_namespace_set(ifmap_id, new_obj_dict)
        return (ok, result)
    #end _ifmap_namespace_update

    def _ifmap_namespace_list(self, parent_type, parent_fq_name):
        children_fq_names = []
        mapclient = self._mapclient
        parent_imid = common.imid.get_ifmap_id_from_fq_name(parent_type, parent_fq_name)
        start_id = str(Identity(name = parent_imid, type = 'other',
                        other_type = 'extended'))
        # if id-perms missing, identity doesn't exist
        parent_link_meta = self._parent_metas[parent_type]['namespace']
        srch_meta = 'contrail:' + parent_link_meta
        srch_result = self._search(start_id, srch_meta)

        result_list = self.parse_result_items(srch_result, parent_imid)
        for r_elem in result_list:
            child_ident = r_elem[1]
            if child_ident is None:
                continue
            child_imid = child_ident.attrib['name']
            fq_name = self._db_client_mgr.ifmap_id_to_fq_name(child_imid)
            children_fq_names.append(fq_name)


        return (True, children_fq_names)
    #end _ifmap_namespace_list

    def _ifmap_namespace_delete(self, obj_ids):
        ifmap_id = obj_ids['imid']
        parent_imid = obj_ids.get('parent_imid', None)
        start_id = str(Identity(name = ifmap_id, type = 'other',
                        other_type = 'extended'))

        if parent_imid:
            # Remove link from parent
            self._delete_id_pair_meta(parent_imid, ifmap_id, None)

        # Remove all property metadata associated with this ident
        self._delete_id_self_meta(ifmap_id, None)

        return (True, '')
    #end _ifmap_namespace_delete

    def _ifmap_physical_interface_alloc(self, parent_type, fq_name):
        imid = self._imid_handler
        (my_imid, parent_imid) = \
            imid.physical_interface_alloc_ifmap_id(parent_type, fq_name)
        return (True, (my_imid, parent_imid))
    #end _ifmap_physical_interface_alloc

    def _ifmap_physical_interface_set(self, my_imid, obj_dict):
        # Properties Meta
        field = obj_dict.get('id_perms', None)
        if field:
            # construct object of xsd-type and get its xml repr
            field = obj_dict['id_perms']
            buf = cStringIO.StringIO()
            # perms might be inserted at server as obj.
            # obj construction diff from dict construction.
            if isinstance(field, dict):
                IdPermsType(**field).exportChildren(buf, level = 1, name_ = 'id-perms', pretty_print = False)
            else: # object
                field.exportChildren(buf, level = 1, name_ = 'id-perms', pretty_print = False)
            id_perms_xml = buf.getvalue()
            buf.close()
            meta = str(Metadata('id-perms' , '',
                   {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail',
                   elements = id_perms_xml))
            self._publish_id_self_meta(my_imid, meta)

        # Ref Link Metas
        imid = self._imid_handler

        # construct object of xsd-type and get its xml repr
        refs = obj_dict.get('logical_interface_refs', None)
        if refs:
            for ref in refs:
                ref_fq_name = ref['to']
                obj_type = 'logical-interface'
                to_imid = common.imid.get_ifmap_id_from_fq_name(obj_type, ref_fq_name)
                physical_interface_logical_interface_xml = ''
                meta = str(Metadata('physical-interface-logical-interface' , '',
                       {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail',
                       elements = physical_interface_logical_interface_xml))
                self._publish_id_pair_meta(my_imid, to_imid, meta)


        return (True, '')
    #end _ifmap_physical_interface_set

    def _ifmap_physical_interface_create(self, obj_ids, obj_dict):
        if not 'parent_type' in obj_dict:
            # parent is config-root
            parent_type = 'config-root'
            parent_imid = 'contrail:config-root:root'
        else:
            parent_type = obj_dict['parent_type']
            parent_imid = obj_ids.get('parent_imid', None)

        # Parent Link Meta
        parent_link_meta = self._parent_metas[parent_type]['physical-interface']
        meta = str(Metadata(parent_link_meta, '',
                   {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail'))
        self._publish_id_pair_meta(parent_imid, obj_ids['imid'], meta)

        (ok, result) = self._ifmap_physical_interface_set(obj_ids['imid'], obj_dict)
        return (ok, result)
    #end _ifmap_physical_interface_create

    def _ifmap_physical_interface_read(self, ifmap_id, field_names = None):
        # field_names = None means all fields will be read
        imid = self._imid_handler
        mapclient = self._mapclient
        start_id = str(Identity(name = ifmap_id, type = 'other',
                        other_type = 'extended'))
        # if id-perms missing, identity doesn't exist

        all_metas = [u'contrail:id-perms', u'contrail:physical-interface-logical-interface']
        if not field_names:
            metas_to_read = all_metas
        else: # read only requested fields
            req_metas = []
            if field_names.has_key('id_perms'):
                req_metas.append('contrail:id-perms')
            if field_names.has_key('physical_interface_logical_interface'):
                req_metas.append('contrail:physical-interface-logical-interface')

            metas_to_read = set(all_metas) & set(req_metas)

        srch_meta = ' or '.join(metas_to_read)
        srch_result = self._search(start_id, srch_meta)

        result_list = self.parse_result_items(srch_result, ifmap_id)
        if (len(result_list) == 1 and 
            result_list[0][2] == None):
            return (False, 'physical-interface ' + ifmap_id + 'does not exist')

        # metas is a dict where key is meta-name and val is list of tuples
        # of form (ident1, ident2, meta)
        metas = {}
        for r_elem in result_list:
            r_meta = r_elem[2]
            # create contrail:<tag>
            meta_name = r_meta.prefix + ':' + re.sub('{.*}', '', r_meta.tag)

            if (
                (meta_name == 'contrail:id-perms') or
                (meta_name == 'contrail:physical-interface-logical-interface')
               ):
                if metas.has_key(meta_name):
                    metas[meta_name].append(r_elem)
                else: # first ident for this link-type
                    metas[meta_name] = [r_elem]

         # Construct dicts from xml
        result = {}
        result['_type'] = 'physical-interface'
        fq_name = self._db_client_mgr.ifmap_id_to_fq_name(ifmap_id)
        result['fq_name'] = fq_name
        result['name'] = fq_name[-1]
        if metas.has_key('contrail:id-perms'):
            result_elems = metas['contrail:id-perms']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                # need to preserve type eg. int for prefix-len
                # for now, xml -> obj -> json -> dict
                # TODO TypeGenerator.py should have xml to dict method
                obj = IdPermsType()
                obj.build(meta)
                obj_json = ''
                obj_json = json.dumps(obj,
                    default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
                obj_val = json.loads(obj_json)
                result['id_perms'] = obj_val

        if metas.has_key('contrail:physical-interface-logical-interface'):
            result['logical_interfaces'] = []
            result_elems = metas['contrail:physical-interface-logical-interface']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                obj_val = {}
                has_ifmap_id = r_elem[1].attrib['name']

                try:
                    has_fq_name = self._db_client_mgr.ifmap_id_to_fq_name(has_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown fq_name for child ' + has_ifmap_id
                    return (False, err_msg)
                try:
                    has_uuid = self._db_client_mgr.ifmap_id_to_uuid(has_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown uuid for child ' + has_ifmap_id
                    return (False, err_msg)

                has_url = self._db_client_mgr.generate_url('logical_interface', has_uuid)
                has_info = {}
                has_info['to'] = has_fq_name
                has_info['attr'] = obj_val
                has_info['href'] = has_url
                has_info['uuid'] = has_uuid
                result['logical_interfaces'].append(has_info)


        return (True, result)
    #end _ifmap_physical_interface_read

    def _ifmap_physical_interface_update(self, ifmap_id, old_obj_dict, new_obj_dict):
        # remove properties that are no longer active
        if ('id_perms' in new_obj_dict) and (new_obj_dict['id_perms'] == None):
            self._delete_id_self_meta(ifmap_id, 'id-perms')

        # remove refs that are no longer active
        (ok, result) = self._ifmap_physical_interface_set(ifmap_id, new_obj_dict)
        return (ok, result)
    #end _ifmap_physical_interface_update

    def _ifmap_physical_interface_list(self, parent_type, parent_fq_name):
        children_fq_names = []
        mapclient = self._mapclient
        parent_imid = common.imid.get_ifmap_id_from_fq_name(parent_type, parent_fq_name)
        start_id = str(Identity(name = parent_imid, type = 'other',
                        other_type = 'extended'))
        # if id-perms missing, identity doesn't exist
        parent_link_meta = self._parent_metas[parent_type]['physical-interface']
        srch_meta = 'contrail:' + parent_link_meta
        srch_result = self._search(start_id, srch_meta)

        result_list = self.parse_result_items(srch_result, parent_imid)
        for r_elem in result_list:
            child_ident = r_elem[1]
            if child_ident is None:
                continue
            child_imid = child_ident.attrib['name']
            fq_name = self._db_client_mgr.ifmap_id_to_fq_name(child_imid)
            children_fq_names.append(fq_name)


        return (True, children_fq_names)
    #end _ifmap_physical_interface_list

    def _ifmap_physical_interface_delete(self, obj_ids):
        ifmap_id = obj_ids['imid']
        parent_imid = obj_ids.get('parent_imid', None)
        start_id = str(Identity(name = ifmap_id, type = 'other',
                        other_type = 'extended'))

        if parent_imid:
            # Remove link from parent
            self._delete_id_pair_meta(parent_imid, ifmap_id, None)

        # Remove all property metadata associated with this ident
        self._delete_id_self_meta(ifmap_id, None)

        return (True, '')
    #end _ifmap_physical_interface_delete

    def _ifmap_access_control_list_alloc(self, parent_type, fq_name):
        imid = self._imid_handler
        (my_imid, parent_imid) = \
            imid.access_control_list_alloc_ifmap_id(parent_type, fq_name)
        return (True, (my_imid, parent_imid))
    #end _ifmap_access_control_list_alloc

    def _ifmap_access_control_list_set(self, my_imid, obj_dict):
        # Properties Meta
        field = obj_dict.get('access_control_list_entries', None)
        if field:
            # construct object of xsd-type and get its xml repr
            field = obj_dict['access_control_list_entries']
            buf = cStringIO.StringIO()
            # perms might be inserted at server as obj.
            # obj construction diff from dict construction.
            if isinstance(field, dict):
                AclEntriesType(**field).exportChildren(buf, level = 1, name_ = 'access-control-list-entries', pretty_print = False)
            else: # object
                field.exportChildren(buf, level = 1, name_ = 'access-control-list-entries', pretty_print = False)
            access_control_list_entries_xml = buf.getvalue()
            buf.close()
            meta = str(Metadata('access-control-list-entries' , '',
                   {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail',
                   elements = access_control_list_entries_xml))
            self._publish_id_self_meta(my_imid, meta)

        field = obj_dict.get('id_perms', None)
        if field:
            # construct object of xsd-type and get its xml repr
            field = obj_dict['id_perms']
            buf = cStringIO.StringIO()
            # perms might be inserted at server as obj.
            # obj construction diff from dict construction.
            if isinstance(field, dict):
                IdPermsType(**field).exportChildren(buf, level = 1, name_ = 'id-perms', pretty_print = False)
            else: # object
                field.exportChildren(buf, level = 1, name_ = 'id-perms', pretty_print = False)
            id_perms_xml = buf.getvalue()
            buf.close()
            meta = str(Metadata('id-perms' , '',
                   {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail',
                   elements = id_perms_xml))
            self._publish_id_self_meta(my_imid, meta)

        # Ref Link Metas
        imid = self._imid_handler


        return (True, '')
    #end _ifmap_access_control_list_set

    def _ifmap_access_control_list_create(self, obj_ids, obj_dict):
        if not 'parent_type' in obj_dict:
            # parent is config-root
            parent_type = 'config-root'
            parent_imid = 'contrail:config-root:root'
        else:
            parent_type = obj_dict['parent_type']
            parent_imid = obj_ids.get('parent_imid', None)

        # Parent Link Meta
        parent_link_meta = self._parent_metas[parent_type]['access-control-list']
        meta = str(Metadata(parent_link_meta, '',
                   {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail'))
        self._publish_id_pair_meta(parent_imid, obj_ids['imid'], meta)

        (ok, result) = self._ifmap_access_control_list_set(obj_ids['imid'], obj_dict)
        return (ok, result)
    #end _ifmap_access_control_list_create

    def _ifmap_access_control_list_read(self, ifmap_id, field_names = None):
        # field_names = None means all fields will be read
        imid = self._imid_handler
        mapclient = self._mapclient
        start_id = str(Identity(name = ifmap_id, type = 'other',
                        other_type = 'extended'))
        # if id-perms missing, identity doesn't exist

        all_metas = [u'contrail:access-control-list-entries', u'contrail:id-perms']
        if not field_names:
            metas_to_read = all_metas
        else: # read only requested fields
            req_metas = []
            if field_names.has_key('access_control_list_entries'):
                req_metas.append('contrail:access-control-list-entries')
            if field_names.has_key('id_perms'):
                req_metas.append('contrail:id-perms')

            metas_to_read = set(all_metas) & set(req_metas)

        srch_meta = ' or '.join(metas_to_read)
        srch_result = self._search(start_id, srch_meta)

        result_list = self.parse_result_items(srch_result, ifmap_id)
        if (len(result_list) == 1 and 
            result_list[0][2] == None):
            return (False, 'access-control-list ' + ifmap_id + 'does not exist')

        # metas is a dict where key is meta-name and val is list of tuples
        # of form (ident1, ident2, meta)
        metas = {}
        for r_elem in result_list:
            r_meta = r_elem[2]
            # create contrail:<tag>
            meta_name = r_meta.prefix + ':' + re.sub('{.*}', '', r_meta.tag)

            if (
                (meta_name == 'contrail:access-control-list-entries') or
                (meta_name == 'contrail:id-perms')
               ):
                if metas.has_key(meta_name):
                    metas[meta_name].append(r_elem)
                else: # first ident for this link-type
                    metas[meta_name] = [r_elem]

         # Construct dicts from xml
        result = {}
        result['_type'] = 'access-control-list'
        fq_name = self._db_client_mgr.ifmap_id_to_fq_name(ifmap_id)
        result['fq_name'] = fq_name
        result['name'] = fq_name[-1]
        if metas.has_key('contrail:access-control-list-entries'):
            result_elems = metas['contrail:access-control-list-entries']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                # need to preserve type eg. int for prefix-len
                # for now, xml -> obj -> json -> dict
                # TODO TypeGenerator.py should have xml to dict method
                obj = AclEntriesType()
                obj.build(meta)
                obj_json = ''
                obj_json = json.dumps(obj,
                    default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
                obj_val = json.loads(obj_json)
                result['access_control_list_entries'] = obj_val

        if metas.has_key('contrail:id-perms'):
            result_elems = metas['contrail:id-perms']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                # need to preserve type eg. int for prefix-len
                # for now, xml -> obj -> json -> dict
                # TODO TypeGenerator.py should have xml to dict method
                obj = IdPermsType()
                obj.build(meta)
                obj_json = ''
                obj_json = json.dumps(obj,
                    default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
                obj_val = json.loads(obj_json)
                result['id_perms'] = obj_val

        return (True, result)
    #end _ifmap_access_control_list_read

    def _ifmap_access_control_list_update(self, ifmap_id, old_obj_dict, new_obj_dict):
        # remove properties that are no longer active
        if ('access_control_list_entries' in new_obj_dict) and (new_obj_dict['access_control_list_entries'] == None):
            self._delete_id_self_meta(ifmap_id, 'access-control-list-entries')

        if ('id_perms' in new_obj_dict) and (new_obj_dict['id_perms'] == None):
            self._delete_id_self_meta(ifmap_id, 'id-perms')

        # remove refs that are no longer active
        (ok, result) = self._ifmap_access_control_list_set(ifmap_id, new_obj_dict)
        return (ok, result)
    #end _ifmap_access_control_list_update

    def _ifmap_access_control_list_list(self, parent_type, parent_fq_name):
        children_fq_names = []
        mapclient = self._mapclient
        parent_imid = common.imid.get_ifmap_id_from_fq_name(parent_type, parent_fq_name)
        start_id = str(Identity(name = parent_imid, type = 'other',
                        other_type = 'extended'))
        # if id-perms missing, identity doesn't exist
        parent_link_meta = self._parent_metas[parent_type]['access-control-list']
        srch_meta = 'contrail:' + parent_link_meta
        srch_result = self._search(start_id, srch_meta)

        result_list = self.parse_result_items(srch_result, parent_imid)
        for r_elem in result_list:
            child_ident = r_elem[1]
            if child_ident is None:
                continue
            child_imid = child_ident.attrib['name']
            fq_name = self._db_client_mgr.ifmap_id_to_fq_name(child_imid)
            children_fq_names.append(fq_name)


        return (True, children_fq_names)
    #end _ifmap_access_control_list_list

    def _ifmap_access_control_list_delete(self, obj_ids):
        ifmap_id = obj_ids['imid']
        parent_imid = obj_ids.get('parent_imid', None)
        start_id = str(Identity(name = ifmap_id, type = 'other',
                        other_type = 'extended'))

        if parent_imid:
            # Remove link from parent
            self._delete_id_pair_meta(parent_imid, ifmap_id, None)

        # Remove all property metadata associated with this ident
        self._delete_id_self_meta(ifmap_id, None)

        return (True, '')
    #end _ifmap_access_control_list_delete

    def _ifmap_virtual_DNS_alloc(self, parent_type, fq_name):
        imid = self._imid_handler
        (my_imid, parent_imid) = \
            imid.virtual_DNS_alloc_ifmap_id(parent_type, fq_name)
        return (True, (my_imid, parent_imid))
    #end _ifmap_virtual_DNS_alloc

    def _ifmap_virtual_DNS_set(self, my_imid, obj_dict):
        # Properties Meta
        field = obj_dict.get('virtual_DNS_data', None)
        if field:
            # construct object of xsd-type and get its xml repr
            field = obj_dict['virtual_DNS_data']
            buf = cStringIO.StringIO()
            # perms might be inserted at server as obj.
            # obj construction diff from dict construction.
            if isinstance(field, dict):
                VirtualDnsType(**field).exportChildren(buf, level = 1, name_ = 'virtual-DNS-data', pretty_print = False)
            else: # object
                field.exportChildren(buf, level = 1, name_ = 'virtual-DNS-data', pretty_print = False)
            virtual_DNS_data_xml = buf.getvalue()
            buf.close()
            meta = str(Metadata('virtual-DNS-data' , '',
                   {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail',
                   elements = virtual_DNS_data_xml))
            self._publish_id_self_meta(my_imid, meta)

        field = obj_dict.get('id_perms', None)
        if field:
            # construct object of xsd-type and get its xml repr
            field = obj_dict['id_perms']
            buf = cStringIO.StringIO()
            # perms might be inserted at server as obj.
            # obj construction diff from dict construction.
            if isinstance(field, dict):
                IdPermsType(**field).exportChildren(buf, level = 1, name_ = 'id-perms', pretty_print = False)
            else: # object
                field.exportChildren(buf, level = 1, name_ = 'id-perms', pretty_print = False)
            id_perms_xml = buf.getvalue()
            buf.close()
            meta = str(Metadata('id-perms' , '',
                   {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail',
                   elements = id_perms_xml))
            self._publish_id_self_meta(my_imid, meta)

        # Ref Link Metas
        imid = self._imid_handler

        # construct object of xsd-type and get its xml repr
        refs = obj_dict.get('virtual_DNS_record_refs', None)
        if refs:
            for ref in refs:
                ref_fq_name = ref['to']
                obj_type = 'virtual-DNS-record'
                to_imid = common.imid.get_ifmap_id_from_fq_name(obj_type, ref_fq_name)
                virtual_DNS_virtual_DNS_record_xml = ''
                meta = str(Metadata('virtual-DNS-virtual-DNS-record' , '',
                       {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail',
                       elements = virtual_DNS_virtual_DNS_record_xml))
                self._publish_id_pair_meta(my_imid, to_imid, meta)


        return (True, '')
    #end _ifmap_virtual_DNS_set

    def _ifmap_virtual_DNS_create(self, obj_ids, obj_dict):
        if not 'parent_type' in obj_dict:
            # parent is config-root
            parent_type = 'config-root'
            parent_imid = 'contrail:config-root:root'
        else:
            parent_type = obj_dict['parent_type']
            parent_imid = obj_ids.get('parent_imid', None)

        # Parent Link Meta
        parent_link_meta = self._parent_metas[parent_type]['virtual-DNS']
        meta = str(Metadata(parent_link_meta, '',
                   {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail'))
        self._publish_id_pair_meta(parent_imid, obj_ids['imid'], meta)

        (ok, result) = self._ifmap_virtual_DNS_set(obj_ids['imid'], obj_dict)
        return (ok, result)
    #end _ifmap_virtual_DNS_create

    def _ifmap_virtual_DNS_read(self, ifmap_id, field_names = None):
        # field_names = None means all fields will be read
        imid = self._imid_handler
        mapclient = self._mapclient
        start_id = str(Identity(name = ifmap_id, type = 'other',
                        other_type = 'extended'))
        # if id-perms missing, identity doesn't exist

        all_metas = [u'contrail:network-ipam-virtual-DNS', u'contrail:virtual-DNS-data', u'contrail:id-perms', u'contrail:virtual-DNS-virtual-DNS-record']
        if not field_names:
            metas_to_read = all_metas
        else: # read only requested fields
            req_metas = []
            if field_names.has_key('network_ipam_back_refs'):
                req_metas.append('contrail:network-ipam-virtual-DNS')
            if field_names.has_key('virtual_DNS_data'):
                req_metas.append('contrail:virtual-DNS-data')
            if field_names.has_key('id_perms'):
                req_metas.append('contrail:id-perms')
            if field_names.has_key('virtual_DNS_virtual_DNS_record'):
                req_metas.append('contrail:virtual-DNS-virtual-DNS-record')

            metas_to_read = set(all_metas) & set(req_metas)

        srch_meta = ' or '.join(metas_to_read)
        srch_result = self._search(start_id, srch_meta)

        result_list = self.parse_result_items(srch_result, ifmap_id)
        if (len(result_list) == 1 and 
            result_list[0][2] == None):
            return (False, 'virtual-DNS ' + ifmap_id + 'does not exist')

        # metas is a dict where key is meta-name and val is list of tuples
        # of form (ident1, ident2, meta)
        metas = {}
        for r_elem in result_list:
            r_meta = r_elem[2]
            # create contrail:<tag>
            meta_name = r_meta.prefix + ':' + re.sub('{.*}', '', r_meta.tag)

            if (
                (meta_name == 'contrail:network-ipam-virtual-DNS') or
                (meta_name == 'contrail:virtual-DNS-data') or
                (meta_name == 'contrail:id-perms') or
                (meta_name == 'contrail:virtual-DNS-virtual-DNS-record')
               ):
                if metas.has_key(meta_name):
                    metas[meta_name].append(r_elem)
                else: # first ident for this link-type
                    metas[meta_name] = [r_elem]

         # Construct dicts from xml
        result = {}
        result['_type'] = 'virtual-DNS'
        fq_name = self._db_client_mgr.ifmap_id_to_fq_name(ifmap_id)
        result['fq_name'] = fq_name
        result['name'] = fq_name[-1]
        if metas.has_key('contrail:network-ipam-virtual-DNS'):
            result['network_ipam_back_refs'] = []
            result_elems = metas['contrail:network-ipam-virtual-DNS']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                obj_val = {}
                back_ref_ifmap_id = r_elem[0].attrib['name']

                try:
                    back_ref_fq_name = self._db_client_mgr.ifmap_id_to_fq_name(back_ref_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown fq_name for backref ' + back_ref_ifmap_id
                    return (False, err_msg)
                try:
                    back_ref_uuid = self._db_client_mgr.ifmap_id_to_uuid(back_ref_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown uuid for backref ' + back_ref_ifmap_id
                    return (False, err_msg)

                back_ref_url = self._db_client_mgr.generate_url('network_ipam', back_ref_uuid)
                back_ref_info = {}
                back_ref_info['to'] = back_ref_fq_name
                back_ref_info['attr'] = obj_val
                back_ref_info['href'] = back_ref_url
                back_ref_info['uuid'] = back_ref_uuid
                result['network_ipam_back_refs'].append(back_ref_info)


        if metas.has_key('contrail:virtual-DNS-data'):
            result_elems = metas['contrail:virtual-DNS-data']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                # need to preserve type eg. int for prefix-len
                # for now, xml -> obj -> json -> dict
                # TODO TypeGenerator.py should have xml to dict method
                obj = VirtualDnsType()
                obj.build(meta)
                obj_json = ''
                obj_json = json.dumps(obj,
                    default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
                obj_val = json.loads(obj_json)
                result['virtual_DNS_data'] = obj_val

        if metas.has_key('contrail:id-perms'):
            result_elems = metas['contrail:id-perms']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                # need to preserve type eg. int for prefix-len
                # for now, xml -> obj -> json -> dict
                # TODO TypeGenerator.py should have xml to dict method
                obj = IdPermsType()
                obj.build(meta)
                obj_json = ''
                obj_json = json.dumps(obj,
                    default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
                obj_val = json.loads(obj_json)
                result['id_perms'] = obj_val

        if metas.has_key('contrail:virtual-DNS-virtual-DNS-record'):
            result['virtual_DNS_records'] = []
            result_elems = metas['contrail:virtual-DNS-virtual-DNS-record']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                obj_val = {}
                has_ifmap_id = r_elem[1].attrib['name']

                try:
                    has_fq_name = self._db_client_mgr.ifmap_id_to_fq_name(has_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown fq_name for child ' + has_ifmap_id
                    return (False, err_msg)
                try:
                    has_uuid = self._db_client_mgr.ifmap_id_to_uuid(has_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown uuid for child ' + has_ifmap_id
                    return (False, err_msg)

                has_url = self._db_client_mgr.generate_url('virtual_DNS_record', has_uuid)
                has_info = {}
                has_info['to'] = has_fq_name
                has_info['attr'] = obj_val
                has_info['href'] = has_url
                has_info['uuid'] = has_uuid
                result['virtual_DNS_records'].append(has_info)


        return (True, result)
    #end _ifmap_virtual_DNS_read

    def _ifmap_virtual_DNS_update(self, ifmap_id, old_obj_dict, new_obj_dict):
        # remove properties that are no longer active
        if ('virtual_DNS_data' in new_obj_dict) and (new_obj_dict['virtual_DNS_data'] == None):
            self._delete_id_self_meta(ifmap_id, 'virtual-DNS-data')

        if ('id_perms' in new_obj_dict) and (new_obj_dict['id_perms'] == None):
            self._delete_id_self_meta(ifmap_id, 'id-perms')

        # remove refs that are no longer active
        (ok, result) = self._ifmap_virtual_DNS_set(ifmap_id, new_obj_dict)
        return (ok, result)
    #end _ifmap_virtual_DNS_update

    def _ifmap_virtual_DNS_list(self, parent_type, parent_fq_name):
        children_fq_names = []
        mapclient = self._mapclient
        parent_imid = common.imid.get_ifmap_id_from_fq_name(parent_type, parent_fq_name)
        start_id = str(Identity(name = parent_imid, type = 'other',
                        other_type = 'extended'))
        # if id-perms missing, identity doesn't exist
        parent_link_meta = self._parent_metas[parent_type]['virtual-DNS']
        srch_meta = 'contrail:' + parent_link_meta
        srch_result = self._search(start_id, srch_meta)

        result_list = self.parse_result_items(srch_result, parent_imid)
        for r_elem in result_list:
            child_ident = r_elem[1]
            if child_ident is None:
                continue
            child_imid = child_ident.attrib['name']
            fq_name = self._db_client_mgr.ifmap_id_to_fq_name(child_imid)
            children_fq_names.append(fq_name)


        return (True, children_fq_names)
    #end _ifmap_virtual_DNS_list

    def _ifmap_virtual_DNS_delete(self, obj_ids):
        ifmap_id = obj_ids['imid']
        parent_imid = obj_ids.get('parent_imid', None)
        start_id = str(Identity(name = ifmap_id, type = 'other',
                        other_type = 'extended'))

        if parent_imid:
            # Remove link from parent
            self._delete_id_pair_meta(parent_imid, ifmap_id, None)

        # Remove all property metadata associated with this ident
        self._delete_id_self_meta(ifmap_id, None)

        return (True, '')
    #end _ifmap_virtual_DNS_delete

    def _ifmap_customer_attachment_alloc(self, parent_type, fq_name):
        imid = self._imid_handler
        (my_imid, parent_imid) = \
            imid.customer_attachment_alloc_ifmap_id(parent_type, fq_name)
        return (True, (my_imid, parent_imid))
    #end _ifmap_customer_attachment_alloc

    def _ifmap_customer_attachment_set(self, my_imid, obj_dict):
        # Properties Meta
        field = obj_dict.get('attachment_address', None)
        if field:
            # construct object of xsd-type and get its xml repr
            field = obj_dict['attachment_address']
            buf = cStringIO.StringIO()
            # perms might be inserted at server as obj.
            # obj construction diff from dict construction.
            if isinstance(field, dict):
                AttachmentAddressType(**field).exportChildren(buf, level = 1, name_ = 'attachment-address', pretty_print = False)
            else: # object
                field.exportChildren(buf, level = 1, name_ = 'attachment-address', pretty_print = False)
            attachment_address_xml = buf.getvalue()
            buf.close()
            meta = str(Metadata('attachment-address' , '',
                   {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail',
                   elements = attachment_address_xml))
            self._publish_id_self_meta(my_imid, meta)

        field = obj_dict.get('id_perms', None)
        if field:
            # construct object of xsd-type and get its xml repr
            field = obj_dict['id_perms']
            buf = cStringIO.StringIO()
            # perms might be inserted at server as obj.
            # obj construction diff from dict construction.
            if isinstance(field, dict):
                IdPermsType(**field).exportChildren(buf, level = 1, name_ = 'id-perms', pretty_print = False)
            else: # object
                field.exportChildren(buf, level = 1, name_ = 'id-perms', pretty_print = False)
            id_perms_xml = buf.getvalue()
            buf.close()
            meta = str(Metadata('id-perms' , '',
                   {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail',
                   elements = id_perms_xml))
            self._publish_id_self_meta(my_imid, meta)

        # Ref Link Metas
        imid = self._imid_handler

        # construct object of xsd-type and get its xml repr
        refs = obj_dict.get('virtual_machine_interface_refs', None)
        if refs:
            for ref in refs:
                ref_fq_name = ref['to']
                obj_type = 'virtual-machine-interface'
                to_imid = common.imid.get_ifmap_id_from_fq_name(obj_type, ref_fq_name)
                customer_attachment_virtual_machine_interface_xml = ''
                meta = str(Metadata('customer-attachment-virtual-machine-interface' , '',
                       {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail',
                       elements = customer_attachment_virtual_machine_interface_xml))
                self._publish_id_pair_meta(my_imid, to_imid, meta)

        # construct object of xsd-type and get its xml repr
        refs = obj_dict.get('floating_ip_refs', None)
        if refs:
            for ref in refs:
                ref_fq_name = ref['to']
                obj_type = 'floating-ip'
                to_imid = common.imid.get_ifmap_id_from_fq_name(obj_type, ref_fq_name)
                customer_attachment_floating_ip_xml = ''
                meta = str(Metadata('customer-attachment-floating-ip' , '',
                       {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail',
                       elements = customer_attachment_floating_ip_xml))
                self._publish_id_pair_meta(my_imid, to_imid, meta)

        # construct object of xsd-type and get its xml repr
        refs = obj_dict.get('routing_instance_refs', None)
        if refs:
            for ref in refs:
                ref_fq_name = ref['to']
                obj_type = 'routing-instance'
                to_imid = common.imid.get_ifmap_id_from_fq_name(obj_type, ref_fq_name)
                binding_xml = ''
                ref_data = ref['attr']
                if ref_data:
                    buf = cStringIO.StringIO()
                    BindingType(**ref_data).exportChildren(buf, level = 1, name_ = 'binding', pretty_print = False)
                    binding_xml = binding_xml + buf.getvalue()
                    buf.close()
                meta = str(Metadata('binding' , '',
                       {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail',
                       elements = binding_xml))
                self._publish_id_pair_meta(my_imid, to_imid, meta)

        # construct object of xsd-type and get its xml repr
        refs = obj_dict.get('provider_attachment_refs', None)
        if refs:
            for ref in refs:
                ref_fq_name = ref['to']
                obj_type = 'provider-attachment'
                to_imid = common.imid.get_ifmap_id_from_fq_name(obj_type, ref_fq_name)
                attachment_info_xml = ''
                ref_data = ref['attr']
                if ref_data:
                    buf = cStringIO.StringIO()
                    AttachmentInfoType(**ref_data).exportChildren(buf, level = 1, name_ = 'attachment-info', pretty_print = False)
                    attachment_info_xml = attachment_info_xml + buf.getvalue()
                    buf.close()
                meta = str(Metadata('attachment-info' , '',
                       {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail',
                       elements = attachment_info_xml))
                self._publish_id_pair_meta(my_imid, to_imid, meta)


        return (True, '')
    #end _ifmap_customer_attachment_set

    def _ifmap_customer_attachment_create(self, obj_ids, obj_dict):
        (ok, result) = self._ifmap_customer_attachment_set(obj_ids['imid'], obj_dict)
        return (ok, result)
    #end _ifmap_customer_attachment_create

    def _ifmap_customer_attachment_read(self, ifmap_id, field_names = None):
        # field_names = None means all fields will be read
        imid = self._imid_handler
        mapclient = self._mapclient
        start_id = str(Identity(name = ifmap_id, type = 'other',
                        other_type = 'extended'))
        # if id-perms missing, identity doesn't exist

        all_metas = [u'contrail:customer-attachment-virtual-machine-interface', u'contrail:customer-attachment-floating-ip', u'contrail:attachment-address', u'contrail:id-perms', u'contrail:binding', u'contrail:attachment-info']
        if not field_names:
            metas_to_read = all_metas
        else: # read only requested fields
            req_metas = []
            if field_names.has_key('virtual_machine_interface_refs'):
                req_metas.append('contrail:customer-attachment-virtual-machine-interface')
            if field_names.has_key('floating_ip_refs'):
                req_metas.append('contrail:customer-attachment-floating-ip')
            if field_names.has_key('attachment_address'):
                req_metas.append('contrail:attachment-address')
            if field_names.has_key('id_perms'):
                req_metas.append('contrail:id-perms')
            if field_names.has_key('binding'):
                req_metas.append('contrail:binding')
            if field_names.has_key('attachment_info'):
                req_metas.append('contrail:attachment-info')

            metas_to_read = set(all_metas) & set(req_metas)

        srch_meta = ' or '.join(metas_to_read)
        srch_result = self._search(start_id, srch_meta)

        result_list = self.parse_result_items(srch_result, ifmap_id)
        if (len(result_list) == 1 and 
            result_list[0][2] == None):
            return (False, 'customer-attachment ' + ifmap_id + 'does not exist')

        # metas is a dict where key is meta-name and val is list of tuples
        # of form (ident1, ident2, meta)
        metas = {}
        for r_elem in result_list:
            r_meta = r_elem[2]
            # create contrail:<tag>
            meta_name = r_meta.prefix + ':' + re.sub('{.*}', '', r_meta.tag)

            if (
                (meta_name == 'contrail:customer-attachment-virtual-machine-interface') or
                (meta_name == 'contrail:customer-attachment-floating-ip') or
                (meta_name == 'contrail:attachment-address') or
                (meta_name == 'contrail:id-perms') or
                (meta_name == 'contrail:binding') or
                (meta_name == 'contrail:attachment-info')
               ):
                if metas.has_key(meta_name):
                    metas[meta_name].append(r_elem)
                else: # first ident for this link-type
                    metas[meta_name] = [r_elem]

         # Construct dicts from xml
        result = {}
        result['_type'] = 'customer-attachment'
        fq_name = self._db_client_mgr.ifmap_id_to_fq_name(ifmap_id)
        result['fq_name'] = fq_name
        result['name'] = fq_name[-1]
        if metas.has_key('contrail:customer-attachment-virtual-machine-interface'):
            result['virtual_machine_interface_refs'] = []
            result_elems = metas['contrail:customer-attachment-virtual-machine-interface']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                obj_val = {}
                # in case of refs between same types of identifiers,
                # the referred ident could appears at idx 0 or 1
                if ifmap_id == r_elem[0].attrib['name']:
                    ref_ifmap_id = r_elem[1].attrib['name']
                else:
                    ref_ifmap_id = r_elem[0].attrib['name']

                try:
                    ref_fq_name = self._db_client_mgr.ifmap_id_to_fq_name(ref_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown fq_name for ref ' + ref_ifmap_id
                    return (False, err_msg)
                try:
                    ref_uuid = self._db_client_mgr.ifmap_id_to_uuid(ref_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown uuid for ref ' + ref_ifmap_id
                    return (False, err_msg)

                ref_url = self._db_client_mgr.generate_url('virtual_machine_interface', ref_uuid)
                ref_info = {}
                ref_info['to'] = ref_fq_name
                ref_info['attr'] = obj_val
                ref_info['href'] = ref_url
                ref_info['uuid'] = ref_uuid
                result['virtual_machine_interface_refs'].append(ref_info)


        if metas.has_key('contrail:customer-attachment-floating-ip'):
            result['floating_ip_refs'] = []
            result_elems = metas['contrail:customer-attachment-floating-ip']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                obj_val = {}
                # in case of refs between same types of identifiers,
                # the referred ident could appears at idx 0 or 1
                if ifmap_id == r_elem[0].attrib['name']:
                    ref_ifmap_id = r_elem[1].attrib['name']
                else:
                    ref_ifmap_id = r_elem[0].attrib['name']

                try:
                    ref_fq_name = self._db_client_mgr.ifmap_id_to_fq_name(ref_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown fq_name for ref ' + ref_ifmap_id
                    return (False, err_msg)
                try:
                    ref_uuid = self._db_client_mgr.ifmap_id_to_uuid(ref_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown uuid for ref ' + ref_ifmap_id
                    return (False, err_msg)

                ref_url = self._db_client_mgr.generate_url('floating_ip', ref_uuid)
                ref_info = {}
                ref_info['to'] = ref_fq_name
                ref_info['attr'] = obj_val
                ref_info['href'] = ref_url
                ref_info['uuid'] = ref_uuid
                result['floating_ip_refs'].append(ref_info)


        if metas.has_key('contrail:attachment-address'):
            result_elems = metas['contrail:attachment-address']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                # need to preserve type eg. int for prefix-len
                # for now, xml -> obj -> json -> dict
                # TODO TypeGenerator.py should have xml to dict method
                obj = AttachmentAddressType()
                obj.build(meta)
                obj_json = ''
                obj_json = json.dumps(obj,
                    default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
                obj_val = json.loads(obj_json)
                result['attachment_address'] = obj_val

        if metas.has_key('contrail:id-perms'):
            result_elems = metas['contrail:id-perms']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                # need to preserve type eg. int for prefix-len
                # for now, xml -> obj -> json -> dict
                # TODO TypeGenerator.py should have xml to dict method
                obj = IdPermsType()
                obj.build(meta)
                obj_json = ''
                obj_json = json.dumps(obj,
                    default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
                obj_val = json.loads(obj_json)
                result['id_perms'] = obj_val

        if metas.has_key('contrail:binding'):
            result['routing_instances'] = []
            result_elems = metas['contrail:binding']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                obj_val = meta.text
                has_ifmap_id = r_elem[1].attrib['name']

                try:
                    has_fq_name = self._db_client_mgr.ifmap_id_to_fq_name(has_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown fq_name for child ' + has_ifmap_id
                    return (False, err_msg)
                try:
                    has_uuid = self._db_client_mgr.ifmap_id_to_uuid(has_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown uuid for child ' + has_ifmap_id
                    return (False, err_msg)

                has_url = self._db_client_mgr.generate_url('routing_instance', has_uuid)
                has_info = {}
                has_info['to'] = has_fq_name
                has_info['attr'] = obj_val
                has_info['href'] = has_url
                has_info['uuid'] = has_uuid
                result['routing_instances'].append(has_info)


        if metas.has_key('contrail:attachment-info'):
            result['provider_attachments'] = []
            result_elems = metas['contrail:attachment-info']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                # need to preserve type eg. int for prefix-len
                # for now, xml -> obj -> json -> dict
                # TODO TypeGenerator.py should have xml to dict method
                obj = AttachmentInfoType()
                obj.build(meta)
                obj_json = ''
                obj_json = json.dumps(obj,
                    default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
                obj_val = json.loads(obj_json)
                has_ifmap_id = r_elem[1].attrib['name']

                try:
                    has_fq_name = self._db_client_mgr.ifmap_id_to_fq_name(has_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown fq_name for child ' + has_ifmap_id
                    return (False, err_msg)
                try:
                    has_uuid = self._db_client_mgr.ifmap_id_to_uuid(has_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown uuid for child ' + has_ifmap_id
                    return (False, err_msg)

                has_url = self._db_client_mgr.generate_url('provider_attachment', has_uuid)
                has_info = {}
                has_info['to'] = has_fq_name
                has_info['attr'] = obj_val
                has_info['href'] = has_url
                has_info['uuid'] = has_uuid
                result['provider_attachments'].append(has_info)


        return (True, result)
    #end _ifmap_customer_attachment_read

    def _ifmap_customer_attachment_update(self, ifmap_id, old_obj_dict, new_obj_dict):
        # remove properties that are no longer active
        if ('attachment_address' in new_obj_dict) and (new_obj_dict['attachment_address'] == None):
            self._delete_id_self_meta(ifmap_id, 'attachment-address')

        if ('id_perms' in new_obj_dict) and (new_obj_dict['id_perms'] == None):
            self._delete_id_self_meta(ifmap_id, 'id-perms')

        # remove refs that are no longer active
        if ('virtual_machine_interface_refs' in old_obj_dict):
            old_refs = [tuple(ref['to']) for ref in old_obj_dict['virtual_machine_interface_refs']]
        else:
            old_refs = []
        if ('virtual_machine_interface_refs' in new_obj_dict):
            if new_obj_dict['virtual_machine_interface_refs'] == None:
                new_refs = []
            else:
                new_refs = [tuple(ref['to']) for ref in new_obj_dict['virtual_machine_interface_refs']]
        else: # no ref key in new_obj
            new_refs = old_refs

        old_set = set(old_refs)
        new_set = set(new_refs)
        inact_refs = old_set - new_set
        for inact_ref in inact_refs:
            to_imid = self.fq_name_to_ifmap_id('virtual-machine-interface', inact_ref)
            self._delete_id_pair_meta(ifmap_id, to_imid, 'contrail:customer-attachment-virtual-machine-interface')

        if ('floating_ip_refs' in old_obj_dict):
            old_refs = [tuple(ref['to']) for ref in old_obj_dict['floating_ip_refs']]
        else:
            old_refs = []
        if ('floating_ip_refs' in new_obj_dict):
            if new_obj_dict['floating_ip_refs'] == None:
                new_refs = []
            else:
                new_refs = [tuple(ref['to']) for ref in new_obj_dict['floating_ip_refs']]
        else: # no ref key in new_obj
            new_refs = old_refs

        old_set = set(old_refs)
        new_set = set(new_refs)
        inact_refs = old_set - new_set
        for inact_ref in inact_refs:
            to_imid = self.fq_name_to_ifmap_id('floating-ip', inact_ref)
            self._delete_id_pair_meta(ifmap_id, to_imid, 'contrail:customer-attachment-floating-ip')

        (ok, result) = self._ifmap_customer_attachment_set(ifmap_id, new_obj_dict)
        return (ok, result)
    #end _ifmap_customer_attachment_update

    def _ifmap_customer_attachment_list(self, parent_type, parent_fq_name):
        children_fq_names = []
        return (True, children_fq_names)
    #end _ifmap_customer_attachment_list

    def _ifmap_customer_attachment_delete(self, obj_ids):
        ifmap_id = obj_ids['imid']
        parent_imid = obj_ids.get('parent_imid', None)
        start_id = str(Identity(name = ifmap_id, type = 'other',
                        other_type = 'extended'))
        # Delete links to our references, first find them
        srch_meta = ' or '.join([u'contrail:customer-attachment-virtual-machine-interface', u'contrail:customer-attachment-floating-ip', u'contrail:binding', u'contrail:attachment-info'])
        srch_result = self._search(start_id, srch_meta)

        result_list = self.parse_result_items(srch_result, ifmap_id)
        for r_elem in result_list:
            to_ident = r_elem[1]
            if to_ident is None:
                continue
            to_imid = to_ident.attrib['name']
            r_meta = r_elem[2]
            # create contrail:<tag>
            meta_name = r_meta.prefix + ':' + re.sub('{.*}', '', r_meta.tag)
            self._delete_id_pair_meta(ifmap_id, to_imid, meta_name)


        if parent_imid:
            # Remove link from parent
            self._delete_id_pair_meta(parent_imid, ifmap_id, None)

        # Remove all property metadata associated with this ident
        self._delete_id_self_meta(ifmap_id, None)

        return (True, '')
    #end _ifmap_customer_attachment_delete

    def _ifmap_virtual_machine_alloc(self, parent_type, fq_name):
        imid = self._imid_handler
        (my_imid, parent_imid) = \
            imid.virtual_machine_alloc_ifmap_id(parent_type, fq_name)
        return (True, (my_imid, parent_imid))
    #end _ifmap_virtual_machine_alloc

    def _ifmap_virtual_machine_set(self, my_imid, obj_dict):
        # Properties Meta
        field = obj_dict.get('id_perms', None)
        if field:
            # construct object of xsd-type and get its xml repr
            field = obj_dict['id_perms']
            buf = cStringIO.StringIO()
            # perms might be inserted at server as obj.
            # obj construction diff from dict construction.
            if isinstance(field, dict):
                IdPermsType(**field).exportChildren(buf, level = 1, name_ = 'id-perms', pretty_print = False)
            else: # object
                field.exportChildren(buf, level = 1, name_ = 'id-perms', pretty_print = False)
            id_perms_xml = buf.getvalue()
            buf.close()
            meta = str(Metadata('id-perms' , '',
                   {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail',
                   elements = id_perms_xml))
            self._publish_id_self_meta(my_imid, meta)

        # Ref Link Metas
        imid = self._imid_handler

        # construct object of xsd-type and get its xml repr
        refs = obj_dict.get('security_group_refs', None)
        if refs:
            for ref in refs:
                ref_fq_name = ref['to']
                obj_type = 'security-group'
                to_imid = common.imid.get_ifmap_id_from_fq_name(obj_type, ref_fq_name)
                virtual_machine_security_group_xml = ''
                meta = str(Metadata('virtual-machine-security-group' , '',
                       {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail',
                       elements = virtual_machine_security_group_xml))
                self._publish_id_pair_meta(my_imid, to_imid, meta)

        # construct object of xsd-type and get its xml repr
        refs = obj_dict.get('virtual_machine_interface_refs', None)
        if refs:
            for ref in refs:
                ref_fq_name = ref['to']
                obj_type = 'virtual-machine-interface'
                to_imid = common.imid.get_ifmap_id_from_fq_name(obj_type, ref_fq_name)
                virtual_machine_virtual_machine_interface_xml = ''
                meta = str(Metadata('virtual-machine-virtual-machine-interface' , '',
                       {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail',
                       elements = virtual_machine_virtual_machine_interface_xml))
                self._publish_id_pair_meta(my_imid, to_imid, meta)

        # construct object of xsd-type and get its xml repr
        refs = obj_dict.get('service_instance_refs', None)
        if refs:
            for ref in refs:
                ref_fq_name = ref['to']
                obj_type = 'service-instance'
                to_imid = common.imid.get_ifmap_id_from_fq_name(obj_type, ref_fq_name)
                virtual_machine_service_instance_xml = ''
                meta = str(Metadata('virtual-machine-service-instance' , '',
                       {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail',
                       elements = virtual_machine_service_instance_xml))
                self._publish_id_pair_meta(my_imid, to_imid, meta)


        return (True, '')
    #end _ifmap_virtual_machine_set

    def _ifmap_virtual_machine_create(self, obj_ids, obj_dict):
        (ok, result) = self._ifmap_virtual_machine_set(obj_ids['imid'], obj_dict)
        return (ok, result)
    #end _ifmap_virtual_machine_create

    def _ifmap_virtual_machine_read(self, ifmap_id, field_names = None):
        # field_names = None means all fields will be read
        imid = self._imid_handler
        mapclient = self._mapclient
        start_id = str(Identity(name = ifmap_id, type = 'other',
                        other_type = 'extended'))
        # if id-perms missing, identity doesn't exist

        all_metas = [u'contrail:virtual-machine-security-group', u'contrail:virtual-machine-service-instance', u'contrail:virtual-router-virtual-machine', u'contrail:id-perms', u'contrail:virtual-machine-virtual-machine-interface']
        if not field_names:
            metas_to_read = all_metas
        else: # read only requested fields
            req_metas = []
            if field_names.has_key('security_group_refs'):
                req_metas.append('contrail:virtual-machine-security-group')
            if field_names.has_key('service_instance_refs'):
                req_metas.append('contrail:virtual-machine-service-instance')
            if field_names.has_key('virtual_router_back_refs'):
                req_metas.append('contrail:virtual-router-virtual-machine')
            if field_names.has_key('id_perms'):
                req_metas.append('contrail:id-perms')
            if field_names.has_key('virtual_machine_virtual_machine_interface'):
                req_metas.append('contrail:virtual-machine-virtual-machine-interface')

            metas_to_read = set(all_metas) & set(req_metas)

        srch_meta = ' or '.join(metas_to_read)
        srch_result = self._search(start_id, srch_meta)

        result_list = self.parse_result_items(srch_result, ifmap_id)
        if (len(result_list) == 1 and 
            result_list[0][2] == None):
            return (False, 'virtual-machine ' + ifmap_id + 'does not exist')

        # metas is a dict where key is meta-name and val is list of tuples
        # of form (ident1, ident2, meta)
        metas = {}
        for r_elem in result_list:
            r_meta = r_elem[2]
            # create contrail:<tag>
            meta_name = r_meta.prefix + ':' + re.sub('{.*}', '', r_meta.tag)

            if (
                (meta_name == 'contrail:virtual-machine-security-group') or
                (meta_name == 'contrail:virtual-machine-service-instance') or
                (meta_name == 'contrail:virtual-router-virtual-machine') or
                (meta_name == 'contrail:id-perms') or
                (meta_name == 'contrail:virtual-machine-virtual-machine-interface')
               ):
                if metas.has_key(meta_name):
                    metas[meta_name].append(r_elem)
                else: # first ident for this link-type
                    metas[meta_name] = [r_elem]

         # Construct dicts from xml
        result = {}
        result['_type'] = 'virtual-machine'
        fq_name = self._db_client_mgr.ifmap_id_to_fq_name(ifmap_id)
        result['fq_name'] = fq_name
        result['name'] = fq_name[-1]
        if metas.has_key('contrail:virtual-machine-security-group'):
            result['security_group_refs'] = []
            result_elems = metas['contrail:virtual-machine-security-group']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                obj_val = {}
                # in case of refs between same types of identifiers,
                # the referred ident could appears at idx 0 or 1
                if ifmap_id == r_elem[0].attrib['name']:
                    ref_ifmap_id = r_elem[1].attrib['name']
                else:
                    ref_ifmap_id = r_elem[0].attrib['name']

                try:
                    ref_fq_name = self._db_client_mgr.ifmap_id_to_fq_name(ref_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown fq_name for ref ' + ref_ifmap_id
                    return (False, err_msg)
                try:
                    ref_uuid = self._db_client_mgr.ifmap_id_to_uuid(ref_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown uuid for ref ' + ref_ifmap_id
                    return (False, err_msg)

                ref_url = self._db_client_mgr.generate_url('security_group', ref_uuid)
                ref_info = {}
                ref_info['to'] = ref_fq_name
                ref_info['attr'] = obj_val
                ref_info['href'] = ref_url
                ref_info['uuid'] = ref_uuid
                result['security_group_refs'].append(ref_info)


        if metas.has_key('contrail:virtual-machine-service-instance'):
            result['service_instance_refs'] = []
            result_elems = metas['contrail:virtual-machine-service-instance']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                obj_val = {}
                # in case of refs between same types of identifiers,
                # the referred ident could appears at idx 0 or 1
                if ifmap_id == r_elem[0].attrib['name']:
                    ref_ifmap_id = r_elem[1].attrib['name']
                else:
                    ref_ifmap_id = r_elem[0].attrib['name']

                try:
                    ref_fq_name = self._db_client_mgr.ifmap_id_to_fq_name(ref_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown fq_name for ref ' + ref_ifmap_id
                    return (False, err_msg)
                try:
                    ref_uuid = self._db_client_mgr.ifmap_id_to_uuid(ref_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown uuid for ref ' + ref_ifmap_id
                    return (False, err_msg)

                ref_url = self._db_client_mgr.generate_url('service_instance', ref_uuid)
                ref_info = {}
                ref_info['to'] = ref_fq_name
                ref_info['attr'] = obj_val
                ref_info['href'] = ref_url
                ref_info['uuid'] = ref_uuid
                result['service_instance_refs'].append(ref_info)


        if metas.has_key('contrail:virtual-router-virtual-machine'):
            result['virtual_router_back_refs'] = []
            result_elems = metas['contrail:virtual-router-virtual-machine']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                obj_val = {}
                back_ref_ifmap_id = r_elem[0].attrib['name']

                try:
                    back_ref_fq_name = self._db_client_mgr.ifmap_id_to_fq_name(back_ref_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown fq_name for backref ' + back_ref_ifmap_id
                    return (False, err_msg)
                try:
                    back_ref_uuid = self._db_client_mgr.ifmap_id_to_uuid(back_ref_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown uuid for backref ' + back_ref_ifmap_id
                    return (False, err_msg)

                back_ref_url = self._db_client_mgr.generate_url('virtual_router', back_ref_uuid)
                back_ref_info = {}
                back_ref_info['to'] = back_ref_fq_name
                back_ref_info['attr'] = obj_val
                back_ref_info['href'] = back_ref_url
                back_ref_info['uuid'] = back_ref_uuid
                result['virtual_router_back_refs'].append(back_ref_info)


        if metas.has_key('contrail:id-perms'):
            result_elems = metas['contrail:id-perms']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                # need to preserve type eg. int for prefix-len
                # for now, xml -> obj -> json -> dict
                # TODO TypeGenerator.py should have xml to dict method
                obj = IdPermsType()
                obj.build(meta)
                obj_json = ''
                obj_json = json.dumps(obj,
                    default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
                obj_val = json.loads(obj_json)
                result['id_perms'] = obj_val

        if metas.has_key('contrail:virtual-machine-virtual-machine-interface'):
            result['virtual_machine_interfaces'] = []
            result_elems = metas['contrail:virtual-machine-virtual-machine-interface']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                obj_val = {}
                has_ifmap_id = r_elem[1].attrib['name']

                try:
                    has_fq_name = self._db_client_mgr.ifmap_id_to_fq_name(has_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown fq_name for child ' + has_ifmap_id
                    return (False, err_msg)
                try:
                    has_uuid = self._db_client_mgr.ifmap_id_to_uuid(has_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown uuid for child ' + has_ifmap_id
                    return (False, err_msg)

                has_url = self._db_client_mgr.generate_url('virtual_machine_interface', has_uuid)
                has_info = {}
                has_info['to'] = has_fq_name
                has_info['attr'] = obj_val
                has_info['href'] = has_url
                has_info['uuid'] = has_uuid
                result['virtual_machine_interfaces'].append(has_info)


        return (True, result)
    #end _ifmap_virtual_machine_read

    def _ifmap_virtual_machine_update(self, ifmap_id, old_obj_dict, new_obj_dict):
        # remove properties that are no longer active
        if ('id_perms' in new_obj_dict) and (new_obj_dict['id_perms'] == None):
            self._delete_id_self_meta(ifmap_id, 'id-perms')

        # remove refs that are no longer active
        if ('security_group_refs' in old_obj_dict):
            old_refs = [tuple(ref['to']) for ref in old_obj_dict['security_group_refs']]
        else:
            old_refs = []
        if ('security_group_refs' in new_obj_dict):
            if new_obj_dict['security_group_refs'] == None:
                new_refs = []
            else:
                new_refs = [tuple(ref['to']) for ref in new_obj_dict['security_group_refs']]
        else: # no ref key in new_obj
            new_refs = old_refs

        old_set = set(old_refs)
        new_set = set(new_refs)
        inact_refs = old_set - new_set
        for inact_ref in inact_refs:
            to_imid = self.fq_name_to_ifmap_id('security-group', inact_ref)
            self._delete_id_pair_meta(ifmap_id, to_imid, 'contrail:virtual-machine-security-group')

        if ('service_instance_refs' in old_obj_dict):
            old_refs = [tuple(ref['to']) for ref in old_obj_dict['service_instance_refs']]
        else:
            old_refs = []
        if ('service_instance_refs' in new_obj_dict):
            if new_obj_dict['service_instance_refs'] == None:
                new_refs = []
            else:
                new_refs = [tuple(ref['to']) for ref in new_obj_dict['service_instance_refs']]
        else: # no ref key in new_obj
            new_refs = old_refs

        old_set = set(old_refs)
        new_set = set(new_refs)
        inact_refs = old_set - new_set
        for inact_ref in inact_refs:
            to_imid = self.fq_name_to_ifmap_id('service-instance', inact_ref)
            self._delete_id_pair_meta(ifmap_id, to_imid, 'contrail:virtual-machine-service-instance')

        (ok, result) = self._ifmap_virtual_machine_set(ifmap_id, new_obj_dict)
        return (ok, result)
    #end _ifmap_virtual_machine_update

    def _ifmap_virtual_machine_list(self, parent_type, parent_fq_name):
        children_fq_names = []
        return (True, children_fq_names)
    #end _ifmap_virtual_machine_list

    def _ifmap_virtual_machine_delete(self, obj_ids):
        ifmap_id = obj_ids['imid']
        parent_imid = obj_ids.get('parent_imid', None)
        start_id = str(Identity(name = ifmap_id, type = 'other',
                        other_type = 'extended'))
        # Delete links to our references, first find them
        srch_meta = ' or '.join([u'contrail:virtual-machine-security-group', u'contrail:virtual-machine-service-instance'])
        srch_result = self._search(start_id, srch_meta)

        result_list = self.parse_result_items(srch_result, ifmap_id)
        for r_elem in result_list:
            to_ident = r_elem[1]
            if to_ident is None:
                continue
            to_imid = to_ident.attrib['name']
            r_meta = r_elem[2]
            # create contrail:<tag>
            meta_name = r_meta.prefix + ':' + re.sub('{.*}', '', r_meta.tag)
            self._delete_id_pair_meta(ifmap_id, to_imid, meta_name)


        if parent_imid:
            # Remove link from parent
            self._delete_id_pair_meta(parent_imid, ifmap_id, None)

        # Remove all property metadata associated with this ident
        self._delete_id_self_meta(ifmap_id, None)

        return (True, '')
    #end _ifmap_virtual_machine_delete

    def _ifmap_service_template_alloc(self, parent_type, fq_name):
        imid = self._imid_handler
        (my_imid, parent_imid) = \
            imid.service_template_alloc_ifmap_id(parent_type, fq_name)
        return (True, (my_imid, parent_imid))
    #end _ifmap_service_template_alloc

    def _ifmap_service_template_set(self, my_imid, obj_dict):
        # Properties Meta
        field = obj_dict.get('service_template_properties', None)
        if field:
            # construct object of xsd-type and get its xml repr
            field = obj_dict['service_template_properties']
            buf = cStringIO.StringIO()
            # perms might be inserted at server as obj.
            # obj construction diff from dict construction.
            if isinstance(field, dict):
                ServiceTemplateType(**field).exportChildren(buf, level = 1, name_ = 'service-template-properties', pretty_print = False)
            else: # object
                field.exportChildren(buf, level = 1, name_ = 'service-template-properties', pretty_print = False)
            service_template_properties_xml = buf.getvalue()
            buf.close()
            meta = str(Metadata('service-template-properties' , '',
                   {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail',
                   elements = service_template_properties_xml))
            self._publish_id_self_meta(my_imid, meta)

        field = obj_dict.get('id_perms', None)
        if field:
            # construct object of xsd-type and get its xml repr
            field = obj_dict['id_perms']
            buf = cStringIO.StringIO()
            # perms might be inserted at server as obj.
            # obj construction diff from dict construction.
            if isinstance(field, dict):
                IdPermsType(**field).exportChildren(buf, level = 1, name_ = 'id-perms', pretty_print = False)
            else: # object
                field.exportChildren(buf, level = 1, name_ = 'id-perms', pretty_print = False)
            id_perms_xml = buf.getvalue()
            buf.close()
            meta = str(Metadata('id-perms' , '',
                   {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail',
                   elements = id_perms_xml))
            self._publish_id_self_meta(my_imid, meta)

        # Ref Link Metas
        imid = self._imid_handler


        return (True, '')
    #end _ifmap_service_template_set

    def _ifmap_service_template_create(self, obj_ids, obj_dict):
        if not 'parent_type' in obj_dict:
            # parent is config-root
            parent_type = 'config-root'
            parent_imid = 'contrail:config-root:root'
        else:
            parent_type = obj_dict['parent_type']
            parent_imid = obj_ids.get('parent_imid', None)

        # Parent Link Meta
        parent_link_meta = self._parent_metas[parent_type]['service-template']
        meta = str(Metadata(parent_link_meta, '',
                   {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail'))
        self._publish_id_pair_meta(parent_imid, obj_ids['imid'], meta)

        (ok, result) = self._ifmap_service_template_set(obj_ids['imid'], obj_dict)
        return (ok, result)
    #end _ifmap_service_template_create

    def _ifmap_service_template_read(self, ifmap_id, field_names = None):
        # field_names = None means all fields will be read
        imid = self._imid_handler
        mapclient = self._mapclient
        start_id = str(Identity(name = ifmap_id, type = 'other',
                        other_type = 'extended'))
        # if id-perms missing, identity doesn't exist

        all_metas = [u'contrail:service-instance-service-template', u'contrail:service-template-properties', u'contrail:id-perms']
        if not field_names:
            metas_to_read = all_metas
        else: # read only requested fields
            req_metas = []
            if field_names.has_key('service_instance_back_refs'):
                req_metas.append('contrail:service-instance-service-template')
            if field_names.has_key('service_template_properties'):
                req_metas.append('contrail:service-template-properties')
            if field_names.has_key('id_perms'):
                req_metas.append('contrail:id-perms')

            metas_to_read = set(all_metas) & set(req_metas)

        srch_meta = ' or '.join(metas_to_read)
        srch_result = self._search(start_id, srch_meta)

        result_list = self.parse_result_items(srch_result, ifmap_id)
        if (len(result_list) == 1 and 
            result_list[0][2] == None):
            return (False, 'service-template ' + ifmap_id + 'does not exist')

        # metas is a dict where key is meta-name and val is list of tuples
        # of form (ident1, ident2, meta)
        metas = {}
        for r_elem in result_list:
            r_meta = r_elem[2]
            # create contrail:<tag>
            meta_name = r_meta.prefix + ':' + re.sub('{.*}', '', r_meta.tag)

            if (
                (meta_name == 'contrail:service-instance-service-template') or
                (meta_name == 'contrail:service-template-properties') or
                (meta_name == 'contrail:id-perms')
               ):
                if metas.has_key(meta_name):
                    metas[meta_name].append(r_elem)
                else: # first ident for this link-type
                    metas[meta_name] = [r_elem]

         # Construct dicts from xml
        result = {}
        result['_type'] = 'service-template'
        fq_name = self._db_client_mgr.ifmap_id_to_fq_name(ifmap_id)
        result['fq_name'] = fq_name
        result['name'] = fq_name[-1]
        if metas.has_key('contrail:service-instance-service-template'):
            result['service_instance_back_refs'] = []
            result_elems = metas['contrail:service-instance-service-template']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                obj_val = {}
                back_ref_ifmap_id = r_elem[0].attrib['name']

                try:
                    back_ref_fq_name = self._db_client_mgr.ifmap_id_to_fq_name(back_ref_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown fq_name for backref ' + back_ref_ifmap_id
                    return (False, err_msg)
                try:
                    back_ref_uuid = self._db_client_mgr.ifmap_id_to_uuid(back_ref_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown uuid for backref ' + back_ref_ifmap_id
                    return (False, err_msg)

                back_ref_url = self._db_client_mgr.generate_url('service_instance', back_ref_uuid)
                back_ref_info = {}
                back_ref_info['to'] = back_ref_fq_name
                back_ref_info['attr'] = obj_val
                back_ref_info['href'] = back_ref_url
                back_ref_info['uuid'] = back_ref_uuid
                result['service_instance_back_refs'].append(back_ref_info)


        if metas.has_key('contrail:service-template-properties'):
            result_elems = metas['contrail:service-template-properties']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                # need to preserve type eg. int for prefix-len
                # for now, xml -> obj -> json -> dict
                # TODO TypeGenerator.py should have xml to dict method
                obj = ServiceTemplateType()
                obj.build(meta)
                obj_json = ''
                obj_json = json.dumps(obj,
                    default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
                obj_val = json.loads(obj_json)
                result['service_template_properties'] = obj_val

        if metas.has_key('contrail:id-perms'):
            result_elems = metas['contrail:id-perms']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                # need to preserve type eg. int for prefix-len
                # for now, xml -> obj -> json -> dict
                # TODO TypeGenerator.py should have xml to dict method
                obj = IdPermsType()
                obj.build(meta)
                obj_json = ''
                obj_json = json.dumps(obj,
                    default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
                obj_val = json.loads(obj_json)
                result['id_perms'] = obj_val

        return (True, result)
    #end _ifmap_service_template_read

    def _ifmap_service_template_update(self, ifmap_id, old_obj_dict, new_obj_dict):
        # remove properties that are no longer active
        if ('service_template_properties' in new_obj_dict) and (new_obj_dict['service_template_properties'] == None):
            self._delete_id_self_meta(ifmap_id, 'service-template-properties')

        if ('id_perms' in new_obj_dict) and (new_obj_dict['id_perms'] == None):
            self._delete_id_self_meta(ifmap_id, 'id-perms')

        # remove refs that are no longer active
        (ok, result) = self._ifmap_service_template_set(ifmap_id, new_obj_dict)
        return (ok, result)
    #end _ifmap_service_template_update

    def _ifmap_service_template_list(self, parent_type, parent_fq_name):
        children_fq_names = []
        mapclient = self._mapclient
        parent_imid = common.imid.get_ifmap_id_from_fq_name(parent_type, parent_fq_name)
        start_id = str(Identity(name = parent_imid, type = 'other',
                        other_type = 'extended'))
        # if id-perms missing, identity doesn't exist
        parent_link_meta = self._parent_metas[parent_type]['service-template']
        srch_meta = 'contrail:' + parent_link_meta
        srch_result = self._search(start_id, srch_meta)

        result_list = self.parse_result_items(srch_result, parent_imid)
        for r_elem in result_list:
            child_ident = r_elem[1]
            if child_ident is None:
                continue
            child_imid = child_ident.attrib['name']
            fq_name = self._db_client_mgr.ifmap_id_to_fq_name(child_imid)
            children_fq_names.append(fq_name)


        return (True, children_fq_names)
    #end _ifmap_service_template_list

    def _ifmap_service_template_delete(self, obj_ids):
        ifmap_id = obj_ids['imid']
        parent_imid = obj_ids.get('parent_imid', None)
        start_id = str(Identity(name = ifmap_id, type = 'other',
                        other_type = 'extended'))

        if parent_imid:
            # Remove link from parent
            self._delete_id_pair_meta(parent_imid, ifmap_id, None)

        # Remove all property metadata associated with this ident
        self._delete_id_self_meta(ifmap_id, None)

        return (True, '')
    #end _ifmap_service_template_delete

    def _ifmap_security_group_alloc(self, parent_type, fq_name):
        imid = self._imid_handler
        (my_imid, parent_imid) = \
            imid.security_group_alloc_ifmap_id(parent_type, fq_name)
        return (True, (my_imid, parent_imid))
    #end _ifmap_security_group_alloc

    def _ifmap_security_group_set(self, my_imid, obj_dict):
        # Properties Meta
        field = obj_dict.get('security_group_id', None)
        if field:
            meta = str(Metadata('security-group-id' , str(obj_dict['security_group_id']),
                   {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail'))
            self._publish_id_self_meta(my_imid, meta)

        field = obj_dict.get('security_group_entries', None)
        if field:
            # construct object of xsd-type and get its xml repr
            field = obj_dict['security_group_entries']
            buf = cStringIO.StringIO()
            # perms might be inserted at server as obj.
            # obj construction diff from dict construction.
            if isinstance(field, dict):
                PolicyEntriesType(**field).exportChildren(buf, level = 1, name_ = 'security-group-entries', pretty_print = False)
            else: # object
                field.exportChildren(buf, level = 1, name_ = 'security-group-entries', pretty_print = False)
            security_group_entries_xml = buf.getvalue()
            buf.close()
            meta = str(Metadata('security-group-entries' , '',
                   {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail',
                   elements = security_group_entries_xml))
            self._publish_id_self_meta(my_imid, meta)

        field = obj_dict.get('id_perms', None)
        if field:
            # construct object of xsd-type and get its xml repr
            field = obj_dict['id_perms']
            buf = cStringIO.StringIO()
            # perms might be inserted at server as obj.
            # obj construction diff from dict construction.
            if isinstance(field, dict):
                IdPermsType(**field).exportChildren(buf, level = 1, name_ = 'id-perms', pretty_print = False)
            else: # object
                field.exportChildren(buf, level = 1, name_ = 'id-perms', pretty_print = False)
            id_perms_xml = buf.getvalue()
            buf.close()
            meta = str(Metadata('id-perms' , '',
                   {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail',
                   elements = id_perms_xml))
            self._publish_id_self_meta(my_imid, meta)

        # Ref Link Metas
        imid = self._imid_handler


        return (True, '')
    #end _ifmap_security_group_set

    def _ifmap_security_group_create(self, obj_ids, obj_dict):
        if not 'parent_type' in obj_dict:
            # parent is config-root
            parent_type = 'config-root'
            parent_imid = 'contrail:config-root:root'
        else:
            parent_type = obj_dict['parent_type']
            parent_imid = obj_ids.get('parent_imid', None)

        # Parent Link Meta
        parent_link_meta = self._parent_metas[parent_type]['security-group']
        meta = str(Metadata(parent_link_meta, '',
                   {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail'))
        self._publish_id_pair_meta(parent_imid, obj_ids['imid'], meta)

        (ok, result) = self._ifmap_security_group_set(obj_ids['imid'], obj_dict)
        return (ok, result)
    #end _ifmap_security_group_create

    def _ifmap_security_group_read(self, ifmap_id, field_names = None):
        # field_names = None means all fields will be read
        imid = self._imid_handler
        mapclient = self._mapclient
        start_id = str(Identity(name = ifmap_id, type = 'other',
                        other_type = 'extended'))
        # if id-perms missing, identity doesn't exist

        all_metas = [u'contrail:virtual-machine-security-group', u'contrail:security-group-id', u'contrail:security-group-entries', u'contrail:id-perms']
        if not field_names:
            metas_to_read = all_metas
        else: # read only requested fields
            req_metas = []
            if field_names.has_key('virtual_machine_back_refs'):
                req_metas.append('contrail:virtual-machine-security-group')
            if field_names.has_key('security_group_id'):
                req_metas.append('contrail:security-group-id')
            if field_names.has_key('security_group_entries'):
                req_metas.append('contrail:security-group-entries')
            if field_names.has_key('id_perms'):
                req_metas.append('contrail:id-perms')

            metas_to_read = set(all_metas) & set(req_metas)

        srch_meta = ' or '.join(metas_to_read)
        srch_result = self._search(start_id, srch_meta)

        result_list = self.parse_result_items(srch_result, ifmap_id)
        if (len(result_list) == 1 and 
            result_list[0][2] == None):
            return (False, 'security-group ' + ifmap_id + 'does not exist')

        # metas is a dict where key is meta-name and val is list of tuples
        # of form (ident1, ident2, meta)
        metas = {}
        for r_elem in result_list:
            r_meta = r_elem[2]
            # create contrail:<tag>
            meta_name = r_meta.prefix + ':' + re.sub('{.*}', '', r_meta.tag)

            if (
                (meta_name == 'contrail:virtual-machine-security-group') or
                (meta_name == 'contrail:security-group-id') or
                (meta_name == 'contrail:security-group-entries') or
                (meta_name == 'contrail:id-perms')
               ):
                if metas.has_key(meta_name):
                    metas[meta_name].append(r_elem)
                else: # first ident for this link-type
                    metas[meta_name] = [r_elem]

         # Construct dicts from xml
        result = {}
        result['_type'] = 'security-group'
        fq_name = self._db_client_mgr.ifmap_id_to_fq_name(ifmap_id)
        result['fq_name'] = fq_name
        result['name'] = fq_name[-1]
        if metas.has_key('contrail:virtual-machine-security-group'):
            result['virtual_machine_back_refs'] = []
            result_elems = metas['contrail:virtual-machine-security-group']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                obj_val = {}
                back_ref_ifmap_id = r_elem[0].attrib['name']

                try:
                    back_ref_fq_name = self._db_client_mgr.ifmap_id_to_fq_name(back_ref_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown fq_name for backref ' + back_ref_ifmap_id
                    return (False, err_msg)
                try:
                    back_ref_uuid = self._db_client_mgr.ifmap_id_to_uuid(back_ref_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown uuid for backref ' + back_ref_ifmap_id
                    return (False, err_msg)

                back_ref_url = self._db_client_mgr.generate_url('virtual_machine', back_ref_uuid)
                back_ref_info = {}
                back_ref_info['to'] = back_ref_fq_name
                back_ref_info['attr'] = obj_val
                back_ref_info['href'] = back_ref_url
                back_ref_info['uuid'] = back_ref_uuid
                result['virtual_machine_back_refs'].append(back_ref_info)


        if metas.has_key('contrail:security-group-id'):
            result_elems = metas['contrail:security-group-id']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                obj_val = meta.text
                result['security_group_id'] = obj_val

        if metas.has_key('contrail:security-group-entries'):
            result_elems = metas['contrail:security-group-entries']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                # need to preserve type eg. int for prefix-len
                # for now, xml -> obj -> json -> dict
                # TODO TypeGenerator.py should have xml to dict method
                obj = PolicyEntriesType()
                obj.build(meta)
                obj_json = ''
                obj_json = json.dumps(obj,
                    default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
                obj_val = json.loads(obj_json)
                result['security_group_entries'] = obj_val

        if metas.has_key('contrail:id-perms'):
            result_elems = metas['contrail:id-perms']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                # need to preserve type eg. int for prefix-len
                # for now, xml -> obj -> json -> dict
                # TODO TypeGenerator.py should have xml to dict method
                obj = IdPermsType()
                obj.build(meta)
                obj_json = ''
                obj_json = json.dumps(obj,
                    default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
                obj_val = json.loads(obj_json)
                result['id_perms'] = obj_val

        return (True, result)
    #end _ifmap_security_group_read

    def _ifmap_security_group_update(self, ifmap_id, old_obj_dict, new_obj_dict):
        # remove properties that are no longer active
        if ('security_group_id' in new_obj_dict) and (new_obj_dict['security_group_id'] == None):
            self._delete_id_self_meta(ifmap_id, 'security-group-id')

        if ('security_group_entries' in new_obj_dict) and (new_obj_dict['security_group_entries'] == None):
            self._delete_id_self_meta(ifmap_id, 'security-group-entries')

        if ('id_perms' in new_obj_dict) and (new_obj_dict['id_perms'] == None):
            self._delete_id_self_meta(ifmap_id, 'id-perms')

        # remove refs that are no longer active
        (ok, result) = self._ifmap_security_group_set(ifmap_id, new_obj_dict)
        return (ok, result)
    #end _ifmap_security_group_update

    def _ifmap_security_group_list(self, parent_type, parent_fq_name):
        children_fq_names = []
        mapclient = self._mapclient
        parent_imid = common.imid.get_ifmap_id_from_fq_name(parent_type, parent_fq_name)
        start_id = str(Identity(name = parent_imid, type = 'other',
                        other_type = 'extended'))
        # if id-perms missing, identity doesn't exist
        parent_link_meta = self._parent_metas[parent_type]['security-group']
        srch_meta = 'contrail:' + parent_link_meta
        srch_result = self._search(start_id, srch_meta)

        result_list = self.parse_result_items(srch_result, parent_imid)
        for r_elem in result_list:
            child_ident = r_elem[1]
            if child_ident is None:
                continue
            child_imid = child_ident.attrib['name']
            fq_name = self._db_client_mgr.ifmap_id_to_fq_name(child_imid)
            children_fq_names.append(fq_name)


        return (True, children_fq_names)
    #end _ifmap_security_group_list

    def _ifmap_security_group_delete(self, obj_ids):
        ifmap_id = obj_ids['imid']
        parent_imid = obj_ids.get('parent_imid', None)
        start_id = str(Identity(name = ifmap_id, type = 'other',
                        other_type = 'extended'))

        if parent_imid:
            # Remove link from parent
            self._delete_id_pair_meta(parent_imid, ifmap_id, None)

        # Remove all property metadata associated with this ident
        self._delete_id_self_meta(ifmap_id, None)

        return (True, '')
    #end _ifmap_security_group_delete

    def _ifmap_provider_attachment_alloc(self, parent_type, fq_name):
        imid = self._imid_handler
        (my_imid, parent_imid) = \
            imid.provider_attachment_alloc_ifmap_id(parent_type, fq_name)
        return (True, (my_imid, parent_imid))
    #end _ifmap_provider_attachment_alloc

    def _ifmap_provider_attachment_set(self, my_imid, obj_dict):
        # Properties Meta
        field = obj_dict.get('id_perms', None)
        if field:
            # construct object of xsd-type and get its xml repr
            field = obj_dict['id_perms']
            buf = cStringIO.StringIO()
            # perms might be inserted at server as obj.
            # obj construction diff from dict construction.
            if isinstance(field, dict):
                IdPermsType(**field).exportChildren(buf, level = 1, name_ = 'id-perms', pretty_print = False)
            else: # object
                field.exportChildren(buf, level = 1, name_ = 'id-perms', pretty_print = False)
            id_perms_xml = buf.getvalue()
            buf.close()
            meta = str(Metadata('id-perms' , '',
                   {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail',
                   elements = id_perms_xml))
            self._publish_id_self_meta(my_imid, meta)

        # Ref Link Metas
        imid = self._imid_handler

        # construct object of xsd-type and get its xml repr
        refs = obj_dict.get('virtual_router_refs', None)
        if refs:
            for ref in refs:
                ref_fq_name = ref['to']
                obj_type = 'virtual-router'
                to_imid = common.imid.get_ifmap_id_from_fq_name(obj_type, ref_fq_name)
                provider_attachment_virtual_router_xml = ''
                meta = str(Metadata('provider-attachment-virtual-router' , '',
                       {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail',
                       elements = provider_attachment_virtual_router_xml))
                self._publish_id_pair_meta(my_imid, to_imid, meta)


        return (True, '')
    #end _ifmap_provider_attachment_set

    def _ifmap_provider_attachment_create(self, obj_ids, obj_dict):
        (ok, result) = self._ifmap_provider_attachment_set(obj_ids['imid'], obj_dict)
        return (ok, result)
    #end _ifmap_provider_attachment_create

    def _ifmap_provider_attachment_read(self, ifmap_id, field_names = None):
        # field_names = None means all fields will be read
        imid = self._imid_handler
        mapclient = self._mapclient
        start_id = str(Identity(name = ifmap_id, type = 'other',
                        other_type = 'extended'))
        # if id-perms missing, identity doesn't exist

        all_metas = [u'contrail:provider-attachment-virtual-router', u'contrail:id-perms']
        if not field_names:
            metas_to_read = all_metas
        else: # read only requested fields
            req_metas = []
            if field_names.has_key('virtual_router_refs'):
                req_metas.append('contrail:provider-attachment-virtual-router')
            if field_names.has_key('id_perms'):
                req_metas.append('contrail:id-perms')

            metas_to_read = set(all_metas) & set(req_metas)

        srch_meta = ' or '.join(metas_to_read)
        srch_result = self._search(start_id, srch_meta)

        result_list = self.parse_result_items(srch_result, ifmap_id)
        if (len(result_list) == 1 and 
            result_list[0][2] == None):
            return (False, 'provider-attachment ' + ifmap_id + 'does not exist')

        # metas is a dict where key is meta-name and val is list of tuples
        # of form (ident1, ident2, meta)
        metas = {}
        for r_elem in result_list:
            r_meta = r_elem[2]
            # create contrail:<tag>
            meta_name = r_meta.prefix + ':' + re.sub('{.*}', '', r_meta.tag)

            if (
                (meta_name == 'contrail:provider-attachment-virtual-router') or
                (meta_name == 'contrail:id-perms')
               ):
                if metas.has_key(meta_name):
                    metas[meta_name].append(r_elem)
                else: # first ident for this link-type
                    metas[meta_name] = [r_elem]

         # Construct dicts from xml
        result = {}
        result['_type'] = 'provider-attachment'
        fq_name = self._db_client_mgr.ifmap_id_to_fq_name(ifmap_id)
        result['fq_name'] = fq_name
        result['name'] = fq_name[-1]
        if metas.has_key('contrail:provider-attachment-virtual-router'):
            result['virtual_router_refs'] = []
            result_elems = metas['contrail:provider-attachment-virtual-router']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                obj_val = {}
                # in case of refs between same types of identifiers,
                # the referred ident could appears at idx 0 or 1
                if ifmap_id == r_elem[0].attrib['name']:
                    ref_ifmap_id = r_elem[1].attrib['name']
                else:
                    ref_ifmap_id = r_elem[0].attrib['name']

                try:
                    ref_fq_name = self._db_client_mgr.ifmap_id_to_fq_name(ref_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown fq_name for ref ' + ref_ifmap_id
                    return (False, err_msg)
                try:
                    ref_uuid = self._db_client_mgr.ifmap_id_to_uuid(ref_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown uuid for ref ' + ref_ifmap_id
                    return (False, err_msg)

                ref_url = self._db_client_mgr.generate_url('virtual_router', ref_uuid)
                ref_info = {}
                ref_info['to'] = ref_fq_name
                ref_info['attr'] = obj_val
                ref_info['href'] = ref_url
                ref_info['uuid'] = ref_uuid
                result['virtual_router_refs'].append(ref_info)


        if metas.has_key('contrail:id-perms'):
            result_elems = metas['contrail:id-perms']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                # need to preserve type eg. int for prefix-len
                # for now, xml -> obj -> json -> dict
                # TODO TypeGenerator.py should have xml to dict method
                obj = IdPermsType()
                obj.build(meta)
                obj_json = ''
                obj_json = json.dumps(obj,
                    default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
                obj_val = json.loads(obj_json)
                result['id_perms'] = obj_val

        return (True, result)
    #end _ifmap_provider_attachment_read

    def _ifmap_provider_attachment_update(self, ifmap_id, old_obj_dict, new_obj_dict):
        # remove properties that are no longer active
        if ('id_perms' in new_obj_dict) and (new_obj_dict['id_perms'] == None):
            self._delete_id_self_meta(ifmap_id, 'id-perms')

        # remove refs that are no longer active
        if ('virtual_router_refs' in old_obj_dict):
            old_refs = [tuple(ref['to']) for ref in old_obj_dict['virtual_router_refs']]
        else:
            old_refs = []
        if ('virtual_router_refs' in new_obj_dict):
            if new_obj_dict['virtual_router_refs'] == None:
                new_refs = []
            else:
                new_refs = [tuple(ref['to']) for ref in new_obj_dict['virtual_router_refs']]
        else: # no ref key in new_obj
            new_refs = old_refs

        old_set = set(old_refs)
        new_set = set(new_refs)
        inact_refs = old_set - new_set
        for inact_ref in inact_refs:
            to_imid = self.fq_name_to_ifmap_id('virtual-router', inact_ref)
            self._delete_id_pair_meta(ifmap_id, to_imid, 'contrail:provider-attachment-virtual-router')

        (ok, result) = self._ifmap_provider_attachment_set(ifmap_id, new_obj_dict)
        return (ok, result)
    #end _ifmap_provider_attachment_update

    def _ifmap_provider_attachment_list(self, parent_type, parent_fq_name):
        children_fq_names = []
        return (True, children_fq_names)
    #end _ifmap_provider_attachment_list

    def _ifmap_provider_attachment_delete(self, obj_ids):
        ifmap_id = obj_ids['imid']
        parent_imid = obj_ids.get('parent_imid', None)
        start_id = str(Identity(name = ifmap_id, type = 'other',
                        other_type = 'extended'))
        # Delete links to our references, first find them
        srch_meta = ' or '.join([u'contrail:provider-attachment-virtual-router'])
        srch_result = self._search(start_id, srch_meta)

        result_list = self.parse_result_items(srch_result, ifmap_id)
        for r_elem in result_list:
            to_ident = r_elem[1]
            if to_ident is None:
                continue
            to_imid = to_ident.attrib['name']
            r_meta = r_elem[2]
            # create contrail:<tag>
            meta_name = r_meta.prefix + ':' + re.sub('{.*}', '', r_meta.tag)
            self._delete_id_pair_meta(ifmap_id, to_imid, meta_name)


        if parent_imid:
            # Remove link from parent
            self._delete_id_pair_meta(parent_imid, ifmap_id, None)

        # Remove all property metadata associated with this ident
        self._delete_id_self_meta(ifmap_id, None)

        return (True, '')
    #end _ifmap_provider_attachment_delete

    def _ifmap_network_ipam_alloc(self, parent_type, fq_name):
        imid = self._imid_handler
        (my_imid, parent_imid) = \
            imid.network_ipam_alloc_ifmap_id(parent_type, fq_name)
        return (True, (my_imid, parent_imid))
    #end _ifmap_network_ipam_alloc

    def _ifmap_network_ipam_set(self, my_imid, obj_dict):
        # Properties Meta
        field = obj_dict.get('network_ipam_mgmt', None)
        if field:
            # construct object of xsd-type and get its xml repr
            field = obj_dict['network_ipam_mgmt']
            buf = cStringIO.StringIO()
            # perms might be inserted at server as obj.
            # obj construction diff from dict construction.
            if isinstance(field, dict):
                IpamType(**field).exportChildren(buf, level = 1, name_ = 'network-ipam-mgmt', pretty_print = False)
            else: # object
                field.exportChildren(buf, level = 1, name_ = 'network-ipam-mgmt', pretty_print = False)
            network_ipam_mgmt_xml = buf.getvalue()
            buf.close()
            meta = str(Metadata('network-ipam-mgmt' , '',
                   {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail',
                   elements = network_ipam_mgmt_xml))
            self._publish_id_self_meta(my_imid, meta)

        field = obj_dict.get('id_perms', None)
        if field:
            # construct object of xsd-type and get its xml repr
            field = obj_dict['id_perms']
            buf = cStringIO.StringIO()
            # perms might be inserted at server as obj.
            # obj construction diff from dict construction.
            if isinstance(field, dict):
                IdPermsType(**field).exportChildren(buf, level = 1, name_ = 'id-perms', pretty_print = False)
            else: # object
                field.exportChildren(buf, level = 1, name_ = 'id-perms', pretty_print = False)
            id_perms_xml = buf.getvalue()
            buf.close()
            meta = str(Metadata('id-perms' , '',
                   {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail',
                   elements = id_perms_xml))
            self._publish_id_self_meta(my_imid, meta)

        # Ref Link Metas
        imid = self._imid_handler

        # construct object of xsd-type and get its xml repr
        refs = obj_dict.get('virtual_DNS_refs', None)
        if refs:
            for ref in refs:
                ref_fq_name = ref['to']
                obj_type = 'virtual-DNS'
                to_imid = common.imid.get_ifmap_id_from_fq_name(obj_type, ref_fq_name)
                network_ipam_virtual_DNS_xml = ''
                meta = str(Metadata('network-ipam-virtual-DNS' , '',
                       {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail',
                       elements = network_ipam_virtual_DNS_xml))
                self._publish_id_pair_meta(my_imid, to_imid, meta)


        return (True, '')
    #end _ifmap_network_ipam_set

    def _ifmap_network_ipam_create(self, obj_ids, obj_dict):
        if not 'parent_type' in obj_dict:
            # parent is config-root
            parent_type = 'config-root'
            parent_imid = 'contrail:config-root:root'
        else:
            parent_type = obj_dict['parent_type']
            parent_imid = obj_ids.get('parent_imid', None)

        # Parent Link Meta
        parent_link_meta = self._parent_metas[parent_type]['network-ipam']
        meta = str(Metadata(parent_link_meta, '',
                   {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail'))
        self._publish_id_pair_meta(parent_imid, obj_ids['imid'], meta)

        (ok, result) = self._ifmap_network_ipam_set(obj_ids['imid'], obj_dict)
        return (ok, result)
    #end _ifmap_network_ipam_create

    def _ifmap_network_ipam_read(self, ifmap_id, field_names = None):
        # field_names = None means all fields will be read
        imid = self._imid_handler
        mapclient = self._mapclient
        start_id = str(Identity(name = ifmap_id, type = 'other',
                        other_type = 'extended'))
        # if id-perms missing, identity doesn't exist

        all_metas = [u'contrail:network-ipam-virtual-DNS', u'contrail:virtual-network-network-ipam', u'contrail:network-ipam-mgmt', u'contrail:id-perms']
        if not field_names:
            metas_to_read = all_metas
        else: # read only requested fields
            req_metas = []
            if field_names.has_key('virtual_DNS_refs'):
                req_metas.append('contrail:network-ipam-virtual-DNS')
            if field_names.has_key('virtual_network_back_refs'):
                req_metas.append('contrail:virtual-network-network-ipam')
            if field_names.has_key('network_ipam_mgmt'):
                req_metas.append('contrail:network-ipam-mgmt')
            if field_names.has_key('id_perms'):
                req_metas.append('contrail:id-perms')

            metas_to_read = set(all_metas) & set(req_metas)

        srch_meta = ' or '.join(metas_to_read)
        srch_result = self._search(start_id, srch_meta)

        result_list = self.parse_result_items(srch_result, ifmap_id)
        if (len(result_list) == 1 and 
            result_list[0][2] == None):
            return (False, 'network-ipam ' + ifmap_id + 'does not exist')

        # metas is a dict where key is meta-name and val is list of tuples
        # of form (ident1, ident2, meta)
        metas = {}
        for r_elem in result_list:
            r_meta = r_elem[2]
            # create contrail:<tag>
            meta_name = r_meta.prefix + ':' + re.sub('{.*}', '', r_meta.tag)

            if (
                (meta_name == 'contrail:network-ipam-virtual-DNS') or
                (meta_name == 'contrail:virtual-network-network-ipam') or
                (meta_name == 'contrail:network-ipam-mgmt') or
                (meta_name == 'contrail:id-perms')
               ):
                if metas.has_key(meta_name):
                    metas[meta_name].append(r_elem)
                else: # first ident for this link-type
                    metas[meta_name] = [r_elem]

         # Construct dicts from xml
        result = {}
        result['_type'] = 'network-ipam'
        fq_name = self._db_client_mgr.ifmap_id_to_fq_name(ifmap_id)
        result['fq_name'] = fq_name
        result['name'] = fq_name[-1]
        if metas.has_key('contrail:network-ipam-virtual-DNS'):
            result['virtual_DNS_refs'] = []
            result_elems = metas['contrail:network-ipam-virtual-DNS']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                obj_val = {}
                # in case of refs between same types of identifiers,
                # the referred ident could appears at idx 0 or 1
                if ifmap_id == r_elem[0].attrib['name']:
                    ref_ifmap_id = r_elem[1].attrib['name']
                else:
                    ref_ifmap_id = r_elem[0].attrib['name']

                try:
                    ref_fq_name = self._db_client_mgr.ifmap_id_to_fq_name(ref_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown fq_name for ref ' + ref_ifmap_id
                    return (False, err_msg)
                try:
                    ref_uuid = self._db_client_mgr.ifmap_id_to_uuid(ref_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown uuid for ref ' + ref_ifmap_id
                    return (False, err_msg)

                ref_url = self._db_client_mgr.generate_url('virtual_DNS', ref_uuid)
                ref_info = {}
                ref_info['to'] = ref_fq_name
                ref_info['attr'] = obj_val
                ref_info['href'] = ref_url
                ref_info['uuid'] = ref_uuid
                result['virtual_DNS_refs'].append(ref_info)


        if metas.has_key('contrail:virtual-network-network-ipam'):
            result['virtual_network_back_refs'] = []
            result_elems = metas['contrail:virtual-network-network-ipam']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                # need to preserve type eg. int for prefix-len
                # for now, xml -> obj -> json -> dict
                # TODO TypeGenerator.py should have xml to dict method
                obj = VnSubnetsType()
                obj.build(meta)
                obj_json = ''
                obj_json = json.dumps(obj,
                    default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
                obj_val = json.loads(obj_json)
                back_ref_ifmap_id = r_elem[0].attrib['name']

                try:
                    back_ref_fq_name = self._db_client_mgr.ifmap_id_to_fq_name(back_ref_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown fq_name for backref ' + back_ref_ifmap_id
                    return (False, err_msg)
                try:
                    back_ref_uuid = self._db_client_mgr.ifmap_id_to_uuid(back_ref_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown uuid for backref ' + back_ref_ifmap_id
                    return (False, err_msg)

                back_ref_url = self._db_client_mgr.generate_url('virtual_network', back_ref_uuid)
                back_ref_info = {}
                back_ref_info['to'] = back_ref_fq_name
                back_ref_info['attr'] = obj_val
                back_ref_info['href'] = back_ref_url
                back_ref_info['uuid'] = back_ref_uuid
                result['virtual_network_back_refs'].append(back_ref_info)


        if metas.has_key('contrail:network-ipam-mgmt'):
            result_elems = metas['contrail:network-ipam-mgmt']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                # need to preserve type eg. int for prefix-len
                # for now, xml -> obj -> json -> dict
                # TODO TypeGenerator.py should have xml to dict method
                obj = IpamType()
                obj.build(meta)
                obj_json = ''
                obj_json = json.dumps(obj,
                    default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
                obj_val = json.loads(obj_json)
                result['network_ipam_mgmt'] = obj_val

        if metas.has_key('contrail:id-perms'):
            result_elems = metas['contrail:id-perms']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                # need to preserve type eg. int for prefix-len
                # for now, xml -> obj -> json -> dict
                # TODO TypeGenerator.py should have xml to dict method
                obj = IdPermsType()
                obj.build(meta)
                obj_json = ''
                obj_json = json.dumps(obj,
                    default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
                obj_val = json.loads(obj_json)
                result['id_perms'] = obj_val

        return (True, result)
    #end _ifmap_network_ipam_read

    def _ifmap_network_ipam_update(self, ifmap_id, old_obj_dict, new_obj_dict):
        # remove properties that are no longer active
        if ('network_ipam_mgmt' in new_obj_dict) and (new_obj_dict['network_ipam_mgmt'] == None):
            self._delete_id_self_meta(ifmap_id, 'network-ipam-mgmt')

        if ('id_perms' in new_obj_dict) and (new_obj_dict['id_perms'] == None):
            self._delete_id_self_meta(ifmap_id, 'id-perms')

        # remove refs that are no longer active
        if ('virtual_DNS_refs' in old_obj_dict):
            old_refs = [tuple(ref['to']) for ref in old_obj_dict['virtual_DNS_refs']]
        else:
            old_refs = []
        if ('virtual_DNS_refs' in new_obj_dict):
            if new_obj_dict['virtual_DNS_refs'] == None:
                new_refs = []
            else:
                new_refs = [tuple(ref['to']) for ref in new_obj_dict['virtual_DNS_refs']]
        else: # no ref key in new_obj
            new_refs = old_refs

        old_set = set(old_refs)
        new_set = set(new_refs)
        inact_refs = old_set - new_set
        for inact_ref in inact_refs:
            to_imid = self.fq_name_to_ifmap_id('virtual-DNS', inact_ref)
            self._delete_id_pair_meta(ifmap_id, to_imid, 'contrail:network-ipam-virtual-DNS')

        (ok, result) = self._ifmap_network_ipam_set(ifmap_id, new_obj_dict)
        return (ok, result)
    #end _ifmap_network_ipam_update

    def _ifmap_network_ipam_list(self, parent_type, parent_fq_name):
        children_fq_names = []
        mapclient = self._mapclient
        parent_imid = common.imid.get_ifmap_id_from_fq_name(parent_type, parent_fq_name)
        start_id = str(Identity(name = parent_imid, type = 'other',
                        other_type = 'extended'))
        # if id-perms missing, identity doesn't exist
        parent_link_meta = self._parent_metas[parent_type]['network-ipam']
        srch_meta = 'contrail:' + parent_link_meta
        srch_result = self._search(start_id, srch_meta)

        result_list = self.parse_result_items(srch_result, parent_imid)
        for r_elem in result_list:
            child_ident = r_elem[1]
            if child_ident is None:
                continue
            child_imid = child_ident.attrib['name']
            fq_name = self._db_client_mgr.ifmap_id_to_fq_name(child_imid)
            children_fq_names.append(fq_name)


        return (True, children_fq_names)
    #end _ifmap_network_ipam_list

    def _ifmap_network_ipam_delete(self, obj_ids):
        ifmap_id = obj_ids['imid']
        parent_imid = obj_ids.get('parent_imid', None)
        start_id = str(Identity(name = ifmap_id, type = 'other',
                        other_type = 'extended'))
        # Delete links to our references, first find them
        srch_meta = ' or '.join([u'contrail:network-ipam-virtual-DNS'])
        srch_result = self._search(start_id, srch_meta)

        result_list = self.parse_result_items(srch_result, ifmap_id)
        for r_elem in result_list:
            to_ident = r_elem[1]
            if to_ident is None:
                continue
            to_imid = to_ident.attrib['name']
            r_meta = r_elem[2]
            # create contrail:<tag>
            meta_name = r_meta.prefix + ':' + re.sub('{.*}', '', r_meta.tag)
            self._delete_id_pair_meta(ifmap_id, to_imid, meta_name)


        if parent_imid:
            # Remove link from parent
            self._delete_id_pair_meta(parent_imid, ifmap_id, None)

        # Remove all property metadata associated with this ident
        self._delete_id_self_meta(ifmap_id, None)

        return (True, '')
    #end _ifmap_network_ipam_delete

    def _ifmap_virtual_network_alloc(self, parent_type, fq_name):
        imid = self._imid_handler
        (my_imid, parent_imid) = \
            imid.virtual_network_alloc_ifmap_id(parent_type, fq_name)
        return (True, (my_imid, parent_imid))
    #end _ifmap_virtual_network_alloc

    def _ifmap_virtual_network_set(self, my_imid, obj_dict):
        # Properties Meta
        field = obj_dict.get('virtual_network_properties', None)
        if field:
            # construct object of xsd-type and get its xml repr
            field = obj_dict['virtual_network_properties']
            buf = cStringIO.StringIO()
            # perms might be inserted at server as obj.
            # obj construction diff from dict construction.
            if isinstance(field, dict):
                VirtualNetworkType(**field).exportChildren(buf, level = 1, name_ = 'virtual-network-properties', pretty_print = False)
            else: # object
                field.exportChildren(buf, level = 1, name_ = 'virtual-network-properties', pretty_print = False)
            virtual_network_properties_xml = buf.getvalue()
            buf.close()
            meta = str(Metadata('virtual-network-properties' , '',
                   {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail',
                   elements = virtual_network_properties_xml))
            self._publish_id_self_meta(my_imid, meta)

        field = obj_dict.get('route_target_list', None)
        if field:
            # construct object of xsd-type and get its xml repr
            field = obj_dict['route_target_list']
            buf = cStringIO.StringIO()
            # perms might be inserted at server as obj.
            # obj construction diff from dict construction.
            if isinstance(field, dict):
                RouteTargetList(**field).exportChildren(buf, level = 1, name_ = 'route-target-list', pretty_print = False)
            else: # object
                field.exportChildren(buf, level = 1, name_ = 'route-target-list', pretty_print = False)
            route_target_list_xml = buf.getvalue()
            buf.close()
            meta = str(Metadata('route-target-list' , '',
                   {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail',
                   elements = route_target_list_xml))
            self._publish_id_self_meta(my_imid, meta)

        field = obj_dict.get('route_table', None)
        if field:
            # construct object of xsd-type and get its xml repr
            field = obj_dict['route_table']
            buf = cStringIO.StringIO()
            # perms might be inserted at server as obj.
            # obj construction diff from dict construction.
            if isinstance(field, dict):
                RouteTableType(**field).exportChildren(buf, level = 1, name_ = 'route-table', pretty_print = False)
            else: # object
                field.exportChildren(buf, level = 1, name_ = 'route-table', pretty_print = False)
            route_table_xml = buf.getvalue()
            buf.close()
            meta = str(Metadata('route-table' , '',
                   {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail',
                   elements = route_table_xml))
            self._publish_id_self_meta(my_imid, meta)

        field = obj_dict.get('id_perms', None)
        if field:
            # construct object of xsd-type and get its xml repr
            field = obj_dict['id_perms']
            buf = cStringIO.StringIO()
            # perms might be inserted at server as obj.
            # obj construction diff from dict construction.
            if isinstance(field, dict):
                IdPermsType(**field).exportChildren(buf, level = 1, name_ = 'id-perms', pretty_print = False)
            else: # object
                field.exportChildren(buf, level = 1, name_ = 'id-perms', pretty_print = False)
            id_perms_xml = buf.getvalue()
            buf.close()
            meta = str(Metadata('id-perms' , '',
                   {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail',
                   elements = id_perms_xml))
            self._publish_id_self_meta(my_imid, meta)

        # Ref Link Metas
        imid = self._imid_handler

        # construct object of xsd-type and get its xml repr
        refs = obj_dict.get('network_ipam_refs', None)
        if refs:
            for ref in refs:
                ref_fq_name = ref['to']
                obj_type = 'network-ipam'
                to_imid = common.imid.get_ifmap_id_from_fq_name(obj_type, ref_fq_name)
                virtual_network_network_ipam_xml = ''
                ref_data = ref['attr']
                if ref_data:
                    buf = cStringIO.StringIO()
                    VnSubnetsType(**ref_data).exportChildren(buf, level = 1, name_ = 'virtual-network-network-ipam', pretty_print = False)
                    virtual_network_network_ipam_xml = virtual_network_network_ipam_xml + buf.getvalue()
                    buf.close()
                meta = str(Metadata('virtual-network-network-ipam' , '',
                       {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail',
                       elements = virtual_network_network_ipam_xml))
                self._publish_id_pair_meta(my_imid, to_imid, meta)

        # construct object of xsd-type and get its xml repr
        refs = obj_dict.get('network_policy_refs', None)
        if refs:
            for ref in refs:
                ref_fq_name = ref['to']
                obj_type = 'network-policy'
                to_imid = common.imid.get_ifmap_id_from_fq_name(obj_type, ref_fq_name)
                virtual_network_network_policy_xml = ''
                ref_data = ref['attr']
                if ref_data:
                    buf = cStringIO.StringIO()
                    VirtualNetworkPolicyType(**ref_data).exportChildren(buf, level = 1, name_ = 'virtual-network-network-policy', pretty_print = False)
                    virtual_network_network_policy_xml = virtual_network_network_policy_xml + buf.getvalue()
                    buf.close()
                meta = str(Metadata('virtual-network-network-policy' , '',
                       {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail',
                       elements = virtual_network_network_policy_xml))
                self._publish_id_pair_meta(my_imid, to_imid, meta)

        # construct object of xsd-type and get its xml repr
        refs = obj_dict.get('access_control_list_refs', None)
        if refs:
            for ref in refs:
                ref_fq_name = ref['to']
                obj_type = 'access-control-list'
                to_imid = common.imid.get_ifmap_id_from_fq_name(obj_type, ref_fq_name)
                access_control_list_link_xml = ''
                meta = str(Metadata('access-control-list-link' , '',
                       {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail',
                       elements = access_control_list_link_xml))
                self._publish_id_pair_meta(my_imid, to_imid, meta)

        # construct object of xsd-type and get its xml repr
        refs = obj_dict.get('floating_ip_pool_refs', None)
        if refs:
            for ref in refs:
                ref_fq_name = ref['to']
                obj_type = 'floating-ip-pool'
                to_imid = common.imid.get_ifmap_id_from_fq_name(obj_type, ref_fq_name)
                virtual_network_floating_ip_pool_xml = ''
                meta = str(Metadata('virtual-network-floating-ip-pool' , '',
                       {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail',
                       elements = virtual_network_floating_ip_pool_xml))
                self._publish_id_pair_meta(my_imid, to_imid, meta)

        # construct object of xsd-type and get its xml repr
        refs = obj_dict.get('routing_instance_refs', None)
        if refs:
            for ref in refs:
                ref_fq_name = ref['to']
                obj_type = 'routing-instance'
                to_imid = common.imid.get_ifmap_id_from_fq_name(obj_type, ref_fq_name)
                virtual_network_routing_instance_xml = ''
                meta = str(Metadata('virtual-network-routing-instance' , '',
                       {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail',
                       elements = virtual_network_routing_instance_xml))
                self._publish_id_pair_meta(my_imid, to_imid, meta)


        return (True, '')
    #end _ifmap_virtual_network_set

    def _ifmap_virtual_network_create(self, obj_ids, obj_dict):
        if not 'parent_type' in obj_dict:
            # parent is config-root
            parent_type = 'config-root'
            parent_imid = 'contrail:config-root:root'
        else:
            parent_type = obj_dict['parent_type']
            parent_imid = obj_ids.get('parent_imid', None)

        # Parent Link Meta
        parent_link_meta = self._parent_metas[parent_type]['virtual-network']
        meta = str(Metadata(parent_link_meta, '',
                   {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail'))
        self._publish_id_pair_meta(parent_imid, obj_ids['imid'], meta)

        (ok, result) = self._ifmap_virtual_network_set(obj_ids['imid'], obj_dict)
        return (ok, result)
    #end _ifmap_virtual_network_create

    def _ifmap_virtual_network_read(self, ifmap_id, field_names = None):
        # field_names = None means all fields will be read
        imid = self._imid_handler
        mapclient = self._mapclient
        start_id = str(Identity(name = ifmap_id, type = 'other',
                        other_type = 'extended'))
        # if id-perms missing, identity doesn't exist

        all_metas = [u'contrail:virtual-network-network-ipam', u'contrail:virtual-network-network-policy', u'contrail:virtual-machine-interface-virtual-network', u'contrail:instance-ip-virtual-network', u'contrail:logical-interface-virtual-network', u'contrail:virtual-network-properties', u'contrail:route-target-list', u'contrail:route-table', u'contrail:id-perms', u'contrail:access-control-list-link', u'contrail:virtual-network-floating-ip-pool', u'contrail:virtual-network-routing-instance']
        if not field_names:
            metas_to_read = all_metas
        else: # read only requested fields
            req_metas = []
            if field_names.has_key('network_ipam_refs'):
                req_metas.append('contrail:virtual-network-network-ipam')
            if field_names.has_key('network_policy_refs'):
                req_metas.append('contrail:virtual-network-network-policy')
            if field_names.has_key('virtual_machine_interface_back_refs'):
                req_metas.append('contrail:virtual-machine-interface-virtual-network')
            if field_names.has_key('instance_ip_back_refs'):
                req_metas.append('contrail:instance-ip-virtual-network')
            if field_names.has_key('logical_interface_back_refs'):
                req_metas.append('contrail:logical-interface-virtual-network')
            if field_names.has_key('virtual_network_properties'):
                req_metas.append('contrail:virtual-network-properties')
            if field_names.has_key('route_target_list'):
                req_metas.append('contrail:route-target-list')
            if field_names.has_key('route_table'):
                req_metas.append('contrail:route-table')
            if field_names.has_key('id_perms'):
                req_metas.append('contrail:id-perms')
            if field_names.has_key('access_control_list_link'):
                req_metas.append('contrail:access-control-list-link')
            if field_names.has_key('virtual_network_floating_ip_pool'):
                req_metas.append('contrail:virtual-network-floating-ip-pool')
            if field_names.has_key('virtual_network_routing_instance'):
                req_metas.append('contrail:virtual-network-routing-instance')

            metas_to_read = set(all_metas) & set(req_metas)

        srch_meta = ' or '.join(metas_to_read)
        srch_result = self._search(start_id, srch_meta)

        result_list = self.parse_result_items(srch_result, ifmap_id)
        if (len(result_list) == 1 and 
            result_list[0][2] == None):
            return (False, 'virtual-network ' + ifmap_id + 'does not exist')

        # metas is a dict where key is meta-name and val is list of tuples
        # of form (ident1, ident2, meta)
        metas = {}
        for r_elem in result_list:
            r_meta = r_elem[2]
            # create contrail:<tag>
            meta_name = r_meta.prefix + ':' + re.sub('{.*}', '', r_meta.tag)

            if (
                (meta_name == 'contrail:virtual-network-network-ipam') or
                (meta_name == 'contrail:virtual-network-network-policy') or
                (meta_name == 'contrail:virtual-machine-interface-virtual-network') or
                (meta_name == 'contrail:instance-ip-virtual-network') or
                (meta_name == 'contrail:logical-interface-virtual-network') or
                (meta_name == 'contrail:virtual-network-properties') or
                (meta_name == 'contrail:route-target-list') or
                (meta_name == 'contrail:route-table') or
                (meta_name == 'contrail:id-perms') or
                (meta_name == 'contrail:access-control-list-link') or
                (meta_name == 'contrail:virtual-network-floating-ip-pool') or
                (meta_name == 'contrail:virtual-network-routing-instance')
               ):
                if metas.has_key(meta_name):
                    metas[meta_name].append(r_elem)
                else: # first ident for this link-type
                    metas[meta_name] = [r_elem]

         # Construct dicts from xml
        result = {}
        result['_type'] = 'virtual-network'
        fq_name = self._db_client_mgr.ifmap_id_to_fq_name(ifmap_id)
        result['fq_name'] = fq_name
        result['name'] = fq_name[-1]
        if metas.has_key('contrail:virtual-network-network-ipam'):
            result['network_ipam_refs'] = []
            result_elems = metas['contrail:virtual-network-network-ipam']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                # need to preserve type eg. int for prefix-len
                # for now, xml -> obj -> json -> dict
                # TODO TypeGenerator.py should have xml to dict method
                obj = VnSubnetsType()
                obj.build(meta)
                obj_json = ''
                obj_json = json.dumps(obj,
                    default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
                obj_val = json.loads(obj_json)
                # in case of refs between same types of identifiers,
                # the referred ident could appears at idx 0 or 1
                if ifmap_id == r_elem[0].attrib['name']:
                    ref_ifmap_id = r_elem[1].attrib['name']
                else:
                    ref_ifmap_id = r_elem[0].attrib['name']

                try:
                    ref_fq_name = self._db_client_mgr.ifmap_id_to_fq_name(ref_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown fq_name for ref ' + ref_ifmap_id
                    return (False, err_msg)
                try:
                    ref_uuid = self._db_client_mgr.ifmap_id_to_uuid(ref_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown uuid for ref ' + ref_ifmap_id
                    return (False, err_msg)

                ref_url = self._db_client_mgr.generate_url('network_ipam', ref_uuid)
                ref_info = {}
                ref_info['to'] = ref_fq_name
                ref_info['attr'] = obj_val
                ref_info['href'] = ref_url
                ref_info['uuid'] = ref_uuid
                result['network_ipam_refs'].append(ref_info)


        if metas.has_key('contrail:virtual-network-network-policy'):
            result['network_policy_refs'] = []
            result_elems = metas['contrail:virtual-network-network-policy']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                # need to preserve type eg. int for prefix-len
                # for now, xml -> obj -> json -> dict
                # TODO TypeGenerator.py should have xml to dict method
                obj = VirtualNetworkPolicyType()
                obj.build(meta)
                obj_json = ''
                obj_json = json.dumps(obj,
                    default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
                obj_val = json.loads(obj_json)
                # in case of refs between same types of identifiers,
                # the referred ident could appears at idx 0 or 1
                if ifmap_id == r_elem[0].attrib['name']:
                    ref_ifmap_id = r_elem[1].attrib['name']
                else:
                    ref_ifmap_id = r_elem[0].attrib['name']

                try:
                    ref_fq_name = self._db_client_mgr.ifmap_id_to_fq_name(ref_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown fq_name for ref ' + ref_ifmap_id
                    return (False, err_msg)
                try:
                    ref_uuid = self._db_client_mgr.ifmap_id_to_uuid(ref_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown uuid for ref ' + ref_ifmap_id
                    return (False, err_msg)

                ref_url = self._db_client_mgr.generate_url('network_policy', ref_uuid)
                ref_info = {}
                ref_info['to'] = ref_fq_name
                ref_info['attr'] = obj_val
                ref_info['href'] = ref_url
                ref_info['uuid'] = ref_uuid
                result['network_policy_refs'].append(ref_info)


        if metas.has_key('contrail:virtual-machine-interface-virtual-network'):
            result['virtual_machine_interface_back_refs'] = []
            result_elems = metas['contrail:virtual-machine-interface-virtual-network']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                obj_val = {}
                back_ref_ifmap_id = r_elem[0].attrib['name']

                try:
                    back_ref_fq_name = self._db_client_mgr.ifmap_id_to_fq_name(back_ref_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown fq_name for backref ' + back_ref_ifmap_id
                    return (False, err_msg)
                try:
                    back_ref_uuid = self._db_client_mgr.ifmap_id_to_uuid(back_ref_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown uuid for backref ' + back_ref_ifmap_id
                    return (False, err_msg)

                back_ref_url = self._db_client_mgr.generate_url('virtual_machine_interface', back_ref_uuid)
                back_ref_info = {}
                back_ref_info['to'] = back_ref_fq_name
                back_ref_info['attr'] = obj_val
                back_ref_info['href'] = back_ref_url
                back_ref_info['uuid'] = back_ref_uuid
                result['virtual_machine_interface_back_refs'].append(back_ref_info)


        if metas.has_key('contrail:instance-ip-virtual-network'):
            result['instance_ip_back_refs'] = []
            result_elems = metas['contrail:instance-ip-virtual-network']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                obj_val = {}
                back_ref_ifmap_id = r_elem[0].attrib['name']

                try:
                    back_ref_fq_name = self._db_client_mgr.ifmap_id_to_fq_name(back_ref_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown fq_name for backref ' + back_ref_ifmap_id
                    return (False, err_msg)
                try:
                    back_ref_uuid = self._db_client_mgr.ifmap_id_to_uuid(back_ref_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown uuid for backref ' + back_ref_ifmap_id
                    return (False, err_msg)

                back_ref_url = self._db_client_mgr.generate_url('instance_ip', back_ref_uuid)
                back_ref_info = {}
                back_ref_info['to'] = back_ref_fq_name
                back_ref_info['attr'] = obj_val
                back_ref_info['href'] = back_ref_url
                back_ref_info['uuid'] = back_ref_uuid
                result['instance_ip_back_refs'].append(back_ref_info)


        if metas.has_key('contrail:logical-interface-virtual-network'):
            result['logical_interface_back_refs'] = []
            result_elems = metas['contrail:logical-interface-virtual-network']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                obj_val = {}
                back_ref_ifmap_id = r_elem[0].attrib['name']

                try:
                    back_ref_fq_name = self._db_client_mgr.ifmap_id_to_fq_name(back_ref_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown fq_name for backref ' + back_ref_ifmap_id
                    return (False, err_msg)
                try:
                    back_ref_uuid = self._db_client_mgr.ifmap_id_to_uuid(back_ref_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown uuid for backref ' + back_ref_ifmap_id
                    return (False, err_msg)

                back_ref_url = self._db_client_mgr.generate_url('logical_interface', back_ref_uuid)
                back_ref_info = {}
                back_ref_info['to'] = back_ref_fq_name
                back_ref_info['attr'] = obj_val
                back_ref_info['href'] = back_ref_url
                back_ref_info['uuid'] = back_ref_uuid
                result['logical_interface_back_refs'].append(back_ref_info)


        if metas.has_key('contrail:virtual-network-properties'):
            result_elems = metas['contrail:virtual-network-properties']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                # need to preserve type eg. int for prefix-len
                # for now, xml -> obj -> json -> dict
                # TODO TypeGenerator.py should have xml to dict method
                obj = VirtualNetworkType()
                obj.build(meta)
                obj_json = ''
                obj_json = json.dumps(obj,
                    default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
                obj_val = json.loads(obj_json)
                result['virtual_network_properties'] = obj_val

        if metas.has_key('contrail:route-target-list'):
            result_elems = metas['contrail:route-target-list']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                # need to preserve type eg. int for prefix-len
                # for now, xml -> obj -> json -> dict
                # TODO TypeGenerator.py should have xml to dict method
                obj = RouteTargetList()
                obj.build(meta)
                obj_json = ''
                obj_json = json.dumps(obj,
                    default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
                obj_val = json.loads(obj_json)
                result['route_target_list'] = obj_val

        if metas.has_key('contrail:route-table'):
            result_elems = metas['contrail:route-table']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                # need to preserve type eg. int for prefix-len
                # for now, xml -> obj -> json -> dict
                # TODO TypeGenerator.py should have xml to dict method
                obj = RouteTableType()
                obj.build(meta)
                obj_json = ''
                obj_json = json.dumps(obj,
                    default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
                obj_val = json.loads(obj_json)
                result['route_table'] = obj_val

        if metas.has_key('contrail:id-perms'):
            result_elems = metas['contrail:id-perms']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                # need to preserve type eg. int for prefix-len
                # for now, xml -> obj -> json -> dict
                # TODO TypeGenerator.py should have xml to dict method
                obj = IdPermsType()
                obj.build(meta)
                obj_json = ''
                obj_json = json.dumps(obj,
                    default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
                obj_val = json.loads(obj_json)
                result['id_perms'] = obj_val

        if metas.has_key('contrail:access-control-list-link'):
            result['access_control_lists'] = []
            result_elems = metas['contrail:access-control-list-link']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                obj_val = {}
                has_ifmap_id = r_elem[1].attrib['name']

                try:
                    has_fq_name = self._db_client_mgr.ifmap_id_to_fq_name(has_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown fq_name for child ' + has_ifmap_id
                    return (False, err_msg)
                try:
                    has_uuid = self._db_client_mgr.ifmap_id_to_uuid(has_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown uuid for child ' + has_ifmap_id
                    return (False, err_msg)

                has_url = self._db_client_mgr.generate_url('access_control_list', has_uuid)
                has_info = {}
                has_info['to'] = has_fq_name
                has_info['attr'] = obj_val
                has_info['href'] = has_url
                has_info['uuid'] = has_uuid
                result['access_control_lists'].append(has_info)


        if metas.has_key('contrail:virtual-network-floating-ip-pool'):
            result['floating_ip_pools'] = []
            result_elems = metas['contrail:virtual-network-floating-ip-pool']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                obj_val = {}
                has_ifmap_id = r_elem[1].attrib['name']

                try:
                    has_fq_name = self._db_client_mgr.ifmap_id_to_fq_name(has_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown fq_name for child ' + has_ifmap_id
                    return (False, err_msg)
                try:
                    has_uuid = self._db_client_mgr.ifmap_id_to_uuid(has_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown uuid for child ' + has_ifmap_id
                    return (False, err_msg)

                has_url = self._db_client_mgr.generate_url('floating_ip_pool', has_uuid)
                has_info = {}
                has_info['to'] = has_fq_name
                has_info['attr'] = obj_val
                has_info['href'] = has_url
                has_info['uuid'] = has_uuid
                result['floating_ip_pools'].append(has_info)


        if metas.has_key('contrail:virtual-network-routing-instance'):
            result['routing_instances'] = []
            result_elems = metas['contrail:virtual-network-routing-instance']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                obj_val = {}
                has_ifmap_id = r_elem[1].attrib['name']

                try:
                    has_fq_name = self._db_client_mgr.ifmap_id_to_fq_name(has_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown fq_name for child ' + has_ifmap_id
                    return (False, err_msg)
                try:
                    has_uuid = self._db_client_mgr.ifmap_id_to_uuid(has_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown uuid for child ' + has_ifmap_id
                    return (False, err_msg)

                has_url = self._db_client_mgr.generate_url('routing_instance', has_uuid)
                has_info = {}
                has_info['to'] = has_fq_name
                has_info['attr'] = obj_val
                has_info['href'] = has_url
                has_info['uuid'] = has_uuid
                result['routing_instances'].append(has_info)


        return (True, result)
    #end _ifmap_virtual_network_read

    def _ifmap_virtual_network_update(self, ifmap_id, old_obj_dict, new_obj_dict):
        # remove properties that are no longer active
        if ('virtual_network_properties' in new_obj_dict) and (new_obj_dict['virtual_network_properties'] == None):
            self._delete_id_self_meta(ifmap_id, 'virtual-network-properties')

        if ('route_target_list' in new_obj_dict) and (new_obj_dict['route_target_list'] == None):
            self._delete_id_self_meta(ifmap_id, 'route-target-list')

        if ('route_table' in new_obj_dict) and (new_obj_dict['route_table'] == None):
            self._delete_id_self_meta(ifmap_id, 'route-table')

        if ('id_perms' in new_obj_dict) and (new_obj_dict['id_perms'] == None):
            self._delete_id_self_meta(ifmap_id, 'id-perms')

        # remove refs that are no longer active
        if ('network_ipam_refs' in old_obj_dict):
            old_refs = [tuple(ref['to']) for ref in old_obj_dict['network_ipam_refs']]
        else:
            old_refs = []
        if ('network_ipam_refs' in new_obj_dict):
            if new_obj_dict['network_ipam_refs'] == None:
                new_refs = []
            else:
                new_refs = [tuple(ref['to']) for ref in new_obj_dict['network_ipam_refs']]
        else: # no ref key in new_obj
            new_refs = old_refs

        old_set = set(old_refs)
        new_set = set(new_refs)
        inact_refs = old_set - new_set
        for inact_ref in inact_refs:
            to_imid = self.fq_name_to_ifmap_id('network-ipam', inact_ref)
            self._delete_id_pair_meta(ifmap_id, to_imid, 'contrail:virtual-network-network-ipam')

        if ('network_policy_refs' in old_obj_dict):
            old_refs = [tuple(ref['to']) for ref in old_obj_dict['network_policy_refs']]
        else:
            old_refs = []
        if ('network_policy_refs' in new_obj_dict):
            if new_obj_dict['network_policy_refs'] == None:
                new_refs = []
            else:
                new_refs = [tuple(ref['to']) for ref in new_obj_dict['network_policy_refs']]
        else: # no ref key in new_obj
            new_refs = old_refs

        old_set = set(old_refs)
        new_set = set(new_refs)
        inact_refs = old_set - new_set
        for inact_ref in inact_refs:
            to_imid = self.fq_name_to_ifmap_id('network-policy', inact_ref)
            self._delete_id_pair_meta(ifmap_id, to_imid, 'contrail:virtual-network-network-policy')

        (ok, result) = self._ifmap_virtual_network_set(ifmap_id, new_obj_dict)
        return (ok, result)
    #end _ifmap_virtual_network_update

    def _ifmap_virtual_network_list(self, parent_type, parent_fq_name):
        children_fq_names = []
        mapclient = self._mapclient
        parent_imid = common.imid.get_ifmap_id_from_fq_name(parent_type, parent_fq_name)
        start_id = str(Identity(name = parent_imid, type = 'other',
                        other_type = 'extended'))
        # if id-perms missing, identity doesn't exist
        parent_link_meta = self._parent_metas[parent_type]['virtual-network']
        srch_meta = 'contrail:' + parent_link_meta
        srch_result = self._search(start_id, srch_meta)

        result_list = self.parse_result_items(srch_result, parent_imid)
        for r_elem in result_list:
            child_ident = r_elem[1]
            if child_ident is None:
                continue
            child_imid = child_ident.attrib['name']
            fq_name = self._db_client_mgr.ifmap_id_to_fq_name(child_imid)
            children_fq_names.append(fq_name)


        return (True, children_fq_names)
    #end _ifmap_virtual_network_list

    def _ifmap_virtual_network_delete(self, obj_ids):
        ifmap_id = obj_ids['imid']
        parent_imid = obj_ids.get('parent_imid', None)
        start_id = str(Identity(name = ifmap_id, type = 'other',
                        other_type = 'extended'))
        # Delete links to our references, first find them
        srch_meta = ' or '.join([u'contrail:virtual-network-network-ipam', u'contrail:virtual-network-network-policy'])
        srch_result = self._search(start_id, srch_meta)

        result_list = self.parse_result_items(srch_result, ifmap_id)
        for r_elem in result_list:
            to_ident = r_elem[1]
            if to_ident is None:
                continue
            to_imid = to_ident.attrib['name']
            r_meta = r_elem[2]
            # create contrail:<tag>
            meta_name = r_meta.prefix + ':' + re.sub('{.*}', '', r_meta.tag)
            self._delete_id_pair_meta(ifmap_id, to_imid, meta_name)


        if parent_imid:
            # Remove link from parent
            self._delete_id_pair_meta(parent_imid, ifmap_id, None)

        # Remove all property metadata associated with this ident
        self._delete_id_self_meta(ifmap_id, None)

        return (True, '')
    #end _ifmap_virtual_network_delete

    def _ifmap_project_alloc(self, parent_type, fq_name):
        imid = self._imid_handler
        (my_imid, parent_imid) = \
            imid.project_alloc_ifmap_id(parent_type, fq_name)
        return (True, (my_imid, parent_imid))
    #end _ifmap_project_alloc

    def _ifmap_project_set(self, my_imid, obj_dict):
        # Properties Meta
        field = obj_dict.get('id_perms', None)
        if field:
            # construct object of xsd-type and get its xml repr
            field = obj_dict['id_perms']
            buf = cStringIO.StringIO()
            # perms might be inserted at server as obj.
            # obj construction diff from dict construction.
            if isinstance(field, dict):
                IdPermsType(**field).exportChildren(buf, level = 1, name_ = 'id-perms', pretty_print = False)
            else: # object
                field.exportChildren(buf, level = 1, name_ = 'id-perms', pretty_print = False)
            id_perms_xml = buf.getvalue()
            buf.close()
            meta = str(Metadata('id-perms' , '',
                   {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail',
                   elements = id_perms_xml))
            self._publish_id_self_meta(my_imid, meta)

        # Ref Link Metas
        imid = self._imid_handler

        # construct object of xsd-type and get its xml repr
        refs = obj_dict.get('namespace_refs', None)
        if refs:
            for ref in refs:
                ref_fq_name = ref['to']
                obj_type = 'namespace'
                to_imid = common.imid.get_ifmap_id_from_fq_name(obj_type, ref_fq_name)
                project_namespace_xml = ''
                ref_data = ref['attr']
                if ref_data:
                    buf = cStringIO.StringIO()
                    SubnetType(**ref_data).exportChildren(buf, level = 1, name_ = 'project-namespace', pretty_print = False)
                    project_namespace_xml = project_namespace_xml + buf.getvalue()
                    buf.close()
                meta = str(Metadata('project-namespace' , '',
                       {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail',
                       elements = project_namespace_xml))
                self._publish_id_pair_meta(my_imid, to_imid, meta)

        # construct object of xsd-type and get its xml repr
        refs = obj_dict.get('security_group_refs', None)
        if refs:
            for ref in refs:
                ref_fq_name = ref['to']
                obj_type = 'security-group'
                to_imid = common.imid.get_ifmap_id_from_fq_name(obj_type, ref_fq_name)
                project_security_group_xml = ''
                meta = str(Metadata('project-security-group' , '',
                       {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail',
                       elements = project_security_group_xml))
                self._publish_id_pair_meta(my_imid, to_imid, meta)

        # construct object of xsd-type and get its xml repr
        refs = obj_dict.get('virtual_network_refs', None)
        if refs:
            for ref in refs:
                ref_fq_name = ref['to']
                obj_type = 'virtual-network'
                to_imid = common.imid.get_ifmap_id_from_fq_name(obj_type, ref_fq_name)
                project_virtual_network_xml = ''
                meta = str(Metadata('project-virtual-network' , '',
                       {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail',
                       elements = project_virtual_network_xml))
                self._publish_id_pair_meta(my_imid, to_imid, meta)

        # construct object of xsd-type and get its xml repr
        refs = obj_dict.get('network_ipam_refs', None)
        if refs:
            for ref in refs:
                ref_fq_name = ref['to']
                obj_type = 'network-ipam'
                to_imid = common.imid.get_ifmap_id_from_fq_name(obj_type, ref_fq_name)
                project_network_ipam_xml = ''
                meta = str(Metadata('project-network-ipam' , '',
                       {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail',
                       elements = project_network_ipam_xml))
                self._publish_id_pair_meta(my_imid, to_imid, meta)

        # construct object of xsd-type and get its xml repr
        refs = obj_dict.get('network_policy_refs', None)
        if refs:
            for ref in refs:
                ref_fq_name = ref['to']
                obj_type = 'network-policy'
                to_imid = common.imid.get_ifmap_id_from_fq_name(obj_type, ref_fq_name)
                project_network_policy_xml = ''
                meta = str(Metadata('project-network-policy' , '',
                       {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail',
                       elements = project_network_policy_xml))
                self._publish_id_pair_meta(my_imid, to_imid, meta)

        # construct object of xsd-type and get its xml repr
        refs = obj_dict.get('floating_ip_pool_refs', None)
        if refs:
            for ref in refs:
                ref_fq_name = ref['to']
                obj_type = 'floating-ip-pool'
                to_imid = common.imid.get_ifmap_id_from_fq_name(obj_type, ref_fq_name)
                project_floating_ip_pool_xml = ''
                meta = str(Metadata('project-floating-ip-pool' , '',
                       {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail',
                       elements = project_floating_ip_pool_xml))
                self._publish_id_pair_meta(my_imid, to_imid, meta)

        # construct object of xsd-type and get its xml repr
        refs = obj_dict.get('service_instance_refs', None)
        if refs:
            for ref in refs:
                ref_fq_name = ref['to']
                obj_type = 'service-instance'
                to_imid = common.imid.get_ifmap_id_from_fq_name(obj_type, ref_fq_name)
                project_service_instance_xml = ''
                meta = str(Metadata('project-service-instance' , '',
                       {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail',
                       elements = project_service_instance_xml))
                self._publish_id_pair_meta(my_imid, to_imid, meta)


        return (True, '')
    #end _ifmap_project_set

    def _ifmap_project_create(self, obj_ids, obj_dict):
        if not 'parent_type' in obj_dict:
            # parent is config-root
            parent_type = 'config-root'
            parent_imid = 'contrail:config-root:root'
        else:
            parent_type = obj_dict['parent_type']
            parent_imid = obj_ids.get('parent_imid', None)

        # Parent Link Meta
        parent_link_meta = self._parent_metas[parent_type]['project']
        meta = str(Metadata(parent_link_meta, '',
                   {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail'))
        self._publish_id_pair_meta(parent_imid, obj_ids['imid'], meta)

        (ok, result) = self._ifmap_project_set(obj_ids['imid'], obj_dict)
        return (ok, result)
    #end _ifmap_project_create

    def _ifmap_project_read(self, ifmap_id, field_names = None):
        # field_names = None means all fields will be read
        imid = self._imid_handler
        mapclient = self._mapclient
        start_id = str(Identity(name = ifmap_id, type = 'other',
                        other_type = 'extended'))
        # if id-perms missing, identity doesn't exist

        all_metas = [u'contrail:project-namespace', u'contrail:project-floating-ip-pool', u'contrail:floating-ip-project', u'contrail:id-perms', u'contrail:project-security-group', u'contrail:project-virtual-network', u'contrail:project-network-ipam', u'contrail:project-network-policy', u'contrail:project-service-instance']
        if not field_names:
            metas_to_read = all_metas
        else: # read only requested fields
            req_metas = []
            if field_names.has_key('namespace_refs'):
                req_metas.append('contrail:project-namespace')
            if field_names.has_key('floating_ip_pool_refs'):
                req_metas.append('contrail:project-floating-ip-pool')
            if field_names.has_key('floating_ip_back_refs'):
                req_metas.append('contrail:floating-ip-project')
            if field_names.has_key('id_perms'):
                req_metas.append('contrail:id-perms')
            if field_names.has_key('project_security_group'):
                req_metas.append('contrail:project-security-group')
            if field_names.has_key('project_virtual_network'):
                req_metas.append('contrail:project-virtual-network')
            if field_names.has_key('project_network_ipam'):
                req_metas.append('contrail:project-network-ipam')
            if field_names.has_key('project_network_policy'):
                req_metas.append('contrail:project-network-policy')
            if field_names.has_key('project_service_instance'):
                req_metas.append('contrail:project-service-instance')

            metas_to_read = set(all_metas) & set(req_metas)

        srch_meta = ' or '.join(metas_to_read)
        srch_result = self._search(start_id, srch_meta)

        result_list = self.parse_result_items(srch_result, ifmap_id)
        if (len(result_list) == 1 and 
            result_list[0][2] == None):
            return (False, 'project ' + ifmap_id + 'does not exist')

        # metas is a dict where key is meta-name and val is list of tuples
        # of form (ident1, ident2, meta)
        metas = {}
        for r_elem in result_list:
            r_meta = r_elem[2]
            # create contrail:<tag>
            meta_name = r_meta.prefix + ':' + re.sub('{.*}', '', r_meta.tag)

            if (
                (meta_name == 'contrail:project-namespace') or
                (meta_name == 'contrail:project-floating-ip-pool') or
                (meta_name == 'contrail:floating-ip-project') or
                (meta_name == 'contrail:id-perms') or
                (meta_name == 'contrail:project-security-group') or
                (meta_name == 'contrail:project-virtual-network') or
                (meta_name == 'contrail:project-network-ipam') or
                (meta_name == 'contrail:project-network-policy') or
                (meta_name == 'contrail:project-service-instance')
               ):
                if metas.has_key(meta_name):
                    metas[meta_name].append(r_elem)
                else: # first ident for this link-type
                    metas[meta_name] = [r_elem]

         # Construct dicts from xml
        result = {}
        result['_type'] = 'project'
        fq_name = self._db_client_mgr.ifmap_id_to_fq_name(ifmap_id)
        result['fq_name'] = fq_name
        result['name'] = fq_name[-1]
        if metas.has_key('contrail:project-namespace'):
            result['namespace_refs'] = []
            result_elems = metas['contrail:project-namespace']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                # need to preserve type eg. int for prefix-len
                # for now, xml -> obj -> json -> dict
                # TODO TypeGenerator.py should have xml to dict method
                obj = SubnetType()
                obj.build(meta)
                obj_json = ''
                obj_json = json.dumps(obj,
                    default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
                obj_val = json.loads(obj_json)
                # in case of refs between same types of identifiers,
                # the referred ident could appears at idx 0 or 1
                if ifmap_id == r_elem[0].attrib['name']:
                    ref_ifmap_id = r_elem[1].attrib['name']
                else:
                    ref_ifmap_id = r_elem[0].attrib['name']

                try:
                    ref_fq_name = self._db_client_mgr.ifmap_id_to_fq_name(ref_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown fq_name for ref ' + ref_ifmap_id
                    return (False, err_msg)
                try:
                    ref_uuid = self._db_client_mgr.ifmap_id_to_uuid(ref_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown uuid for ref ' + ref_ifmap_id
                    return (False, err_msg)

                ref_url = self._db_client_mgr.generate_url('namespace', ref_uuid)
                ref_info = {}
                ref_info['to'] = ref_fq_name
                ref_info['attr'] = obj_val
                ref_info['href'] = ref_url
                ref_info['uuid'] = ref_uuid
                result['namespace_refs'].append(ref_info)


        if metas.has_key('contrail:project-floating-ip-pool'):
            result['floating_ip_pool_refs'] = []
            result_elems = metas['contrail:project-floating-ip-pool']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                obj_val = {}
                # in case of refs between same types of identifiers,
                # the referred ident could appears at idx 0 or 1
                if ifmap_id == r_elem[0].attrib['name']:
                    ref_ifmap_id = r_elem[1].attrib['name']
                else:
                    ref_ifmap_id = r_elem[0].attrib['name']

                try:
                    ref_fq_name = self._db_client_mgr.ifmap_id_to_fq_name(ref_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown fq_name for ref ' + ref_ifmap_id
                    return (False, err_msg)
                try:
                    ref_uuid = self._db_client_mgr.ifmap_id_to_uuid(ref_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown uuid for ref ' + ref_ifmap_id
                    return (False, err_msg)

                ref_url = self._db_client_mgr.generate_url('floating_ip_pool', ref_uuid)
                ref_info = {}
                ref_info['to'] = ref_fq_name
                ref_info['attr'] = obj_val
                ref_info['href'] = ref_url
                ref_info['uuid'] = ref_uuid
                result['floating_ip_pool_refs'].append(ref_info)


        if metas.has_key('contrail:floating-ip-project'):
            result['floating_ip_back_refs'] = []
            result_elems = metas['contrail:floating-ip-project']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                obj_val = {}
                back_ref_ifmap_id = r_elem[0].attrib['name']

                try:
                    back_ref_fq_name = self._db_client_mgr.ifmap_id_to_fq_name(back_ref_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown fq_name for backref ' + back_ref_ifmap_id
                    return (False, err_msg)
                try:
                    back_ref_uuid = self._db_client_mgr.ifmap_id_to_uuid(back_ref_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown uuid for backref ' + back_ref_ifmap_id
                    return (False, err_msg)

                back_ref_url = self._db_client_mgr.generate_url('floating_ip', back_ref_uuid)
                back_ref_info = {}
                back_ref_info['to'] = back_ref_fq_name
                back_ref_info['attr'] = obj_val
                back_ref_info['href'] = back_ref_url
                back_ref_info['uuid'] = back_ref_uuid
                result['floating_ip_back_refs'].append(back_ref_info)


        if metas.has_key('contrail:id-perms'):
            result_elems = metas['contrail:id-perms']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                # need to preserve type eg. int for prefix-len
                # for now, xml -> obj -> json -> dict
                # TODO TypeGenerator.py should have xml to dict method
                obj = IdPermsType()
                obj.build(meta)
                obj_json = ''
                obj_json = json.dumps(obj,
                    default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
                obj_val = json.loads(obj_json)
                result['id_perms'] = obj_val

        if metas.has_key('contrail:project-security-group'):
            result['security_groups'] = []
            result_elems = metas['contrail:project-security-group']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                obj_val = {}
                has_ifmap_id = r_elem[1].attrib['name']

                try:
                    has_fq_name = self._db_client_mgr.ifmap_id_to_fq_name(has_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown fq_name for child ' + has_ifmap_id
                    return (False, err_msg)
                try:
                    has_uuid = self._db_client_mgr.ifmap_id_to_uuid(has_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown uuid for child ' + has_ifmap_id
                    return (False, err_msg)

                has_url = self._db_client_mgr.generate_url('security_group', has_uuid)
                has_info = {}
                has_info['to'] = has_fq_name
                has_info['attr'] = obj_val
                has_info['href'] = has_url
                has_info['uuid'] = has_uuid
                result['security_groups'].append(has_info)


        if metas.has_key('contrail:project-virtual-network'):
            result['virtual_networks'] = []
            result_elems = metas['contrail:project-virtual-network']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                obj_val = {}
                has_ifmap_id = r_elem[1].attrib['name']

                try:
                    has_fq_name = self._db_client_mgr.ifmap_id_to_fq_name(has_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown fq_name for child ' + has_ifmap_id
                    return (False, err_msg)
                try:
                    has_uuid = self._db_client_mgr.ifmap_id_to_uuid(has_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown uuid for child ' + has_ifmap_id
                    return (False, err_msg)

                has_url = self._db_client_mgr.generate_url('virtual_network', has_uuid)
                has_info = {}
                has_info['to'] = has_fq_name
                has_info['attr'] = obj_val
                has_info['href'] = has_url
                has_info['uuid'] = has_uuid
                result['virtual_networks'].append(has_info)


        if metas.has_key('contrail:project-network-ipam'):
            result['network_ipams'] = []
            result_elems = metas['contrail:project-network-ipam']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                obj_val = {}
                has_ifmap_id = r_elem[1].attrib['name']

                try:
                    has_fq_name = self._db_client_mgr.ifmap_id_to_fq_name(has_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown fq_name for child ' + has_ifmap_id
                    return (False, err_msg)
                try:
                    has_uuid = self._db_client_mgr.ifmap_id_to_uuid(has_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown uuid for child ' + has_ifmap_id
                    return (False, err_msg)

                has_url = self._db_client_mgr.generate_url('network_ipam', has_uuid)
                has_info = {}
                has_info['to'] = has_fq_name
                has_info['attr'] = obj_val
                has_info['href'] = has_url
                has_info['uuid'] = has_uuid
                result['network_ipams'].append(has_info)


        if metas.has_key('contrail:project-network-policy'):
            result['network_policys'] = []
            result_elems = metas['contrail:project-network-policy']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                obj_val = {}
                has_ifmap_id = r_elem[1].attrib['name']

                try:
                    has_fq_name = self._db_client_mgr.ifmap_id_to_fq_name(has_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown fq_name for child ' + has_ifmap_id
                    return (False, err_msg)
                try:
                    has_uuid = self._db_client_mgr.ifmap_id_to_uuid(has_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown uuid for child ' + has_ifmap_id
                    return (False, err_msg)

                has_url = self._db_client_mgr.generate_url('network_policy', has_uuid)
                has_info = {}
                has_info['to'] = has_fq_name
                has_info['attr'] = obj_val
                has_info['href'] = has_url
                has_info['uuid'] = has_uuid
                result['network_policys'].append(has_info)


        if metas.has_key('contrail:project-service-instance'):
            result['service_instances'] = []
            result_elems = metas['contrail:project-service-instance']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                obj_val = {}
                has_ifmap_id = r_elem[1].attrib['name']

                try:
                    has_fq_name = self._db_client_mgr.ifmap_id_to_fq_name(has_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown fq_name for child ' + has_ifmap_id
                    return (False, err_msg)
                try:
                    has_uuid = self._db_client_mgr.ifmap_id_to_uuid(has_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown uuid for child ' + has_ifmap_id
                    return (False, err_msg)

                has_url = self._db_client_mgr.generate_url('service_instance', has_uuid)
                has_info = {}
                has_info['to'] = has_fq_name
                has_info['attr'] = obj_val
                has_info['href'] = has_url
                has_info['uuid'] = has_uuid
                result['service_instances'].append(has_info)


        return (True, result)
    #end _ifmap_project_read

    def _ifmap_project_update(self, ifmap_id, old_obj_dict, new_obj_dict):
        # remove properties that are no longer active
        if ('id_perms' in new_obj_dict) and (new_obj_dict['id_perms'] == None):
            self._delete_id_self_meta(ifmap_id, 'id-perms')

        # remove refs that are no longer active
        if ('namespace_refs' in old_obj_dict):
            old_refs = [tuple(ref['to']) for ref in old_obj_dict['namespace_refs']]
        else:
            old_refs = []
        if ('namespace_refs' in new_obj_dict):
            if new_obj_dict['namespace_refs'] == None:
                new_refs = []
            else:
                new_refs = [tuple(ref['to']) for ref in new_obj_dict['namespace_refs']]
        else: # no ref key in new_obj
            new_refs = old_refs

        old_set = set(old_refs)
        new_set = set(new_refs)
        inact_refs = old_set - new_set
        for inact_ref in inact_refs:
            to_imid = self.fq_name_to_ifmap_id('namespace', inact_ref)
            self._delete_id_pair_meta(ifmap_id, to_imid, 'contrail:project-namespace')

        if ('floating_ip_pool_refs' in old_obj_dict):
            old_refs = [tuple(ref['to']) for ref in old_obj_dict['floating_ip_pool_refs']]
        else:
            old_refs = []
        if ('floating_ip_pool_refs' in new_obj_dict):
            if new_obj_dict['floating_ip_pool_refs'] == None:
                new_refs = []
            else:
                new_refs = [tuple(ref['to']) for ref in new_obj_dict['floating_ip_pool_refs']]
        else: # no ref key in new_obj
            new_refs = old_refs

        old_set = set(old_refs)
        new_set = set(new_refs)
        inact_refs = old_set - new_set
        for inact_ref in inact_refs:
            to_imid = self.fq_name_to_ifmap_id('floating-ip-pool', inact_ref)
            self._delete_id_pair_meta(ifmap_id, to_imid, 'contrail:project-floating-ip-pool')

        (ok, result) = self._ifmap_project_set(ifmap_id, new_obj_dict)
        return (ok, result)
    #end _ifmap_project_update

    def _ifmap_project_list(self, parent_type, parent_fq_name):
        children_fq_names = []
        mapclient = self._mapclient
        parent_imid = common.imid.get_ifmap_id_from_fq_name(parent_type, parent_fq_name)
        start_id = str(Identity(name = parent_imid, type = 'other',
                        other_type = 'extended'))
        # if id-perms missing, identity doesn't exist
        parent_link_meta = self._parent_metas[parent_type]['project']
        srch_meta = 'contrail:' + parent_link_meta
        srch_result = self._search(start_id, srch_meta)

        result_list = self.parse_result_items(srch_result, parent_imid)
        for r_elem in result_list:
            child_ident = r_elem[1]
            if child_ident is None:
                continue
            child_imid = child_ident.attrib['name']
            fq_name = self._db_client_mgr.ifmap_id_to_fq_name(child_imid)
            children_fq_names.append(fq_name)


        return (True, children_fq_names)
    #end _ifmap_project_list

    def _ifmap_project_delete(self, obj_ids):
        ifmap_id = obj_ids['imid']
        parent_imid = obj_ids.get('parent_imid', None)
        start_id = str(Identity(name = ifmap_id, type = 'other',
                        other_type = 'extended'))
        # Delete links to our references, first find them
        srch_meta = ' or '.join([u'contrail:project-namespace', u'contrail:project-floating-ip-pool'])
        srch_result = self._search(start_id, srch_meta)

        result_list = self.parse_result_items(srch_result, ifmap_id)
        for r_elem in result_list:
            to_ident = r_elem[1]
            if to_ident is None:
                continue
            to_imid = to_ident.attrib['name']
            r_meta = r_elem[2]
            # create contrail:<tag>
            meta_name = r_meta.prefix + ':' + re.sub('{.*}', '', r_meta.tag)
            self._delete_id_pair_meta(ifmap_id, to_imid, meta_name)


        if parent_imid:
            # Remove link from parent
            self._delete_id_pair_meta(parent_imid, ifmap_id, None)

        # Remove all property metadata associated with this ident
        self._delete_id_self_meta(ifmap_id, None)

        return (True, '')
    #end _ifmap_project_delete

    def _ifmap_logical_interface_alloc(self, parent_type, fq_name):
        imid = self._imid_handler
        (my_imid, parent_imid) = \
            imid.logical_interface_alloc_ifmap_id(parent_type, fq_name)
        return (True, (my_imid, parent_imid))
    #end _ifmap_logical_interface_alloc

    def _ifmap_logical_interface_set(self, my_imid, obj_dict):
        # Properties Meta
        field = obj_dict.get('id_perms', None)
        if field:
            # construct object of xsd-type and get its xml repr
            field = obj_dict['id_perms']
            buf = cStringIO.StringIO()
            # perms might be inserted at server as obj.
            # obj construction diff from dict construction.
            if isinstance(field, dict):
                IdPermsType(**field).exportChildren(buf, level = 1, name_ = 'id-perms', pretty_print = False)
            else: # object
                field.exportChildren(buf, level = 1, name_ = 'id-perms', pretty_print = False)
            id_perms_xml = buf.getvalue()
            buf.close()
            meta = str(Metadata('id-perms' , '',
                   {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail',
                   elements = id_perms_xml))
            self._publish_id_self_meta(my_imid, meta)

        # Ref Link Metas
        imid = self._imid_handler

        # construct object of xsd-type and get its xml repr
        refs = obj_dict.get('virtual_network_refs', None)
        if refs:
            for ref in refs:
                ref_fq_name = ref['to']
                obj_type = 'virtual-network'
                to_imid = common.imid.get_ifmap_id_from_fq_name(obj_type, ref_fq_name)
                logical_interface_virtual_network_xml = ''
                meta = str(Metadata('logical-interface-virtual-network' , '',
                       {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail',
                       elements = logical_interface_virtual_network_xml))
                self._publish_id_pair_meta(my_imid, to_imid, meta)


        return (True, '')
    #end _ifmap_logical_interface_set

    def _ifmap_logical_interface_create(self, obj_ids, obj_dict):
        if not 'parent_type' in obj_dict:
            # parent is config-root
            parent_type = 'config-root'
            parent_imid = 'contrail:config-root:root'
        else:
            parent_type = obj_dict['parent_type']
            parent_imid = obj_ids.get('parent_imid', None)

        # Parent Link Meta
        parent_link_meta = self._parent_metas[parent_type]['logical-interface']
        meta = str(Metadata(parent_link_meta, '',
                   {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail'))
        self._publish_id_pair_meta(parent_imid, obj_ids['imid'], meta)

        (ok, result) = self._ifmap_logical_interface_set(obj_ids['imid'], obj_dict)
        return (ok, result)
    #end _ifmap_logical_interface_create

    def _ifmap_logical_interface_read(self, ifmap_id, field_names = None):
        # field_names = None means all fields will be read
        imid = self._imid_handler
        mapclient = self._mapclient
        start_id = str(Identity(name = ifmap_id, type = 'other',
                        other_type = 'extended'))
        # if id-perms missing, identity doesn't exist

        all_metas = [u'contrail:logical-interface-virtual-network', u'contrail:id-perms']
        if not field_names:
            metas_to_read = all_metas
        else: # read only requested fields
            req_metas = []
            if field_names.has_key('virtual_network_refs'):
                req_metas.append('contrail:logical-interface-virtual-network')
            if field_names.has_key('id_perms'):
                req_metas.append('contrail:id-perms')

            metas_to_read = set(all_metas) & set(req_metas)

        srch_meta = ' or '.join(metas_to_read)
        srch_result = self._search(start_id, srch_meta)

        result_list = self.parse_result_items(srch_result, ifmap_id)
        if (len(result_list) == 1 and 
            result_list[0][2] == None):
            return (False, 'logical-interface ' + ifmap_id + 'does not exist')

        # metas is a dict where key is meta-name and val is list of tuples
        # of form (ident1, ident2, meta)
        metas = {}
        for r_elem in result_list:
            r_meta = r_elem[2]
            # create contrail:<tag>
            meta_name = r_meta.prefix + ':' + re.sub('{.*}', '', r_meta.tag)

            if (
                (meta_name == 'contrail:logical-interface-virtual-network') or
                (meta_name == 'contrail:id-perms')
               ):
                if metas.has_key(meta_name):
                    metas[meta_name].append(r_elem)
                else: # first ident for this link-type
                    metas[meta_name] = [r_elem]

         # Construct dicts from xml
        result = {}
        result['_type'] = 'logical-interface'
        fq_name = self._db_client_mgr.ifmap_id_to_fq_name(ifmap_id)
        result['fq_name'] = fq_name
        result['name'] = fq_name[-1]
        if metas.has_key('contrail:logical-interface-virtual-network'):
            result['virtual_network_refs'] = []
            result_elems = metas['contrail:logical-interface-virtual-network']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                obj_val = {}
                # in case of refs between same types of identifiers,
                # the referred ident could appears at idx 0 or 1
                if ifmap_id == r_elem[0].attrib['name']:
                    ref_ifmap_id = r_elem[1].attrib['name']
                else:
                    ref_ifmap_id = r_elem[0].attrib['name']

                try:
                    ref_fq_name = self._db_client_mgr.ifmap_id_to_fq_name(ref_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown fq_name for ref ' + ref_ifmap_id
                    return (False, err_msg)
                try:
                    ref_uuid = self._db_client_mgr.ifmap_id_to_uuid(ref_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown uuid for ref ' + ref_ifmap_id
                    return (False, err_msg)

                ref_url = self._db_client_mgr.generate_url('virtual_network', ref_uuid)
                ref_info = {}
                ref_info['to'] = ref_fq_name
                ref_info['attr'] = obj_val
                ref_info['href'] = ref_url
                ref_info['uuid'] = ref_uuid
                result['virtual_network_refs'].append(ref_info)


        if metas.has_key('contrail:id-perms'):
            result_elems = metas['contrail:id-perms']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                # need to preserve type eg. int for prefix-len
                # for now, xml -> obj -> json -> dict
                # TODO TypeGenerator.py should have xml to dict method
                obj = IdPermsType()
                obj.build(meta)
                obj_json = ''
                obj_json = json.dumps(obj,
                    default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
                obj_val = json.loads(obj_json)
                result['id_perms'] = obj_val

        return (True, result)
    #end _ifmap_logical_interface_read

    def _ifmap_logical_interface_update(self, ifmap_id, old_obj_dict, new_obj_dict):
        # remove properties that are no longer active
        if ('id_perms' in new_obj_dict) and (new_obj_dict['id_perms'] == None):
            self._delete_id_self_meta(ifmap_id, 'id-perms')

        # remove refs that are no longer active
        if ('virtual_network_refs' in old_obj_dict):
            old_refs = [tuple(ref['to']) for ref in old_obj_dict['virtual_network_refs']]
        else:
            old_refs = []
        if ('virtual_network_refs' in new_obj_dict):
            if new_obj_dict['virtual_network_refs'] == None:
                new_refs = []
            else:
                new_refs = [tuple(ref['to']) for ref in new_obj_dict['virtual_network_refs']]
        else: # no ref key in new_obj
            new_refs = old_refs

        old_set = set(old_refs)
        new_set = set(new_refs)
        inact_refs = old_set - new_set
        for inact_ref in inact_refs:
            to_imid = self.fq_name_to_ifmap_id('virtual-network', inact_ref)
            self._delete_id_pair_meta(ifmap_id, to_imid, 'contrail:logical-interface-virtual-network')

        (ok, result) = self._ifmap_logical_interface_set(ifmap_id, new_obj_dict)
        return (ok, result)
    #end _ifmap_logical_interface_update

    def _ifmap_logical_interface_list(self, parent_type, parent_fq_name):
        children_fq_names = []
        mapclient = self._mapclient
        parent_imid = common.imid.get_ifmap_id_from_fq_name(parent_type, parent_fq_name)
        start_id = str(Identity(name = parent_imid, type = 'other',
                        other_type = 'extended'))
        # if id-perms missing, identity doesn't exist
        parent_link_meta = self._parent_metas[parent_type]['logical-interface']
        srch_meta = 'contrail:' + parent_link_meta
        srch_result = self._search(start_id, srch_meta)

        result_list = self.parse_result_items(srch_result, parent_imid)
        for r_elem in result_list:
            child_ident = r_elem[1]
            if child_ident is None:
                continue
            child_imid = child_ident.attrib['name']
            fq_name = self._db_client_mgr.ifmap_id_to_fq_name(child_imid)
            children_fq_names.append(fq_name)


        return (True, children_fq_names)
    #end _ifmap_logical_interface_list

    def _ifmap_logical_interface_delete(self, obj_ids):
        ifmap_id = obj_ids['imid']
        parent_imid = obj_ids.get('parent_imid', None)
        start_id = str(Identity(name = ifmap_id, type = 'other',
                        other_type = 'extended'))
        # Delete links to our references, first find them
        srch_meta = ' or '.join([u'contrail:logical-interface-virtual-network'])
        srch_result = self._search(start_id, srch_meta)

        result_list = self.parse_result_items(srch_result, ifmap_id)
        for r_elem in result_list:
            to_ident = r_elem[1]
            if to_ident is None:
                continue
            to_imid = to_ident.attrib['name']
            r_meta = r_elem[2]
            # create contrail:<tag>
            meta_name = r_meta.prefix + ':' + re.sub('{.*}', '', r_meta.tag)
            self._delete_id_pair_meta(ifmap_id, to_imid, meta_name)


        if parent_imid:
            # Remove link from parent
            self._delete_id_pair_meta(parent_imid, ifmap_id, None)

        # Remove all property metadata associated with this ident
        self._delete_id_self_meta(ifmap_id, None)

        return (True, '')
    #end _ifmap_logical_interface_delete

    def _ifmap_routing_instance_alloc(self, parent_type, fq_name):
        imid = self._imid_handler
        (my_imid, parent_imid) = \
            imid.routing_instance_alloc_ifmap_id(parent_type, fq_name)
        return (True, (my_imid, parent_imid))
    #end _ifmap_routing_instance_alloc

    def _ifmap_routing_instance_set(self, my_imid, obj_dict):
        # Properties Meta
        field = obj_dict.get('static_route_entries', None)
        if field:
            # construct object of xsd-type and get its xml repr
            field = obj_dict['static_route_entries']
            buf = cStringIO.StringIO()
            # perms might be inserted at server as obj.
            # obj construction diff from dict construction.
            if isinstance(field, dict):
                StaticRouteEntriesType(**field).exportChildren(buf, level = 1, name_ = 'static-route-entries', pretty_print = False)
            else: # object
                field.exportChildren(buf, level = 1, name_ = 'static-route-entries', pretty_print = False)
            static_route_entries_xml = buf.getvalue()
            buf.close()
            meta = str(Metadata('static-route-entries' , '',
                   {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail',
                   elements = static_route_entries_xml))
            self._publish_id_self_meta(my_imid, meta)

        field = obj_dict.get('service_chain_information', None)
        if field:
            # construct object of xsd-type and get its xml repr
            field = obj_dict['service_chain_information']
            buf = cStringIO.StringIO()
            # perms might be inserted at server as obj.
            # obj construction diff from dict construction.
            if isinstance(field, dict):
                ServiceChainInfo(**field).exportChildren(buf, level = 1, name_ = 'service-chain-information', pretty_print = False)
            else: # object
                field.exportChildren(buf, level = 1, name_ = 'service-chain-information', pretty_print = False)
            service_chain_information_xml = buf.getvalue()
            buf.close()
            meta = str(Metadata('service-chain-information' , '',
                   {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail',
                   elements = service_chain_information_xml))
            self._publish_id_self_meta(my_imid, meta)

        field = obj_dict.get('default_ce_protocol', None)
        if field:
            # construct object of xsd-type and get its xml repr
            field = obj_dict['default_ce_protocol']
            buf = cStringIO.StringIO()
            # perms might be inserted at server as obj.
            # obj construction diff from dict construction.
            if isinstance(field, dict):
                DefaultProtocolType(**field).exportChildren(buf, level = 1, name_ = 'default-ce-protocol', pretty_print = False)
            else: # object
                field.exportChildren(buf, level = 1, name_ = 'default-ce-protocol', pretty_print = False)
            default_ce_protocol_xml = buf.getvalue()
            buf.close()
            meta = str(Metadata('default-ce-protocol' , '',
                   {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail',
                   elements = default_ce_protocol_xml))
            self._publish_id_self_meta(my_imid, meta)

        field = obj_dict.get('id_perms', None)
        if field:
            # construct object of xsd-type and get its xml repr
            field = obj_dict['id_perms']
            buf = cStringIO.StringIO()
            # perms might be inserted at server as obj.
            # obj construction diff from dict construction.
            if isinstance(field, dict):
                IdPermsType(**field).exportChildren(buf, level = 1, name_ = 'id-perms', pretty_print = False)
            else: # object
                field.exportChildren(buf, level = 1, name_ = 'id-perms', pretty_print = False)
            id_perms_xml = buf.getvalue()
            buf.close()
            meta = str(Metadata('id-perms' , '',
                   {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail',
                   elements = id_perms_xml))
            self._publish_id_self_meta(my_imid, meta)

        # Ref Link Metas
        imid = self._imid_handler

        # construct object of xsd-type and get its xml repr
        refs = obj_dict.get('bgp_router_refs', None)
        if refs:
            for ref in refs:
                ref_fq_name = ref['to']
                obj_type = 'bgp-router'
                to_imid = common.imid.get_ifmap_id_from_fq_name(obj_type, ref_fq_name)
                instance_bgp_router_xml = ''
                meta = str(Metadata('instance-bgp-router' , '',
                       {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail',
                       elements = instance_bgp_router_xml))
                self._publish_id_pair_meta(my_imid, to_imid, meta)

        # construct object of xsd-type and get its xml repr
        refs = obj_dict.get('routing_instance_refs', None)
        if refs:
            for ref in refs:
                ref_fq_name = ref['to']
                obj_type = 'routing-instance'
                to_imid = common.imid.get_ifmap_id_from_fq_name(obj_type, ref_fq_name)
                connection_xml = ''
                ref_data = ref['attr']
                if ref_data:
                    buf = cStringIO.StringIO()
                    ConnectionType(**ref_data).exportChildren(buf, level = 1, name_ = 'connection', pretty_print = False)
                    connection_xml = connection_xml + buf.getvalue()
                    buf.close()
                meta = str(Metadata('connection' , '',
                       {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail',
                       elements = connection_xml))
                self._publish_id_pair_meta(my_imid, to_imid, meta)

        # construct object of xsd-type and get its xml repr
        refs = obj_dict.get('route_target_refs', None)
        if refs:
            for ref in refs:
                ref_fq_name = ref['to']
                obj_type = 'route-target'
                to_imid = common.imid.get_ifmap_id_from_fq_name(obj_type, ref_fq_name)
                instance_target_xml = ''
                ref_data = ref['attr']
                if ref_data:
                    buf = cStringIO.StringIO()
                    InstanceTargetType(**ref_data).exportChildren(buf, level = 1, name_ = 'instance-target', pretty_print = False)
                    instance_target_xml = instance_target_xml + buf.getvalue()
                    buf.close()
                meta = str(Metadata('instance-target' , '',
                       {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail',
                       elements = instance_target_xml))
                self._publish_id_pair_meta(my_imid, to_imid, meta)


        return (True, '')
    #end _ifmap_routing_instance_set

    def _ifmap_routing_instance_create(self, obj_ids, obj_dict):
        if not 'parent_type' in obj_dict:
            # parent is config-root
            parent_type = 'config-root'
            parent_imid = 'contrail:config-root:root'
        else:
            parent_type = obj_dict['parent_type']
            parent_imid = obj_ids.get('parent_imid', None)

        # Parent Link Meta
        parent_link_meta = self._parent_metas[parent_type]['routing-instance']
        meta = str(Metadata(parent_link_meta, '',
                   {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail'))
        self._publish_id_pair_meta(parent_imid, obj_ids['imid'], meta)

        (ok, result) = self._ifmap_routing_instance_set(obj_ids['imid'], obj_dict)
        return (ok, result)
    #end _ifmap_routing_instance_create

    def _ifmap_routing_instance_read(self, ifmap_id, field_names = None):
        # field_names = None means all fields will be read
        imid = self._imid_handler
        mapclient = self._mapclient
        start_id = str(Identity(name = ifmap_id, type = 'other',
                        other_type = 'extended'))
        # if id-perms missing, identity doesn't exist

        all_metas = [u'contrail:connection', u'contrail:instance-target', u'contrail:virtual-machine-interface-routing-instance', u'contrail:connection', u'contrail:static-route-entries', u'contrail:service-chain-information', u'contrail:default-ce-protocol', u'contrail:id-perms', u'contrail:instance-bgp-router']
        if not field_names:
            metas_to_read = all_metas
        else: # read only requested fields
            req_metas = []
            if field_names.has_key('routing_instance_refs'):
                req_metas.append('contrail:connection')
            if field_names.has_key('route_target_refs'):
                req_metas.append('contrail:instance-target')
            if field_names.has_key('virtual_machine_interface_back_refs'):
                req_metas.append('contrail:virtual-machine-interface-routing-instance')
            if field_names.has_key('routing_instance_refs'):
                req_metas.append('contrail:connection')
            if field_names.has_key('static_route_entries'):
                req_metas.append('contrail:static-route-entries')
            if field_names.has_key('service_chain_information'):
                req_metas.append('contrail:service-chain-information')
            if field_names.has_key('default_ce_protocol'):
                req_metas.append('contrail:default-ce-protocol')
            if field_names.has_key('id_perms'):
                req_metas.append('contrail:id-perms')
            if field_names.has_key('instance_bgp_router'):
                req_metas.append('contrail:instance-bgp-router')

            metas_to_read = set(all_metas) & set(req_metas)

        srch_meta = ' or '.join(metas_to_read)
        srch_result = self._search(start_id, srch_meta)

        result_list = self.parse_result_items(srch_result, ifmap_id)
        if (len(result_list) == 1 and 
            result_list[0][2] == None):
            return (False, 'routing-instance ' + ifmap_id + 'does not exist')

        # metas is a dict where key is meta-name and val is list of tuples
        # of form (ident1, ident2, meta)
        metas = {}
        for r_elem in result_list:
            r_meta = r_elem[2]
            # create contrail:<tag>
            meta_name = r_meta.prefix + ':' + re.sub('{.*}', '', r_meta.tag)

            if (
                (meta_name == 'contrail:connection') or
                (meta_name == 'contrail:instance-target') or
                (meta_name == 'contrail:virtual-machine-interface-routing-instance') or
                (meta_name == 'contrail:connection') or
                (meta_name == 'contrail:static-route-entries') or
                (meta_name == 'contrail:service-chain-information') or
                (meta_name == 'contrail:default-ce-protocol') or
                (meta_name == 'contrail:id-perms') or
                (meta_name == 'contrail:instance-bgp-router')
               ):
                if metas.has_key(meta_name):
                    metas[meta_name].append(r_elem)
                else: # first ident for this link-type
                    metas[meta_name] = [r_elem]

         # Construct dicts from xml
        result = {}
        result['_type'] = 'routing-instance'
        fq_name = self._db_client_mgr.ifmap_id_to_fq_name(ifmap_id)
        result['fq_name'] = fq_name
        result['name'] = fq_name[-1]
        if metas.has_key('contrail:connection'):
            result['routing_instance_refs'] = []
            result_elems = metas['contrail:connection']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                obj_val = meta.text
                # in case of refs between same types of identifiers,
                # the referred ident could appears at idx 0 or 1
                if ifmap_id == r_elem[0].attrib['name']:
                    ref_ifmap_id = r_elem[1].attrib['name']
                else:
                    ref_ifmap_id = r_elem[0].attrib['name']

                try:
                    ref_fq_name = self._db_client_mgr.ifmap_id_to_fq_name(ref_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown fq_name for ref ' + ref_ifmap_id
                    return (False, err_msg)
                try:
                    ref_uuid = self._db_client_mgr.ifmap_id_to_uuid(ref_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown uuid for ref ' + ref_ifmap_id
                    return (False, err_msg)

                ref_url = self._db_client_mgr.generate_url('routing_instance', ref_uuid)
                ref_info = {}
                ref_info['to'] = ref_fq_name
                ref_info['attr'] = obj_val
                ref_info['href'] = ref_url
                ref_info['uuid'] = ref_uuid
                result['routing_instance_refs'].append(ref_info)


        if metas.has_key('contrail:instance-target'):
            result['route_target_refs'] = []
            result_elems = metas['contrail:instance-target']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                # need to preserve type eg. int for prefix-len
                # for now, xml -> obj -> json -> dict
                # TODO TypeGenerator.py should have xml to dict method
                obj = InstanceTargetType()
                obj.build(meta)
                obj_json = ''
                obj_json = json.dumps(obj,
                    default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
                obj_val = json.loads(obj_json)
                # in case of refs between same types of identifiers,
                # the referred ident could appears at idx 0 or 1
                if ifmap_id == r_elem[0].attrib['name']:
                    ref_ifmap_id = r_elem[1].attrib['name']
                else:
                    ref_ifmap_id = r_elem[0].attrib['name']

                try:
                    ref_fq_name = self._db_client_mgr.ifmap_id_to_fq_name(ref_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown fq_name for ref ' + ref_ifmap_id
                    return (False, err_msg)
                try:
                    ref_uuid = self._db_client_mgr.ifmap_id_to_uuid(ref_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown uuid for ref ' + ref_ifmap_id
                    return (False, err_msg)

                ref_url = self._db_client_mgr.generate_url('route_target', ref_uuid)
                ref_info = {}
                ref_info['to'] = ref_fq_name
                ref_info['attr'] = obj_val
                ref_info['href'] = ref_url
                ref_info['uuid'] = ref_uuid
                result['route_target_refs'].append(ref_info)


        if metas.has_key('contrail:virtual-machine-interface-routing-instance'):
            result['virtual_machine_interface_back_refs'] = []
            result_elems = metas['contrail:virtual-machine-interface-routing-instance']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                # need to preserve type eg. int for prefix-len
                # for now, xml -> obj -> json -> dict
                # TODO TypeGenerator.py should have xml to dict method
                obj = PolicyBasedForwardingRuleType()
                obj.build(meta)
                obj_json = ''
                obj_json = json.dumps(obj,
                    default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
                obj_val = json.loads(obj_json)
                back_ref_ifmap_id = r_elem[0].attrib['name']

                try:
                    back_ref_fq_name = self._db_client_mgr.ifmap_id_to_fq_name(back_ref_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown fq_name for backref ' + back_ref_ifmap_id
                    return (False, err_msg)
                try:
                    back_ref_uuid = self._db_client_mgr.ifmap_id_to_uuid(back_ref_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown uuid for backref ' + back_ref_ifmap_id
                    return (False, err_msg)

                back_ref_url = self._db_client_mgr.generate_url('virtual_machine_interface', back_ref_uuid)
                back_ref_info = {}
                back_ref_info['to'] = back_ref_fq_name
                back_ref_info['attr'] = obj_val
                back_ref_info['href'] = back_ref_url
                back_ref_info['uuid'] = back_ref_uuid
                result['virtual_machine_interface_back_refs'].append(back_ref_info)


        if metas.has_key('contrail:connection'):
            result['routing_instance_refs'] = []
            result_elems = metas['contrail:connection']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                obj_val = meta.text
                # in case of refs between same types of identifiers,
                # the referred ident could appears at idx 0 or 1
                if ifmap_id == r_elem[0].attrib['name']:
                    ref_ifmap_id = r_elem[1].attrib['name']
                else:
                    ref_ifmap_id = r_elem[0].attrib['name']

                try:
                    ref_fq_name = self._db_client_mgr.ifmap_id_to_fq_name(ref_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown fq_name for ref ' + ref_ifmap_id
                    return (False, err_msg)
                try:
                    ref_uuid = self._db_client_mgr.ifmap_id_to_uuid(ref_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown uuid for ref ' + ref_ifmap_id
                    return (False, err_msg)

                ref_url = self._db_client_mgr.generate_url('routing_instance', ref_uuid)
                ref_info = {}
                ref_info['to'] = ref_fq_name
                ref_info['attr'] = obj_val
                ref_info['href'] = ref_url
                ref_info['uuid'] = ref_uuid
                result['routing_instance_refs'].append(ref_info)


        if metas.has_key('contrail:static-route-entries'):
            result_elems = metas['contrail:static-route-entries']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                # need to preserve type eg. int for prefix-len
                # for now, xml -> obj -> json -> dict
                # TODO TypeGenerator.py should have xml to dict method
                obj = StaticRouteEntriesType()
                obj.build(meta)
                obj_json = ''
                obj_json = json.dumps(obj,
                    default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
                obj_val = json.loads(obj_json)
                result['static_route_entries'] = obj_val

        if metas.has_key('contrail:service-chain-information'):
            result_elems = metas['contrail:service-chain-information']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                # need to preserve type eg. int for prefix-len
                # for now, xml -> obj -> json -> dict
                # TODO TypeGenerator.py should have xml to dict method
                obj = ServiceChainInfo()
                obj.build(meta)
                obj_json = ''
                obj_json = json.dumps(obj,
                    default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
                obj_val = json.loads(obj_json)
                result['service_chain_information'] = obj_val

        if metas.has_key('contrail:default-ce-protocol'):
            result_elems = metas['contrail:default-ce-protocol']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                # need to preserve type eg. int for prefix-len
                # for now, xml -> obj -> json -> dict
                # TODO TypeGenerator.py should have xml to dict method
                obj = DefaultProtocolType()
                obj.build(meta)
                obj_json = ''
                obj_json = json.dumps(obj,
                    default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
                obj_val = json.loads(obj_json)
                result['default_ce_protocol'] = obj_val

        if metas.has_key('contrail:id-perms'):
            result_elems = metas['contrail:id-perms']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                # need to preserve type eg. int for prefix-len
                # for now, xml -> obj -> json -> dict
                # TODO TypeGenerator.py should have xml to dict method
                obj = IdPermsType()
                obj.build(meta)
                obj_json = ''
                obj_json = json.dumps(obj,
                    default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
                obj_val = json.loads(obj_json)
                result['id_perms'] = obj_val

        if metas.has_key('contrail:instance-bgp-router'):
            result['bgp_routers'] = []
            result_elems = metas['contrail:instance-bgp-router']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                obj_val = {}
                has_ifmap_id = r_elem[1].attrib['name']

                try:
                    has_fq_name = self._db_client_mgr.ifmap_id_to_fq_name(has_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown fq_name for child ' + has_ifmap_id
                    return (False, err_msg)
                try:
                    has_uuid = self._db_client_mgr.ifmap_id_to_uuid(has_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown uuid for child ' + has_ifmap_id
                    return (False, err_msg)

                has_url = self._db_client_mgr.generate_url('bgp_router', has_uuid)
                has_info = {}
                has_info['to'] = has_fq_name
                has_info['attr'] = obj_val
                has_info['href'] = has_url
                has_info['uuid'] = has_uuid
                result['bgp_routers'].append(has_info)


        return (True, result)
    #end _ifmap_routing_instance_read

    def _ifmap_routing_instance_update(self, ifmap_id, old_obj_dict, new_obj_dict):
        # remove properties that are no longer active
        if ('static_route_entries' in new_obj_dict) and (new_obj_dict['static_route_entries'] == None):
            self._delete_id_self_meta(ifmap_id, 'static-route-entries')

        if ('service_chain_information' in new_obj_dict) and (new_obj_dict['service_chain_information'] == None):
            self._delete_id_self_meta(ifmap_id, 'service-chain-information')

        if ('default_ce_protocol' in new_obj_dict) and (new_obj_dict['default_ce_protocol'] == None):
            self._delete_id_self_meta(ifmap_id, 'default-ce-protocol')

        if ('id_perms' in new_obj_dict) and (new_obj_dict['id_perms'] == None):
            self._delete_id_self_meta(ifmap_id, 'id-perms')

        # remove refs that are no longer active
        if ('routing_instance_refs' in old_obj_dict):
            old_refs = [tuple(ref['to']) for ref in old_obj_dict['routing_instance_refs']]
        else:
            old_refs = []
        if ('routing_instance_refs' in new_obj_dict):
            if new_obj_dict['routing_instance_refs'] == None:
                new_refs = []
            else:
                new_refs = [tuple(ref['to']) for ref in new_obj_dict['routing_instance_refs']]
        else: # no ref key in new_obj
            new_refs = old_refs

        old_set = set(old_refs)
        new_set = set(new_refs)
        inact_refs = old_set - new_set
        for inact_ref in inact_refs:
            to_imid = self.fq_name_to_ifmap_id('routing-instance', inact_ref)
            self._delete_id_pair_meta(ifmap_id, to_imid, 'contrail:connection')

        if ('route_target_refs' in old_obj_dict):
            old_refs = [tuple(ref['to']) for ref in old_obj_dict['route_target_refs']]
        else:
            old_refs = []
        if ('route_target_refs' in new_obj_dict):
            if new_obj_dict['route_target_refs'] == None:
                new_refs = []
            else:
                new_refs = [tuple(ref['to']) for ref in new_obj_dict['route_target_refs']]
        else: # no ref key in new_obj
            new_refs = old_refs

        old_set = set(old_refs)
        new_set = set(new_refs)
        inact_refs = old_set - new_set
        for inact_ref in inact_refs:
            to_imid = self.fq_name_to_ifmap_id('route-target', inact_ref)
            self._delete_id_pair_meta(ifmap_id, to_imid, 'contrail:instance-target')

        (ok, result) = self._ifmap_routing_instance_set(ifmap_id, new_obj_dict)
        return (ok, result)
    #end _ifmap_routing_instance_update

    def _ifmap_routing_instance_list(self, parent_type, parent_fq_name):
        children_fq_names = []
        mapclient = self._mapclient
        parent_imid = common.imid.get_ifmap_id_from_fq_name(parent_type, parent_fq_name)
        start_id = str(Identity(name = parent_imid, type = 'other',
                        other_type = 'extended'))
        # if id-perms missing, identity doesn't exist
        parent_link_meta = self._parent_metas[parent_type]['routing-instance']
        srch_meta = 'contrail:' + parent_link_meta
        srch_result = self._search(start_id, srch_meta)

        result_list = self.parse_result_items(srch_result, parent_imid)
        for r_elem in result_list:
            child_ident = r_elem[1]
            if child_ident is None:
                continue
            child_imid = child_ident.attrib['name']
            fq_name = self._db_client_mgr.ifmap_id_to_fq_name(child_imid)
            children_fq_names.append(fq_name)


        return (True, children_fq_names)
    #end _ifmap_routing_instance_list

    def _ifmap_routing_instance_delete(self, obj_ids):
        ifmap_id = obj_ids['imid']
        parent_imid = obj_ids.get('parent_imid', None)
        start_id = str(Identity(name = ifmap_id, type = 'other',
                        other_type = 'extended'))
        # Delete links to our references, first find them
        srch_meta = ' or '.join([u'contrail:connection', u'contrail:instance-target'])
        srch_result = self._search(start_id, srch_meta)

        result_list = self.parse_result_items(srch_result, ifmap_id)
        for r_elem in result_list:
            to_ident = r_elem[1]
            if to_ident is None:
                continue
            to_imid = to_ident.attrib['name']
            r_meta = r_elem[2]
            # create contrail:<tag>
            meta_name = r_meta.prefix + ':' + re.sub('{.*}', '', r_meta.tag)
            self._delete_id_pair_meta(ifmap_id, to_imid, meta_name)


        if parent_imid:
            # Remove link from parent
            self._delete_id_pair_meta(parent_imid, ifmap_id, None)

        # Remove all property metadata associated with this ident
        self._delete_id_self_meta(ifmap_id, None)

        return (True, '')
    #end _ifmap_routing_instance_delete

    def _ifmap_virtual_machine_interface_alloc(self, parent_type, fq_name):
        imid = self._imid_handler
        (my_imid, parent_imid) = \
            imid.virtual_machine_interface_alloc_ifmap_id(parent_type, fq_name)
        return (True, (my_imid, parent_imid))
    #end _ifmap_virtual_machine_interface_alloc

    def _ifmap_virtual_machine_interface_set(self, my_imid, obj_dict):
        # Properties Meta
        field = obj_dict.get('virtual_machine_interface_mac_addresses', None)
        if field:
            # construct object of xsd-type and get its xml repr
            field = obj_dict['virtual_machine_interface_mac_addresses']
            buf = cStringIO.StringIO()
            # perms might be inserted at server as obj.
            # obj construction diff from dict construction.
            if isinstance(field, dict):
                MacAddressesType(**field).exportChildren(buf, level = 1, name_ = 'virtual-machine-interface-mac-addresses', pretty_print = False)
            else: # object
                field.exportChildren(buf, level = 1, name_ = 'virtual-machine-interface-mac-addresses', pretty_print = False)
            virtual_machine_interface_mac_addresses_xml = buf.getvalue()
            buf.close()
            meta = str(Metadata('virtual-machine-interface-mac-addresses' , '',
                   {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail',
                   elements = virtual_machine_interface_mac_addresses_xml))
            self._publish_id_self_meta(my_imid, meta)

        field = obj_dict.get('virtual_machine_interface_properties', None)
        if field:
            # construct object of xsd-type and get its xml repr
            field = obj_dict['virtual_machine_interface_properties']
            buf = cStringIO.StringIO()
            # perms might be inserted at server as obj.
            # obj construction diff from dict construction.
            if isinstance(field, dict):
                VirtualMachineInterfacePropertiesType(**field).exportChildren(buf, level = 1, name_ = 'virtual-machine-interface-properties', pretty_print = False)
            else: # object
                field.exportChildren(buf, level = 1, name_ = 'virtual-machine-interface-properties', pretty_print = False)
            virtual_machine_interface_properties_xml = buf.getvalue()
            buf.close()
            meta = str(Metadata('virtual-machine-interface-properties' , '',
                   {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail',
                   elements = virtual_machine_interface_properties_xml))
            self._publish_id_self_meta(my_imid, meta)

        field = obj_dict.get('id_perms', None)
        if field:
            # construct object of xsd-type and get its xml repr
            field = obj_dict['id_perms']
            buf = cStringIO.StringIO()
            # perms might be inserted at server as obj.
            # obj construction diff from dict construction.
            if isinstance(field, dict):
                IdPermsType(**field).exportChildren(buf, level = 1, name_ = 'id-perms', pretty_print = False)
            else: # object
                field.exportChildren(buf, level = 1, name_ = 'id-perms', pretty_print = False)
            id_perms_xml = buf.getvalue()
            buf.close()
            meta = str(Metadata('id-perms' , '',
                   {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail',
                   elements = id_perms_xml))
            self._publish_id_self_meta(my_imid, meta)

        # Ref Link Metas
        imid = self._imid_handler

        # construct object of xsd-type and get its xml repr
        refs = obj_dict.get('virtual_network_refs', None)
        if refs:
            for ref in refs:
                ref_fq_name = ref['to']
                obj_type = 'virtual-network'
                to_imid = common.imid.get_ifmap_id_from_fq_name(obj_type, ref_fq_name)
                virtual_machine_interface_virtual_network_xml = ''
                meta = str(Metadata('virtual-machine-interface-virtual-network' , '',
                       {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail',
                       elements = virtual_machine_interface_virtual_network_xml))
                self._publish_id_pair_meta(my_imid, to_imid, meta)

        # construct object of xsd-type and get its xml repr
        refs = obj_dict.get('routing_instance_refs', None)
        if refs:
            for ref in refs:
                ref_fq_name = ref['to']
                obj_type = 'routing-instance'
                to_imid = common.imid.get_ifmap_id_from_fq_name(obj_type, ref_fq_name)
                virtual_machine_interface_routing_instance_xml = ''
                ref_data = ref['attr']
                if ref_data:
                    buf = cStringIO.StringIO()
                    PolicyBasedForwardingRuleType(**ref_data).exportChildren(buf, level = 1, name_ = 'virtual-machine-interface-routing-instance', pretty_print = False)
                    virtual_machine_interface_routing_instance_xml = virtual_machine_interface_routing_instance_xml + buf.getvalue()
                    buf.close()
                meta = str(Metadata('virtual-machine-interface-routing-instance' , '',
                       {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail',
                       elements = virtual_machine_interface_routing_instance_xml))
                self._publish_id_pair_meta(my_imid, to_imid, meta)


        return (True, '')
    #end _ifmap_virtual_machine_interface_set

    def _ifmap_virtual_machine_interface_create(self, obj_ids, obj_dict):
        if not 'parent_type' in obj_dict:
            # parent is config-root
            parent_type = 'config-root'
            parent_imid = 'contrail:config-root:root'
        else:
            parent_type = obj_dict['parent_type']
            parent_imid = obj_ids.get('parent_imid', None)

        # Parent Link Meta
        parent_link_meta = self._parent_metas[parent_type]['virtual-machine-interface']
        meta = str(Metadata(parent_link_meta, '',
                   {'ifmap-cardinality':'singleValue'}, ns_prefix = 'contrail'))
        self._publish_id_pair_meta(parent_imid, obj_ids['imid'], meta)

        (ok, result) = self._ifmap_virtual_machine_interface_set(obj_ids['imid'], obj_dict)
        return (ok, result)
    #end _ifmap_virtual_machine_interface_create

    def _ifmap_virtual_machine_interface_read(self, ifmap_id, field_names = None):
        # field_names = None means all fields will be read
        imid = self._imid_handler
        mapclient = self._mapclient
        start_id = str(Identity(name = ifmap_id, type = 'other',
                        other_type = 'extended'))
        # if id-perms missing, identity doesn't exist

        all_metas = [u'contrail:virtual-machine-interface-virtual-network', u'contrail:virtual-machine-interface-routing-instance', u'contrail:instance-ip-virtual-machine-interface', u'contrail:floating-ip-virtual-machine-interface', u'contrail:customer-attachment-virtual-machine-interface', u'contrail:virtual-machine-interface-mac-addresses', u'contrail:virtual-machine-interface-properties', u'contrail:id-perms']
        if not field_names:
            metas_to_read = all_metas
        else: # read only requested fields
            req_metas = []
            if field_names.has_key('virtual_network_refs'):
                req_metas.append('contrail:virtual-machine-interface-virtual-network')
            if field_names.has_key('routing_instance_refs'):
                req_metas.append('contrail:virtual-machine-interface-routing-instance')
            if field_names.has_key('instance_ip_back_refs'):
                req_metas.append('contrail:instance-ip-virtual-machine-interface')
            if field_names.has_key('floating_ip_back_refs'):
                req_metas.append('contrail:floating-ip-virtual-machine-interface')
            if field_names.has_key('customer_attachment_back_refs'):
                req_metas.append('contrail:customer-attachment-virtual-machine-interface')
            if field_names.has_key('virtual_machine_interface_mac_addresses'):
                req_metas.append('contrail:virtual-machine-interface-mac-addresses')
            if field_names.has_key('virtual_machine_interface_properties'):
                req_metas.append('contrail:virtual-machine-interface-properties')
            if field_names.has_key('id_perms'):
                req_metas.append('contrail:id-perms')

            metas_to_read = set(all_metas) & set(req_metas)

        srch_meta = ' or '.join(metas_to_read)
        srch_result = self._search(start_id, srch_meta)

        result_list = self.parse_result_items(srch_result, ifmap_id)
        if (len(result_list) == 1 and 
            result_list[0][2] == None):
            return (False, 'virtual-machine-interface ' + ifmap_id + 'does not exist')

        # metas is a dict where key is meta-name and val is list of tuples
        # of form (ident1, ident2, meta)
        metas = {}
        for r_elem in result_list:
            r_meta = r_elem[2]
            # create contrail:<tag>
            meta_name = r_meta.prefix + ':' + re.sub('{.*}', '', r_meta.tag)

            if (
                (meta_name == 'contrail:virtual-machine-interface-virtual-network') or
                (meta_name == 'contrail:virtual-machine-interface-routing-instance') or
                (meta_name == 'contrail:instance-ip-virtual-machine-interface') or
                (meta_name == 'contrail:floating-ip-virtual-machine-interface') or
                (meta_name == 'contrail:customer-attachment-virtual-machine-interface') or
                (meta_name == 'contrail:virtual-machine-interface-mac-addresses') or
                (meta_name == 'contrail:virtual-machine-interface-properties') or
                (meta_name == 'contrail:id-perms')
               ):
                if metas.has_key(meta_name):
                    metas[meta_name].append(r_elem)
                else: # first ident for this link-type
                    metas[meta_name] = [r_elem]

         # Construct dicts from xml
        result = {}
        result['_type'] = 'virtual-machine-interface'
        fq_name = self._db_client_mgr.ifmap_id_to_fq_name(ifmap_id)
        result['fq_name'] = fq_name
        result['name'] = fq_name[-1]
        if metas.has_key('contrail:virtual-machine-interface-virtual-network'):
            result['virtual_network_refs'] = []
            result_elems = metas['contrail:virtual-machine-interface-virtual-network']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                obj_val = {}
                # in case of refs between same types of identifiers,
                # the referred ident could appears at idx 0 or 1
                if ifmap_id == r_elem[0].attrib['name']:
                    ref_ifmap_id = r_elem[1].attrib['name']
                else:
                    ref_ifmap_id = r_elem[0].attrib['name']

                try:
                    ref_fq_name = self._db_client_mgr.ifmap_id_to_fq_name(ref_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown fq_name for ref ' + ref_ifmap_id
                    return (False, err_msg)
                try:
                    ref_uuid = self._db_client_mgr.ifmap_id_to_uuid(ref_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown uuid for ref ' + ref_ifmap_id
                    return (False, err_msg)

                ref_url = self._db_client_mgr.generate_url('virtual_network', ref_uuid)
                ref_info = {}
                ref_info['to'] = ref_fq_name
                ref_info['attr'] = obj_val
                ref_info['href'] = ref_url
                ref_info['uuid'] = ref_uuid
                result['virtual_network_refs'].append(ref_info)


        if metas.has_key('contrail:virtual-machine-interface-routing-instance'):
            result['routing_instance_refs'] = []
            result_elems = metas['contrail:virtual-machine-interface-routing-instance']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                # need to preserve type eg. int for prefix-len
                # for now, xml -> obj -> json -> dict
                # TODO TypeGenerator.py should have xml to dict method
                obj = PolicyBasedForwardingRuleType()
                obj.build(meta)
                obj_json = ''
                obj_json = json.dumps(obj,
                    default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
                obj_val = json.loads(obj_json)
                # in case of refs between same types of identifiers,
                # the referred ident could appears at idx 0 or 1
                if ifmap_id == r_elem[0].attrib['name']:
                    ref_ifmap_id = r_elem[1].attrib['name']
                else:
                    ref_ifmap_id = r_elem[0].attrib['name']

                try:
                    ref_fq_name = self._db_client_mgr.ifmap_id_to_fq_name(ref_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown fq_name for ref ' + ref_ifmap_id
                    return (False, err_msg)
                try:
                    ref_uuid = self._db_client_mgr.ifmap_id_to_uuid(ref_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown uuid for ref ' + ref_ifmap_id
                    return (False, err_msg)

                ref_url = self._db_client_mgr.generate_url('routing_instance', ref_uuid)
                ref_info = {}
                ref_info['to'] = ref_fq_name
                ref_info['attr'] = obj_val
                ref_info['href'] = ref_url
                ref_info['uuid'] = ref_uuid
                result['routing_instance_refs'].append(ref_info)


        if metas.has_key('contrail:instance-ip-virtual-machine-interface'):
            result['instance_ip_back_refs'] = []
            result_elems = metas['contrail:instance-ip-virtual-machine-interface']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                obj_val = {}
                back_ref_ifmap_id = r_elem[0].attrib['name']

                try:
                    back_ref_fq_name = self._db_client_mgr.ifmap_id_to_fq_name(back_ref_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown fq_name for backref ' + back_ref_ifmap_id
                    return (False, err_msg)
                try:
                    back_ref_uuid = self._db_client_mgr.ifmap_id_to_uuid(back_ref_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown uuid for backref ' + back_ref_ifmap_id
                    return (False, err_msg)

                back_ref_url = self._db_client_mgr.generate_url('instance_ip', back_ref_uuid)
                back_ref_info = {}
                back_ref_info['to'] = back_ref_fq_name
                back_ref_info['attr'] = obj_val
                back_ref_info['href'] = back_ref_url
                back_ref_info['uuid'] = back_ref_uuid
                result['instance_ip_back_refs'].append(back_ref_info)


        if metas.has_key('contrail:floating-ip-virtual-machine-interface'):
            result['floating_ip_back_refs'] = []
            result_elems = metas['contrail:floating-ip-virtual-machine-interface']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                obj_val = {}
                back_ref_ifmap_id = r_elem[0].attrib['name']

                try:
                    back_ref_fq_name = self._db_client_mgr.ifmap_id_to_fq_name(back_ref_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown fq_name for backref ' + back_ref_ifmap_id
                    return (False, err_msg)
                try:
                    back_ref_uuid = self._db_client_mgr.ifmap_id_to_uuid(back_ref_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown uuid for backref ' + back_ref_ifmap_id
                    return (False, err_msg)

                back_ref_url = self._db_client_mgr.generate_url('floating_ip', back_ref_uuid)
                back_ref_info = {}
                back_ref_info['to'] = back_ref_fq_name
                back_ref_info['attr'] = obj_val
                back_ref_info['href'] = back_ref_url
                back_ref_info['uuid'] = back_ref_uuid
                result['floating_ip_back_refs'].append(back_ref_info)


        if metas.has_key('contrail:customer-attachment-virtual-machine-interface'):
            result['customer_attachment_back_refs'] = []
            result_elems = metas['contrail:customer-attachment-virtual-machine-interface']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                obj_val = {}
                back_ref_ifmap_id = r_elem[0].attrib['name']

                try:
                    back_ref_fq_name = self._db_client_mgr.ifmap_id_to_fq_name(back_ref_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown fq_name for backref ' + back_ref_ifmap_id
                    return (False, err_msg)
                try:
                    back_ref_uuid = self._db_client_mgr.ifmap_id_to_uuid(back_ref_ifmap_id)
                except common.exceptions.NoIdError:
                    err_msg = 'Unknown uuid for backref ' + back_ref_ifmap_id
                    return (False, err_msg)

                back_ref_url = self._db_client_mgr.generate_url('customer_attachment', back_ref_uuid)
                back_ref_info = {}
                back_ref_info['to'] = back_ref_fq_name
                back_ref_info['attr'] = obj_val
                back_ref_info['href'] = back_ref_url
                back_ref_info['uuid'] = back_ref_uuid
                result['customer_attachment_back_refs'].append(back_ref_info)


        if metas.has_key('contrail:virtual-machine-interface-mac-addresses'):
            result_elems = metas['contrail:virtual-machine-interface-mac-addresses']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                # need to preserve type eg. int for prefix-len
                # for now, xml -> obj -> json -> dict
                # TODO TypeGenerator.py should have xml to dict method
                obj = MacAddressesType()
                obj.build(meta)
                obj_json = ''
                obj_json = json.dumps(obj,
                    default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
                obj_val = json.loads(obj_json)
                result['virtual_machine_interface_mac_addresses'] = obj_val

        if metas.has_key('contrail:virtual-machine-interface-properties'):
            result_elems = metas['contrail:virtual-machine-interface-properties']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                # need to preserve type eg. int for prefix-len
                # for now, xml -> obj -> json -> dict
                # TODO TypeGenerator.py should have xml to dict method
                obj = VirtualMachineInterfacePropertiesType()
                obj.build(meta)
                obj_json = ''
                obj_json = json.dumps(obj,
                    default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
                obj_val = json.loads(obj_json)
                result['virtual_machine_interface_properties'] = obj_val

        if metas.has_key('contrail:id-perms'):
            result_elems = metas['contrail:id-perms']
            # metas[key] is always a list
            for r_elem in result_elems:
                meta = r_elem[2]
                # need to preserve type eg. int for prefix-len
                # for now, xml -> obj -> json -> dict
                # TODO TypeGenerator.py should have xml to dict method
                obj = IdPermsType()
                obj.build(meta)
                obj_json = ''
                obj_json = json.dumps(obj,
                    default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
                obj_val = json.loads(obj_json)
                result['id_perms'] = obj_val

        return (True, result)
    #end _ifmap_virtual_machine_interface_read

    def _ifmap_virtual_machine_interface_update(self, ifmap_id, old_obj_dict, new_obj_dict):
        # remove properties that are no longer active
        if ('virtual_machine_interface_mac_addresses' in new_obj_dict) and (new_obj_dict['virtual_machine_interface_mac_addresses'] == None):
            self._delete_id_self_meta(ifmap_id, 'virtual-machine-interface-mac-addresses')

        if ('virtual_machine_interface_properties' in new_obj_dict) and (new_obj_dict['virtual_machine_interface_properties'] == None):
            self._delete_id_self_meta(ifmap_id, 'virtual-machine-interface-properties')

        if ('id_perms' in new_obj_dict) and (new_obj_dict['id_perms'] == None):
            self._delete_id_self_meta(ifmap_id, 'id-perms')

        # remove refs that are no longer active
        if ('virtual_network_refs' in old_obj_dict):
            old_refs = [tuple(ref['to']) for ref in old_obj_dict['virtual_network_refs']]
        else:
            old_refs = []
        if ('virtual_network_refs' in new_obj_dict):
            if new_obj_dict['virtual_network_refs'] == None:
                new_refs = []
            else:
                new_refs = [tuple(ref['to']) for ref in new_obj_dict['virtual_network_refs']]
        else: # no ref key in new_obj
            new_refs = old_refs

        old_set = set(old_refs)
        new_set = set(new_refs)
        inact_refs = old_set - new_set
        for inact_ref in inact_refs:
            to_imid = self.fq_name_to_ifmap_id('virtual-network', inact_ref)
            self._delete_id_pair_meta(ifmap_id, to_imid, 'contrail:virtual-machine-interface-virtual-network')

        if ('routing_instance_refs' in old_obj_dict):
            old_refs = [tuple(ref['to']) for ref in old_obj_dict['routing_instance_refs']]
        else:
            old_refs = []
        if ('routing_instance_refs' in new_obj_dict):
            if new_obj_dict['routing_instance_refs'] == None:
                new_refs = []
            else:
                new_refs = [tuple(ref['to']) for ref in new_obj_dict['routing_instance_refs']]
        else: # no ref key in new_obj
            new_refs = old_refs

        old_set = set(old_refs)
        new_set = set(new_refs)
        inact_refs = old_set - new_set
        for inact_ref in inact_refs:
            to_imid = self.fq_name_to_ifmap_id('routing-instance', inact_ref)
            self._delete_id_pair_meta(ifmap_id, to_imid, 'contrail:virtual-machine-interface-routing-instance')

        (ok, result) = self._ifmap_virtual_machine_interface_set(ifmap_id, new_obj_dict)
        return (ok, result)
    #end _ifmap_virtual_machine_interface_update

    def _ifmap_virtual_machine_interface_list(self, parent_type, parent_fq_name):
        children_fq_names = []
        mapclient = self._mapclient
        parent_imid = common.imid.get_ifmap_id_from_fq_name(parent_type, parent_fq_name)
        start_id = str(Identity(name = parent_imid, type = 'other',
                        other_type = 'extended'))
        # if id-perms missing, identity doesn't exist
        parent_link_meta = self._parent_metas[parent_type]['virtual-machine-interface']
        srch_meta = 'contrail:' + parent_link_meta
        srch_result = self._search(start_id, srch_meta)

        result_list = self.parse_result_items(srch_result, parent_imid)
        for r_elem in result_list:
            child_ident = r_elem[1]
            if child_ident is None:
                continue
            child_imid = child_ident.attrib['name']
            fq_name = self._db_client_mgr.ifmap_id_to_fq_name(child_imid)
            children_fq_names.append(fq_name)


        return (True, children_fq_names)
    #end _ifmap_virtual_machine_interface_list

    def _ifmap_virtual_machine_interface_delete(self, obj_ids):
        ifmap_id = obj_ids['imid']
        parent_imid = obj_ids.get('parent_imid', None)
        start_id = str(Identity(name = ifmap_id, type = 'other',
                        other_type = 'extended'))
        # Delete links to our references, first find them
        srch_meta = ' or '.join([u'contrail:virtual-machine-interface-virtual-network', u'contrail:virtual-machine-interface-routing-instance'])
        srch_result = self._search(start_id, srch_meta)

        result_list = self.parse_result_items(srch_result, ifmap_id)
        for r_elem in result_list:
            to_ident = r_elem[1]
            if to_ident is None:
                continue
            to_imid = to_ident.attrib['name']
            r_meta = r_elem[2]
            # create contrail:<tag>
            meta_name = r_meta.prefix + ':' + re.sub('{.*}', '', r_meta.tag)
            self._delete_id_pair_meta(ifmap_id, to_imid, meta_name)


        if parent_imid:
            # Remove link from parent
            self._delete_id_pair_meta(parent_imid, ifmap_id, None)

        # Remove all property metadata associated with this ident
        self._delete_id_self_meta(ifmap_id, None)

        return (True, '')
    #end _ifmap_virtual_machine_interface_delete

#end class VncIfmapClientGen

class ImidGen(object):
    def domain_alloc_ifmap_id(self, parent_type, fq_name):
        my_fqn = ':'.join(fq_name)
        parent_fqn = ':'.join(fq_name[:-1])

        my_imid = 'contrail:domain:' + my_fqn
        if parent_fqn:
            parent_imid = 'contrail:' + parent_type + ':' + parent_fqn
        else: # parent is config-root
            parent_imid = 'contrail:config-root:root'

        return (my_imid, parent_imid)
    #end domain_alloc_ifmap_id

    def service_instance_alloc_ifmap_id(self, parent_type, fq_name):
        my_fqn = ':'.join(fq_name)
        parent_fqn = ':'.join(fq_name[:-1])

        my_imid = 'contrail:service-instance:' + my_fqn
        if parent_fqn:
            parent_imid = 'contrail:' + parent_type + ':' + parent_fqn
        else: # parent is config-root
            parent_imid = 'contrail:config-root:root'

        return (my_imid, parent_imid)
    #end service_instance_alloc_ifmap_id

    def instance_ip_alloc_ifmap_id(self, parent_type, fq_name):
        my_fqn = ':'.join(fq_name)
        parent_fqn = ':'.join(fq_name[:-1])

        my_imid = 'contrail:instance-ip:' + my_fqn
        if parent_fqn:
            parent_imid = 'contrail:' + parent_type + ':' + parent_fqn
        else: # parent is config-root
            parent_imid = 'contrail:config-root:root'

        return (my_imid, parent_imid)
    #end instance_ip_alloc_ifmap_id

    def network_policy_alloc_ifmap_id(self, parent_type, fq_name):
        my_fqn = ':'.join(fq_name)
        parent_fqn = ':'.join(fq_name[:-1])

        my_imid = 'contrail:network-policy:' + my_fqn
        if parent_fqn:
            parent_imid = 'contrail:' + parent_type + ':' + parent_fqn
        else: # parent is config-root
            parent_imid = 'contrail:config-root:root'

        return (my_imid, parent_imid)
    #end network_policy_alloc_ifmap_id

    def virtual_DNS_record_alloc_ifmap_id(self, parent_type, fq_name):
        my_fqn = ':'.join(fq_name)
        parent_fqn = ':'.join(fq_name[:-1])

        my_imid = 'contrail:virtual-DNS-record:' + my_fqn
        if parent_fqn:
            parent_imid = 'contrail:' + parent_type + ':' + parent_fqn
        else: # parent is config-root
            parent_imid = 'contrail:config-root:root'

        return (my_imid, parent_imid)
    #end virtual_DNS_record_alloc_ifmap_id

    def route_target_alloc_ifmap_id(self, parent_type, fq_name):
        my_fqn = ':'.join(fq_name)
        parent_fqn = ':'.join(fq_name[:-1])

        my_imid = 'contrail:route-target:' + my_fqn
        if parent_fqn:
            parent_imid = 'contrail:' + parent_type + ':' + parent_fqn
        else: # parent is config-root
            parent_imid = 'contrail:config-root:root'

        return (my_imid, parent_imid)
    #end route_target_alloc_ifmap_id

    def floating_ip_alloc_ifmap_id(self, parent_type, fq_name):
        my_fqn = ':'.join(fq_name)
        parent_fqn = ':'.join(fq_name[:-1])

        my_imid = 'contrail:floating-ip:' + my_fqn
        if parent_fqn:
            parent_imid = 'contrail:' + parent_type + ':' + parent_fqn
        else: # parent is config-root
            parent_imid = 'contrail:config-root:root'

        return (my_imid, parent_imid)
    #end floating_ip_alloc_ifmap_id

    def floating_ip_pool_alloc_ifmap_id(self, parent_type, fq_name):
        my_fqn = ':'.join(fq_name)
        parent_fqn = ':'.join(fq_name[:-1])

        my_imid = 'contrail:floating-ip-pool:' + my_fqn
        if parent_fqn:
            parent_imid = 'contrail:' + parent_type + ':' + parent_fqn
        else: # parent is config-root
            parent_imid = 'contrail:config-root:root'

        return (my_imid, parent_imid)
    #end floating_ip_pool_alloc_ifmap_id

    def physical_router_alloc_ifmap_id(self, parent_type, fq_name):
        my_fqn = ':'.join(fq_name)
        parent_fqn = ':'.join(fq_name[:-1])

        my_imid = 'contrail:physical-router:' + my_fqn
        if parent_fqn:
            parent_imid = 'contrail:' + parent_type + ':' + parent_fqn
        else: # parent is config-root
            parent_imid = 'contrail:config-root:root'

        return (my_imid, parent_imid)
    #end physical_router_alloc_ifmap_id

    def bgp_router_alloc_ifmap_id(self, parent_type, fq_name):
        my_fqn = ':'.join(fq_name)
        parent_fqn = ':'.join(fq_name[:-1])

        my_imid = 'contrail:bgp-router:' + my_fqn
        if parent_fqn:
            parent_imid = 'contrail:' + parent_type + ':' + parent_fqn
        else: # parent is config-root
            parent_imid = 'contrail:config-root:root'

        return (my_imid, parent_imid)
    #end bgp_router_alloc_ifmap_id

    def virtual_router_alloc_ifmap_id(self, parent_type, fq_name):
        my_fqn = ':'.join(fq_name)
        parent_fqn = ':'.join(fq_name[:-1])

        my_imid = 'contrail:virtual-router:' + my_fqn
        if parent_fqn:
            parent_imid = 'contrail:' + parent_type + ':' + parent_fqn
        else: # parent is config-root
            parent_imid = 'contrail:config-root:root'

        return (my_imid, parent_imid)
    #end virtual_router_alloc_ifmap_id

    def config_root_alloc_ifmap_id(self, parent_type, fq_name):
        my_fqn = ':'.join(fq_name)
        parent_fqn = ':'.join(fq_name[:-1])

        my_imid = 'contrail:config-root:' + my_fqn
        if parent_fqn:
            parent_imid = 'contrail:' + parent_type + ':' + parent_fqn
        else: # parent is config-root
            parent_imid = 'contrail:config-root:root'

        return (my_imid, parent_imid)
    #end config_root_alloc_ifmap_id

    def global_system_config_alloc_ifmap_id(self, parent_type, fq_name):
        my_fqn = ':'.join(fq_name)
        parent_fqn = ':'.join(fq_name[:-1])

        my_imid = 'contrail:global-system-config:' + my_fqn
        if parent_fqn:
            parent_imid = 'contrail:' + parent_type + ':' + parent_fqn
        else: # parent is config-root
            parent_imid = 'contrail:config-root:root'

        return (my_imid, parent_imid)
    #end global_system_config_alloc_ifmap_id

    def namespace_alloc_ifmap_id(self, parent_type, fq_name):
        my_fqn = ':'.join(fq_name)
        parent_fqn = ':'.join(fq_name[:-1])

        my_imid = 'contrail:namespace:' + my_fqn
        if parent_fqn:
            parent_imid = 'contrail:' + parent_type + ':' + parent_fqn
        else: # parent is config-root
            parent_imid = 'contrail:config-root:root'

        return (my_imid, parent_imid)
    #end namespace_alloc_ifmap_id

    def physical_interface_alloc_ifmap_id(self, parent_type, fq_name):
        my_fqn = ':'.join(fq_name)
        parent_fqn = ':'.join(fq_name[:-1])

        my_imid = 'contrail:physical-interface:' + my_fqn
        if parent_fqn:
            parent_imid = 'contrail:' + parent_type + ':' + parent_fqn
        else: # parent is config-root
            parent_imid = 'contrail:config-root:root'

        return (my_imid, parent_imid)
    #end physical_interface_alloc_ifmap_id

    def access_control_list_alloc_ifmap_id(self, parent_type, fq_name):
        my_fqn = ':'.join(fq_name)
        parent_fqn = ':'.join(fq_name[:-1])

        my_imid = 'contrail:access-control-list:' + my_fqn
        if parent_fqn:
            parent_imid = 'contrail:' + parent_type + ':' + parent_fqn
        else: # parent is config-root
            parent_imid = 'contrail:config-root:root'

        return (my_imid, parent_imid)
    #end access_control_list_alloc_ifmap_id

    def virtual_DNS_alloc_ifmap_id(self, parent_type, fq_name):
        my_fqn = ':'.join(fq_name)
        parent_fqn = ':'.join(fq_name[:-1])

        my_imid = 'contrail:virtual-DNS:' + my_fqn
        if parent_fqn:
            parent_imid = 'contrail:' + parent_type + ':' + parent_fqn
        else: # parent is config-root
            parent_imid = 'contrail:config-root:root'

        return (my_imid, parent_imid)
    #end virtual_DNS_alloc_ifmap_id

    def customer_attachment_alloc_ifmap_id(self, parent_type, fq_name):
        my_fqn = ':'.join(fq_name)
        parent_fqn = ':'.join(fq_name[:-1])

        my_imid = 'contrail:customer-attachment:' + my_fqn
        if parent_fqn:
            parent_imid = 'contrail:' + parent_type + ':' + parent_fqn
        else: # parent is config-root
            parent_imid = 'contrail:config-root:root'

        return (my_imid, parent_imid)
    #end customer_attachment_alloc_ifmap_id

    def virtual_machine_alloc_ifmap_id(self, parent_type, fq_name):
        my_fqn = ':'.join(fq_name)
        parent_fqn = ':'.join(fq_name[:-1])

        my_imid = 'contrail:virtual-machine:' + my_fqn
        if parent_fqn:
            parent_imid = 'contrail:' + parent_type + ':' + parent_fqn
        else: # parent is config-root
            parent_imid = 'contrail:config-root:root'

        return (my_imid, parent_imid)
    #end virtual_machine_alloc_ifmap_id

    def service_template_alloc_ifmap_id(self, parent_type, fq_name):
        my_fqn = ':'.join(fq_name)
        parent_fqn = ':'.join(fq_name[:-1])

        my_imid = 'contrail:service-template:' + my_fqn
        if parent_fqn:
            parent_imid = 'contrail:' + parent_type + ':' + parent_fqn
        else: # parent is config-root
            parent_imid = 'contrail:config-root:root'

        return (my_imid, parent_imid)
    #end service_template_alloc_ifmap_id

    def security_group_alloc_ifmap_id(self, parent_type, fq_name):
        my_fqn = ':'.join(fq_name)
        parent_fqn = ':'.join(fq_name[:-1])

        my_imid = 'contrail:security-group:' + my_fqn
        if parent_fqn:
            parent_imid = 'contrail:' + parent_type + ':' + parent_fqn
        else: # parent is config-root
            parent_imid = 'contrail:config-root:root'

        return (my_imid, parent_imid)
    #end security_group_alloc_ifmap_id

    def provider_attachment_alloc_ifmap_id(self, parent_type, fq_name):
        my_fqn = ':'.join(fq_name)
        parent_fqn = ':'.join(fq_name[:-1])

        my_imid = 'contrail:provider-attachment:' + my_fqn
        if parent_fqn:
            parent_imid = 'contrail:' + parent_type + ':' + parent_fqn
        else: # parent is config-root
            parent_imid = 'contrail:config-root:root'

        return (my_imid, parent_imid)
    #end provider_attachment_alloc_ifmap_id

    def network_ipam_alloc_ifmap_id(self, parent_type, fq_name):
        my_fqn = ':'.join(fq_name)
        parent_fqn = ':'.join(fq_name[:-1])

        my_imid = 'contrail:network-ipam:' + my_fqn
        if parent_fqn:
            parent_imid = 'contrail:' + parent_type + ':' + parent_fqn
        else: # parent is config-root
            parent_imid = 'contrail:config-root:root'

        return (my_imid, parent_imid)
    #end network_ipam_alloc_ifmap_id

    def virtual_network_alloc_ifmap_id(self, parent_type, fq_name):
        my_fqn = ':'.join(fq_name)
        parent_fqn = ':'.join(fq_name[:-1])

        my_imid = 'contrail:virtual-network:' + my_fqn
        if parent_fqn:
            parent_imid = 'contrail:' + parent_type + ':' + parent_fqn
        else: # parent is config-root
            parent_imid = 'contrail:config-root:root'

        return (my_imid, parent_imid)
    #end virtual_network_alloc_ifmap_id

    def project_alloc_ifmap_id(self, parent_type, fq_name):
        my_fqn = ':'.join(fq_name)
        parent_fqn = ':'.join(fq_name[:-1])

        my_imid = 'contrail:project:' + my_fqn
        if parent_fqn:
            parent_imid = 'contrail:' + parent_type + ':' + parent_fqn
        else: # parent is config-root
            parent_imid = 'contrail:config-root:root'

        return (my_imid, parent_imid)
    #end project_alloc_ifmap_id

    def logical_interface_alloc_ifmap_id(self, parent_type, fq_name):
        my_fqn = ':'.join(fq_name)
        parent_fqn = ':'.join(fq_name[:-1])

        my_imid = 'contrail:logical-interface:' + my_fqn
        if parent_fqn:
            parent_imid = 'contrail:' + parent_type + ':' + parent_fqn
        else: # parent is config-root
            parent_imid = 'contrail:config-root:root'

        return (my_imid, parent_imid)
    #end logical_interface_alloc_ifmap_id

    def routing_instance_alloc_ifmap_id(self, parent_type, fq_name):
        my_fqn = ':'.join(fq_name)
        parent_fqn = ':'.join(fq_name[:-1])

        my_imid = 'contrail:routing-instance:' + my_fqn
        if parent_fqn:
            parent_imid = 'contrail:' + parent_type + ':' + parent_fqn
        else: # parent is config-root
            parent_imid = 'contrail:config-root:root'

        return (my_imid, parent_imid)
    #end routing_instance_alloc_ifmap_id

    def virtual_machine_interface_alloc_ifmap_id(self, parent_type, fq_name):
        my_fqn = ':'.join(fq_name)
        parent_fqn = ':'.join(fq_name[:-1])

        my_imid = 'contrail:virtual-machine-interface:' + my_fqn
        if parent_fqn:
            parent_imid = 'contrail:' + parent_type + ':' + parent_fqn
        else: # parent is config-root
            parent_imid = 'contrail:config-root:root'

        return (my_imid, parent_imid)
    #end virtual_machine_interface_alloc_ifmap_id


link_name_to_xsd_type = {
    "project-namespace":"SubnetType",
    "connection":"ConnectionType",
    "bgp-peering":"BgpPeeringAttributes",
    "virtual-machine-interface-routing-instance":"PolicyBasedForwardingRuleType",
    "virtual-network-network-policy":"VirtualNetworkPolicyType",
    "instance-target":"InstanceTargetType",
    "virtual-network-network-ipam":"VnSubnetsType"
}


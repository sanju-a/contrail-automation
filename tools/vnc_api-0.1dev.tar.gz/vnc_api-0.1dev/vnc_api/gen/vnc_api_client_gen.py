
# AUTO-GENERATED file from IFMapApiGenerator. Do Not Edit!

import json
from vnc_api.gen.resource_xsd import *
from vnc_api.gen.resource_client import *
from vnc_api.gen.connection_drv_gen import ConnectionDriverBase
from vnc_api.common import rest
from vnc_api.common.exceptions import *

class VncApiClientGen(ConnectionDriverBase):
    """
    This class provides type specific methods to create,
    read, update, delete and list objects from the server
    """

    _tenant_name = 'default-tenant'
    def __init__(self):
        pass
    #end __init__
    def domain_create(self, obj):
        """Create new domain.
        
        :param obj: :class:`.Domain` object
        
        """
        # Ignore fields with None value in json representation
        json_param = json.dumps(obj,
            default = lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        json_body = '{"domain":' + json_param + '}'
        content = self._request_server(rest.OP_POST,
                       DomainClientGen.create_uri,
                       data = json_body)

        domain_dict = json.loads(content)['domain']
        obj.uuid = domain_dict['uuid']
        if 'parent_uuid' in domain_dict:
            obj.parent_uuid = domain_dict['parent_uuid']

        return obj.uuid
    #end domain_create

    def domain_read(self, fq_name = None, fq_name_str = None, id = None, ifmap_id = None):
        """Return domain information.
        
        :param fq_name: Fully qualified name of domain
        :param fq_name_str: Fully qualified name string of domain
        :param id: UUID of domain
        :param ifmap_id: IFMAP id of domain
        :returns: :class:`.Domain` object
        
        """
        (args_ok, result) = self._read_args_to_id('domain', fq_name, fq_name_str, id, ifmap_id)
        if not args_ok:
            return result

        id = result
        uri = DomainClientGen.resource_uri_base['domain'] + '/' + id

        content = self._request_server(rest.OP_GET, uri)

        obj_dict = json.loads(content)['domain']
        obj_dict['name'] = obj_dict['fq_name'][-1]
        if obj_dict.has_key('domain_limits'):
            prop_obj = DomainLimitsType(**obj_dict['domain_limits'])
            obj_dict['domain_limits'] = prop_obj

        if obj_dict.has_key('api_access_list'):
            prop_obj = ApiAccessListType(**obj_dict['api_access_list'])
            obj_dict['api_access_list'] = prop_obj

        if obj_dict.has_key('id_perms'):
            prop_obj = IdPermsType(**obj_dict['id_perms'])
            obj_dict['id_perms'] = prop_obj

        # fill ref links
        # fill back ref links
        return Domain.factory(**obj_dict)
    #end domain_read

    def domain_update(self, obj):
        """Update domain.
        
        :param obj: :class:`.Domain` object
        
        """
        # Read in uuid from api-server if not specified in obj
        if not obj.uuid:
            obj.uuid = self.fq_name_to_id('domain', obj.get_fq_name())

        # Ignore fields with None value in json representation
        json_param = json.dumps(obj,
            default = lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        json_body = '{"domain":' + json_param + '}'

        id = obj.uuid
        uri = DomainClientGen.resource_uri_base['domain'] + '/' + id
        content = self._request_server(rest.OP_PUT, uri, data = json_body)
        return content
    #end domain_update

    def domains_list(self, parent_id = None, parent_fq_name = None):
        """List all domains.
        
        :param parent_id: UUID of parent as optional search filter
        :param parent_fq_name: full qualified name of parent as optional search filter
        :returns: list of :class:`.Domain` objects
        
        """
        filt = None
        # TODO validate only one of id or name is given
        filt = {}
        if parent_fq_name:
            parent_fq_name_str = ':'.join(parent_fq_name)
            filt['parent_fq_name_str'] = parent_fq_name_str
        elif parent_id:
            filt['parent_id'] = parent_id
        content = self._request_server(rest.OP_GET,
                       DomainClientGen.create_uri,
                       data = filt)
        return content
    #end domains_list

    def domain_delete(self, fq_name = None, id = None, ifmap_id = None):
        """Delete domain from the system.
        
        :param fq_name: Fully qualified name of domain
        :param id: UUID of domain
        :param ifmap_id: IFMAP id of domain
        
        """
        (args_ok, result) = self._read_args_to_id(obj_type = 'domain', fq_name = fq_name, id = id, ifmap_id = ifmap_id)
        if not args_ok:
            return result

        id = result
        uri = DomainClientGen.resource_uri_base['domain'] + '/' + id

        content = self._request_server(rest.OP_DELETE, uri)
    #end domain_delete

    def get_default_domain_id(self):
        """Return UUID of default domain."""
        return self.fq_name_to_id('domain', Domain().get_fq_name())
    #end get_default_domain_delete

    def service_instance_create(self, obj):
        """Create new service-instance.
        
        :param obj: :class:`.ServiceInstance` object
        
        """
        # Ignore fields with None value in json representation
        json_param = json.dumps(obj,
            default = lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        json_body = '{"service-instance":' + json_param + '}'
        content = self._request_server(rest.OP_POST,
                       ServiceInstanceClientGen.create_uri,
                       data = json_body)

        service_instance_dict = json.loads(content)['service-instance']
        obj.uuid = service_instance_dict['uuid']
        if 'parent_uuid' in service_instance_dict:
            obj.parent_uuid = service_instance_dict['parent_uuid']

        return obj.uuid
    #end service_instance_create

    def service_instance_read(self, fq_name = None, fq_name_str = None, id = None, ifmap_id = None):
        """Return service-instance information.
        
        :param fq_name: Fully qualified name of service-instance
        :param fq_name_str: Fully qualified name string of service-instance
        :param id: UUID of service-instance
        :param ifmap_id: IFMAP id of service-instance
        :returns: :class:`.ServiceInstance` object
        
        """
        (args_ok, result) = self._read_args_to_id('service-instance', fq_name, fq_name_str, id, ifmap_id)
        if not args_ok:
            return result

        id = result
        uri = ServiceInstanceClientGen.resource_uri_base['service-instance'] + '/' + id

        content = self._request_server(rest.OP_GET, uri)

        obj_dict = json.loads(content)['service-instance']
        obj_dict['name'] = obj_dict['fq_name'][-1]
        if obj_dict.has_key('service_instance_properties'):
            prop_obj = ServiceInstanceType(**obj_dict['service_instance_properties'])
            obj_dict['service_instance_properties'] = prop_obj

        if obj_dict.has_key('id_perms'):
            prop_obj = IdPermsType(**obj_dict['id_perms'])
            obj_dict['id_perms'] = prop_obj

        # fill ref links
        # fill back ref links
        return ServiceInstance.factory(**obj_dict)
    #end service_instance_read

    def service_instance_update(self, obj):
        """Update service-instance.
        
        :param obj: :class:`.ServiceInstance` object
        
        """
        # Read in uuid from api-server if not specified in obj
        if not obj.uuid:
            obj.uuid = self.fq_name_to_id('service-instance', obj.get_fq_name())

        # Ignore fields with None value in json representation
        json_param = json.dumps(obj,
            default = lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        json_body = '{"service-instance":' + json_param + '}'

        id = obj.uuid
        uri = ServiceInstanceClientGen.resource_uri_base['service-instance'] + '/' + id
        content = self._request_server(rest.OP_PUT, uri, data = json_body)
        return content
    #end service_instance_update

    def service_instances_list(self, parent_id = None, parent_fq_name = None):
        """List all service-instances.
        
        :param parent_id: UUID of parent as optional search filter
        :param parent_fq_name: full qualified name of parent as optional search filter
        :returns: list of :class:`.ServiceInstance` objects
        
        """
        filt = None
        # TODO validate only one of id or name is given
        filt = {}
        if parent_fq_name:
            parent_fq_name_str = ':'.join(parent_fq_name)
            filt['parent_fq_name_str'] = parent_fq_name_str
        elif parent_id:
            filt['parent_id'] = parent_id
        content = self._request_server(rest.OP_GET,
                       ServiceInstanceClientGen.create_uri,
                       data = filt)
        return content
    #end service_instances_list

    def service_instance_delete(self, fq_name = None, id = None, ifmap_id = None):
        """Delete service-instance from the system.
        
        :param fq_name: Fully qualified name of service-instance
        :param id: UUID of service-instance
        :param ifmap_id: IFMAP id of service-instance
        
        """
        (args_ok, result) = self._read_args_to_id(obj_type = 'service-instance', fq_name = fq_name, id = id, ifmap_id = ifmap_id)
        if not args_ok:
            return result

        id = result
        uri = ServiceInstanceClientGen.resource_uri_base['service-instance'] + '/' + id

        content = self._request_server(rest.OP_DELETE, uri)
    #end service_instance_delete

    def get_default_service_instance_id(self):
        """Return UUID of default service-instance."""
        return self.fq_name_to_id('service-instance', ServiceInstance().get_fq_name())
    #end get_default_service_instance_delete

    def instance_ip_create(self, obj):
        """Create new instance-ip.
        
        :param obj: :class:`.InstanceIp` object
        
        """
        # Ignore fields with None value in json representation
        json_param = json.dumps(obj,
            default = lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        json_body = '{"instance-ip":' + json_param + '}'
        content = self._request_server(rest.OP_POST,
                       InstanceIpClientGen.create_uri,
                       data = json_body)

        instance_ip_dict = json.loads(content)['instance-ip']
        obj.uuid = instance_ip_dict['uuid']
        if 'parent_uuid' in instance_ip_dict:
            obj.parent_uuid = instance_ip_dict['parent_uuid']

        return obj.uuid
    #end instance_ip_create

    def instance_ip_read(self, fq_name = None, fq_name_str = None, id = None, ifmap_id = None):
        """Return instance-ip information.
        
        :param fq_name: Fully qualified name of instance-ip
        :param fq_name_str: Fully qualified name string of instance-ip
        :param id: UUID of instance-ip
        :param ifmap_id: IFMAP id of instance-ip
        :returns: :class:`.InstanceIp` object
        
        """
        (args_ok, result) = self._read_args_to_id('instance-ip', fq_name, fq_name_str, id, ifmap_id)
        if not args_ok:
            return result

        id = result
        uri = InstanceIpClientGen.resource_uri_base['instance-ip'] + '/' + id

        content = self._request_server(rest.OP_GET, uri)

        obj_dict = json.loads(content)['instance-ip']
        obj_dict['name'] = obj_dict['fq_name'][-1]

        if obj_dict.has_key('id_perms'):
            prop_obj = IdPermsType(**obj_dict['id_perms'])
            obj_dict['id_perms'] = prop_obj

        # fill ref links
        # fill back ref links
        return InstanceIp.factory(**obj_dict)
    #end instance_ip_read

    def instance_ip_update(self, obj):
        """Update instance-ip.
        
        :param obj: :class:`.InstanceIp` object
        
        """
        # Read in uuid from api-server if not specified in obj
        if not obj.uuid:
            obj.uuid = self.fq_name_to_id('instance-ip', obj.get_fq_name())

        # Ignore fields with None value in json representation
        json_param = json.dumps(obj,
            default = lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        json_body = '{"instance-ip":' + json_param + '}'

        id = obj.uuid
        uri = InstanceIpClientGen.resource_uri_base['instance-ip'] + '/' + id
        content = self._request_server(rest.OP_PUT, uri, data = json_body)
        return content
    #end instance_ip_update

    def instance_ips_list(self):
        """List all instance-ips."""
        filt = None
        # TODO validate only one of id or name is given
        filt = {}
        content = self._request_server(rest.OP_GET,
                       InstanceIpClientGen.create_uri,
                       data = filt)
        return content
    #end instance_ips_list

    def instance_ip_delete(self, fq_name = None, id = None, ifmap_id = None):
        """Delete instance-ip from the system.
        
        :param fq_name: Fully qualified name of instance-ip
        :param id: UUID of instance-ip
        :param ifmap_id: IFMAP id of instance-ip
        
        """
        (args_ok, result) = self._read_args_to_id(obj_type = 'instance-ip', fq_name = fq_name, id = id, ifmap_id = ifmap_id)
        if not args_ok:
            return result

        id = result
        uri = InstanceIpClientGen.resource_uri_base['instance-ip'] + '/' + id

        content = self._request_server(rest.OP_DELETE, uri)
    #end instance_ip_delete

    def get_default_instance_ip_id(self):
        """Return UUID of default instance-ip."""
        return self.fq_name_to_id('instance-ip', InstanceIp().get_fq_name())
    #end get_default_instance_ip_delete

    def network_policy_create(self, obj):
        """Create new network-policy.
        
        :param obj: :class:`.NetworkPolicy` object
        
        """
        # Ignore fields with None value in json representation
        json_param = json.dumps(obj,
            default = lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        json_body = '{"network-policy":' + json_param + '}'
        content = self._request_server(rest.OP_POST,
                       NetworkPolicyClientGen.create_uri,
                       data = json_body)

        network_policy_dict = json.loads(content)['network-policy']
        obj.uuid = network_policy_dict['uuid']
        if 'parent_uuid' in network_policy_dict:
            obj.parent_uuid = network_policy_dict['parent_uuid']

        return obj.uuid
    #end network_policy_create

    def network_policy_read(self, fq_name = None, fq_name_str = None, id = None, ifmap_id = None):
        """Return network-policy information.
        
        :param fq_name: Fully qualified name of network-policy
        :param fq_name_str: Fully qualified name string of network-policy
        :param id: UUID of network-policy
        :param ifmap_id: IFMAP id of network-policy
        :returns: :class:`.NetworkPolicy` object
        
        """
        (args_ok, result) = self._read_args_to_id('network-policy', fq_name, fq_name_str, id, ifmap_id)
        if not args_ok:
            return result

        id = result
        uri = NetworkPolicyClientGen.resource_uri_base['network-policy'] + '/' + id

        content = self._request_server(rest.OP_GET, uri)

        obj_dict = json.loads(content)['network-policy']
        obj_dict['name'] = obj_dict['fq_name'][-1]
        if obj_dict.has_key('network_policy_entries'):
            prop_obj = PolicyEntriesType(**obj_dict['network_policy_entries'])
            obj_dict['network_policy_entries'] = prop_obj

        if obj_dict.has_key('id_perms'):
            prop_obj = IdPermsType(**obj_dict['id_perms'])
            obj_dict['id_perms'] = prop_obj

        # fill ref links
        # fill back ref links
        if obj_dict.has_key('virtual_network_back_refs'):
            list_len = len(obj_dict['virtual_network_back_refs'])
            for idx in range(list_len):
                back_ref = obj_dict['virtual_network_back_refs'][idx]
                data_obj = VirtualNetworkPolicyType(**back_ref['attr'])
                back_ref_dict = {}
                back_ref_dict['to'] = back_ref['to']
                back_ref_dict['attr'] = data_obj
                back_ref_dict['uuid'] = back_ref['uuid']
                back_ref_dict['href'] = back_ref['href']
                obj_dict['virtual_network_back_refs'][idx] = back_ref_dict

        return NetworkPolicy.factory(**obj_dict)
    #end network_policy_read

    def network_policy_update(self, obj):
        """Update network-policy.
        
        :param obj: :class:`.NetworkPolicy` object
        
        """
        # Read in uuid from api-server if not specified in obj
        if not obj.uuid:
            obj.uuid = self.fq_name_to_id('network-policy', obj.get_fq_name())

        # Ignore fields with None value in json representation
        json_param = json.dumps(obj,
            default = lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        json_body = '{"network-policy":' + json_param + '}'

        id = obj.uuid
        uri = NetworkPolicyClientGen.resource_uri_base['network-policy'] + '/' + id
        content = self._request_server(rest.OP_PUT, uri, data = json_body)
        return content
    #end network_policy_update

    def network_policys_list(self, parent_id = None, parent_fq_name = None):
        """List all network-policys.
        
        :param parent_id: UUID of parent as optional search filter
        :param parent_fq_name: full qualified name of parent as optional search filter
        :returns: list of :class:`.NetworkPolicy` objects
        
        """
        filt = None
        # TODO validate only one of id or name is given
        filt = {}
        if parent_fq_name:
            parent_fq_name_str = ':'.join(parent_fq_name)
            filt['parent_fq_name_str'] = parent_fq_name_str
        elif parent_id:
            filt['parent_id'] = parent_id
        content = self._request_server(rest.OP_GET,
                       NetworkPolicyClientGen.create_uri,
                       data = filt)
        return content
    #end network_policys_list

    def network_policy_delete(self, fq_name = None, id = None, ifmap_id = None):
        """Delete network-policy from the system.
        
        :param fq_name: Fully qualified name of network-policy
        :param id: UUID of network-policy
        :param ifmap_id: IFMAP id of network-policy
        
        """
        (args_ok, result) = self._read_args_to_id(obj_type = 'network-policy', fq_name = fq_name, id = id, ifmap_id = ifmap_id)
        if not args_ok:
            return result

        id = result
        uri = NetworkPolicyClientGen.resource_uri_base['network-policy'] + '/' + id

        content = self._request_server(rest.OP_DELETE, uri)
    #end network_policy_delete

    def get_default_network_policy_id(self):
        """Return UUID of default network-policy."""
        return self.fq_name_to_id('network-policy', NetworkPolicy().get_fq_name())
    #end get_default_network_policy_delete

    def virtual_DNS_record_create(self, obj):
        """Create new virtual-DNS-record.
        
        :param obj: :class:`.VirtualDnsRecord` object
        
        """
        # Ignore fields with None value in json representation
        json_param = json.dumps(obj,
            default = lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        json_body = '{"virtual-DNS-record":' + json_param + '}'
        content = self._request_server(rest.OP_POST,
                       VirtualDnsRecordClientGen.create_uri,
                       data = json_body)

        virtual_DNS_record_dict = json.loads(content)['virtual-DNS-record']
        obj.uuid = virtual_DNS_record_dict['uuid']
        if 'parent_uuid' in virtual_DNS_record_dict:
            obj.parent_uuid = virtual_DNS_record_dict['parent_uuid']

        return obj.uuid
    #end virtual_DNS_record_create

    def virtual_DNS_record_read(self, fq_name = None, fq_name_str = None, id = None, ifmap_id = None):
        """Return virtual-DNS-record information.
        
        :param fq_name: Fully qualified name of virtual-DNS-record
        :param fq_name_str: Fully qualified name string of virtual-DNS-record
        :param id: UUID of virtual-DNS-record
        :param ifmap_id: IFMAP id of virtual-DNS-record
        :returns: :class:`.VirtualDnsRecord` object
        
        """
        (args_ok, result) = self._read_args_to_id('virtual-DNS-record', fq_name, fq_name_str, id, ifmap_id)
        if not args_ok:
            return result

        id = result
        uri = VirtualDnsRecordClientGen.resource_uri_base['virtual-DNS-record'] + '/' + id

        content = self._request_server(rest.OP_GET, uri)

        obj_dict = json.loads(content)['virtual-DNS-record']
        obj_dict['name'] = obj_dict['fq_name'][-1]
        if obj_dict.has_key('virtual_DNS_record_data'):
            prop_obj = VirtualDnsRecordType(**obj_dict['virtual_DNS_record_data'])
            obj_dict['virtual_DNS_record_data'] = prop_obj

        if obj_dict.has_key('id_perms'):
            prop_obj = IdPermsType(**obj_dict['id_perms'])
            obj_dict['id_perms'] = prop_obj

        # fill ref links
        # fill back ref links
        return VirtualDnsRecord.factory(**obj_dict)
    #end virtual_DNS_record_read

    def virtual_DNS_record_update(self, obj):
        """Update virtual-DNS-record.
        
        :param obj: :class:`.VirtualDnsRecord` object
        
        """
        # Read in uuid from api-server if not specified in obj
        if not obj.uuid:
            obj.uuid = self.fq_name_to_id('virtual-DNS-record', obj.get_fq_name())

        # Ignore fields with None value in json representation
        json_param = json.dumps(obj,
            default = lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        json_body = '{"virtual-DNS-record":' + json_param + '}'

        id = obj.uuid
        uri = VirtualDnsRecordClientGen.resource_uri_base['virtual-DNS-record'] + '/' + id
        content = self._request_server(rest.OP_PUT, uri, data = json_body)
        return content
    #end virtual_DNS_record_update

    def virtual_DNS_records_list(self, parent_id = None, parent_fq_name = None):
        """List all virtual-DNS-records.
        
        :param parent_id: UUID of parent as optional search filter
        :param parent_fq_name: full qualified name of parent as optional search filter
        :returns: list of :class:`.VirtualDnsRecord` objects
        
        """
        filt = None
        # TODO validate only one of id or name is given
        filt = {}
        if parent_fq_name:
            parent_fq_name_str = ':'.join(parent_fq_name)
            filt['parent_fq_name_str'] = parent_fq_name_str
        elif parent_id:
            filt['parent_id'] = parent_id
        content = self._request_server(rest.OP_GET,
                       VirtualDnsRecordClientGen.create_uri,
                       data = filt)
        return content
    #end virtual_DNS_records_list

    def virtual_DNS_record_delete(self, fq_name = None, id = None, ifmap_id = None):
        """Delete virtual-DNS-record from the system.
        
        :param fq_name: Fully qualified name of virtual-DNS-record
        :param id: UUID of virtual-DNS-record
        :param ifmap_id: IFMAP id of virtual-DNS-record
        
        """
        (args_ok, result) = self._read_args_to_id(obj_type = 'virtual-DNS-record', fq_name = fq_name, id = id, ifmap_id = ifmap_id)
        if not args_ok:
            return result

        id = result
        uri = VirtualDnsRecordClientGen.resource_uri_base['virtual-DNS-record'] + '/' + id

        content = self._request_server(rest.OP_DELETE, uri)
    #end virtual_DNS_record_delete

    def get_default_virtual_DNS_record_id(self):
        """Return UUID of default virtual-DNS-record."""
        return self.fq_name_to_id('virtual-DNS-record', VirtualDnsRecord().get_fq_name())
    #end get_default_virtual_DNS_record_delete

    def route_target_create(self, obj):
        """Create new route-target.
        
        :param obj: :class:`.RouteTarget` object
        
        """
        # Ignore fields with None value in json representation
        json_param = json.dumps(obj,
            default = lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        json_body = '{"route-target":' + json_param + '}'
        content = self._request_server(rest.OP_POST,
                       RouteTargetClientGen.create_uri,
                       data = json_body)

        route_target_dict = json.loads(content)['route-target']
        obj.uuid = route_target_dict['uuid']
        if 'parent_uuid' in route_target_dict:
            obj.parent_uuid = route_target_dict['parent_uuid']

        return obj.uuid
    #end route_target_create

    def route_target_read(self, fq_name = None, fq_name_str = None, id = None, ifmap_id = None):
        """Return route-target information.
        
        :param fq_name: Fully qualified name of route-target
        :param fq_name_str: Fully qualified name string of route-target
        :param id: UUID of route-target
        :param ifmap_id: IFMAP id of route-target
        :returns: :class:`.RouteTarget` object
        
        """
        (args_ok, result) = self._read_args_to_id('route-target', fq_name, fq_name_str, id, ifmap_id)
        if not args_ok:
            return result

        id = result
        uri = RouteTargetClientGen.resource_uri_base['route-target'] + '/' + id

        content = self._request_server(rest.OP_GET, uri)

        obj_dict = json.loads(content)['route-target']
        obj_dict['name'] = obj_dict['fq_name'][-1]
        if obj_dict.has_key('id_perms'):
            prop_obj = IdPermsType(**obj_dict['id_perms'])
            obj_dict['id_perms'] = prop_obj

        # fill ref links
        # fill back ref links
        if obj_dict.has_key('routing_instance_back_refs'):
            list_len = len(obj_dict['routing_instance_back_refs'])
            for idx in range(list_len):
                back_ref = obj_dict['routing_instance_back_refs'][idx]
                data_obj = InstanceTargetType(**back_ref['attr'])
                back_ref_dict = {}
                back_ref_dict['to'] = back_ref['to']
                back_ref_dict['attr'] = data_obj
                back_ref_dict['uuid'] = back_ref['uuid']
                back_ref_dict['href'] = back_ref['href']
                obj_dict['routing_instance_back_refs'][idx] = back_ref_dict

        return RouteTarget.factory(**obj_dict)
    #end route_target_read

    def route_target_update(self, obj):
        """Update route-target.
        
        :param obj: :class:`.RouteTarget` object
        
        """
        # Read in uuid from api-server if not specified in obj
        if not obj.uuid:
            obj.uuid = self.fq_name_to_id('route-target', obj.get_fq_name())

        # Ignore fields with None value in json representation
        json_param = json.dumps(obj,
            default = lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        json_body = '{"route-target":' + json_param + '}'

        id = obj.uuid
        uri = RouteTargetClientGen.resource_uri_base['route-target'] + '/' + id
        content = self._request_server(rest.OP_PUT, uri, data = json_body)
        return content
    #end route_target_update

    def route_targets_list(self):
        """List all route-targets."""
        filt = None
        # TODO validate only one of id or name is given
        filt = {}
        content = self._request_server(rest.OP_GET,
                       RouteTargetClientGen.create_uri,
                       data = filt)
        return content
    #end route_targets_list

    def route_target_delete(self, fq_name = None, id = None, ifmap_id = None):
        """Delete route-target from the system.
        
        :param fq_name: Fully qualified name of route-target
        :param id: UUID of route-target
        :param ifmap_id: IFMAP id of route-target
        
        """
        (args_ok, result) = self._read_args_to_id(obj_type = 'route-target', fq_name = fq_name, id = id, ifmap_id = ifmap_id)
        if not args_ok:
            return result

        id = result
        uri = RouteTargetClientGen.resource_uri_base['route-target'] + '/' + id

        content = self._request_server(rest.OP_DELETE, uri)
    #end route_target_delete

    def get_default_route_target_id(self):
        """Return UUID of default route-target."""
        return self.fq_name_to_id('route-target', RouteTarget().get_fq_name())
    #end get_default_route_target_delete

    def floating_ip_create(self, obj):
        """Create new floating-ip.
        
        :param obj: :class:`.FloatingIp` object
        
        """
        # Ignore fields with None value in json representation
        json_param = json.dumps(obj,
            default = lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        json_body = '{"floating-ip":' + json_param + '}'
        content = self._request_server(rest.OP_POST,
                       FloatingIpClientGen.create_uri,
                       data = json_body)

        floating_ip_dict = json.loads(content)['floating-ip']
        obj.uuid = floating_ip_dict['uuid']
        if 'parent_uuid' in floating_ip_dict:
            obj.parent_uuid = floating_ip_dict['parent_uuid']

        return obj.uuid
    #end floating_ip_create

    def floating_ip_read(self, fq_name = None, fq_name_str = None, id = None, ifmap_id = None):
        """Return floating-ip information.
        
        :param fq_name: Fully qualified name of floating-ip
        :param fq_name_str: Fully qualified name string of floating-ip
        :param id: UUID of floating-ip
        :param ifmap_id: IFMAP id of floating-ip
        :returns: :class:`.FloatingIp` object
        
        """
        (args_ok, result) = self._read_args_to_id('floating-ip', fq_name, fq_name_str, id, ifmap_id)
        if not args_ok:
            return result

        id = result
        uri = FloatingIpClientGen.resource_uri_base['floating-ip'] + '/' + id

        content = self._request_server(rest.OP_GET, uri)

        obj_dict = json.loads(content)['floating-ip']
        obj_dict['name'] = obj_dict['fq_name'][-1]


        if obj_dict.has_key('id_perms'):
            prop_obj = IdPermsType(**obj_dict['id_perms'])
            obj_dict['id_perms'] = prop_obj

        # fill ref links
        # fill back ref links
        return FloatingIp.factory(**obj_dict)
    #end floating_ip_read

    def floating_ip_update(self, obj):
        """Update floating-ip.
        
        :param obj: :class:`.FloatingIp` object
        
        """
        # Read in uuid from api-server if not specified in obj
        if not obj.uuid:
            obj.uuid = self.fq_name_to_id('floating-ip', obj.get_fq_name())

        # Ignore fields with None value in json representation
        json_param = json.dumps(obj,
            default = lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        json_body = '{"floating-ip":' + json_param + '}'

        id = obj.uuid
        uri = FloatingIpClientGen.resource_uri_base['floating-ip'] + '/' + id
        content = self._request_server(rest.OP_PUT, uri, data = json_body)
        return content
    #end floating_ip_update

    def floating_ips_list(self, parent_id = None, parent_fq_name = None):
        """List all floating-ips.
        
        :param parent_id: UUID of parent as optional search filter
        :param parent_fq_name: full qualified name of parent as optional search filter
        :returns: list of :class:`.FloatingIp` objects
        
        """
        filt = None
        # TODO validate only one of id or name is given
        filt = {}
        if parent_fq_name:
            parent_fq_name_str = ':'.join(parent_fq_name)
            filt['parent_fq_name_str'] = parent_fq_name_str
        elif parent_id:
            filt['parent_id'] = parent_id
        content = self._request_server(rest.OP_GET,
                       FloatingIpClientGen.create_uri,
                       data = filt)
        return content
    #end floating_ips_list

    def floating_ip_delete(self, fq_name = None, id = None, ifmap_id = None):
        """Delete floating-ip from the system.
        
        :param fq_name: Fully qualified name of floating-ip
        :param id: UUID of floating-ip
        :param ifmap_id: IFMAP id of floating-ip
        
        """
        (args_ok, result) = self._read_args_to_id(obj_type = 'floating-ip', fq_name = fq_name, id = id, ifmap_id = ifmap_id)
        if not args_ok:
            return result

        id = result
        uri = FloatingIpClientGen.resource_uri_base['floating-ip'] + '/' + id

        content = self._request_server(rest.OP_DELETE, uri)
    #end floating_ip_delete

    def get_default_floating_ip_id(self):
        """Return UUID of default floating-ip."""
        return self.fq_name_to_id('floating-ip', FloatingIp().get_fq_name())
    #end get_default_floating_ip_delete

    def floating_ip_pool_create(self, obj):
        """Create new floating-ip-pool.
        
        :param obj: :class:`.FloatingIpPool` object
        
        """
        # Ignore fields with None value in json representation
        json_param = json.dumps(obj,
            default = lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        json_body = '{"floating-ip-pool":' + json_param + '}'
        content = self._request_server(rest.OP_POST,
                       FloatingIpPoolClientGen.create_uri,
                       data = json_body)

        floating_ip_pool_dict = json.loads(content)['floating-ip-pool']
        obj.uuid = floating_ip_pool_dict['uuid']
        if 'parent_uuid' in floating_ip_pool_dict:
            obj.parent_uuid = floating_ip_pool_dict['parent_uuid']

        return obj.uuid
    #end floating_ip_pool_create

    def floating_ip_pool_read(self, fq_name = None, fq_name_str = None, id = None, ifmap_id = None):
        """Return floating-ip-pool information.
        
        :param fq_name: Fully qualified name of floating-ip-pool
        :param fq_name_str: Fully qualified name string of floating-ip-pool
        :param id: UUID of floating-ip-pool
        :param ifmap_id: IFMAP id of floating-ip-pool
        :returns: :class:`.FloatingIpPool` object
        
        """
        (args_ok, result) = self._read_args_to_id('floating-ip-pool', fq_name, fq_name_str, id, ifmap_id)
        if not args_ok:
            return result

        id = result
        uri = FloatingIpPoolClientGen.resource_uri_base['floating-ip-pool'] + '/' + id

        content = self._request_server(rest.OP_GET, uri)

        obj_dict = json.loads(content)['floating-ip-pool']
        obj_dict['name'] = obj_dict['fq_name'][-1]
        if obj_dict.has_key('floating_ip_pool_prefixes'):
            prop_obj = FloatingIpPoolType(**obj_dict['floating_ip_pool_prefixes'])
            obj_dict['floating_ip_pool_prefixes'] = prop_obj

        if obj_dict.has_key('id_perms'):
            prop_obj = IdPermsType(**obj_dict['id_perms'])
            obj_dict['id_perms'] = prop_obj

        # fill ref links
        # fill back ref links
        return FloatingIpPool.factory(**obj_dict)
    #end floating_ip_pool_read

    def floating_ip_pool_update(self, obj):
        """Update floating-ip-pool.
        
        :param obj: :class:`.FloatingIpPool` object
        
        """
        # Read in uuid from api-server if not specified in obj
        if not obj.uuid:
            obj.uuid = self.fq_name_to_id('floating-ip-pool', obj.get_fq_name())

        # Ignore fields with None value in json representation
        json_param = json.dumps(obj,
            default = lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        json_body = '{"floating-ip-pool":' + json_param + '}'

        id = obj.uuid
        uri = FloatingIpPoolClientGen.resource_uri_base['floating-ip-pool'] + '/' + id
        content = self._request_server(rest.OP_PUT, uri, data = json_body)
        return content
    #end floating_ip_pool_update

    def floating_ip_pools_list(self, parent_id = None, parent_fq_name = None):
        """List all floating-ip-pools.
        
        :param parent_id: UUID of parent as optional search filter
        :param parent_fq_name: full qualified name of parent as optional search filter
        :returns: list of :class:`.FloatingIpPool` objects
        
        """
        filt = None
        # TODO validate only one of id or name is given
        filt = {}
        if parent_fq_name:
            parent_fq_name_str = ':'.join(parent_fq_name)
            filt['parent_fq_name_str'] = parent_fq_name_str
        elif parent_id:
            filt['parent_id'] = parent_id
        content = self._request_server(rest.OP_GET,
                       FloatingIpPoolClientGen.create_uri,
                       data = filt)
        return content
    #end floating_ip_pools_list

    def floating_ip_pool_delete(self, fq_name = None, id = None, ifmap_id = None):
        """Delete floating-ip-pool from the system.
        
        :param fq_name: Fully qualified name of floating-ip-pool
        :param id: UUID of floating-ip-pool
        :param ifmap_id: IFMAP id of floating-ip-pool
        
        """
        (args_ok, result) = self._read_args_to_id(obj_type = 'floating-ip-pool', fq_name = fq_name, id = id, ifmap_id = ifmap_id)
        if not args_ok:
            return result

        id = result
        uri = FloatingIpPoolClientGen.resource_uri_base['floating-ip-pool'] + '/' + id

        content = self._request_server(rest.OP_DELETE, uri)
    #end floating_ip_pool_delete

    def get_default_floating_ip_pool_id(self):
        """Return UUID of default floating-ip-pool."""
        return self.fq_name_to_id('floating-ip-pool', FloatingIpPool().get_fq_name())
    #end get_default_floating_ip_pool_delete

    def physical_router_create(self, obj):
        """Create new physical-router.
        
        :param obj: :class:`.PhysicalRouter` object
        
        """
        # Ignore fields with None value in json representation
        json_param = json.dumps(obj,
            default = lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        json_body = '{"physical-router":' + json_param + '}'
        content = self._request_server(rest.OP_POST,
                       PhysicalRouterClientGen.create_uri,
                       data = json_body)

        physical_router_dict = json.loads(content)['physical-router']
        obj.uuid = physical_router_dict['uuid']
        if 'parent_uuid' in physical_router_dict:
            obj.parent_uuid = physical_router_dict['parent_uuid']

        return obj.uuid
    #end physical_router_create

    def physical_router_read(self, fq_name = None, fq_name_str = None, id = None, ifmap_id = None):
        """Return physical-router information.
        
        :param fq_name: Fully qualified name of physical-router
        :param fq_name_str: Fully qualified name string of physical-router
        :param id: UUID of physical-router
        :param ifmap_id: IFMAP id of physical-router
        :returns: :class:`.PhysicalRouter` object
        
        """
        (args_ok, result) = self._read_args_to_id('physical-router', fq_name, fq_name_str, id, ifmap_id)
        if not args_ok:
            return result

        id = result
        uri = PhysicalRouterClientGen.resource_uri_base['physical-router'] + '/' + id

        content = self._request_server(rest.OP_GET, uri)

        obj_dict = json.loads(content)['physical-router']
        obj_dict['name'] = obj_dict['fq_name'][-1]
        if obj_dict.has_key('id_perms'):
            prop_obj = IdPermsType(**obj_dict['id_perms'])
            obj_dict['id_perms'] = prop_obj

        # fill ref links
        # fill back ref links
        return PhysicalRouter.factory(**obj_dict)
    #end physical_router_read

    def physical_router_update(self, obj):
        """Update physical-router.
        
        :param obj: :class:`.PhysicalRouter` object
        
        """
        # Read in uuid from api-server if not specified in obj
        if not obj.uuid:
            obj.uuid = self.fq_name_to_id('physical-router', obj.get_fq_name())

        # Ignore fields with None value in json representation
        json_param = json.dumps(obj,
            default = lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        json_body = '{"physical-router":' + json_param + '}'

        id = obj.uuid
        uri = PhysicalRouterClientGen.resource_uri_base['physical-router'] + '/' + id
        content = self._request_server(rest.OP_PUT, uri, data = json_body)
        return content
    #end physical_router_update

    def physical_routers_list(self, parent_id = None, parent_fq_name = None):
        """List all physical-routers.
        
        :param parent_id: UUID of parent as optional search filter
        :param parent_fq_name: full qualified name of parent as optional search filter
        :returns: list of :class:`.PhysicalRouter` objects
        
        """
        filt = None
        # TODO validate only one of id or name is given
        filt = {}
        if parent_fq_name:
            parent_fq_name_str = ':'.join(parent_fq_name)
            filt['parent_fq_name_str'] = parent_fq_name_str
        elif parent_id:
            filt['parent_id'] = parent_id
        content = self._request_server(rest.OP_GET,
                       PhysicalRouterClientGen.create_uri,
                       data = filt)
        return content
    #end physical_routers_list

    def physical_router_delete(self, fq_name = None, id = None, ifmap_id = None):
        """Delete physical-router from the system.
        
        :param fq_name: Fully qualified name of physical-router
        :param id: UUID of physical-router
        :param ifmap_id: IFMAP id of physical-router
        
        """
        (args_ok, result) = self._read_args_to_id(obj_type = 'physical-router', fq_name = fq_name, id = id, ifmap_id = ifmap_id)
        if not args_ok:
            return result

        id = result
        uri = PhysicalRouterClientGen.resource_uri_base['physical-router'] + '/' + id

        content = self._request_server(rest.OP_DELETE, uri)
    #end physical_router_delete

    def get_default_physical_router_id(self):
        """Return UUID of default physical-router."""
        return self.fq_name_to_id('physical-router', PhysicalRouter().get_fq_name())
    #end get_default_physical_router_delete

    def bgp_router_create(self, obj):
        """Create new bgp-router.
        
        :param obj: :class:`.BgpRouter` object
        
        """
        # Ignore fields with None value in json representation
        json_param = json.dumps(obj,
            default = lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        json_body = '{"bgp-router":' + json_param + '}'
        content = self._request_server(rest.OP_POST,
                       BgpRouterClientGen.create_uri,
                       data = json_body)

        bgp_router_dict = json.loads(content)['bgp-router']
        obj.uuid = bgp_router_dict['uuid']
        if 'parent_uuid' in bgp_router_dict:
            obj.parent_uuid = bgp_router_dict['parent_uuid']

        return obj.uuid
    #end bgp_router_create

    def bgp_router_read(self, fq_name = None, fq_name_str = None, id = None, ifmap_id = None):
        """Return bgp-router information.
        
        :param fq_name: Fully qualified name of bgp-router
        :param fq_name_str: Fully qualified name string of bgp-router
        :param id: UUID of bgp-router
        :param ifmap_id: IFMAP id of bgp-router
        :returns: :class:`.BgpRouter` object
        
        """
        (args_ok, result) = self._read_args_to_id('bgp-router', fq_name, fq_name_str, id, ifmap_id)
        if not args_ok:
            return result

        id = result
        uri = BgpRouterClientGen.resource_uri_base['bgp-router'] + '/' + id

        content = self._request_server(rest.OP_GET, uri)

        obj_dict = json.loads(content)['bgp-router']
        obj_dict['name'] = obj_dict['fq_name'][-1]
        if obj_dict.has_key('bgp_router_parameters'):
            prop_obj = BgpRouterParams(**obj_dict['bgp_router_parameters'])
            obj_dict['bgp_router_parameters'] = prop_obj

        if obj_dict.has_key('id_perms'):
            prop_obj = IdPermsType(**obj_dict['id_perms'])
            obj_dict['id_perms'] = prop_obj

        # fill ref links
        if obj_dict.has_key('bgp_router_refs'):
            list_len = len(obj_dict['bgp_router_refs'])
            for idx in range(list_len):
                ref = obj_dict['bgp_router_refs'][idx]
                data_obj = BgpPeeringAttributes(**ref['attr'])
                ref_dict = {}
                ref_dict['to'] = ref['to']
                ref_dict['attr'] = data_obj
                ref_dict['uuid'] = ref['uuid']
                ref_dict['href'] = ref['href']
                obj_dict['bgp_router_refs'][idx] = ref_dict

        # fill back ref links
        if obj_dict.has_key('bgp_router_back_refs'):
            list_len = len(obj_dict['bgp_router_back_refs'])
            for idx in range(list_len):
                back_ref = obj_dict['bgp_router_back_refs'][idx]
                data_obj = BgpPeeringAttributes(**back_ref['attr'])
                back_ref_dict = {}
                back_ref_dict['to'] = back_ref['to']
                back_ref_dict['attr'] = data_obj
                back_ref_dict['uuid'] = back_ref['uuid']
                back_ref_dict['href'] = back_ref['href']
                obj_dict['bgp_router_back_refs'][idx] = back_ref_dict

        return BgpRouter.factory(**obj_dict)
    #end bgp_router_read

    def bgp_router_update(self, obj):
        """Update bgp-router.
        
        :param obj: :class:`.BgpRouter` object
        
        """
        # Read in uuid from api-server if not specified in obj
        if not obj.uuid:
            obj.uuid = self.fq_name_to_id('bgp-router', obj.get_fq_name())

        # Ignore fields with None value in json representation
        json_param = json.dumps(obj,
            default = lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        json_body = '{"bgp-router":' + json_param + '}'

        id = obj.uuid
        uri = BgpRouterClientGen.resource_uri_base['bgp-router'] + '/' + id
        content = self._request_server(rest.OP_PUT, uri, data = json_body)
        return content
    #end bgp_router_update

    def bgp_routers_list(self, parent_id = None, parent_fq_name = None):
        """List all bgp-routers.
        
        :param parent_id: UUID of parent as optional search filter
        :param parent_fq_name: full qualified name of parent as optional search filter
        :returns: list of :class:`.BgpRouter` objects
        
        """
        filt = None
        # TODO validate only one of id or name is given
        filt = {}
        if parent_fq_name:
            parent_fq_name_str = ':'.join(parent_fq_name)
            filt['parent_fq_name_str'] = parent_fq_name_str
        elif parent_id:
            filt['parent_id'] = parent_id
        content = self._request_server(rest.OP_GET,
                       BgpRouterClientGen.create_uri,
                       data = filt)
        return content
    #end bgp_routers_list

    def bgp_router_delete(self, fq_name = None, id = None, ifmap_id = None):
        """Delete bgp-router from the system.
        
        :param fq_name: Fully qualified name of bgp-router
        :param id: UUID of bgp-router
        :param ifmap_id: IFMAP id of bgp-router
        
        """
        (args_ok, result) = self._read_args_to_id(obj_type = 'bgp-router', fq_name = fq_name, id = id, ifmap_id = ifmap_id)
        if not args_ok:
            return result

        id = result
        uri = BgpRouterClientGen.resource_uri_base['bgp-router'] + '/' + id

        content = self._request_server(rest.OP_DELETE, uri)
    #end bgp_router_delete

    def get_default_bgp_router_id(self):
        """Return UUID of default bgp-router."""
        return self.fq_name_to_id('bgp-router', BgpRouter().get_fq_name())
    #end get_default_bgp_router_delete

    def virtual_router_create(self, obj):
        """Create new virtual-router.
        
        :param obj: :class:`.VirtualRouter` object
        
        """
        # Ignore fields with None value in json representation
        json_param = json.dumps(obj,
            default = lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        json_body = '{"virtual-router":' + json_param + '}'
        content = self._request_server(rest.OP_POST,
                       VirtualRouterClientGen.create_uri,
                       data = json_body)

        virtual_router_dict = json.loads(content)['virtual-router']
        obj.uuid = virtual_router_dict['uuid']
        if 'parent_uuid' in virtual_router_dict:
            obj.parent_uuid = virtual_router_dict['parent_uuid']

        return obj.uuid
    #end virtual_router_create

    def virtual_router_read(self, fq_name = None, fq_name_str = None, id = None, ifmap_id = None):
        """Return virtual-router information.
        
        :param fq_name: Fully qualified name of virtual-router
        :param fq_name_str: Fully qualified name string of virtual-router
        :param id: UUID of virtual-router
        :param ifmap_id: IFMAP id of virtual-router
        :returns: :class:`.VirtualRouter` object
        
        """
        (args_ok, result) = self._read_args_to_id('virtual-router', fq_name, fq_name_str, id, ifmap_id)
        if not args_ok:
            return result

        id = result
        uri = VirtualRouterClientGen.resource_uri_base['virtual-router'] + '/' + id

        content = self._request_server(rest.OP_GET, uri)

        obj_dict = json.loads(content)['virtual-router']
        obj_dict['name'] = obj_dict['fq_name'][-1]

        if obj_dict.has_key('id_perms'):
            prop_obj = IdPermsType(**obj_dict['id_perms'])
            obj_dict['id_perms'] = prop_obj

        # fill ref links
        # fill back ref links
        return VirtualRouter.factory(**obj_dict)
    #end virtual_router_read

    def virtual_router_update(self, obj):
        """Update virtual-router.
        
        :param obj: :class:`.VirtualRouter` object
        
        """
        # Read in uuid from api-server if not specified in obj
        if not obj.uuid:
            obj.uuid = self.fq_name_to_id('virtual-router', obj.get_fq_name())

        # Ignore fields with None value in json representation
        json_param = json.dumps(obj,
            default = lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        json_body = '{"virtual-router":' + json_param + '}'

        id = obj.uuid
        uri = VirtualRouterClientGen.resource_uri_base['virtual-router'] + '/' + id
        content = self._request_server(rest.OP_PUT, uri, data = json_body)
        return content
    #end virtual_router_update

    def virtual_routers_list(self, parent_id = None, parent_fq_name = None):
        """List all virtual-routers.
        
        :param parent_id: UUID of parent as optional search filter
        :param parent_fq_name: full qualified name of parent as optional search filter
        :returns: list of :class:`.VirtualRouter` objects
        
        """
        filt = None
        # TODO validate only one of id or name is given
        filt = {}
        if parent_fq_name:
            parent_fq_name_str = ':'.join(parent_fq_name)
            filt['parent_fq_name_str'] = parent_fq_name_str
        elif parent_id:
            filt['parent_id'] = parent_id
        content = self._request_server(rest.OP_GET,
                       VirtualRouterClientGen.create_uri,
                       data = filt)
        return content
    #end virtual_routers_list

    def virtual_router_delete(self, fq_name = None, id = None, ifmap_id = None):
        """Delete virtual-router from the system.
        
        :param fq_name: Fully qualified name of virtual-router
        :param id: UUID of virtual-router
        :param ifmap_id: IFMAP id of virtual-router
        
        """
        (args_ok, result) = self._read_args_to_id(obj_type = 'virtual-router', fq_name = fq_name, id = id, ifmap_id = ifmap_id)
        if not args_ok:
            return result

        id = result
        uri = VirtualRouterClientGen.resource_uri_base['virtual-router'] + '/' + id

        content = self._request_server(rest.OP_DELETE, uri)
    #end virtual_router_delete

    def get_default_virtual_router_id(self):
        """Return UUID of default virtual-router."""
        return self.fq_name_to_id('virtual-router', VirtualRouter().get_fq_name())
    #end get_default_virtual_router_delete

    def config_root_create(self, obj):
        """Create new config-root.
        
        :param obj: :class:`.ConfigRoot` object
        
        """
        # Ignore fields with None value in json representation
        json_param = json.dumps(obj,
            default = lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        json_body = '{"config-root":' + json_param + '}'
        content = self._request_server(rest.OP_POST,
                       ConfigRootClientGen.create_uri,
                       data = json_body)

        config_root_dict = json.loads(content)['config-root']
        obj.uuid = config_root_dict['uuid']
        if 'parent_uuid' in config_root_dict:
            obj.parent_uuid = config_root_dict['parent_uuid']

        return obj.uuid
    #end config_root_create

    def config_root_read(self, fq_name = None, fq_name_str = None, id = None, ifmap_id = None):
        """Return config-root information.
        
        :param fq_name: Fully qualified name of config-root
        :param fq_name_str: Fully qualified name string of config-root
        :param id: UUID of config-root
        :param ifmap_id: IFMAP id of config-root
        :returns: :class:`.ConfigRoot` object
        
        """
        (args_ok, result) = self._read_args_to_id('config-root', fq_name, fq_name_str, id, ifmap_id)
        if not args_ok:
            return result

        id = result
        uri = ConfigRootClientGen.resource_uri_base['config-root'] + '/' + id

        content = self._request_server(rest.OP_GET, uri)

        obj_dict = json.loads(content)['config-root']
        obj_dict['name'] = obj_dict['fq_name'][-1]
        if obj_dict.has_key('id_perms'):
            prop_obj = IdPermsType(**obj_dict['id_perms'])
            obj_dict['id_perms'] = prop_obj

        # fill ref links
        # fill back ref links
        return ConfigRoot.factory(**obj_dict)
    #end config_root_read

    def config_root_update(self, obj):
        """Update config-root.
        
        :param obj: :class:`.ConfigRoot` object
        
        """
        # Read in uuid from api-server if not specified in obj
        if not obj.uuid:
            obj.uuid = self.fq_name_to_id('config-root', obj.get_fq_name())

        # Ignore fields with None value in json representation
        json_param = json.dumps(obj,
            default = lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        json_body = '{"config-root":' + json_param + '}'

        id = obj.uuid
        uri = ConfigRootClientGen.resource_uri_base['config-root'] + '/' + id
        content = self._request_server(rest.OP_PUT, uri, data = json_body)
        return content
    #end config_root_update

    def config_roots_list(self):
        """List all config-roots."""
        filt = None
        # TODO validate only one of id or name is given
        filt = {}
        content = self._request_server(rest.OP_GET,
                       ConfigRootClientGen.create_uri,
                       data = filt)
        return content
    #end config_roots_list

    def config_root_delete(self, fq_name = None, id = None, ifmap_id = None):
        """Delete config-root from the system.
        
        :param fq_name: Fully qualified name of config-root
        :param id: UUID of config-root
        :param ifmap_id: IFMAP id of config-root
        
        """
        (args_ok, result) = self._read_args_to_id(obj_type = 'config-root', fq_name = fq_name, id = id, ifmap_id = ifmap_id)
        if not args_ok:
            return result

        id = result
        uri = ConfigRootClientGen.resource_uri_base['config-root'] + '/' + id

        content = self._request_server(rest.OP_DELETE, uri)
    #end config_root_delete

    def get_default_config_root_id(self):
        """Return UUID of default config-root."""
        return self.fq_name_to_id('config-root', ConfigRoot().get_fq_name())
    #end get_default_config_root_delete

    def global_system_config_create(self, obj):
        """Create new global-system-config.
        
        :param obj: :class:`.GlobalSystemConfig` object
        
        """
        # Ignore fields with None value in json representation
        json_param = json.dumps(obj,
            default = lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        json_body = '{"global-system-config":' + json_param + '}'
        content = self._request_server(rest.OP_POST,
                       GlobalSystemConfigClientGen.create_uri,
                       data = json_body)

        global_system_config_dict = json.loads(content)['global-system-config']
        obj.uuid = global_system_config_dict['uuid']
        if 'parent_uuid' in global_system_config_dict:
            obj.parent_uuid = global_system_config_dict['parent_uuid']

        return obj.uuid
    #end global_system_config_create

    def global_system_config_read(self, fq_name = None, fq_name_str = None, id = None, ifmap_id = None):
        """Return global-system-config information.
        
        :param fq_name: Fully qualified name of global-system-config
        :param fq_name_str: Fully qualified name string of global-system-config
        :param id: UUID of global-system-config
        :param ifmap_id: IFMAP id of global-system-config
        :returns: :class:`.GlobalSystemConfig` object
        
        """
        (args_ok, result) = self._read_args_to_id('global-system-config', fq_name, fq_name_str, id, ifmap_id)
        if not args_ok:
            return result

        id = result
        uri = GlobalSystemConfigClientGen.resource_uri_base['global-system-config'] + '/' + id

        content = self._request_server(rest.OP_GET, uri)

        obj_dict = json.loads(content)['global-system-config']
        obj_dict['name'] = obj_dict['fq_name'][-1]

        if obj_dict.has_key('id_perms'):
            prop_obj = IdPermsType(**obj_dict['id_perms'])
            obj_dict['id_perms'] = prop_obj

        # fill ref links
        # fill back ref links
        return GlobalSystemConfig.factory(**obj_dict)
    #end global_system_config_read

    def global_system_config_update(self, obj):
        """Update global-system-config.
        
        :param obj: :class:`.GlobalSystemConfig` object
        
        """
        # Read in uuid from api-server if not specified in obj
        if not obj.uuid:
            obj.uuid = self.fq_name_to_id('global-system-config', obj.get_fq_name())

        # Ignore fields with None value in json representation
        json_param = json.dumps(obj,
            default = lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        json_body = '{"global-system-config":' + json_param + '}'

        id = obj.uuid
        uri = GlobalSystemConfigClientGen.resource_uri_base['global-system-config'] + '/' + id
        content = self._request_server(rest.OP_PUT, uri, data = json_body)
        return content
    #end global_system_config_update

    def global_system_configs_list(self, parent_id = None, parent_fq_name = None):
        """List all global-system-configs.
        
        :param parent_id: UUID of parent as optional search filter
        :param parent_fq_name: full qualified name of parent as optional search filter
        :returns: list of :class:`.GlobalSystemConfig` objects
        
        """
        filt = None
        # TODO validate only one of id or name is given
        filt = {}
        if parent_fq_name:
            parent_fq_name_str = ':'.join(parent_fq_name)
            filt['parent_fq_name_str'] = parent_fq_name_str
        elif parent_id:
            filt['parent_id'] = parent_id
        content = self._request_server(rest.OP_GET,
                       GlobalSystemConfigClientGen.create_uri,
                       data = filt)
        return content
    #end global_system_configs_list

    def global_system_config_delete(self, fq_name = None, id = None, ifmap_id = None):
        """Delete global-system-config from the system.
        
        :param fq_name: Fully qualified name of global-system-config
        :param id: UUID of global-system-config
        :param ifmap_id: IFMAP id of global-system-config
        
        """
        (args_ok, result) = self._read_args_to_id(obj_type = 'global-system-config', fq_name = fq_name, id = id, ifmap_id = ifmap_id)
        if not args_ok:
            return result

        id = result
        uri = GlobalSystemConfigClientGen.resource_uri_base['global-system-config'] + '/' + id

        content = self._request_server(rest.OP_DELETE, uri)
    #end global_system_config_delete

    def get_default_global_system_config_id(self):
        """Return UUID of default global-system-config."""
        return self.fq_name_to_id('global-system-config', GlobalSystemConfig().get_fq_name())
    #end get_default_global_system_config_delete

    def namespace_create(self, obj):
        """Create new namespace.
        
        :param obj: :class:`.Namespace` object
        
        """
        # Ignore fields with None value in json representation
        json_param = json.dumps(obj,
            default = lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        json_body = '{"namespace":' + json_param + '}'
        content = self._request_server(rest.OP_POST,
                       NamespaceClientGen.create_uri,
                       data = json_body)

        namespace_dict = json.loads(content)['namespace']
        obj.uuid = namespace_dict['uuid']
        if 'parent_uuid' in namespace_dict:
            obj.parent_uuid = namespace_dict['parent_uuid']

        return obj.uuid
    #end namespace_create

    def namespace_read(self, fq_name = None, fq_name_str = None, id = None, ifmap_id = None):
        """Return namespace information.
        
        :param fq_name: Fully qualified name of namespace
        :param fq_name_str: Fully qualified name string of namespace
        :param id: UUID of namespace
        :param ifmap_id: IFMAP id of namespace
        :returns: :class:`.Namespace` object
        
        """
        (args_ok, result) = self._read_args_to_id('namespace', fq_name, fq_name_str, id, ifmap_id)
        if not args_ok:
            return result

        id = result
        uri = NamespaceClientGen.resource_uri_base['namespace'] + '/' + id

        content = self._request_server(rest.OP_GET, uri)

        obj_dict = json.loads(content)['namespace']
        obj_dict['name'] = obj_dict['fq_name'][-1]
        if obj_dict.has_key('namespace_cidr'):
            prop_obj = SubnetType(**obj_dict['namespace_cidr'])
            obj_dict['namespace_cidr'] = prop_obj

        if obj_dict.has_key('id_perms'):
            prop_obj = IdPermsType(**obj_dict['id_perms'])
            obj_dict['id_perms'] = prop_obj

        # fill ref links
        # fill back ref links
        if obj_dict.has_key('project_back_refs'):
            list_len = len(obj_dict['project_back_refs'])
            for idx in range(list_len):
                back_ref = obj_dict['project_back_refs'][idx]
                data_obj = SubnetType(**back_ref['attr'])
                back_ref_dict = {}
                back_ref_dict['to'] = back_ref['to']
                back_ref_dict['attr'] = data_obj
                back_ref_dict['uuid'] = back_ref['uuid']
                back_ref_dict['href'] = back_ref['href']
                obj_dict['project_back_refs'][idx] = back_ref_dict

        return Namespace.factory(**obj_dict)
    #end namespace_read

    def namespace_update(self, obj):
        """Update namespace.
        
        :param obj: :class:`.Namespace` object
        
        """
        # Read in uuid from api-server if not specified in obj
        if not obj.uuid:
            obj.uuid = self.fq_name_to_id('namespace', obj.get_fq_name())

        # Ignore fields with None value in json representation
        json_param = json.dumps(obj,
            default = lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        json_body = '{"namespace":' + json_param + '}'

        id = obj.uuid
        uri = NamespaceClientGen.resource_uri_base['namespace'] + '/' + id
        content = self._request_server(rest.OP_PUT, uri, data = json_body)
        return content
    #end namespace_update

    def namespaces_list(self, parent_id = None, parent_fq_name = None):
        """List all namespaces.
        
        :param parent_id: UUID of parent as optional search filter
        :param parent_fq_name: full qualified name of parent as optional search filter
        :returns: list of :class:`.Namespace` objects
        
        """
        filt = None
        # TODO validate only one of id or name is given
        filt = {}
        if parent_fq_name:
            parent_fq_name_str = ':'.join(parent_fq_name)
            filt['parent_fq_name_str'] = parent_fq_name_str
        elif parent_id:
            filt['parent_id'] = parent_id
        content = self._request_server(rest.OP_GET,
                       NamespaceClientGen.create_uri,
                       data = filt)
        return content
    #end namespaces_list

    def namespace_delete(self, fq_name = None, id = None, ifmap_id = None):
        """Delete namespace from the system.
        
        :param fq_name: Fully qualified name of namespace
        :param id: UUID of namespace
        :param ifmap_id: IFMAP id of namespace
        
        """
        (args_ok, result) = self._read_args_to_id(obj_type = 'namespace', fq_name = fq_name, id = id, ifmap_id = ifmap_id)
        if not args_ok:
            return result

        id = result
        uri = NamespaceClientGen.resource_uri_base['namespace'] + '/' + id

        content = self._request_server(rest.OP_DELETE, uri)
    #end namespace_delete

    def get_default_namespace_id(self):
        """Return UUID of default namespace."""
        return self.fq_name_to_id('namespace', Namespace().get_fq_name())
    #end get_default_namespace_delete

    def physical_interface_create(self, obj):
        """Create new physical-interface.
        
        :param obj: :class:`.PhysicalInterface` object
        
        """
        # Ignore fields with None value in json representation
        json_param = json.dumps(obj,
            default = lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        json_body = '{"physical-interface":' + json_param + '}'
        content = self._request_server(rest.OP_POST,
                       PhysicalInterfaceClientGen.create_uri,
                       data = json_body)

        physical_interface_dict = json.loads(content)['physical-interface']
        obj.uuid = physical_interface_dict['uuid']
        if 'parent_uuid' in physical_interface_dict:
            obj.parent_uuid = physical_interface_dict['parent_uuid']

        return obj.uuid
    #end physical_interface_create

    def physical_interface_read(self, fq_name = None, fq_name_str = None, id = None, ifmap_id = None):
        """Return physical-interface information.
        
        :param fq_name: Fully qualified name of physical-interface
        :param fq_name_str: Fully qualified name string of physical-interface
        :param id: UUID of physical-interface
        :param ifmap_id: IFMAP id of physical-interface
        :returns: :class:`.PhysicalInterface` object
        
        """
        (args_ok, result) = self._read_args_to_id('physical-interface', fq_name, fq_name_str, id, ifmap_id)
        if not args_ok:
            return result

        id = result
        uri = PhysicalInterfaceClientGen.resource_uri_base['physical-interface'] + '/' + id

        content = self._request_server(rest.OP_GET, uri)

        obj_dict = json.loads(content)['physical-interface']
        obj_dict['name'] = obj_dict['fq_name'][-1]
        if obj_dict.has_key('id_perms'):
            prop_obj = IdPermsType(**obj_dict['id_perms'])
            obj_dict['id_perms'] = prop_obj

        # fill ref links
        # fill back ref links
        return PhysicalInterface.factory(**obj_dict)
    #end physical_interface_read

    def physical_interface_update(self, obj):
        """Update physical-interface.
        
        :param obj: :class:`.PhysicalInterface` object
        
        """
        # Read in uuid from api-server if not specified in obj
        if not obj.uuid:
            obj.uuid = self.fq_name_to_id('physical-interface', obj.get_fq_name())

        # Ignore fields with None value in json representation
        json_param = json.dumps(obj,
            default = lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        json_body = '{"physical-interface":' + json_param + '}'

        id = obj.uuid
        uri = PhysicalInterfaceClientGen.resource_uri_base['physical-interface'] + '/' + id
        content = self._request_server(rest.OP_PUT, uri, data = json_body)
        return content
    #end physical_interface_update

    def physical_interfaces_list(self, parent_id = None, parent_fq_name = None):
        """List all physical-interfaces.
        
        :param parent_id: UUID of parent as optional search filter
        :param parent_fq_name: full qualified name of parent as optional search filter
        :returns: list of :class:`.PhysicalInterface` objects
        
        """
        filt = None
        # TODO validate only one of id or name is given
        filt = {}
        if parent_fq_name:
            parent_fq_name_str = ':'.join(parent_fq_name)
            filt['parent_fq_name_str'] = parent_fq_name_str
        elif parent_id:
            filt['parent_id'] = parent_id
        content = self._request_server(rest.OP_GET,
                       PhysicalInterfaceClientGen.create_uri,
                       data = filt)
        return content
    #end physical_interfaces_list

    def physical_interface_delete(self, fq_name = None, id = None, ifmap_id = None):
        """Delete physical-interface from the system.
        
        :param fq_name: Fully qualified name of physical-interface
        :param id: UUID of physical-interface
        :param ifmap_id: IFMAP id of physical-interface
        
        """
        (args_ok, result) = self._read_args_to_id(obj_type = 'physical-interface', fq_name = fq_name, id = id, ifmap_id = ifmap_id)
        if not args_ok:
            return result

        id = result
        uri = PhysicalInterfaceClientGen.resource_uri_base['physical-interface'] + '/' + id

        content = self._request_server(rest.OP_DELETE, uri)
    #end physical_interface_delete

    def get_default_physical_interface_id(self):
        """Return UUID of default physical-interface."""
        return self.fq_name_to_id('physical-interface', PhysicalInterface().get_fq_name())
    #end get_default_physical_interface_delete

    def access_control_list_create(self, obj):
        """Create new access-control-list.
        
        :param obj: :class:`.AccessControlList` object
        
        """
        # Ignore fields with None value in json representation
        json_param = json.dumps(obj,
            default = lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        json_body = '{"access-control-list":' + json_param + '}'
        content = self._request_server(rest.OP_POST,
                       AccessControlListClientGen.create_uri,
                       data = json_body)

        access_control_list_dict = json.loads(content)['access-control-list']
        obj.uuid = access_control_list_dict['uuid']
        if 'parent_uuid' in access_control_list_dict:
            obj.parent_uuid = access_control_list_dict['parent_uuid']

        return obj.uuid
    #end access_control_list_create

    def access_control_list_read(self, fq_name = None, fq_name_str = None, id = None, ifmap_id = None):
        """Return access-control-list information.
        
        :param fq_name: Fully qualified name of access-control-list
        :param fq_name_str: Fully qualified name string of access-control-list
        :param id: UUID of access-control-list
        :param ifmap_id: IFMAP id of access-control-list
        :returns: :class:`.AccessControlList` object
        
        """
        (args_ok, result) = self._read_args_to_id('access-control-list', fq_name, fq_name_str, id, ifmap_id)
        if not args_ok:
            return result

        id = result
        uri = AccessControlListClientGen.resource_uri_base['access-control-list'] + '/' + id

        content = self._request_server(rest.OP_GET, uri)

        obj_dict = json.loads(content)['access-control-list']
        obj_dict['name'] = obj_dict['fq_name'][-1]
        if obj_dict.has_key('access_control_list_entries'):
            prop_obj = AclEntriesType(**obj_dict['access_control_list_entries'])
            obj_dict['access_control_list_entries'] = prop_obj

        if obj_dict.has_key('id_perms'):
            prop_obj = IdPermsType(**obj_dict['id_perms'])
            obj_dict['id_perms'] = prop_obj

        # fill ref links
        # fill back ref links
        return AccessControlList.factory(**obj_dict)
    #end access_control_list_read

    def access_control_list_update(self, obj):
        """Update access-control-list.
        
        :param obj: :class:`.AccessControlList` object
        
        """
        # Read in uuid from api-server if not specified in obj
        if not obj.uuid:
            obj.uuid = self.fq_name_to_id('access-control-list', obj.get_fq_name())

        # Ignore fields with None value in json representation
        json_param = json.dumps(obj,
            default = lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        json_body = '{"access-control-list":' + json_param + '}'

        id = obj.uuid
        uri = AccessControlListClientGen.resource_uri_base['access-control-list'] + '/' + id
        content = self._request_server(rest.OP_PUT, uri, data = json_body)
        return content
    #end access_control_list_update

    def access_control_lists_list(self, parent_id = None, parent_fq_name = None):
        """List all access-control-lists.
        
        :param parent_id: UUID of parent as optional search filter
        :param parent_fq_name: full qualified name of parent as optional search filter
        :returns: list of :class:`.AccessControlList` objects
        
        """
        filt = None
        # TODO validate only one of id or name is given
        filt = {}
        if parent_fq_name:
            parent_fq_name_str = ':'.join(parent_fq_name)
            filt['parent_fq_name_str'] = parent_fq_name_str
        elif parent_id:
            filt['parent_id'] = parent_id
        content = self._request_server(rest.OP_GET,
                       AccessControlListClientGen.create_uri,
                       data = filt)
        return content
    #end access_control_lists_list

    def access_control_list_delete(self, fq_name = None, id = None, ifmap_id = None):
        """Delete access-control-list from the system.
        
        :param fq_name: Fully qualified name of access-control-list
        :param id: UUID of access-control-list
        :param ifmap_id: IFMAP id of access-control-list
        
        """
        (args_ok, result) = self._read_args_to_id(obj_type = 'access-control-list', fq_name = fq_name, id = id, ifmap_id = ifmap_id)
        if not args_ok:
            return result

        id = result
        uri = AccessControlListClientGen.resource_uri_base['access-control-list'] + '/' + id

        content = self._request_server(rest.OP_DELETE, uri)
    #end access_control_list_delete

    def get_default_access_control_list_id(self):
        """Return UUID of default access-control-list."""
        return self.fq_name_to_id('access-control-list', AccessControlList().get_fq_name())
    #end get_default_access_control_list_delete

    def virtual_DNS_create(self, obj):
        """Create new virtual-DNS.
        
        :param obj: :class:`.VirtualDns` object
        
        """
        # Ignore fields with None value in json representation
        json_param = json.dumps(obj,
            default = lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        json_body = '{"virtual-DNS":' + json_param + '}'
        content = self._request_server(rest.OP_POST,
                       VirtualDnsClientGen.create_uri,
                       data = json_body)

        virtual_DNS_dict = json.loads(content)['virtual-DNS']
        obj.uuid = virtual_DNS_dict['uuid']
        if 'parent_uuid' in virtual_DNS_dict:
            obj.parent_uuid = virtual_DNS_dict['parent_uuid']

        return obj.uuid
    #end virtual_DNS_create

    def virtual_DNS_read(self, fq_name = None, fq_name_str = None, id = None, ifmap_id = None):
        """Return virtual-DNS information.
        
        :param fq_name: Fully qualified name of virtual-DNS
        :param fq_name_str: Fully qualified name string of virtual-DNS
        :param id: UUID of virtual-DNS
        :param ifmap_id: IFMAP id of virtual-DNS
        :returns: :class:`.VirtualDns` object
        
        """
        (args_ok, result) = self._read_args_to_id('virtual-DNS', fq_name, fq_name_str, id, ifmap_id)
        if not args_ok:
            return result

        id = result
        uri = VirtualDnsClientGen.resource_uri_base['virtual-DNS'] + '/' + id

        content = self._request_server(rest.OP_GET, uri)

        obj_dict = json.loads(content)['virtual-DNS']
        obj_dict['name'] = obj_dict['fq_name'][-1]
        if obj_dict.has_key('virtual_DNS_data'):
            prop_obj = VirtualDnsType(**obj_dict['virtual_DNS_data'])
            obj_dict['virtual_DNS_data'] = prop_obj

        if obj_dict.has_key('id_perms'):
            prop_obj = IdPermsType(**obj_dict['id_perms'])
            obj_dict['id_perms'] = prop_obj

        # fill ref links
        # fill back ref links
        return VirtualDns.factory(**obj_dict)
    #end virtual_DNS_read

    def virtual_DNS_update(self, obj):
        """Update virtual-DNS.
        
        :param obj: :class:`.VirtualDns` object
        
        """
        # Read in uuid from api-server if not specified in obj
        if not obj.uuid:
            obj.uuid = self.fq_name_to_id('virtual-DNS', obj.get_fq_name())

        # Ignore fields with None value in json representation
        json_param = json.dumps(obj,
            default = lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        json_body = '{"virtual-DNS":' + json_param + '}'

        id = obj.uuid
        uri = VirtualDnsClientGen.resource_uri_base['virtual-DNS'] + '/' + id
        content = self._request_server(rest.OP_PUT, uri, data = json_body)
        return content
    #end virtual_DNS_update

    def virtual_DNSs_list(self, parent_id = None, parent_fq_name = None):
        """List all virtual-DNSs.
        
        :param parent_id: UUID of parent as optional search filter
        :param parent_fq_name: full qualified name of parent as optional search filter
        :returns: list of :class:`.VirtualDns` objects
        
        """
        filt = None
        # TODO validate only one of id or name is given
        filt = {}
        if parent_fq_name:
            parent_fq_name_str = ':'.join(parent_fq_name)
            filt['parent_fq_name_str'] = parent_fq_name_str
        elif parent_id:
            filt['parent_id'] = parent_id
        content = self._request_server(rest.OP_GET,
                       VirtualDnsClientGen.create_uri,
                       data = filt)
        return content
    #end virtual_DNSs_list

    def virtual_DNS_delete(self, fq_name = None, id = None, ifmap_id = None):
        """Delete virtual-DNS from the system.
        
        :param fq_name: Fully qualified name of virtual-DNS
        :param id: UUID of virtual-DNS
        :param ifmap_id: IFMAP id of virtual-DNS
        
        """
        (args_ok, result) = self._read_args_to_id(obj_type = 'virtual-DNS', fq_name = fq_name, id = id, ifmap_id = ifmap_id)
        if not args_ok:
            return result

        id = result
        uri = VirtualDnsClientGen.resource_uri_base['virtual-DNS'] + '/' + id

        content = self._request_server(rest.OP_DELETE, uri)
    #end virtual_DNS_delete

    def get_default_virtual_DNS_id(self):
        """Return UUID of default virtual-DNS."""
        return self.fq_name_to_id('virtual-DNS', VirtualDns().get_fq_name())
    #end get_default_virtual_DNS_delete

    def customer_attachment_create(self, obj):
        """Create new customer-attachment.
        
        :param obj: :class:`.CustomerAttachment` object
        
        """
        # Ignore fields with None value in json representation
        json_param = json.dumps(obj,
            default = lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        json_body = '{"customer-attachment":' + json_param + '}'
        content = self._request_server(rest.OP_POST,
                       CustomerAttachmentClientGen.create_uri,
                       data = json_body)

        customer_attachment_dict = json.loads(content)['customer-attachment']
        obj.uuid = customer_attachment_dict['uuid']
        if 'parent_uuid' in customer_attachment_dict:
            obj.parent_uuid = customer_attachment_dict['parent_uuid']

        return obj.uuid
    #end customer_attachment_create

    def customer_attachment_read(self, fq_name = None, fq_name_str = None, id = None, ifmap_id = None):
        """Return customer-attachment information.
        
        :param fq_name: Fully qualified name of customer-attachment
        :param fq_name_str: Fully qualified name string of customer-attachment
        :param id: UUID of customer-attachment
        :param ifmap_id: IFMAP id of customer-attachment
        :returns: :class:`.CustomerAttachment` object
        
        """
        (args_ok, result) = self._read_args_to_id('customer-attachment', fq_name, fq_name_str, id, ifmap_id)
        if not args_ok:
            return result

        id = result
        uri = CustomerAttachmentClientGen.resource_uri_base['customer-attachment'] + '/' + id

        content = self._request_server(rest.OP_GET, uri)

        obj_dict = json.loads(content)['customer-attachment']
        obj_dict['name'] = obj_dict['fq_name'][-1]
        if obj_dict.has_key('attachment_address'):
            prop_obj = AttachmentAddressType(**obj_dict['attachment_address'])
            obj_dict['attachment_address'] = prop_obj

        if obj_dict.has_key('id_perms'):
            prop_obj = IdPermsType(**obj_dict['id_perms'])
            obj_dict['id_perms'] = prop_obj

        # fill ref links
        # fill back ref links
        return CustomerAttachment.factory(**obj_dict)
    #end customer_attachment_read

    def customer_attachment_update(self, obj):
        """Update customer-attachment.
        
        :param obj: :class:`.CustomerAttachment` object
        
        """
        # Read in uuid from api-server if not specified in obj
        if not obj.uuid:
            obj.uuid = self.fq_name_to_id('customer-attachment', obj.get_fq_name())

        # Ignore fields with None value in json representation
        json_param = json.dumps(obj,
            default = lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        json_body = '{"customer-attachment":' + json_param + '}'

        id = obj.uuid
        uri = CustomerAttachmentClientGen.resource_uri_base['customer-attachment'] + '/' + id
        content = self._request_server(rest.OP_PUT, uri, data = json_body)
        return content
    #end customer_attachment_update

    def customer_attachments_list(self):
        """List all customer-attachments."""
        filt = None
        # TODO validate only one of id or name is given
        filt = {}
        content = self._request_server(rest.OP_GET,
                       CustomerAttachmentClientGen.create_uri,
                       data = filt)
        return content
    #end customer_attachments_list

    def customer_attachment_delete(self, fq_name = None, id = None, ifmap_id = None):
        """Delete customer-attachment from the system.
        
        :param fq_name: Fully qualified name of customer-attachment
        :param id: UUID of customer-attachment
        :param ifmap_id: IFMAP id of customer-attachment
        
        """
        (args_ok, result) = self._read_args_to_id(obj_type = 'customer-attachment', fq_name = fq_name, id = id, ifmap_id = ifmap_id)
        if not args_ok:
            return result

        id = result
        uri = CustomerAttachmentClientGen.resource_uri_base['customer-attachment'] + '/' + id

        content = self._request_server(rest.OP_DELETE, uri)
    #end customer_attachment_delete

    def get_default_customer_attachment_id(self):
        """Return UUID of default customer-attachment."""
        return self.fq_name_to_id('customer-attachment', CustomerAttachment().get_fq_name())
    #end get_default_customer_attachment_delete

    def virtual_machine_create(self, obj):
        """Create new virtual-machine.
        
        :param obj: :class:`.VirtualMachine` object
        
        """
        # Ignore fields with None value in json representation
        json_param = json.dumps(obj,
            default = lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        json_body = '{"virtual-machine":' + json_param + '}'
        content = self._request_server(rest.OP_POST,
                       VirtualMachineClientGen.create_uri,
                       data = json_body)

        virtual_machine_dict = json.loads(content)['virtual-machine']
        obj.uuid = virtual_machine_dict['uuid']
        if 'parent_uuid' in virtual_machine_dict:
            obj.parent_uuid = virtual_machine_dict['parent_uuid']

        return obj.uuid
    #end virtual_machine_create

    def virtual_machine_read(self, fq_name = None, fq_name_str = None, id = None, ifmap_id = None):
        """Return virtual-machine information.
        
        :param fq_name: Fully qualified name of virtual-machine
        :param fq_name_str: Fully qualified name string of virtual-machine
        :param id: UUID of virtual-machine
        :param ifmap_id: IFMAP id of virtual-machine
        :returns: :class:`.VirtualMachine` object
        
        """
        (args_ok, result) = self._read_args_to_id('virtual-machine', fq_name, fq_name_str, id, ifmap_id)
        if not args_ok:
            return result

        id = result
        uri = VirtualMachineClientGen.resource_uri_base['virtual-machine'] + '/' + id

        content = self._request_server(rest.OP_GET, uri)

        obj_dict = json.loads(content)['virtual-machine']
        obj_dict['name'] = obj_dict['fq_name'][-1]
        if obj_dict.has_key('id_perms'):
            prop_obj = IdPermsType(**obj_dict['id_perms'])
            obj_dict['id_perms'] = prop_obj

        # fill ref links
        # fill back ref links
        return VirtualMachine.factory(**obj_dict)
    #end virtual_machine_read

    def virtual_machine_update(self, obj):
        """Update virtual-machine.
        
        :param obj: :class:`.VirtualMachine` object
        
        """
        # Read in uuid from api-server if not specified in obj
        if not obj.uuid:
            obj.uuid = self.fq_name_to_id('virtual-machine', obj.get_fq_name())

        # Ignore fields with None value in json representation
        json_param = json.dumps(obj,
            default = lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        json_body = '{"virtual-machine":' + json_param + '}'

        id = obj.uuid
        uri = VirtualMachineClientGen.resource_uri_base['virtual-machine'] + '/' + id
        content = self._request_server(rest.OP_PUT, uri, data = json_body)
        return content
    #end virtual_machine_update

    def virtual_machines_list(self):
        """List all virtual-machines."""
        filt = None
        # TODO validate only one of id or name is given
        filt = {}
        content = self._request_server(rest.OP_GET,
                       VirtualMachineClientGen.create_uri,
                       data = filt)
        return content
    #end virtual_machines_list

    def virtual_machine_delete(self, fq_name = None, id = None, ifmap_id = None):
        """Delete virtual-machine from the system.
        
        :param fq_name: Fully qualified name of virtual-machine
        :param id: UUID of virtual-machine
        :param ifmap_id: IFMAP id of virtual-machine
        
        """
        (args_ok, result) = self._read_args_to_id(obj_type = 'virtual-machine', fq_name = fq_name, id = id, ifmap_id = ifmap_id)
        if not args_ok:
            return result

        id = result
        uri = VirtualMachineClientGen.resource_uri_base['virtual-machine'] + '/' + id

        content = self._request_server(rest.OP_DELETE, uri)
    #end virtual_machine_delete

    def get_default_virtual_machine_id(self):
        """Return UUID of default virtual-machine."""
        return self.fq_name_to_id('virtual-machine', VirtualMachine().get_fq_name())
    #end get_default_virtual_machine_delete

    def service_template_create(self, obj):
        """Create new service-template.
        
        :param obj: :class:`.ServiceTemplate` object
        
        """
        # Ignore fields with None value in json representation
        json_param = json.dumps(obj,
            default = lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        json_body = '{"service-template":' + json_param + '}'
        content = self._request_server(rest.OP_POST,
                       ServiceTemplateClientGen.create_uri,
                       data = json_body)

        service_template_dict = json.loads(content)['service-template']
        obj.uuid = service_template_dict['uuid']
        if 'parent_uuid' in service_template_dict:
            obj.parent_uuid = service_template_dict['parent_uuid']

        return obj.uuid
    #end service_template_create

    def service_template_read(self, fq_name = None, fq_name_str = None, id = None, ifmap_id = None):
        """Return service-template information.
        
        :param fq_name: Fully qualified name of service-template
        :param fq_name_str: Fully qualified name string of service-template
        :param id: UUID of service-template
        :param ifmap_id: IFMAP id of service-template
        :returns: :class:`.ServiceTemplate` object
        
        """
        (args_ok, result) = self._read_args_to_id('service-template', fq_name, fq_name_str, id, ifmap_id)
        if not args_ok:
            return result

        id = result
        uri = ServiceTemplateClientGen.resource_uri_base['service-template'] + '/' + id

        content = self._request_server(rest.OP_GET, uri)

        obj_dict = json.loads(content)['service-template']
        obj_dict['name'] = obj_dict['fq_name'][-1]
        if obj_dict.has_key('service_template_properties'):
            prop_obj = ServiceTemplateType(**obj_dict['service_template_properties'])
            obj_dict['service_template_properties'] = prop_obj

        if obj_dict.has_key('id_perms'):
            prop_obj = IdPermsType(**obj_dict['id_perms'])
            obj_dict['id_perms'] = prop_obj

        # fill ref links
        # fill back ref links
        return ServiceTemplate.factory(**obj_dict)
    #end service_template_read

    def service_template_update(self, obj):
        """Update service-template.
        
        :param obj: :class:`.ServiceTemplate` object
        
        """
        # Read in uuid from api-server if not specified in obj
        if not obj.uuid:
            obj.uuid = self.fq_name_to_id('service-template', obj.get_fq_name())

        # Ignore fields with None value in json representation
        json_param = json.dumps(obj,
            default = lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        json_body = '{"service-template":' + json_param + '}'

        id = obj.uuid
        uri = ServiceTemplateClientGen.resource_uri_base['service-template'] + '/' + id
        content = self._request_server(rest.OP_PUT, uri, data = json_body)
        return content
    #end service_template_update

    def service_templates_list(self, parent_id = None, parent_fq_name = None):
        """List all service-templates.
        
        :param parent_id: UUID of parent as optional search filter
        :param parent_fq_name: full qualified name of parent as optional search filter
        :returns: list of :class:`.ServiceTemplate` objects
        
        """
        filt = None
        # TODO validate only one of id or name is given
        filt = {}
        if parent_fq_name:
            parent_fq_name_str = ':'.join(parent_fq_name)
            filt['parent_fq_name_str'] = parent_fq_name_str
        elif parent_id:
            filt['parent_id'] = parent_id
        content = self._request_server(rest.OP_GET,
                       ServiceTemplateClientGen.create_uri,
                       data = filt)
        return content
    #end service_templates_list

    def service_template_delete(self, fq_name = None, id = None, ifmap_id = None):
        """Delete service-template from the system.
        
        :param fq_name: Fully qualified name of service-template
        :param id: UUID of service-template
        :param ifmap_id: IFMAP id of service-template
        
        """
        (args_ok, result) = self._read_args_to_id(obj_type = 'service-template', fq_name = fq_name, id = id, ifmap_id = ifmap_id)
        if not args_ok:
            return result

        id = result
        uri = ServiceTemplateClientGen.resource_uri_base['service-template'] + '/' + id

        content = self._request_server(rest.OP_DELETE, uri)
    #end service_template_delete

    def get_default_service_template_id(self):
        """Return UUID of default service-template."""
        return self.fq_name_to_id('service-template', ServiceTemplate().get_fq_name())
    #end get_default_service_template_delete

    def security_group_create(self, obj):
        """Create new security-group.
        
        :param obj: :class:`.SecurityGroup` object
        
        """
        # Ignore fields with None value in json representation
        json_param = json.dumps(obj,
            default = lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        json_body = '{"security-group":' + json_param + '}'
        content = self._request_server(rest.OP_POST,
                       SecurityGroupClientGen.create_uri,
                       data = json_body)

        security_group_dict = json.loads(content)['security-group']
        obj.uuid = security_group_dict['uuid']
        if 'parent_uuid' in security_group_dict:
            obj.parent_uuid = security_group_dict['parent_uuid']

        return obj.uuid
    #end security_group_create

    def security_group_read(self, fq_name = None, fq_name_str = None, id = None, ifmap_id = None):
        """Return security-group information.
        
        :param fq_name: Fully qualified name of security-group
        :param fq_name_str: Fully qualified name string of security-group
        :param id: UUID of security-group
        :param ifmap_id: IFMAP id of security-group
        :returns: :class:`.SecurityGroup` object
        
        """
        (args_ok, result) = self._read_args_to_id('security-group', fq_name, fq_name_str, id, ifmap_id)
        if not args_ok:
            return result

        id = result
        uri = SecurityGroupClientGen.resource_uri_base['security-group'] + '/' + id

        content = self._request_server(rest.OP_GET, uri)

        obj_dict = json.loads(content)['security-group']
        obj_dict['name'] = obj_dict['fq_name'][-1]

        if obj_dict.has_key('security_group_entries'):
            prop_obj = PolicyEntriesType(**obj_dict['security_group_entries'])
            obj_dict['security_group_entries'] = prop_obj

        if obj_dict.has_key('id_perms'):
            prop_obj = IdPermsType(**obj_dict['id_perms'])
            obj_dict['id_perms'] = prop_obj

        # fill ref links
        # fill back ref links
        return SecurityGroup.factory(**obj_dict)
    #end security_group_read

    def security_group_update(self, obj):
        """Update security-group.
        
        :param obj: :class:`.SecurityGroup` object
        
        """
        # Read in uuid from api-server if not specified in obj
        if not obj.uuid:
            obj.uuid = self.fq_name_to_id('security-group', obj.get_fq_name())

        # Ignore fields with None value in json representation
        json_param = json.dumps(obj,
            default = lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        json_body = '{"security-group":' + json_param + '}'

        id = obj.uuid
        uri = SecurityGroupClientGen.resource_uri_base['security-group'] + '/' + id
        content = self._request_server(rest.OP_PUT, uri, data = json_body)
        return content
    #end security_group_update

    def security_groups_list(self, parent_id = None, parent_fq_name = None):
        """List all security-groups.
        
        :param parent_id: UUID of parent as optional search filter
        :param parent_fq_name: full qualified name of parent as optional search filter
        :returns: list of :class:`.SecurityGroup` objects
        
        """
        filt = None
        # TODO validate only one of id or name is given
        filt = {}
        if parent_fq_name:
            parent_fq_name_str = ':'.join(parent_fq_name)
            filt['parent_fq_name_str'] = parent_fq_name_str
        elif parent_id:
            filt['parent_id'] = parent_id
        content = self._request_server(rest.OP_GET,
                       SecurityGroupClientGen.create_uri,
                       data = filt)
        return content
    #end security_groups_list

    def security_group_delete(self, fq_name = None, id = None, ifmap_id = None):
        """Delete security-group from the system.
        
        :param fq_name: Fully qualified name of security-group
        :param id: UUID of security-group
        :param ifmap_id: IFMAP id of security-group
        
        """
        (args_ok, result) = self._read_args_to_id(obj_type = 'security-group', fq_name = fq_name, id = id, ifmap_id = ifmap_id)
        if not args_ok:
            return result

        id = result
        uri = SecurityGroupClientGen.resource_uri_base['security-group'] + '/' + id

        content = self._request_server(rest.OP_DELETE, uri)
    #end security_group_delete

    def get_default_security_group_id(self):
        """Return UUID of default security-group."""
        return self.fq_name_to_id('security-group', SecurityGroup().get_fq_name())
    #end get_default_security_group_delete

    def provider_attachment_create(self, obj):
        """Create new provider-attachment.
        
        :param obj: :class:`.ProviderAttachment` object
        
        """
        # Ignore fields with None value in json representation
        json_param = json.dumps(obj,
            default = lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        json_body = '{"provider-attachment":' + json_param + '}'
        content = self._request_server(rest.OP_POST,
                       ProviderAttachmentClientGen.create_uri,
                       data = json_body)

        provider_attachment_dict = json.loads(content)['provider-attachment']
        obj.uuid = provider_attachment_dict['uuid']
        if 'parent_uuid' in provider_attachment_dict:
            obj.parent_uuid = provider_attachment_dict['parent_uuid']

        return obj.uuid
    #end provider_attachment_create

    def provider_attachment_read(self, fq_name = None, fq_name_str = None, id = None, ifmap_id = None):
        """Return provider-attachment information.
        
        :param fq_name: Fully qualified name of provider-attachment
        :param fq_name_str: Fully qualified name string of provider-attachment
        :param id: UUID of provider-attachment
        :param ifmap_id: IFMAP id of provider-attachment
        :returns: :class:`.ProviderAttachment` object
        
        """
        (args_ok, result) = self._read_args_to_id('provider-attachment', fq_name, fq_name_str, id, ifmap_id)
        if not args_ok:
            return result

        id = result
        uri = ProviderAttachmentClientGen.resource_uri_base['provider-attachment'] + '/' + id

        content = self._request_server(rest.OP_GET, uri)

        obj_dict = json.loads(content)['provider-attachment']
        obj_dict['name'] = obj_dict['fq_name'][-1]
        if obj_dict.has_key('id_perms'):
            prop_obj = IdPermsType(**obj_dict['id_perms'])
            obj_dict['id_perms'] = prop_obj

        # fill ref links
        # fill back ref links
        return ProviderAttachment.factory(**obj_dict)
    #end provider_attachment_read

    def provider_attachment_update(self, obj):
        """Update provider-attachment.
        
        :param obj: :class:`.ProviderAttachment` object
        
        """
        # Read in uuid from api-server if not specified in obj
        if not obj.uuid:
            obj.uuid = self.fq_name_to_id('provider-attachment', obj.get_fq_name())

        # Ignore fields with None value in json representation
        json_param = json.dumps(obj,
            default = lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        json_body = '{"provider-attachment":' + json_param + '}'

        id = obj.uuid
        uri = ProviderAttachmentClientGen.resource_uri_base['provider-attachment'] + '/' + id
        content = self._request_server(rest.OP_PUT, uri, data = json_body)
        return content
    #end provider_attachment_update

    def provider_attachments_list(self):
        """List all provider-attachments."""
        filt = None
        # TODO validate only one of id or name is given
        filt = {}
        content = self._request_server(rest.OP_GET,
                       ProviderAttachmentClientGen.create_uri,
                       data = filt)
        return content
    #end provider_attachments_list

    def provider_attachment_delete(self, fq_name = None, id = None, ifmap_id = None):
        """Delete provider-attachment from the system.
        
        :param fq_name: Fully qualified name of provider-attachment
        :param id: UUID of provider-attachment
        :param ifmap_id: IFMAP id of provider-attachment
        
        """
        (args_ok, result) = self._read_args_to_id(obj_type = 'provider-attachment', fq_name = fq_name, id = id, ifmap_id = ifmap_id)
        if not args_ok:
            return result

        id = result
        uri = ProviderAttachmentClientGen.resource_uri_base['provider-attachment'] + '/' + id

        content = self._request_server(rest.OP_DELETE, uri)
    #end provider_attachment_delete

    def get_default_provider_attachment_id(self):
        """Return UUID of default provider-attachment."""
        return self.fq_name_to_id('provider-attachment', ProviderAttachment().get_fq_name())
    #end get_default_provider_attachment_delete

    def network_ipam_create(self, obj):
        """Create new network-ipam.
        
        :param obj: :class:`.NetworkIpam` object
        
        """
        # Ignore fields with None value in json representation
        json_param = json.dumps(obj,
            default = lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        json_body = '{"network-ipam":' + json_param + '}'
        content = self._request_server(rest.OP_POST,
                       NetworkIpamClientGen.create_uri,
                       data = json_body)

        network_ipam_dict = json.loads(content)['network-ipam']
        obj.uuid = network_ipam_dict['uuid']
        if 'parent_uuid' in network_ipam_dict:
            obj.parent_uuid = network_ipam_dict['parent_uuid']

        return obj.uuid
    #end network_ipam_create

    def network_ipam_read(self, fq_name = None, fq_name_str = None, id = None, ifmap_id = None):
        """Return network-ipam information.
        
        :param fq_name: Fully qualified name of network-ipam
        :param fq_name_str: Fully qualified name string of network-ipam
        :param id: UUID of network-ipam
        :param ifmap_id: IFMAP id of network-ipam
        :returns: :class:`.NetworkIpam` object
        
        """
        (args_ok, result) = self._read_args_to_id('network-ipam', fq_name, fq_name_str, id, ifmap_id)
        if not args_ok:
            return result

        id = result
        uri = NetworkIpamClientGen.resource_uri_base['network-ipam'] + '/' + id

        content = self._request_server(rest.OP_GET, uri)

        obj_dict = json.loads(content)['network-ipam']
        obj_dict['name'] = obj_dict['fq_name'][-1]
        if obj_dict.has_key('network_ipam_mgmt'):
            prop_obj = IpamType(**obj_dict['network_ipam_mgmt'])
            obj_dict['network_ipam_mgmt'] = prop_obj

        if obj_dict.has_key('id_perms'):
            prop_obj = IdPermsType(**obj_dict['id_perms'])
            obj_dict['id_perms'] = prop_obj

        # fill ref links
        # fill back ref links
        if obj_dict.has_key('virtual_network_back_refs'):
            list_len = len(obj_dict['virtual_network_back_refs'])
            for idx in range(list_len):
                back_ref = obj_dict['virtual_network_back_refs'][idx]
                data_obj = VnSubnetsType(**back_ref['attr'])
                back_ref_dict = {}
                back_ref_dict['to'] = back_ref['to']
                back_ref_dict['attr'] = data_obj
                back_ref_dict['uuid'] = back_ref['uuid']
                back_ref_dict['href'] = back_ref['href']
                obj_dict['virtual_network_back_refs'][idx] = back_ref_dict

        return NetworkIpam.factory(**obj_dict)
    #end network_ipam_read

    def network_ipam_update(self, obj):
        """Update network-ipam.
        
        :param obj: :class:`.NetworkIpam` object
        
        """
        # Read in uuid from api-server if not specified in obj
        if not obj.uuid:
            obj.uuid = self.fq_name_to_id('network-ipam', obj.get_fq_name())

        # Ignore fields with None value in json representation
        json_param = json.dumps(obj,
            default = lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        json_body = '{"network-ipam":' + json_param + '}'

        id = obj.uuid
        uri = NetworkIpamClientGen.resource_uri_base['network-ipam'] + '/' + id
        content = self._request_server(rest.OP_PUT, uri, data = json_body)
        return content
    #end network_ipam_update

    def network_ipams_list(self, parent_id = None, parent_fq_name = None):
        """List all network-ipams.
        
        :param parent_id: UUID of parent as optional search filter
        :param parent_fq_name: full qualified name of parent as optional search filter
        :returns: list of :class:`.NetworkIpam` objects
        
        """
        filt = None
        # TODO validate only one of id or name is given
        filt = {}
        if parent_fq_name:
            parent_fq_name_str = ':'.join(parent_fq_name)
            filt['parent_fq_name_str'] = parent_fq_name_str
        elif parent_id:
            filt['parent_id'] = parent_id
        content = self._request_server(rest.OP_GET,
                       NetworkIpamClientGen.create_uri,
                       data = filt)
        return content
    #end network_ipams_list

    def network_ipam_delete(self, fq_name = None, id = None, ifmap_id = None):
        """Delete network-ipam from the system.
        
        :param fq_name: Fully qualified name of network-ipam
        :param id: UUID of network-ipam
        :param ifmap_id: IFMAP id of network-ipam
        
        """
        (args_ok, result) = self._read_args_to_id(obj_type = 'network-ipam', fq_name = fq_name, id = id, ifmap_id = ifmap_id)
        if not args_ok:
            return result

        id = result
        uri = NetworkIpamClientGen.resource_uri_base['network-ipam'] + '/' + id

        content = self._request_server(rest.OP_DELETE, uri)
    #end network_ipam_delete

    def get_default_network_ipam_id(self):
        """Return UUID of default network-ipam."""
        return self.fq_name_to_id('network-ipam', NetworkIpam().get_fq_name())
    #end get_default_network_ipam_delete

    def virtual_network_create(self, obj):
        """Create new virtual-network.
        
        :param obj: :class:`.VirtualNetwork` object
        
        """
        # Ignore fields with None value in json representation
        json_param = json.dumps(obj,
            default = lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        json_body = '{"virtual-network":' + json_param + '}'
        content = self._request_server(rest.OP_POST,
                       VirtualNetworkClientGen.create_uri,
                       data = json_body)

        virtual_network_dict = json.loads(content)['virtual-network']
        obj.uuid = virtual_network_dict['uuid']
        if 'parent_uuid' in virtual_network_dict:
            obj.parent_uuid = virtual_network_dict['parent_uuid']

        return obj.uuid
    #end virtual_network_create

    def virtual_network_read(self, fq_name = None, fq_name_str = None, id = None, ifmap_id = None):
        """Return virtual-network information.
        
        :param fq_name: Fully qualified name of virtual-network
        :param fq_name_str: Fully qualified name string of virtual-network
        :param id: UUID of virtual-network
        :param ifmap_id: IFMAP id of virtual-network
        :returns: :class:`.VirtualNetwork` object
        
        """
        (args_ok, result) = self._read_args_to_id('virtual-network', fq_name, fq_name_str, id, ifmap_id)
        if not args_ok:
            return result

        id = result
        uri = VirtualNetworkClientGen.resource_uri_base['virtual-network'] + '/' + id

        content = self._request_server(rest.OP_GET, uri)

        obj_dict = json.loads(content)['virtual-network']
        obj_dict['name'] = obj_dict['fq_name'][-1]
        if obj_dict.has_key('virtual_network_properties'):
            prop_obj = VirtualNetworkType(**obj_dict['virtual_network_properties'])
            obj_dict['virtual_network_properties'] = prop_obj

        if obj_dict.has_key('route_target_list'):
            prop_obj = RouteTargetList(**obj_dict['route_target_list'])
            obj_dict['route_target_list'] = prop_obj

        if obj_dict.has_key('route_table'):
            prop_obj = RouteTableType(**obj_dict['route_table'])
            obj_dict['route_table'] = prop_obj

        if obj_dict.has_key('id_perms'):
            prop_obj = IdPermsType(**obj_dict['id_perms'])
            obj_dict['id_perms'] = prop_obj

        # fill ref links
        if obj_dict.has_key('network_ipam_refs'):
            list_len = len(obj_dict['network_ipam_refs'])
            for idx in range(list_len):
                ref = obj_dict['network_ipam_refs'][idx]
                data_obj = VnSubnetsType(**ref['attr'])
                ref_dict = {}
                ref_dict['to'] = ref['to']
                ref_dict['attr'] = data_obj
                ref_dict['uuid'] = ref['uuid']
                ref_dict['href'] = ref['href']
                obj_dict['network_ipam_refs'][idx] = ref_dict

        if obj_dict.has_key('network_policy_refs'):
            list_len = len(obj_dict['network_policy_refs'])
            for idx in range(list_len):
                ref = obj_dict['network_policy_refs'][idx]
                data_obj = VirtualNetworkPolicyType(**ref['attr'])
                ref_dict = {}
                ref_dict['to'] = ref['to']
                ref_dict['attr'] = data_obj
                ref_dict['uuid'] = ref['uuid']
                ref_dict['href'] = ref['href']
                obj_dict['network_policy_refs'][idx] = ref_dict

        # fill back ref links
        return VirtualNetwork.factory(**obj_dict)
    #end virtual_network_read

    def virtual_network_update(self, obj):
        """Update virtual-network.
        
        :param obj: :class:`.VirtualNetwork` object
        
        """
        # Read in uuid from api-server if not specified in obj
        if not obj.uuid:
            obj.uuid = self.fq_name_to_id('virtual-network', obj.get_fq_name())

        # Ignore fields with None value in json representation
        json_param = json.dumps(obj,
            default = lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        json_body = '{"virtual-network":' + json_param + '}'

        id = obj.uuid
        uri = VirtualNetworkClientGen.resource_uri_base['virtual-network'] + '/' + id
        content = self._request_server(rest.OP_PUT, uri, data = json_body)
        return content
    #end virtual_network_update

    def virtual_networks_list(self, parent_id = None, parent_fq_name = None):
        """List all virtual-networks.
        
        :param parent_id: UUID of parent as optional search filter
        :param parent_fq_name: full qualified name of parent as optional search filter
        :returns: list of :class:`.VirtualNetwork` objects
        
        """
        filt = None
        # TODO validate only one of id or name is given
        filt = {}
        if parent_fq_name:
            parent_fq_name_str = ':'.join(parent_fq_name)
            filt['parent_fq_name_str'] = parent_fq_name_str
        elif parent_id:
            filt['parent_id'] = parent_id
        content = self._request_server(rest.OP_GET,
                       VirtualNetworkClientGen.create_uri,
                       data = filt)
        return content
    #end virtual_networks_list

    def virtual_network_delete(self, fq_name = None, id = None, ifmap_id = None):
        """Delete virtual-network from the system.
        
        :param fq_name: Fully qualified name of virtual-network
        :param id: UUID of virtual-network
        :param ifmap_id: IFMAP id of virtual-network
        
        """
        (args_ok, result) = self._read_args_to_id(obj_type = 'virtual-network', fq_name = fq_name, id = id, ifmap_id = ifmap_id)
        if not args_ok:
            return result

        id = result
        uri = VirtualNetworkClientGen.resource_uri_base['virtual-network'] + '/' + id

        content = self._request_server(rest.OP_DELETE, uri)
    #end virtual_network_delete

    def get_default_virtual_network_id(self):
        """Return UUID of default virtual-network."""
        return self.fq_name_to_id('virtual-network', VirtualNetwork().get_fq_name())
    #end get_default_virtual_network_delete

    def project_create(self, obj):
        """Create new project.
        
        :param obj: :class:`.Project` object
        
        """
        # Ignore fields with None value in json representation
        json_param = json.dumps(obj,
            default = lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        json_body = '{"project":' + json_param + '}'
        content = self._request_server(rest.OP_POST,
                       ProjectClientGen.create_uri,
                       data = json_body)

        project_dict = json.loads(content)['project']
        obj.uuid = project_dict['uuid']
        if 'parent_uuid' in project_dict:
            obj.parent_uuid = project_dict['parent_uuid']

        return obj.uuid
    #end project_create

    def project_read(self, fq_name = None, fq_name_str = None, id = None, ifmap_id = None):
        """Return project information.
        
        :param fq_name: Fully qualified name of project
        :param fq_name_str: Fully qualified name string of project
        :param id: UUID of project
        :param ifmap_id: IFMAP id of project
        :returns: :class:`.Project` object
        
        """
        (args_ok, result) = self._read_args_to_id('project', fq_name, fq_name_str, id, ifmap_id)
        if not args_ok:
            return result

        id = result
        uri = ProjectClientGen.resource_uri_base['project'] + '/' + id

        content = self._request_server(rest.OP_GET, uri)

        obj_dict = json.loads(content)['project']
        obj_dict['name'] = obj_dict['fq_name'][-1]
        if obj_dict.has_key('id_perms'):
            prop_obj = IdPermsType(**obj_dict['id_perms'])
            obj_dict['id_perms'] = prop_obj

        # fill ref links
        if obj_dict.has_key('namespace_refs'):
            list_len = len(obj_dict['namespace_refs'])
            for idx in range(list_len):
                ref = obj_dict['namespace_refs'][idx]
                data_obj = SubnetType(**ref['attr'])
                ref_dict = {}
                ref_dict['to'] = ref['to']
                ref_dict['attr'] = data_obj
                ref_dict['uuid'] = ref['uuid']
                ref_dict['href'] = ref['href']
                obj_dict['namespace_refs'][idx] = ref_dict

        # fill back ref links
        return Project.factory(**obj_dict)
    #end project_read

    def project_update(self, obj):
        """Update project.
        
        :param obj: :class:`.Project` object
        
        """
        # Read in uuid from api-server if not specified in obj
        if not obj.uuid:
            obj.uuid = self.fq_name_to_id('project', obj.get_fq_name())

        # Ignore fields with None value in json representation
        json_param = json.dumps(obj,
            default = lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        json_body = '{"project":' + json_param + '}'

        id = obj.uuid
        uri = ProjectClientGen.resource_uri_base['project'] + '/' + id
        content = self._request_server(rest.OP_PUT, uri, data = json_body)
        return content
    #end project_update

    def projects_list(self, parent_id = None, parent_fq_name = None):
        """List all projects.
        
        :param parent_id: UUID of parent as optional search filter
        :param parent_fq_name: full qualified name of parent as optional search filter
        :returns: list of :class:`.Project` objects
        
        """
        filt = None
        # TODO validate only one of id or name is given
        filt = {}
        if parent_fq_name:
            parent_fq_name_str = ':'.join(parent_fq_name)
            filt['parent_fq_name_str'] = parent_fq_name_str
        elif parent_id:
            filt['parent_id'] = parent_id
        content = self._request_server(rest.OP_GET,
                       ProjectClientGen.create_uri,
                       data = filt)
        return content
    #end projects_list

    def project_delete(self, fq_name = None, id = None, ifmap_id = None):
        """Delete project from the system.
        
        :param fq_name: Fully qualified name of project
        :param id: UUID of project
        :param ifmap_id: IFMAP id of project
        
        """
        (args_ok, result) = self._read_args_to_id(obj_type = 'project', fq_name = fq_name, id = id, ifmap_id = ifmap_id)
        if not args_ok:
            return result

        id = result
        uri = ProjectClientGen.resource_uri_base['project'] + '/' + id

        content = self._request_server(rest.OP_DELETE, uri)
    #end project_delete

    def get_default_project_id(self):
        """Return UUID of default project."""
        return self.fq_name_to_id('project', Project().get_fq_name())
    #end get_default_project_delete

    def logical_interface_create(self, obj):
        """Create new logical-interface.
        
        :param obj: :class:`.LogicalInterface` object
        
        """
        # Ignore fields with None value in json representation
        json_param = json.dumps(obj,
            default = lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        json_body = '{"logical-interface":' + json_param + '}'
        content = self._request_server(rest.OP_POST,
                       LogicalInterfaceClientGen.create_uri,
                       data = json_body)

        logical_interface_dict = json.loads(content)['logical-interface']
        obj.uuid = logical_interface_dict['uuid']
        if 'parent_uuid' in logical_interface_dict:
            obj.parent_uuid = logical_interface_dict['parent_uuid']

        return obj.uuid
    #end logical_interface_create

    def logical_interface_read(self, fq_name = None, fq_name_str = None, id = None, ifmap_id = None):
        """Return logical-interface information.
        
        :param fq_name: Fully qualified name of logical-interface
        :param fq_name_str: Fully qualified name string of logical-interface
        :param id: UUID of logical-interface
        :param ifmap_id: IFMAP id of logical-interface
        :returns: :class:`.LogicalInterface` object
        
        """
        (args_ok, result) = self._read_args_to_id('logical-interface', fq_name, fq_name_str, id, ifmap_id)
        if not args_ok:
            return result

        id = result
        uri = LogicalInterfaceClientGen.resource_uri_base['logical-interface'] + '/' + id

        content = self._request_server(rest.OP_GET, uri)

        obj_dict = json.loads(content)['logical-interface']
        obj_dict['name'] = obj_dict['fq_name'][-1]
        if obj_dict.has_key('id_perms'):
            prop_obj = IdPermsType(**obj_dict['id_perms'])
            obj_dict['id_perms'] = prop_obj

        # fill ref links
        # fill back ref links
        return LogicalInterface.factory(**obj_dict)
    #end logical_interface_read

    def logical_interface_update(self, obj):
        """Update logical-interface.
        
        :param obj: :class:`.LogicalInterface` object
        
        """
        # Read in uuid from api-server if not specified in obj
        if not obj.uuid:
            obj.uuid = self.fq_name_to_id('logical-interface', obj.get_fq_name())

        # Ignore fields with None value in json representation
        json_param = json.dumps(obj,
            default = lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        json_body = '{"logical-interface":' + json_param + '}'

        id = obj.uuid
        uri = LogicalInterfaceClientGen.resource_uri_base['logical-interface'] + '/' + id
        content = self._request_server(rest.OP_PUT, uri, data = json_body)
        return content
    #end logical_interface_update

    def logical_interfaces_list(self, parent_id = None, parent_fq_name = None):
        """List all logical-interfaces.
        
        :param parent_id: UUID of parent as optional search filter
        :param parent_fq_name: full qualified name of parent as optional search filter
        :returns: list of :class:`.LogicalInterface` objects
        
        """
        filt = None
        # TODO validate only one of id or name is given
        filt = {}
        if parent_fq_name:
            parent_fq_name_str = ':'.join(parent_fq_name)
            filt['parent_fq_name_str'] = parent_fq_name_str
        elif parent_id:
            filt['parent_id'] = parent_id
        content = self._request_server(rest.OP_GET,
                       LogicalInterfaceClientGen.create_uri,
                       data = filt)
        return content
    #end logical_interfaces_list

    def logical_interface_delete(self, fq_name = None, id = None, ifmap_id = None):
        """Delete logical-interface from the system.
        
        :param fq_name: Fully qualified name of logical-interface
        :param id: UUID of logical-interface
        :param ifmap_id: IFMAP id of logical-interface
        
        """
        (args_ok, result) = self._read_args_to_id(obj_type = 'logical-interface', fq_name = fq_name, id = id, ifmap_id = ifmap_id)
        if not args_ok:
            return result

        id = result
        uri = LogicalInterfaceClientGen.resource_uri_base['logical-interface'] + '/' + id

        content = self._request_server(rest.OP_DELETE, uri)
    #end logical_interface_delete

    def get_default_logical_interface_id(self):
        """Return UUID of default logical-interface."""
        return self.fq_name_to_id('logical-interface', LogicalInterface().get_fq_name())
    #end get_default_logical_interface_delete

    def routing_instance_create(self, obj):
        """Create new routing-instance.
        
        :param obj: :class:`.RoutingInstance` object
        
        """
        # Ignore fields with None value in json representation
        json_param = json.dumps(obj,
            default = lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        json_body = '{"routing-instance":' + json_param + '}'
        content = self._request_server(rest.OP_POST,
                       RoutingInstanceClientGen.create_uri,
                       data = json_body)

        routing_instance_dict = json.loads(content)['routing-instance']
        obj.uuid = routing_instance_dict['uuid']
        if 'parent_uuid' in routing_instance_dict:
            obj.parent_uuid = routing_instance_dict['parent_uuid']

        return obj.uuid
    #end routing_instance_create

    def routing_instance_read(self, fq_name = None, fq_name_str = None, id = None, ifmap_id = None):
        """Return routing-instance information.
        
        :param fq_name: Fully qualified name of routing-instance
        :param fq_name_str: Fully qualified name string of routing-instance
        :param id: UUID of routing-instance
        :param ifmap_id: IFMAP id of routing-instance
        :returns: :class:`.RoutingInstance` object
        
        """
        (args_ok, result) = self._read_args_to_id('routing-instance', fq_name, fq_name_str, id, ifmap_id)
        if not args_ok:
            return result

        id = result
        uri = RoutingInstanceClientGen.resource_uri_base['routing-instance'] + '/' + id

        content = self._request_server(rest.OP_GET, uri)

        obj_dict = json.loads(content)['routing-instance']
        obj_dict['name'] = obj_dict['fq_name'][-1]
        if obj_dict.has_key('static_route_entries'):
            prop_obj = StaticRouteEntriesType(**obj_dict['static_route_entries'])
            obj_dict['static_route_entries'] = prop_obj

        if obj_dict.has_key('service_chain_information'):
            prop_obj = ServiceChainInfo(**obj_dict['service_chain_information'])
            obj_dict['service_chain_information'] = prop_obj

        if obj_dict.has_key('default_ce_protocol'):
            prop_obj = DefaultProtocolType(**obj_dict['default_ce_protocol'])
            obj_dict['default_ce_protocol'] = prop_obj

        if obj_dict.has_key('id_perms'):
            prop_obj = IdPermsType(**obj_dict['id_perms'])
            obj_dict['id_perms'] = prop_obj

        # fill ref links
        if obj_dict.has_key('route_target_refs'):
            list_len = len(obj_dict['route_target_refs'])
            for idx in range(list_len):
                ref = obj_dict['route_target_refs'][idx]
                data_obj = InstanceTargetType(**ref['attr'])
                ref_dict = {}
                ref_dict['to'] = ref['to']
                ref_dict['attr'] = data_obj
                ref_dict['uuid'] = ref['uuid']
                ref_dict['href'] = ref['href']
                obj_dict['route_target_refs'][idx] = ref_dict

        # fill back ref links
        if obj_dict.has_key('virtual_machine_interface_back_refs'):
            list_len = len(obj_dict['virtual_machine_interface_back_refs'])
            for idx in range(list_len):
                back_ref = obj_dict['virtual_machine_interface_back_refs'][idx]
                data_obj = PolicyBasedForwardingRuleType(**back_ref['attr'])
                back_ref_dict = {}
                back_ref_dict['to'] = back_ref['to']
                back_ref_dict['attr'] = data_obj
                back_ref_dict['uuid'] = back_ref['uuid']
                back_ref_dict['href'] = back_ref['href']
                obj_dict['virtual_machine_interface_back_refs'][idx] = back_ref_dict

        return RoutingInstance.factory(**obj_dict)
    #end routing_instance_read

    def routing_instance_update(self, obj):
        """Update routing-instance.
        
        :param obj: :class:`.RoutingInstance` object
        
        """
        # Read in uuid from api-server if not specified in obj
        if not obj.uuid:
            obj.uuid = self.fq_name_to_id('routing-instance', obj.get_fq_name())

        # Ignore fields with None value in json representation
        json_param = json.dumps(obj,
            default = lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        json_body = '{"routing-instance":' + json_param + '}'

        id = obj.uuid
        uri = RoutingInstanceClientGen.resource_uri_base['routing-instance'] + '/' + id
        content = self._request_server(rest.OP_PUT, uri, data = json_body)
        return content
    #end routing_instance_update

    def routing_instances_list(self, parent_id = None, parent_fq_name = None):
        """List all routing-instances.
        
        :param parent_id: UUID of parent as optional search filter
        :param parent_fq_name: full qualified name of parent as optional search filter
        :returns: list of :class:`.RoutingInstance` objects
        
        """
        filt = None
        # TODO validate only one of id or name is given
        filt = {}
        if parent_fq_name:
            parent_fq_name_str = ':'.join(parent_fq_name)
            filt['parent_fq_name_str'] = parent_fq_name_str
        elif parent_id:
            filt['parent_id'] = parent_id
        content = self._request_server(rest.OP_GET,
                       RoutingInstanceClientGen.create_uri,
                       data = filt)
        return content
    #end routing_instances_list

    def routing_instance_delete(self, fq_name = None, id = None, ifmap_id = None):
        """Delete routing-instance from the system.
        
        :param fq_name: Fully qualified name of routing-instance
        :param id: UUID of routing-instance
        :param ifmap_id: IFMAP id of routing-instance
        
        """
        (args_ok, result) = self._read_args_to_id(obj_type = 'routing-instance', fq_name = fq_name, id = id, ifmap_id = ifmap_id)
        if not args_ok:
            return result

        id = result
        uri = RoutingInstanceClientGen.resource_uri_base['routing-instance'] + '/' + id

        content = self._request_server(rest.OP_DELETE, uri)
    #end routing_instance_delete

    def get_default_routing_instance_id(self):
        """Return UUID of default routing-instance."""
        return self.fq_name_to_id('routing-instance', RoutingInstance().get_fq_name())
    #end get_default_routing_instance_delete

    def virtual_machine_interface_create(self, obj):
        """Create new virtual-machine-interface.
        
        :param obj: :class:`.VirtualMachineInterface` object
        
        """
        # Ignore fields with None value in json representation
        json_param = json.dumps(obj,
            default = lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        json_body = '{"virtual-machine-interface":' + json_param + '}'
        content = self._request_server(rest.OP_POST,
                       VirtualMachineInterfaceClientGen.create_uri,
                       data = json_body)

        virtual_machine_interface_dict = json.loads(content)['virtual-machine-interface']
        obj.uuid = virtual_machine_interface_dict['uuid']
        if 'parent_uuid' in virtual_machine_interface_dict:
            obj.parent_uuid = virtual_machine_interface_dict['parent_uuid']

        return obj.uuid
    #end virtual_machine_interface_create

    def virtual_machine_interface_read(self, fq_name = None, fq_name_str = None, id = None, ifmap_id = None):
        """Return virtual-machine-interface information.
        
        :param fq_name: Fully qualified name of virtual-machine-interface
        :param fq_name_str: Fully qualified name string of virtual-machine-interface
        :param id: UUID of virtual-machine-interface
        :param ifmap_id: IFMAP id of virtual-machine-interface
        :returns: :class:`.VirtualMachineInterface` object
        
        """
        (args_ok, result) = self._read_args_to_id('virtual-machine-interface', fq_name, fq_name_str, id, ifmap_id)
        if not args_ok:
            return result

        id = result
        uri = VirtualMachineInterfaceClientGen.resource_uri_base['virtual-machine-interface'] + '/' + id

        content = self._request_server(rest.OP_GET, uri)

        obj_dict = json.loads(content)['virtual-machine-interface']
        obj_dict['name'] = obj_dict['fq_name'][-1]
        if obj_dict.has_key('virtual_machine_interface_mac_addresses'):
            prop_obj = MacAddressesType(**obj_dict['virtual_machine_interface_mac_addresses'])
            obj_dict['virtual_machine_interface_mac_addresses'] = prop_obj

        if obj_dict.has_key('virtual_machine_interface_properties'):
            prop_obj = VirtualMachineInterfacePropertiesType(**obj_dict['virtual_machine_interface_properties'])
            obj_dict['virtual_machine_interface_properties'] = prop_obj

        if obj_dict.has_key('id_perms'):
            prop_obj = IdPermsType(**obj_dict['id_perms'])
            obj_dict['id_perms'] = prop_obj

        # fill ref links
        if obj_dict.has_key('routing_instance_refs'):
            list_len = len(obj_dict['routing_instance_refs'])
            for idx in range(list_len):
                ref = obj_dict['routing_instance_refs'][idx]
                data_obj = PolicyBasedForwardingRuleType(**ref['attr'])
                ref_dict = {}
                ref_dict['to'] = ref['to']
                ref_dict['attr'] = data_obj
                ref_dict['uuid'] = ref['uuid']
                ref_dict['href'] = ref['href']
                obj_dict['routing_instance_refs'][idx] = ref_dict

        # fill back ref links
        return VirtualMachineInterface.factory(**obj_dict)
    #end virtual_machine_interface_read

    def virtual_machine_interface_update(self, obj):
        """Update virtual-machine-interface.
        
        :param obj: :class:`.VirtualMachineInterface` object
        
        """
        # Read in uuid from api-server if not specified in obj
        if not obj.uuid:
            obj.uuid = self.fq_name_to_id('virtual-machine-interface', obj.get_fq_name())

        # Ignore fields with None value in json representation
        json_param = json.dumps(obj,
            default = lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        json_body = '{"virtual-machine-interface":' + json_param + '}'

        id = obj.uuid
        uri = VirtualMachineInterfaceClientGen.resource_uri_base['virtual-machine-interface'] + '/' + id
        content = self._request_server(rest.OP_PUT, uri, data = json_body)
        return content
    #end virtual_machine_interface_update

    def virtual_machine_interfaces_list(self, parent_id = None, parent_fq_name = None):
        """List all virtual-machine-interfaces.
        
        :param parent_id: UUID of parent as optional search filter
        :param parent_fq_name: full qualified name of parent as optional search filter
        :returns: list of :class:`.VirtualMachineInterface` objects
        
        """
        filt = None
        # TODO validate only one of id or name is given
        filt = {}
        if parent_fq_name:
            parent_fq_name_str = ':'.join(parent_fq_name)
            filt['parent_fq_name_str'] = parent_fq_name_str
        elif parent_id:
            filt['parent_id'] = parent_id
        content = self._request_server(rest.OP_GET,
                       VirtualMachineInterfaceClientGen.create_uri,
                       data = filt)
        return content
    #end virtual_machine_interfaces_list

    def virtual_machine_interface_delete(self, fq_name = None, id = None, ifmap_id = None):
        """Delete virtual-machine-interface from the system.
        
        :param fq_name: Fully qualified name of virtual-machine-interface
        :param id: UUID of virtual-machine-interface
        :param ifmap_id: IFMAP id of virtual-machine-interface
        
        """
        (args_ok, result) = self._read_args_to_id(obj_type = 'virtual-machine-interface', fq_name = fq_name, id = id, ifmap_id = ifmap_id)
        if not args_ok:
            return result

        id = result
        uri = VirtualMachineInterfaceClientGen.resource_uri_base['virtual-machine-interface'] + '/' + id

        content = self._request_server(rest.OP_DELETE, uri)
    #end virtual_machine_interface_delete

    def get_default_virtual_machine_interface_id(self):
        """Return UUID of default virtual-machine-interface."""
        return self.fq_name_to_id('virtual-machine-interface', VirtualMachineInterface().get_fq_name())
    #end get_default_virtual_machine_interface_delete

#end class VncApiClientGen

    prop_name_to_xsd_type = {
        "domain-limits":"DomainLimitsType",
        "virtual-DNS-data":"VirtualDnsType",
        "service-template-properties":"ServiceTemplateType",
        "default-ce-protocol":"DefaultProtocolType",
        "api-access-list":"ApiAccessListType",
        "namespace-cidr":"SubnetType",
        "network-policy-entries":"PolicyEntriesType",
        "access-control-list-entries":"AclEntriesType",
        "virtual-machine-interface-properties":"VirtualMachineInterfacePropertiesType",
        "virtual-network-properties":"VirtualNetworkType",
        "attachment-address":"AttachmentAddressType",
        "bgp-router-parameters":"BgpRouterParams",
        "route-table":"RouteTableType",
        "route-target-list":"RouteTargetList",
        "virtual-DNS-record-data":"VirtualDnsRecordType",
        "service-instance-properties":"ServiceInstanceType",
        "virtual-machine-interface-mac-addresses":"MacAddressesType",
        "security-group-entries":"PolicyEntriesType",
        "service-chain-information":"ServiceChainInfo",
        "static-route-entries":"StaticRouteEntriesType",
        "id-perms":"IdPermsType",
        "floating-ip-pool-prefixes":"FloatingIpPoolType",
        "network-ipam-mgmt":"IpamType"
        }

ConnectionDriverBase.register (VncApiClientGen)

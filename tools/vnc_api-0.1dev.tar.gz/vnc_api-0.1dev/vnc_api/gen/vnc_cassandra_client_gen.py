
# AUTO-GENERATED file from IFMapApiGenerator. Do Not Edit!

import re
import json
import pycassa
import datetime
from operator import itemgetter
import common.exceptions

class VncCassandraClientGen(object):
    def __init__(self):
        self._db_client_mgr = None
    #end __init__

    def _cassandra_domain_alloc(self, fq_name):
        return (True, '')
    #end _cassandra_domain_alloc

    def _cassandra_domain_create(self, obj_ids, obj_dict):
        # Gather column values for obj and updates to backrefs
        # in a batch and write it at the end
        bch = self._obj_uuid_cf.batch()

        obj_cols = {}
        obj_cols['fq_name'] = json.dumps(obj_dict['fq_name'])
        obj_cols['type'] = json.dumps('domain')
        if 'parent_type' in obj_dict:
            # non config-root child
            parent_type = obj_dict['parent_type']
            parent_method_type = parent_type.replace('-', '_')
            parent_fq_name = obj_dict['fq_name'][:-1]
            obj_cols['parent_type'] = json.dumps(parent_type)
            parent_uuid = self.fq_name_to_uuid(parent_method_type, parent_fq_name)
            self._create_child(bch, parent_method_type, parent_uuid, 'domain', obj_ids['uuid'])

        # Properties
        field = obj_dict.get('domain_limits', None)
        if field:
            self._create_prop(bch, obj_ids['uuid'], 'domain_limits', field)

        field = obj_dict.get('api_access_list', None)
        if field:
            self._create_prop(bch, obj_ids['uuid'], 'api_access_list', field)

        field = obj_dict.get('id_perms', None)
        field['created'] = datetime.datetime.now().isoformat()
        field['last_modified'] = field['created']
        if field:
            self._create_prop(bch, obj_ids['uuid'], 'id_perms', field)


        # References

        bch.insert(obj_ids['uuid'], obj_cols)
        bch.send()

        # Update fqname table
        fq_name_str = ':'.join(obj_dict['fq_name'])
        fq_name_cols = {fq_name_str + ':' + obj_ids['uuid']: json.dumps(None)}
        self._obj_fq_name_cf.insert('domain', fq_name_cols)

        return (True, '')
    #end _cassandra_domain_create

    def _cassandra_domain_read(self, obj_uuid, field_names = None):
        obj_uuid_cf = self._obj_uuid_cf
        obj_cols_iter = obj_uuid_cf.xget(obj_uuid, include_timestamp = True)
        # TODO optimize this if needed
        obj_cols = {}
        for col in obj_cols_iter:
            # col-name = value + tstamp
            obj_cols[col[0]] = {'value': col[1][0], 'tstamp': col[1][1]}
            # TODO use compile RE
            if re.match('parent:', col[0]):
                (_, _, parent_uuid) = col[0].split(':')

        if not obj_cols:
            raise common.exceptions.NoIdError(obj_uuid)

        result = {}
        # Name info
        result['fq_name'] = json.loads(obj_cols['fq_name']['value'])
        if 'parent_type' in obj_cols:
            # non config-root child
            parent_type = json.loads(obj_cols['parent_type']['value'])
            result['parent_type'] = parent_type
            try:
                result['parent_uuid'] = parent_uuid
                result['parent_href'] = self._db_client_mgr.generate_url(parent_type, parent_uuid)
            except common.exceptions.NoIdError:
                err_msg = 'Unknown uuid for parent ' + result['fq_name'][-2]
                return (False, err_msg)

        for col_name in obj_cols.keys():
            # TODO use compiled RE
            if re.match('prop:', col_name):
                (_, prop_name) = col_name.split(':')
                result[prop_name] = json.loads(obj_cols[col_name]['value'])

            # TODO use compiled RE
            if re.match('children:', col_name):
                (_, child_type, child_uuid) = col_name.split(':')
                child_tstamp = obj_cols[col_name]['tstamp']
                try:
                    self._read_child(result, obj_uuid, child_type, child_uuid, child_tstamp)
                except common.exceptions.NoIdError:
                    continue

            # TODO use compiled RE
            if re.match('ref:', col_name):
                (_, ref_type, ref_uuid) = col_name.split(':')
                self._read_ref(result, obj_uuid, ref_type, ref_uuid, obj_cols[col_name]['value'])

            if re.match('backref:', col_name):
                (_, back_ref_type, back_ref_uuid) = col_name.split(':')
                try:
                    self._read_back_ref(result, obj_uuid, back_ref_type, back_ref_uuid, \
                                        obj_cols[col_name]['value'])
                except common.exceptions.NoIdError:
                    continue

        # for all column names

        if 'projects' in result:
            # sort children; TODO do this based on schema
            sorted_children = sorted(result['projects'], key = itemgetter('tstamp'))
            # re-write result's children without timestamp
            result['projects'] = sorted_children
            [child.pop('tstamp') for child in result['projects']]

        if 'namespaces' in result:
            # sort children; TODO do this based on schema
            sorted_children = sorted(result['namespaces'], key = itemgetter('tstamp'))
            # re-write result's children without timestamp
            result['namespaces'] = sorted_children
            [child.pop('tstamp') for child in result['namespaces']]

        if 'service_templates' in result:
            # sort children; TODO do this based on schema
            sorted_children = sorted(result['service_templates'], key = itemgetter('tstamp'))
            # re-write result's children without timestamp
            result['service_templates'] = sorted_children
            [child.pop('tstamp') for child in result['service_templates']]

        if 'virtual_DNSs' in result:
            # sort children; TODO do this based on schema
            sorted_children = sorted(result['virtual_DNSs'], key = itemgetter('tstamp'))
            # re-write result's children without timestamp
            result['virtual_DNSs'] = sorted_children
            [child.pop('tstamp') for child in result['virtual_DNSs']]


        return (True, result)
    #end _cassandra_domain_read

    def _cassandra_domain_update(self, obj_uuid, dummy_old_obj_dict, new_obj_dict):
        # Grab ref-uuids and properties in new version
        new_ref_infos = {}

        new_props = {}
        if 'domain_limits' in new_obj_dict:
            new_props['domain_limits'] = new_obj_dict['domain_limits']
        if 'api_access_list' in new_obj_dict:
            new_props['api_access_list'] = new_obj_dict['api_access_list']
        if 'id_perms' in new_obj_dict:
            new_props['id_perms'] = new_obj_dict['id_perms']
        # Gather column values for obj and updates to backrefs
        # in a batch and write it at the end
        obj_uuid_cf = self._obj_uuid_cf
        obj_cols_iter = obj_uuid_cf.xget(obj_uuid)
        # TODO optimize this (converts tuple to dict)
        obj_cols = {}
        for col_info in obj_cols_iter:
            obj_cols[col_info[0]] = col_info[1]

        bch = obj_uuid_cf.batch()
        for col_name in obj_cols.keys():
            # TODO use compiled RE
            if re.match('prop:', col_name):
                (_, prop_name) = col_name.split(':')
                if prop_name == 'id_perms':
                    # id-perms always has to be updated for last-mod timestamp
                    # get it from request dict(or from db if not in request dict)
                    new_id_perms = new_obj_dict.get(prop_name, json.loads(obj_cols[col_name]))
                    new_id_perms['last_modified'] = datetime.datetime.now().isoformat()
                    new_props['id_perms'] = new_id_perms
                    self._update_prop(bch, obj_uuid, 'id_perms', new_props)
                elif prop_name in new_obj_dict:
                    self._update_prop(bch, obj_uuid, prop_name, new_props)

            # TODO use compiled RE
            if re.match('ref:', col_name):
                (_, ref_type, ref_uuid) = col_name.split(':')
                self._update_ref(bch, 'domain', obj_uuid, ref_type, ref_uuid, new_ref_infos)
        # for all column names

        # create new refs
        for ref_type in new_ref_infos.keys():
            for ref_uuid in new_ref_infos[ref_type].keys():
                ref_data = new_ref_infos[ref_type][ref_uuid]
                self._create_ref(bch, 'domain', obj_uuid, ref_type, ref_uuid, ref_data)

        # create new props
        for prop_name in new_props.keys():
            self._create_prop(bch, obj_uuid, prop_name, new_props[prop_name])

        bch.send()

        return (True, '')
    #end _cassandra_domain_update

    def _cassandra_domain_list(self, parent_uuid):
        children_fq_names = []
        if not parent_uuid:
            # grab all resources of this type
            obj_fq_name_cf = self._obj_fq_name_cf
            col_name_iter = obj_fq_name_cf.xget('domain')
            for (col_name, col_val) in col_name_iter:
                fq_name = col_name.split(':')[:-1]
                children_fq_names.append(fq_name)
        else:
            # go from parent to child
            obj_uuid_cf = self._obj_uuid_cf
            col_start = 'children:domain:'
            col_fin = 'children:domain;'
            col_name_iter = obj_uuid_cf.xget(parent_uuid, column_start = col_start, \
                                column_finish = col_fin, include_timestamp = True)

            unsorted_fq_names = []
            for col in col_name_iter:
                col_name = col[0]
                col_val_ts = col[1]
                child_uuid = col_name.split(':')[2]
                child_fq_name = self.uuid_to_fq_name(child_uuid)
                tstamp = col_val_ts[1]
                unsorted_fq_names.append({'fq_name': child_fq_name, 'tstamp': tstamp})

                # sort children; TODO do this based on schema
                sorted_children = sorted(unsorted_fq_names, key = itemgetter('tstamp'))
                # re-write result's children without timestamp
                children_fq_names = [child['fq_name'] for child in sorted_children]

        return (True, children_fq_names)
    #end _cassandra_domain_list

    def _cassandra_domain_delete(self, obj_uuid):
        obj_uuid_cf = self._obj_uuid_cf
        fq_name = json.loads(obj_uuid_cf.get(obj_uuid, columns = ['fq_name'])['fq_name'])
        bch = obj_uuid_cf.batch()

        # unlink from parent
        col_start = 'parent:'
        col_fin = 'parent;'
        col_name_iter = obj_uuid_cf.xget(obj_uuid, column_start = col_start, column_finish = col_fin)
        for (col_name, col_val) in col_name_iter:
            (_, parent_type, parent_uuid) = col_name.split(':')
            self._delete_child(bch, parent_type, parent_uuid, 'domain', obj_uuid)

        # remove refs
        col_start = 'ref:'
        col_fin = 'ref;'
        col_name_iter = obj_uuid_cf.xget(obj_uuid, column_start = col_start, column_finish = col_fin)
        for (col_name, col_val) in col_name_iter:
            (_, ref_type, ref_uuid) = col_name.split(':')
            self._delete_ref(bch, 'domain', obj_uuid, ref_type, ref_uuid)

        bch.remove(obj_uuid)
        bch.send()

        # Update fqname table
        fq_name_str = ':'.join(fq_name)
        fq_name_col = fq_name_str + ':' + obj_uuid
        self._obj_fq_name_cf.remove('domain', columns = [fq_name_col])


        return (True, '')
    #end _cassandra_domain_delete

    def _cassandra_service_instance_alloc(self, fq_name):
        return (True, '')
    #end _cassandra_service_instance_alloc

    def _cassandra_service_instance_create(self, obj_ids, obj_dict):
        # Gather column values for obj and updates to backrefs
        # in a batch and write it at the end
        bch = self._obj_uuid_cf.batch()

        obj_cols = {}
        obj_cols['fq_name'] = json.dumps(obj_dict['fq_name'])
        obj_cols['type'] = json.dumps('service_instance')
        if 'parent_type' in obj_dict:
            # non config-root child
            parent_type = obj_dict['parent_type']
            parent_method_type = parent_type.replace('-', '_')
            parent_fq_name = obj_dict['fq_name'][:-1]
            obj_cols['parent_type'] = json.dumps(parent_type)
            parent_uuid = self.fq_name_to_uuid(parent_method_type, parent_fq_name)
            self._create_child(bch, parent_method_type, parent_uuid, 'service_instance', obj_ids['uuid'])

        # Properties
        field = obj_dict.get('service_instance_properties', None)
        if field:
            self._create_prop(bch, obj_ids['uuid'], 'service_instance_properties', field)

        field = obj_dict.get('id_perms', None)
        field['created'] = datetime.datetime.now().isoformat()
        field['last_modified'] = field['created']
        if field:
            self._create_prop(bch, obj_ids['uuid'], 'id_perms', field)


        # References
        refs = obj_dict.get('service_template_refs', [])
        for ref in refs:
            ref_uuid = self.fq_name_to_uuid('service_template', ref['to'])
            ref_attr = ref.get('attr', None)
            ref_data = {'attr': ref_attr, 'is_weakref': False}
            self._create_ref(bch, 'service_instance', obj_ids['uuid'], 'service_template', ref_uuid, ref_data)

        bch.insert(obj_ids['uuid'], obj_cols)
        bch.send()

        # Update fqname table
        fq_name_str = ':'.join(obj_dict['fq_name'])
        fq_name_cols = {fq_name_str + ':' + obj_ids['uuid']: json.dumps(None)}
        self._obj_fq_name_cf.insert('service_instance', fq_name_cols)

        return (True, '')
    #end _cassandra_service_instance_create

    def _cassandra_service_instance_read(self, obj_uuid, field_names = None):
        obj_uuid_cf = self._obj_uuid_cf
        obj_cols_iter = obj_uuid_cf.xget(obj_uuid, include_timestamp = True)
        # TODO optimize this if needed
        obj_cols = {}
        for col in obj_cols_iter:
            # col-name = value + tstamp
            obj_cols[col[0]] = {'value': col[1][0], 'tstamp': col[1][1]}
            # TODO use compile RE
            if re.match('parent:', col[0]):
                (_, _, parent_uuid) = col[0].split(':')

        if not obj_cols:
            raise common.exceptions.NoIdError(obj_uuid)

        result = {}
        # Name info
        result['fq_name'] = json.loads(obj_cols['fq_name']['value'])
        if 'parent_type' in obj_cols:
            # non config-root child
            parent_type = json.loads(obj_cols['parent_type']['value'])
            result['parent_type'] = parent_type
            try:
                result['parent_uuid'] = parent_uuid
                result['parent_href'] = self._db_client_mgr.generate_url(parent_type, parent_uuid)
            except common.exceptions.NoIdError:
                err_msg = 'Unknown uuid for parent ' + result['fq_name'][-2]
                return (False, err_msg)

        for col_name in obj_cols.keys():
            # TODO use compiled RE
            if re.match('prop:', col_name):
                (_, prop_name) = col_name.split(':')
                result[prop_name] = json.loads(obj_cols[col_name]['value'])

            # TODO use compiled RE
            if re.match('children:', col_name):
                (_, child_type, child_uuid) = col_name.split(':')
                child_tstamp = obj_cols[col_name]['tstamp']
                try:
                    self._read_child(result, obj_uuid, child_type, child_uuid, child_tstamp)
                except common.exceptions.NoIdError:
                    continue

            # TODO use compiled RE
            if re.match('ref:', col_name):
                (_, ref_type, ref_uuid) = col_name.split(':')
                self._read_ref(result, obj_uuid, ref_type, ref_uuid, obj_cols[col_name]['value'])

            if re.match('backref:', col_name):
                (_, back_ref_type, back_ref_uuid) = col_name.split(':')
                try:
                    self._read_back_ref(result, obj_uuid, back_ref_type, back_ref_uuid, \
                                        obj_cols[col_name]['value'])
                except common.exceptions.NoIdError:
                    continue

        # for all column names


        return (True, result)
    #end _cassandra_service_instance_read

    def _cassandra_service_instance_update(self, obj_uuid, dummy_old_obj_dict, new_obj_dict):
        # Grab ref-uuids and properties in new version
        new_ref_infos = {}

        if 'service_template_refs' in new_obj_dict:
            new_ref_infos['service_template'] = {}
            new_refs = new_obj_dict['service_template_refs']
            if new_refs:
                for new_ref in new_refs:
                    new_ref_uuid = self.fq_name_to_uuid('service_template', new_ref['to'])
                    new_ref_attr = new_ref.get('attr', None)
                    new_ref_data = {'attr': new_ref_attr, 'is_weakref': False}
                    new_ref_infos['service_template'][new_ref_uuid] = new_ref_data

        new_props = {}
        if 'service_instance_properties' in new_obj_dict:
            new_props['service_instance_properties'] = new_obj_dict['service_instance_properties']
        if 'id_perms' in new_obj_dict:
            new_props['id_perms'] = new_obj_dict['id_perms']
        # Gather column values for obj and updates to backrefs
        # in a batch and write it at the end
        obj_uuid_cf = self._obj_uuid_cf
        obj_cols_iter = obj_uuid_cf.xget(obj_uuid)
        # TODO optimize this (converts tuple to dict)
        obj_cols = {}
        for col_info in obj_cols_iter:
            obj_cols[col_info[0]] = col_info[1]

        bch = obj_uuid_cf.batch()
        for col_name in obj_cols.keys():
            # TODO use compiled RE
            if re.match('prop:', col_name):
                (_, prop_name) = col_name.split(':')
                if prop_name == 'id_perms':
                    # id-perms always has to be updated for last-mod timestamp
                    # get it from request dict(or from db if not in request dict)
                    new_id_perms = new_obj_dict.get(prop_name, json.loads(obj_cols[col_name]))
                    new_id_perms['last_modified'] = datetime.datetime.now().isoformat()
                    new_props['id_perms'] = new_id_perms
                    self._update_prop(bch, obj_uuid, 'id_perms', new_props)
                elif prop_name in new_obj_dict:
                    self._update_prop(bch, obj_uuid, prop_name, new_props)

            # TODO use compiled RE
            if re.match('ref:', col_name):
                (_, ref_type, ref_uuid) = col_name.split(':')
                self._update_ref(bch, 'service_instance', obj_uuid, ref_type, ref_uuid, new_ref_infos)
        # for all column names

        # create new refs
        for ref_type in new_ref_infos.keys():
            for ref_uuid in new_ref_infos[ref_type].keys():
                ref_data = new_ref_infos[ref_type][ref_uuid]
                self._create_ref(bch, 'service_instance', obj_uuid, ref_type, ref_uuid, ref_data)

        # create new props
        for prop_name in new_props.keys():
            self._create_prop(bch, obj_uuid, prop_name, new_props[prop_name])

        bch.send()

        return (True, '')
    #end _cassandra_service_instance_update

    def _cassandra_service_instance_list(self, parent_uuid):
        children_fq_names = []
        if not parent_uuid:
            # grab all resources of this type
            obj_fq_name_cf = self._obj_fq_name_cf
            col_name_iter = obj_fq_name_cf.xget('service_instance')
            for (col_name, col_val) in col_name_iter:
                fq_name = col_name.split(':')[:-1]
                children_fq_names.append(fq_name)
        else:
            # go from parent to child
            obj_uuid_cf = self._obj_uuid_cf
            col_start = 'children:service_instance:'
            col_fin = 'children:service_instance;'
            col_name_iter = obj_uuid_cf.xget(parent_uuid, column_start = col_start, \
                                column_finish = col_fin, include_timestamp = True)

            unsorted_fq_names = []
            for col in col_name_iter:
                col_name = col[0]
                col_val_ts = col[1]
                child_uuid = col_name.split(':')[2]
                child_fq_name = self.uuid_to_fq_name(child_uuid)
                tstamp = col_val_ts[1]
                unsorted_fq_names.append({'fq_name': child_fq_name, 'tstamp': tstamp})

                # sort children; TODO do this based on schema
                sorted_children = sorted(unsorted_fq_names, key = itemgetter('tstamp'))
                # re-write result's children without timestamp
                children_fq_names = [child['fq_name'] for child in sorted_children]

        return (True, children_fq_names)
    #end _cassandra_service_instance_list

    def _cassandra_service_instance_delete(self, obj_uuid):
        obj_uuid_cf = self._obj_uuid_cf
        fq_name = json.loads(obj_uuid_cf.get(obj_uuid, columns = ['fq_name'])['fq_name'])
        bch = obj_uuid_cf.batch()

        # unlink from parent
        col_start = 'parent:'
        col_fin = 'parent;'
        col_name_iter = obj_uuid_cf.xget(obj_uuid, column_start = col_start, column_finish = col_fin)
        for (col_name, col_val) in col_name_iter:
            (_, parent_type, parent_uuid) = col_name.split(':')
            self._delete_child(bch, parent_type, parent_uuid, 'service_instance', obj_uuid)

        # remove refs
        col_start = 'ref:'
        col_fin = 'ref;'
        col_name_iter = obj_uuid_cf.xget(obj_uuid, column_start = col_start, column_finish = col_fin)
        for (col_name, col_val) in col_name_iter:
            (_, ref_type, ref_uuid) = col_name.split(':')
            self._delete_ref(bch, 'service_instance', obj_uuid, ref_type, ref_uuid)

        bch.remove(obj_uuid)
        bch.send()

        # Update fqname table
        fq_name_str = ':'.join(fq_name)
        fq_name_col = fq_name_str + ':' + obj_uuid
        self._obj_fq_name_cf.remove('service_instance', columns = [fq_name_col])


        return (True, '')
    #end _cassandra_service_instance_delete

    def _cassandra_instance_ip_alloc(self, fq_name):
        return (True, '')
    #end _cassandra_instance_ip_alloc

    def _cassandra_instance_ip_create(self, obj_ids, obj_dict):
        # Gather column values for obj and updates to backrefs
        # in a batch and write it at the end
        bch = self._obj_uuid_cf.batch()

        obj_cols = {}
        obj_cols['fq_name'] = json.dumps(obj_dict['fq_name'])
        obj_cols['type'] = json.dumps('instance_ip')

        # Properties
        field = obj_dict.get('instance_ip_address', None)
        if field:
            self._create_prop(bch, obj_ids['uuid'], 'instance_ip_address', field)

        field = obj_dict.get('id_perms', None)
        field['created'] = datetime.datetime.now().isoformat()
        field['last_modified'] = field['created']
        if field:
            self._create_prop(bch, obj_ids['uuid'], 'id_perms', field)


        # References
        refs = obj_dict.get('virtual_network_refs', [])
        for ref in refs:
            ref_uuid = self.fq_name_to_uuid('virtual_network', ref['to'])
            ref_attr = ref.get('attr', None)
            ref_data = {'attr': ref_attr, 'is_weakref': False}
            self._create_ref(bch, 'instance_ip', obj_ids['uuid'], 'virtual_network', ref_uuid, ref_data)
        refs = obj_dict.get('virtual_machine_interface_refs', [])
        for ref in refs:
            ref_uuid = self.fq_name_to_uuid('virtual_machine_interface', ref['to'])
            ref_attr = ref.get('attr', None)
            ref_data = {'attr': ref_attr, 'is_weakref': False}
            self._create_ref(bch, 'instance_ip', obj_ids['uuid'], 'virtual_machine_interface', ref_uuid, ref_data)

        bch.insert(obj_ids['uuid'], obj_cols)
        bch.send()

        # Update fqname table
        fq_name_str = ':'.join(obj_dict['fq_name'])
        fq_name_cols = {fq_name_str + ':' + obj_ids['uuid']: json.dumps(None)}
        self._obj_fq_name_cf.insert('instance_ip', fq_name_cols)

        return (True, '')
    #end _cassandra_instance_ip_create

    def _cassandra_instance_ip_read(self, obj_uuid, field_names = None):
        obj_uuid_cf = self._obj_uuid_cf
        obj_cols_iter = obj_uuid_cf.xget(obj_uuid, include_timestamp = True)
        # TODO optimize this if needed
        obj_cols = {}
        for col in obj_cols_iter:
            # col-name = value + tstamp
            obj_cols[col[0]] = {'value': col[1][0], 'tstamp': col[1][1]}
            # TODO use compile RE
            if re.match('parent:', col[0]):
                (_, _, parent_uuid) = col[0].split(':')

        if not obj_cols:
            raise common.exceptions.NoIdError(obj_uuid)

        result = {}
        # Name info
        result['fq_name'] = json.loads(obj_cols['fq_name']['value'])

        for col_name in obj_cols.keys():
            # TODO use compiled RE
            if re.match('prop:', col_name):
                (_, prop_name) = col_name.split(':')
                result[prop_name] = json.loads(obj_cols[col_name]['value'])

            # TODO use compiled RE
            if re.match('children:', col_name):
                (_, child_type, child_uuid) = col_name.split(':')
                child_tstamp = obj_cols[col_name]['tstamp']
                try:
                    self._read_child(result, obj_uuid, child_type, child_uuid, child_tstamp)
                except common.exceptions.NoIdError:
                    continue

            # TODO use compiled RE
            if re.match('ref:', col_name):
                (_, ref_type, ref_uuid) = col_name.split(':')
                self._read_ref(result, obj_uuid, ref_type, ref_uuid, obj_cols[col_name]['value'])

            if re.match('backref:', col_name):
                (_, back_ref_type, back_ref_uuid) = col_name.split(':')
                try:
                    self._read_back_ref(result, obj_uuid, back_ref_type, back_ref_uuid, \
                                        obj_cols[col_name]['value'])
                except common.exceptions.NoIdError:
                    continue

        # for all column names


        return (True, result)
    #end _cassandra_instance_ip_read

    def _cassandra_instance_ip_update(self, obj_uuid, dummy_old_obj_dict, new_obj_dict):
        # Grab ref-uuids and properties in new version
        new_ref_infos = {}

        if 'virtual_network_refs' in new_obj_dict:
            new_ref_infos['virtual_network'] = {}
            new_refs = new_obj_dict['virtual_network_refs']
            if new_refs:
                for new_ref in new_refs:
                    new_ref_uuid = self.fq_name_to_uuid('virtual_network', new_ref['to'])
                    new_ref_attr = new_ref.get('attr', None)
                    new_ref_data = {'attr': new_ref_attr, 'is_weakref': False}
                    new_ref_infos['virtual_network'][new_ref_uuid] = new_ref_data

        if 'virtual_machine_interface_refs' in new_obj_dict:
            new_ref_infos['virtual_machine_interface'] = {}
            new_refs = new_obj_dict['virtual_machine_interface_refs']
            if new_refs:
                for new_ref in new_refs:
                    new_ref_uuid = self.fq_name_to_uuid('virtual_machine_interface', new_ref['to'])
                    new_ref_attr = new_ref.get('attr', None)
                    new_ref_data = {'attr': new_ref_attr, 'is_weakref': False}
                    new_ref_infos['virtual_machine_interface'][new_ref_uuid] = new_ref_data

        new_props = {}
        if 'instance_ip_address' in new_obj_dict:
            new_props['instance_ip_address'] = new_obj_dict['instance_ip_address']
        if 'id_perms' in new_obj_dict:
            new_props['id_perms'] = new_obj_dict['id_perms']
        # Gather column values for obj and updates to backrefs
        # in a batch and write it at the end
        obj_uuid_cf = self._obj_uuid_cf
        obj_cols_iter = obj_uuid_cf.xget(obj_uuid)
        # TODO optimize this (converts tuple to dict)
        obj_cols = {}
        for col_info in obj_cols_iter:
            obj_cols[col_info[0]] = col_info[1]

        bch = obj_uuid_cf.batch()
        for col_name in obj_cols.keys():
            # TODO use compiled RE
            if re.match('prop:', col_name):
                (_, prop_name) = col_name.split(':')
                if prop_name == 'id_perms':
                    # id-perms always has to be updated for last-mod timestamp
                    # get it from request dict(or from db if not in request dict)
                    new_id_perms = new_obj_dict.get(prop_name, json.loads(obj_cols[col_name]))
                    new_id_perms['last_modified'] = datetime.datetime.now().isoformat()
                    new_props['id_perms'] = new_id_perms
                    self._update_prop(bch, obj_uuid, 'id_perms', new_props)
                elif prop_name in new_obj_dict:
                    self._update_prop(bch, obj_uuid, prop_name, new_props)

            # TODO use compiled RE
            if re.match('ref:', col_name):
                (_, ref_type, ref_uuid) = col_name.split(':')
                self._update_ref(bch, 'instance_ip', obj_uuid, ref_type, ref_uuid, new_ref_infos)
        # for all column names

        # create new refs
        for ref_type in new_ref_infos.keys():
            for ref_uuid in new_ref_infos[ref_type].keys():
                ref_data = new_ref_infos[ref_type][ref_uuid]
                self._create_ref(bch, 'instance_ip', obj_uuid, ref_type, ref_uuid, ref_data)

        # create new props
        for prop_name in new_props.keys():
            self._create_prop(bch, obj_uuid, prop_name, new_props[prop_name])

        bch.send()

        return (True, '')
    #end _cassandra_instance_ip_update

    def _cassandra_instance_ip_list(self, parent_uuid):
        children_fq_names = []
        if not parent_uuid:
            # grab all resources of this type
            obj_fq_name_cf = self._obj_fq_name_cf
            col_name_iter = obj_fq_name_cf.xget('instance_ip')
            for (col_name, col_val) in col_name_iter:
                fq_name = col_name.split(':')[:-1]
                children_fq_names.append(fq_name)
        else:
            # go from parent to child
            obj_uuid_cf = self._obj_uuid_cf
            col_start = 'children:instance_ip:'
            col_fin = 'children:instance_ip;'
            col_name_iter = obj_uuid_cf.xget(parent_uuid, column_start = col_start, \
                                column_finish = col_fin, include_timestamp = True)

            unsorted_fq_names = []
            for col in col_name_iter:
                col_name = col[0]
                col_val_ts = col[1]
                child_uuid = col_name.split(':')[2]
                child_fq_name = self.uuid_to_fq_name(child_uuid)
                tstamp = col_val_ts[1]
                unsorted_fq_names.append({'fq_name': child_fq_name, 'tstamp': tstamp})

                # sort children; TODO do this based on schema
                sorted_children = sorted(unsorted_fq_names, key = itemgetter('tstamp'))
                # re-write result's children without timestamp
                children_fq_names = [child['fq_name'] for child in sorted_children]

        return (True, children_fq_names)
    #end _cassandra_instance_ip_list

    def _cassandra_instance_ip_delete(self, obj_uuid):
        obj_uuid_cf = self._obj_uuid_cf
        fq_name = json.loads(obj_uuid_cf.get(obj_uuid, columns = ['fq_name'])['fq_name'])
        bch = obj_uuid_cf.batch()

        # unlink from parent
        col_start = 'parent:'
        col_fin = 'parent;'
        col_name_iter = obj_uuid_cf.xget(obj_uuid, column_start = col_start, column_finish = col_fin)
        for (col_name, col_val) in col_name_iter:
            (_, parent_type, parent_uuid) = col_name.split(':')
            self._delete_child(bch, parent_type, parent_uuid, 'instance_ip', obj_uuid)

        # remove refs
        col_start = 'ref:'
        col_fin = 'ref;'
        col_name_iter = obj_uuid_cf.xget(obj_uuid, column_start = col_start, column_finish = col_fin)
        for (col_name, col_val) in col_name_iter:
            (_, ref_type, ref_uuid) = col_name.split(':')
            self._delete_ref(bch, 'instance_ip', obj_uuid, ref_type, ref_uuid)

        bch.remove(obj_uuid)
        bch.send()

        # Update fqname table
        fq_name_str = ':'.join(fq_name)
        fq_name_col = fq_name_str + ':' + obj_uuid
        self._obj_fq_name_cf.remove('instance_ip', columns = [fq_name_col])


        return (True, '')
    #end _cassandra_instance_ip_delete

    def _cassandra_network_policy_alloc(self, fq_name):
        return (True, '')
    #end _cassandra_network_policy_alloc

    def _cassandra_network_policy_create(self, obj_ids, obj_dict):
        # Gather column values for obj and updates to backrefs
        # in a batch and write it at the end
        bch = self._obj_uuid_cf.batch()

        obj_cols = {}
        obj_cols['fq_name'] = json.dumps(obj_dict['fq_name'])
        obj_cols['type'] = json.dumps('network_policy')
        if 'parent_type' in obj_dict:
            # non config-root child
            parent_type = obj_dict['parent_type']
            parent_method_type = parent_type.replace('-', '_')
            parent_fq_name = obj_dict['fq_name'][:-1]
            obj_cols['parent_type'] = json.dumps(parent_type)
            parent_uuid = self.fq_name_to_uuid(parent_method_type, parent_fq_name)
            self._create_child(bch, parent_method_type, parent_uuid, 'network_policy', obj_ids['uuid'])

        # Properties
        field = obj_dict.get('network_policy_entries', None)
        if field:
            self._create_prop(bch, obj_ids['uuid'], 'network_policy_entries', field)

        field = obj_dict.get('id_perms', None)
        field['created'] = datetime.datetime.now().isoformat()
        field['last_modified'] = field['created']
        if field:
            self._create_prop(bch, obj_ids['uuid'], 'id_perms', field)


        # References

        bch.insert(obj_ids['uuid'], obj_cols)
        bch.send()

        # Update fqname table
        fq_name_str = ':'.join(obj_dict['fq_name'])
        fq_name_cols = {fq_name_str + ':' + obj_ids['uuid']: json.dumps(None)}
        self._obj_fq_name_cf.insert('network_policy', fq_name_cols)

        return (True, '')
    #end _cassandra_network_policy_create

    def _cassandra_network_policy_read(self, obj_uuid, field_names = None):
        obj_uuid_cf = self._obj_uuid_cf
        obj_cols_iter = obj_uuid_cf.xget(obj_uuid, include_timestamp = True)
        # TODO optimize this if needed
        obj_cols = {}
        for col in obj_cols_iter:
            # col-name = value + tstamp
            obj_cols[col[0]] = {'value': col[1][0], 'tstamp': col[1][1]}
            # TODO use compile RE
            if re.match('parent:', col[0]):
                (_, _, parent_uuid) = col[0].split(':')

        if not obj_cols:
            raise common.exceptions.NoIdError(obj_uuid)

        result = {}
        # Name info
        result['fq_name'] = json.loads(obj_cols['fq_name']['value'])
        if 'parent_type' in obj_cols:
            # non config-root child
            parent_type = json.loads(obj_cols['parent_type']['value'])
            result['parent_type'] = parent_type
            try:
                result['parent_uuid'] = parent_uuid
                result['parent_href'] = self._db_client_mgr.generate_url(parent_type, parent_uuid)
            except common.exceptions.NoIdError:
                err_msg = 'Unknown uuid for parent ' + result['fq_name'][-2]
                return (False, err_msg)

        for col_name in obj_cols.keys():
            # TODO use compiled RE
            if re.match('prop:', col_name):
                (_, prop_name) = col_name.split(':')
                result[prop_name] = json.loads(obj_cols[col_name]['value'])

            # TODO use compiled RE
            if re.match('children:', col_name):
                (_, child_type, child_uuid) = col_name.split(':')
                child_tstamp = obj_cols[col_name]['tstamp']
                try:
                    self._read_child(result, obj_uuid, child_type, child_uuid, child_tstamp)
                except common.exceptions.NoIdError:
                    continue

            # TODO use compiled RE
            if re.match('ref:', col_name):
                (_, ref_type, ref_uuid) = col_name.split(':')
                self._read_ref(result, obj_uuid, ref_type, ref_uuid, obj_cols[col_name]['value'])

            if re.match('backref:', col_name):
                (_, back_ref_type, back_ref_uuid) = col_name.split(':')
                try:
                    self._read_back_ref(result, obj_uuid, back_ref_type, back_ref_uuid, \
                                        obj_cols[col_name]['value'])
                except common.exceptions.NoIdError:
                    continue

        # for all column names


        return (True, result)
    #end _cassandra_network_policy_read

    def _cassandra_network_policy_update(self, obj_uuid, dummy_old_obj_dict, new_obj_dict):
        # Grab ref-uuids and properties in new version
        new_ref_infos = {}

        new_props = {}
        if 'network_policy_entries' in new_obj_dict:
            new_props['network_policy_entries'] = new_obj_dict['network_policy_entries']
        if 'id_perms' in new_obj_dict:
            new_props['id_perms'] = new_obj_dict['id_perms']
        # Gather column values for obj and updates to backrefs
        # in a batch and write it at the end
        obj_uuid_cf = self._obj_uuid_cf
        obj_cols_iter = obj_uuid_cf.xget(obj_uuid)
        # TODO optimize this (converts tuple to dict)
        obj_cols = {}
        for col_info in obj_cols_iter:
            obj_cols[col_info[0]] = col_info[1]

        bch = obj_uuid_cf.batch()
        for col_name in obj_cols.keys():
            # TODO use compiled RE
            if re.match('prop:', col_name):
                (_, prop_name) = col_name.split(':')
                if prop_name == 'id_perms':
                    # id-perms always has to be updated for last-mod timestamp
                    # get it from request dict(or from db if not in request dict)
                    new_id_perms = new_obj_dict.get(prop_name, json.loads(obj_cols[col_name]))
                    new_id_perms['last_modified'] = datetime.datetime.now().isoformat()
                    new_props['id_perms'] = new_id_perms
                    self._update_prop(bch, obj_uuid, 'id_perms', new_props)
                elif prop_name in new_obj_dict:
                    self._update_prop(bch, obj_uuid, prop_name, new_props)

            # TODO use compiled RE
            if re.match('ref:', col_name):
                (_, ref_type, ref_uuid) = col_name.split(':')
                self._update_ref(bch, 'network_policy', obj_uuid, ref_type, ref_uuid, new_ref_infos)
        # for all column names

        # create new refs
        for ref_type in new_ref_infos.keys():
            for ref_uuid in new_ref_infos[ref_type].keys():
                ref_data = new_ref_infos[ref_type][ref_uuid]
                self._create_ref(bch, 'network_policy', obj_uuid, ref_type, ref_uuid, ref_data)

        # create new props
        for prop_name in new_props.keys():
            self._create_prop(bch, obj_uuid, prop_name, new_props[prop_name])

        bch.send()

        return (True, '')
    #end _cassandra_network_policy_update

    def _cassandra_network_policy_list(self, parent_uuid):
        children_fq_names = []
        if not parent_uuid:
            # grab all resources of this type
            obj_fq_name_cf = self._obj_fq_name_cf
            col_name_iter = obj_fq_name_cf.xget('network_policy')
            for (col_name, col_val) in col_name_iter:
                fq_name = col_name.split(':')[:-1]
                children_fq_names.append(fq_name)
        else:
            # go from parent to child
            obj_uuid_cf = self._obj_uuid_cf
            col_start = 'children:network_policy:'
            col_fin = 'children:network_policy;'
            col_name_iter = obj_uuid_cf.xget(parent_uuid, column_start = col_start, \
                                column_finish = col_fin, include_timestamp = True)

            unsorted_fq_names = []
            for col in col_name_iter:
                col_name = col[0]
                col_val_ts = col[1]
                child_uuid = col_name.split(':')[2]
                child_fq_name = self.uuid_to_fq_name(child_uuid)
                tstamp = col_val_ts[1]
                unsorted_fq_names.append({'fq_name': child_fq_name, 'tstamp': tstamp})

                # sort children; TODO do this based on schema
                sorted_children = sorted(unsorted_fq_names, key = itemgetter('tstamp'))
                # re-write result's children without timestamp
                children_fq_names = [child['fq_name'] for child in sorted_children]

        return (True, children_fq_names)
    #end _cassandra_network_policy_list

    def _cassandra_network_policy_delete(self, obj_uuid):
        obj_uuid_cf = self._obj_uuid_cf
        fq_name = json.loads(obj_uuid_cf.get(obj_uuid, columns = ['fq_name'])['fq_name'])
        bch = obj_uuid_cf.batch()

        # unlink from parent
        col_start = 'parent:'
        col_fin = 'parent;'
        col_name_iter = obj_uuid_cf.xget(obj_uuid, column_start = col_start, column_finish = col_fin)
        for (col_name, col_val) in col_name_iter:
            (_, parent_type, parent_uuid) = col_name.split(':')
            self._delete_child(bch, parent_type, parent_uuid, 'network_policy', obj_uuid)

        # remove refs
        col_start = 'ref:'
        col_fin = 'ref;'
        col_name_iter = obj_uuid_cf.xget(obj_uuid, column_start = col_start, column_finish = col_fin)
        for (col_name, col_val) in col_name_iter:
            (_, ref_type, ref_uuid) = col_name.split(':')
            self._delete_ref(bch, 'network_policy', obj_uuid, ref_type, ref_uuid)

        bch.remove(obj_uuid)
        bch.send()

        # Update fqname table
        fq_name_str = ':'.join(fq_name)
        fq_name_col = fq_name_str + ':' + obj_uuid
        self._obj_fq_name_cf.remove('network_policy', columns = [fq_name_col])


        return (True, '')
    #end _cassandra_network_policy_delete

    def _cassandra_virtual_DNS_record_alloc(self, fq_name):
        return (True, '')
    #end _cassandra_virtual_DNS_record_alloc

    def _cassandra_virtual_DNS_record_create(self, obj_ids, obj_dict):
        # Gather column values for obj and updates to backrefs
        # in a batch and write it at the end
        bch = self._obj_uuid_cf.batch()

        obj_cols = {}
        obj_cols['fq_name'] = json.dumps(obj_dict['fq_name'])
        obj_cols['type'] = json.dumps('virtual_DNS_record')
        if 'parent_type' in obj_dict:
            # non config-root child
            parent_type = obj_dict['parent_type']
            parent_method_type = parent_type.replace('-', '_')
            parent_fq_name = obj_dict['fq_name'][:-1]
            obj_cols['parent_type'] = json.dumps(parent_type)
            parent_uuid = self.fq_name_to_uuid(parent_method_type, parent_fq_name)
            self._create_child(bch, parent_method_type, parent_uuid, 'virtual_DNS_record', obj_ids['uuid'])

        # Properties
        field = obj_dict.get('virtual_DNS_record_data', None)
        if field:
            self._create_prop(bch, obj_ids['uuid'], 'virtual_DNS_record_data', field)

        field = obj_dict.get('id_perms', None)
        field['created'] = datetime.datetime.now().isoformat()
        field['last_modified'] = field['created']
        if field:
            self._create_prop(bch, obj_ids['uuid'], 'id_perms', field)


        # References

        bch.insert(obj_ids['uuid'], obj_cols)
        bch.send()

        # Update fqname table
        fq_name_str = ':'.join(obj_dict['fq_name'])
        fq_name_cols = {fq_name_str + ':' + obj_ids['uuid']: json.dumps(None)}
        self._obj_fq_name_cf.insert('virtual_DNS_record', fq_name_cols)

        return (True, '')
    #end _cassandra_virtual_DNS_record_create

    def _cassandra_virtual_DNS_record_read(self, obj_uuid, field_names = None):
        obj_uuid_cf = self._obj_uuid_cf
        obj_cols_iter = obj_uuid_cf.xget(obj_uuid, include_timestamp = True)
        # TODO optimize this if needed
        obj_cols = {}
        for col in obj_cols_iter:
            # col-name = value + tstamp
            obj_cols[col[0]] = {'value': col[1][0], 'tstamp': col[1][1]}
            # TODO use compile RE
            if re.match('parent:', col[0]):
                (_, _, parent_uuid) = col[0].split(':')

        if not obj_cols:
            raise common.exceptions.NoIdError(obj_uuid)

        result = {}
        # Name info
        result['fq_name'] = json.loads(obj_cols['fq_name']['value'])
        if 'parent_type' in obj_cols:
            # non config-root child
            parent_type = json.loads(obj_cols['parent_type']['value'])
            result['parent_type'] = parent_type
            try:
                result['parent_uuid'] = parent_uuid
                result['parent_href'] = self._db_client_mgr.generate_url(parent_type, parent_uuid)
            except common.exceptions.NoIdError:
                err_msg = 'Unknown uuid for parent ' + result['fq_name'][-2]
                return (False, err_msg)

        for col_name in obj_cols.keys():
            # TODO use compiled RE
            if re.match('prop:', col_name):
                (_, prop_name) = col_name.split(':')
                result[prop_name] = json.loads(obj_cols[col_name]['value'])

            # TODO use compiled RE
            if re.match('children:', col_name):
                (_, child_type, child_uuid) = col_name.split(':')
                child_tstamp = obj_cols[col_name]['tstamp']
                try:
                    self._read_child(result, obj_uuid, child_type, child_uuid, child_tstamp)
                except common.exceptions.NoIdError:
                    continue

            # TODO use compiled RE
            if re.match('ref:', col_name):
                (_, ref_type, ref_uuid) = col_name.split(':')
                self._read_ref(result, obj_uuid, ref_type, ref_uuid, obj_cols[col_name]['value'])

            if re.match('backref:', col_name):
                (_, back_ref_type, back_ref_uuid) = col_name.split(':')
                try:
                    self._read_back_ref(result, obj_uuid, back_ref_type, back_ref_uuid, \
                                        obj_cols[col_name]['value'])
                except common.exceptions.NoIdError:
                    continue

        # for all column names


        return (True, result)
    #end _cassandra_virtual_DNS_record_read

    def _cassandra_virtual_DNS_record_update(self, obj_uuid, dummy_old_obj_dict, new_obj_dict):
        # Grab ref-uuids and properties in new version
        new_ref_infos = {}

        new_props = {}
        if 'virtual_DNS_record_data' in new_obj_dict:
            new_props['virtual_DNS_record_data'] = new_obj_dict['virtual_DNS_record_data']
        if 'id_perms' in new_obj_dict:
            new_props['id_perms'] = new_obj_dict['id_perms']
        # Gather column values for obj and updates to backrefs
        # in a batch and write it at the end
        obj_uuid_cf = self._obj_uuid_cf
        obj_cols_iter = obj_uuid_cf.xget(obj_uuid)
        # TODO optimize this (converts tuple to dict)
        obj_cols = {}
        for col_info in obj_cols_iter:
            obj_cols[col_info[0]] = col_info[1]

        bch = obj_uuid_cf.batch()
        for col_name in obj_cols.keys():
            # TODO use compiled RE
            if re.match('prop:', col_name):
                (_, prop_name) = col_name.split(':')
                if prop_name == 'id_perms':
                    # id-perms always has to be updated for last-mod timestamp
                    # get it from request dict(or from db if not in request dict)
                    new_id_perms = new_obj_dict.get(prop_name, json.loads(obj_cols[col_name]))
                    new_id_perms['last_modified'] = datetime.datetime.now().isoformat()
                    new_props['id_perms'] = new_id_perms
                    self._update_prop(bch, obj_uuid, 'id_perms', new_props)
                elif prop_name in new_obj_dict:
                    self._update_prop(bch, obj_uuid, prop_name, new_props)

            # TODO use compiled RE
            if re.match('ref:', col_name):
                (_, ref_type, ref_uuid) = col_name.split(':')
                self._update_ref(bch, 'virtual_DNS_record', obj_uuid, ref_type, ref_uuid, new_ref_infos)
        # for all column names

        # create new refs
        for ref_type in new_ref_infos.keys():
            for ref_uuid in new_ref_infos[ref_type].keys():
                ref_data = new_ref_infos[ref_type][ref_uuid]
                self._create_ref(bch, 'virtual_DNS_record', obj_uuid, ref_type, ref_uuid, ref_data)

        # create new props
        for prop_name in new_props.keys():
            self._create_prop(bch, obj_uuid, prop_name, new_props[prop_name])

        bch.send()

        return (True, '')
    #end _cassandra_virtual_DNS_record_update

    def _cassandra_virtual_DNS_record_list(self, parent_uuid):
        children_fq_names = []
        if not parent_uuid:
            # grab all resources of this type
            obj_fq_name_cf = self._obj_fq_name_cf
            col_name_iter = obj_fq_name_cf.xget('virtual_DNS_record')
            for (col_name, col_val) in col_name_iter:
                fq_name = col_name.split(':')[:-1]
                children_fq_names.append(fq_name)
        else:
            # go from parent to child
            obj_uuid_cf = self._obj_uuid_cf
            col_start = 'children:virtual_DNS_record:'
            col_fin = 'children:virtual_DNS_record;'
            col_name_iter = obj_uuid_cf.xget(parent_uuid, column_start = col_start, \
                                column_finish = col_fin, include_timestamp = True)

            unsorted_fq_names = []
            for col in col_name_iter:
                col_name = col[0]
                col_val_ts = col[1]
                child_uuid = col_name.split(':')[2]
                child_fq_name = self.uuid_to_fq_name(child_uuid)
                tstamp = col_val_ts[1]
                unsorted_fq_names.append({'fq_name': child_fq_name, 'tstamp': tstamp})

                # sort children; TODO do this based on schema
                sorted_children = sorted(unsorted_fq_names, key = itemgetter('tstamp'))
                # re-write result's children without timestamp
                children_fq_names = [child['fq_name'] for child in sorted_children]

        return (True, children_fq_names)
    #end _cassandra_virtual_DNS_record_list

    def _cassandra_virtual_DNS_record_delete(self, obj_uuid):
        obj_uuid_cf = self._obj_uuid_cf
        fq_name = json.loads(obj_uuid_cf.get(obj_uuid, columns = ['fq_name'])['fq_name'])
        bch = obj_uuid_cf.batch()

        # unlink from parent
        col_start = 'parent:'
        col_fin = 'parent;'
        col_name_iter = obj_uuid_cf.xget(obj_uuid, column_start = col_start, column_finish = col_fin)
        for (col_name, col_val) in col_name_iter:
            (_, parent_type, parent_uuid) = col_name.split(':')
            self._delete_child(bch, parent_type, parent_uuid, 'virtual_DNS_record', obj_uuid)

        # remove refs
        col_start = 'ref:'
        col_fin = 'ref;'
        col_name_iter = obj_uuid_cf.xget(obj_uuid, column_start = col_start, column_finish = col_fin)
        for (col_name, col_val) in col_name_iter:
            (_, ref_type, ref_uuid) = col_name.split(':')
            self._delete_ref(bch, 'virtual_DNS_record', obj_uuid, ref_type, ref_uuid)

        bch.remove(obj_uuid)
        bch.send()

        # Update fqname table
        fq_name_str = ':'.join(fq_name)
        fq_name_col = fq_name_str + ':' + obj_uuid
        self._obj_fq_name_cf.remove('virtual_DNS_record', columns = [fq_name_col])


        return (True, '')
    #end _cassandra_virtual_DNS_record_delete

    def _cassandra_route_target_alloc(self, fq_name):
        return (True, '')
    #end _cassandra_route_target_alloc

    def _cassandra_route_target_create(self, obj_ids, obj_dict):
        # Gather column values for obj and updates to backrefs
        # in a batch and write it at the end
        bch = self._obj_uuid_cf.batch()

        obj_cols = {}
        obj_cols['fq_name'] = json.dumps(obj_dict['fq_name'])
        obj_cols['type'] = json.dumps('route_target')

        # Properties
        field = obj_dict.get('id_perms', None)
        field['created'] = datetime.datetime.now().isoformat()
        field['last_modified'] = field['created']
        if field:
            self._create_prop(bch, obj_ids['uuid'], 'id_perms', field)


        # References

        bch.insert(obj_ids['uuid'], obj_cols)
        bch.send()

        # Update fqname table
        fq_name_str = ':'.join(obj_dict['fq_name'])
        fq_name_cols = {fq_name_str + ':' + obj_ids['uuid']: json.dumps(None)}
        self._obj_fq_name_cf.insert('route_target', fq_name_cols)

        return (True, '')
    #end _cassandra_route_target_create

    def _cassandra_route_target_read(self, obj_uuid, field_names = None):
        obj_uuid_cf = self._obj_uuid_cf
        obj_cols_iter = obj_uuid_cf.xget(obj_uuid, include_timestamp = True)
        # TODO optimize this if needed
        obj_cols = {}
        for col in obj_cols_iter:
            # col-name = value + tstamp
            obj_cols[col[0]] = {'value': col[1][0], 'tstamp': col[1][1]}
            # TODO use compile RE
            if re.match('parent:', col[0]):
                (_, _, parent_uuid) = col[0].split(':')

        if not obj_cols:
            raise common.exceptions.NoIdError(obj_uuid)

        result = {}
        # Name info
        result['fq_name'] = json.loads(obj_cols['fq_name']['value'])

        for col_name in obj_cols.keys():
            # TODO use compiled RE
            if re.match('prop:', col_name):
                (_, prop_name) = col_name.split(':')
                result[prop_name] = json.loads(obj_cols[col_name]['value'])

            # TODO use compiled RE
            if re.match('children:', col_name):
                (_, child_type, child_uuid) = col_name.split(':')
                child_tstamp = obj_cols[col_name]['tstamp']
                try:
                    self._read_child(result, obj_uuid, child_type, child_uuid, child_tstamp)
                except common.exceptions.NoIdError:
                    continue

            # TODO use compiled RE
            if re.match('ref:', col_name):
                (_, ref_type, ref_uuid) = col_name.split(':')
                self._read_ref(result, obj_uuid, ref_type, ref_uuid, obj_cols[col_name]['value'])

            if re.match('backref:', col_name):
                (_, back_ref_type, back_ref_uuid) = col_name.split(':')
                try:
                    self._read_back_ref(result, obj_uuid, back_ref_type, back_ref_uuid, \
                                        obj_cols[col_name]['value'])
                except common.exceptions.NoIdError:
                    continue

        # for all column names


        return (True, result)
    #end _cassandra_route_target_read

    def _cassandra_route_target_update(self, obj_uuid, dummy_old_obj_dict, new_obj_dict):
        # Grab ref-uuids and properties in new version
        new_ref_infos = {}

        new_props = {}
        if 'id_perms' in new_obj_dict:
            new_props['id_perms'] = new_obj_dict['id_perms']
        # Gather column values for obj and updates to backrefs
        # in a batch and write it at the end
        obj_uuid_cf = self._obj_uuid_cf
        obj_cols_iter = obj_uuid_cf.xget(obj_uuid)
        # TODO optimize this (converts tuple to dict)
        obj_cols = {}
        for col_info in obj_cols_iter:
            obj_cols[col_info[0]] = col_info[1]

        bch = obj_uuid_cf.batch()
        for col_name in obj_cols.keys():
            # TODO use compiled RE
            if re.match('prop:', col_name):
                (_, prop_name) = col_name.split(':')
                if prop_name == 'id_perms':
                    # id-perms always has to be updated for last-mod timestamp
                    # get it from request dict(or from db if not in request dict)
                    new_id_perms = new_obj_dict.get(prop_name, json.loads(obj_cols[col_name]))
                    new_id_perms['last_modified'] = datetime.datetime.now().isoformat()
                    new_props['id_perms'] = new_id_perms
                    self._update_prop(bch, obj_uuid, 'id_perms', new_props)
                elif prop_name in new_obj_dict:
                    self._update_prop(bch, obj_uuid, prop_name, new_props)

            # TODO use compiled RE
            if re.match('ref:', col_name):
                (_, ref_type, ref_uuid) = col_name.split(':')
                self._update_ref(bch, 'route_target', obj_uuid, ref_type, ref_uuid, new_ref_infos)
        # for all column names

        # create new refs
        for ref_type in new_ref_infos.keys():
            for ref_uuid in new_ref_infos[ref_type].keys():
                ref_data = new_ref_infos[ref_type][ref_uuid]
                self._create_ref(bch, 'route_target', obj_uuid, ref_type, ref_uuid, ref_data)

        # create new props
        for prop_name in new_props.keys():
            self._create_prop(bch, obj_uuid, prop_name, new_props[prop_name])

        bch.send()

        return (True, '')
    #end _cassandra_route_target_update

    def _cassandra_route_target_list(self, parent_uuid):
        children_fq_names = []
        if not parent_uuid:
            # grab all resources of this type
            obj_fq_name_cf = self._obj_fq_name_cf
            col_name_iter = obj_fq_name_cf.xget('route_target')
            for (col_name, col_val) in col_name_iter:
                fq_name = col_name.split(':')[:-1]
                children_fq_names.append(fq_name)
        else:
            # go from parent to child
            obj_uuid_cf = self._obj_uuid_cf
            col_start = 'children:route_target:'
            col_fin = 'children:route_target;'
            col_name_iter = obj_uuid_cf.xget(parent_uuid, column_start = col_start, \
                                column_finish = col_fin, include_timestamp = True)

            unsorted_fq_names = []
            for col in col_name_iter:
                col_name = col[0]
                col_val_ts = col[1]
                child_uuid = col_name.split(':')[2]
                child_fq_name = self.uuid_to_fq_name(child_uuid)
                tstamp = col_val_ts[1]
                unsorted_fq_names.append({'fq_name': child_fq_name, 'tstamp': tstamp})

                # sort children; TODO do this based on schema
                sorted_children = sorted(unsorted_fq_names, key = itemgetter('tstamp'))
                # re-write result's children without timestamp
                children_fq_names = [child['fq_name'] for child in sorted_children]

        return (True, children_fq_names)
    #end _cassandra_route_target_list

    def _cassandra_route_target_delete(self, obj_uuid):
        obj_uuid_cf = self._obj_uuid_cf
        fq_name = json.loads(obj_uuid_cf.get(obj_uuid, columns = ['fq_name'])['fq_name'])
        bch = obj_uuid_cf.batch()

        # unlink from parent
        col_start = 'parent:'
        col_fin = 'parent;'
        col_name_iter = obj_uuid_cf.xget(obj_uuid, column_start = col_start, column_finish = col_fin)
        for (col_name, col_val) in col_name_iter:
            (_, parent_type, parent_uuid) = col_name.split(':')
            self._delete_child(bch, parent_type, parent_uuid, 'route_target', obj_uuid)

        # remove refs
        col_start = 'ref:'
        col_fin = 'ref;'
        col_name_iter = obj_uuid_cf.xget(obj_uuid, column_start = col_start, column_finish = col_fin)
        for (col_name, col_val) in col_name_iter:
            (_, ref_type, ref_uuid) = col_name.split(':')
            self._delete_ref(bch, 'route_target', obj_uuid, ref_type, ref_uuid)

        bch.remove(obj_uuid)
        bch.send()

        # Update fqname table
        fq_name_str = ':'.join(fq_name)
        fq_name_col = fq_name_str + ':' + obj_uuid
        self._obj_fq_name_cf.remove('route_target', columns = [fq_name_col])


        return (True, '')
    #end _cassandra_route_target_delete

    def _cassandra_floating_ip_alloc(self, fq_name):
        return (True, '')
    #end _cassandra_floating_ip_alloc

    def _cassandra_floating_ip_create(self, obj_ids, obj_dict):
        # Gather column values for obj and updates to backrefs
        # in a batch and write it at the end
        bch = self._obj_uuid_cf.batch()

        obj_cols = {}
        obj_cols['fq_name'] = json.dumps(obj_dict['fq_name'])
        obj_cols['type'] = json.dumps('floating_ip')
        if 'parent_type' in obj_dict:
            # non config-root child
            parent_type = obj_dict['parent_type']
            parent_method_type = parent_type.replace('-', '_')
            parent_fq_name = obj_dict['fq_name'][:-1]
            obj_cols['parent_type'] = json.dumps(parent_type)
            parent_uuid = self.fq_name_to_uuid(parent_method_type, parent_fq_name)
            self._create_child(bch, parent_method_type, parent_uuid, 'floating_ip', obj_ids['uuid'])

        # Properties
        field = obj_dict.get('floating_ip_address', None)
        if field:
            self._create_prop(bch, obj_ids['uuid'], 'floating_ip_address', field)

        field = obj_dict.get('floating_ip_is_virtual_ip', None)
        if field:
            self._create_prop(bch, obj_ids['uuid'], 'floating_ip_is_virtual_ip', field)

        field = obj_dict.get('id_perms', None)
        field['created'] = datetime.datetime.now().isoformat()
        field['last_modified'] = field['created']
        if field:
            self._create_prop(bch, obj_ids['uuid'], 'id_perms', field)


        # References
        refs = obj_dict.get('project_refs', [])
        for ref in refs:
            ref_uuid = self.fq_name_to_uuid('project', ref['to'])
            ref_attr = ref.get('attr', None)
            ref_data = {'attr': ref_attr, 'is_weakref': False}
            self._create_ref(bch, 'floating_ip', obj_ids['uuid'], 'project', ref_uuid, ref_data)
        refs = obj_dict.get('virtual_machine_interface_refs', [])
        for ref in refs:
            ref_uuid = self.fq_name_to_uuid('virtual_machine_interface', ref['to'])
            ref_attr = ref.get('attr', None)
            ref_data = {'attr': ref_attr, 'is_weakref': False}
            self._create_ref(bch, 'floating_ip', obj_ids['uuid'], 'virtual_machine_interface', ref_uuid, ref_data)

        bch.insert(obj_ids['uuid'], obj_cols)
        bch.send()

        # Update fqname table
        fq_name_str = ':'.join(obj_dict['fq_name'])
        fq_name_cols = {fq_name_str + ':' + obj_ids['uuid']: json.dumps(None)}
        self._obj_fq_name_cf.insert('floating_ip', fq_name_cols)

        return (True, '')
    #end _cassandra_floating_ip_create

    def _cassandra_floating_ip_read(self, obj_uuid, field_names = None):
        obj_uuid_cf = self._obj_uuid_cf
        obj_cols_iter = obj_uuid_cf.xget(obj_uuid, include_timestamp = True)
        # TODO optimize this if needed
        obj_cols = {}
        for col in obj_cols_iter:
            # col-name = value + tstamp
            obj_cols[col[0]] = {'value': col[1][0], 'tstamp': col[1][1]}
            # TODO use compile RE
            if re.match('parent:', col[0]):
                (_, _, parent_uuid) = col[0].split(':')

        if not obj_cols:
            raise common.exceptions.NoIdError(obj_uuid)

        result = {}
        # Name info
        result['fq_name'] = json.loads(obj_cols['fq_name']['value'])
        if 'parent_type' in obj_cols:
            # non config-root child
            parent_type = json.loads(obj_cols['parent_type']['value'])
            result['parent_type'] = parent_type
            try:
                result['parent_uuid'] = parent_uuid
                result['parent_href'] = self._db_client_mgr.generate_url(parent_type, parent_uuid)
            except common.exceptions.NoIdError:
                err_msg = 'Unknown uuid for parent ' + result['fq_name'][-2]
                return (False, err_msg)

        for col_name in obj_cols.keys():
            # TODO use compiled RE
            if re.match('prop:', col_name):
                (_, prop_name) = col_name.split(':')
                result[prop_name] = json.loads(obj_cols[col_name]['value'])

            # TODO use compiled RE
            if re.match('children:', col_name):
                (_, child_type, child_uuid) = col_name.split(':')
                child_tstamp = obj_cols[col_name]['tstamp']
                try:
                    self._read_child(result, obj_uuid, child_type, child_uuid, child_tstamp)
                except common.exceptions.NoIdError:
                    continue

            # TODO use compiled RE
            if re.match('ref:', col_name):
                (_, ref_type, ref_uuid) = col_name.split(':')
                self._read_ref(result, obj_uuid, ref_type, ref_uuid, obj_cols[col_name]['value'])

            if re.match('backref:', col_name):
                (_, back_ref_type, back_ref_uuid) = col_name.split(':')
                try:
                    self._read_back_ref(result, obj_uuid, back_ref_type, back_ref_uuid, \
                                        obj_cols[col_name]['value'])
                except common.exceptions.NoIdError:
                    continue

        # for all column names


        return (True, result)
    #end _cassandra_floating_ip_read

    def _cassandra_floating_ip_update(self, obj_uuid, dummy_old_obj_dict, new_obj_dict):
        # Grab ref-uuids and properties in new version
        new_ref_infos = {}

        if 'project_refs' in new_obj_dict:
            new_ref_infos['project'] = {}
            new_refs = new_obj_dict['project_refs']
            if new_refs:
                for new_ref in new_refs:
                    new_ref_uuid = self.fq_name_to_uuid('project', new_ref['to'])
                    new_ref_attr = new_ref.get('attr', None)
                    new_ref_data = {'attr': new_ref_attr, 'is_weakref': False}
                    new_ref_infos['project'][new_ref_uuid] = new_ref_data

        if 'virtual_machine_interface_refs' in new_obj_dict:
            new_ref_infos['virtual_machine_interface'] = {}
            new_refs = new_obj_dict['virtual_machine_interface_refs']
            if new_refs:
                for new_ref in new_refs:
                    new_ref_uuid = self.fq_name_to_uuid('virtual_machine_interface', new_ref['to'])
                    new_ref_attr = new_ref.get('attr', None)
                    new_ref_data = {'attr': new_ref_attr, 'is_weakref': False}
                    new_ref_infos['virtual_machine_interface'][new_ref_uuid] = new_ref_data

        new_props = {}
        if 'floating_ip_address' in new_obj_dict:
            new_props['floating_ip_address'] = new_obj_dict['floating_ip_address']
        if 'floating_ip_is_virtual_ip' in new_obj_dict:
            new_props['floating_ip_is_virtual_ip'] = new_obj_dict['floating_ip_is_virtual_ip']
        if 'id_perms' in new_obj_dict:
            new_props['id_perms'] = new_obj_dict['id_perms']
        # Gather column values for obj and updates to backrefs
        # in a batch and write it at the end
        obj_uuid_cf = self._obj_uuid_cf
        obj_cols_iter = obj_uuid_cf.xget(obj_uuid)
        # TODO optimize this (converts tuple to dict)
        obj_cols = {}
        for col_info in obj_cols_iter:
            obj_cols[col_info[0]] = col_info[1]

        bch = obj_uuid_cf.batch()
        for col_name in obj_cols.keys():
            # TODO use compiled RE
            if re.match('prop:', col_name):
                (_, prop_name) = col_name.split(':')
                if prop_name == 'id_perms':
                    # id-perms always has to be updated for last-mod timestamp
                    # get it from request dict(or from db if not in request dict)
                    new_id_perms = new_obj_dict.get(prop_name, json.loads(obj_cols[col_name]))
                    new_id_perms['last_modified'] = datetime.datetime.now().isoformat()
                    new_props['id_perms'] = new_id_perms
                    self._update_prop(bch, obj_uuid, 'id_perms', new_props)
                elif prop_name in new_obj_dict:
                    self._update_prop(bch, obj_uuid, prop_name, new_props)

            # TODO use compiled RE
            if re.match('ref:', col_name):
                (_, ref_type, ref_uuid) = col_name.split(':')
                self._update_ref(bch, 'floating_ip', obj_uuid, ref_type, ref_uuid, new_ref_infos)
        # for all column names

        # create new refs
        for ref_type in new_ref_infos.keys():
            for ref_uuid in new_ref_infos[ref_type].keys():
                ref_data = new_ref_infos[ref_type][ref_uuid]
                self._create_ref(bch, 'floating_ip', obj_uuid, ref_type, ref_uuid, ref_data)

        # create new props
        for prop_name in new_props.keys():
            self._create_prop(bch, obj_uuid, prop_name, new_props[prop_name])

        bch.send()

        return (True, '')
    #end _cassandra_floating_ip_update

    def _cassandra_floating_ip_list(self, parent_uuid):
        children_fq_names = []
        if not parent_uuid:
            # grab all resources of this type
            obj_fq_name_cf = self._obj_fq_name_cf
            col_name_iter = obj_fq_name_cf.xget('floating_ip')
            for (col_name, col_val) in col_name_iter:
                fq_name = col_name.split(':')[:-1]
                children_fq_names.append(fq_name)
        else:
            # go from parent to child
            obj_uuid_cf = self._obj_uuid_cf
            col_start = 'children:floating_ip:'
            col_fin = 'children:floating_ip;'
            col_name_iter = obj_uuid_cf.xget(parent_uuid, column_start = col_start, \
                                column_finish = col_fin, include_timestamp = True)

            unsorted_fq_names = []
            for col in col_name_iter:
                col_name = col[0]
                col_val_ts = col[1]
                child_uuid = col_name.split(':')[2]
                child_fq_name = self.uuid_to_fq_name(child_uuid)
                tstamp = col_val_ts[1]
                unsorted_fq_names.append({'fq_name': child_fq_name, 'tstamp': tstamp})

                # sort children; TODO do this based on schema
                sorted_children = sorted(unsorted_fq_names, key = itemgetter('tstamp'))
                # re-write result's children without timestamp
                children_fq_names = [child['fq_name'] for child in sorted_children]

        return (True, children_fq_names)
    #end _cassandra_floating_ip_list

    def _cassandra_floating_ip_delete(self, obj_uuid):
        obj_uuid_cf = self._obj_uuid_cf
        fq_name = json.loads(obj_uuid_cf.get(obj_uuid, columns = ['fq_name'])['fq_name'])
        bch = obj_uuid_cf.batch()

        # unlink from parent
        col_start = 'parent:'
        col_fin = 'parent;'
        col_name_iter = obj_uuid_cf.xget(obj_uuid, column_start = col_start, column_finish = col_fin)
        for (col_name, col_val) in col_name_iter:
            (_, parent_type, parent_uuid) = col_name.split(':')
            self._delete_child(bch, parent_type, parent_uuid, 'floating_ip', obj_uuid)

        # remove refs
        col_start = 'ref:'
        col_fin = 'ref;'
        col_name_iter = obj_uuid_cf.xget(obj_uuid, column_start = col_start, column_finish = col_fin)
        for (col_name, col_val) in col_name_iter:
            (_, ref_type, ref_uuid) = col_name.split(':')
            self._delete_ref(bch, 'floating_ip', obj_uuid, ref_type, ref_uuid)

        bch.remove(obj_uuid)
        bch.send()

        # Update fqname table
        fq_name_str = ':'.join(fq_name)
        fq_name_col = fq_name_str + ':' + obj_uuid
        self._obj_fq_name_cf.remove('floating_ip', columns = [fq_name_col])


        return (True, '')
    #end _cassandra_floating_ip_delete

    def _cassandra_floating_ip_pool_alloc(self, fq_name):
        return (True, '')
    #end _cassandra_floating_ip_pool_alloc

    def _cassandra_floating_ip_pool_create(self, obj_ids, obj_dict):
        # Gather column values for obj and updates to backrefs
        # in a batch and write it at the end
        bch = self._obj_uuid_cf.batch()

        obj_cols = {}
        obj_cols['fq_name'] = json.dumps(obj_dict['fq_name'])
        obj_cols['type'] = json.dumps('floating_ip_pool')
        if 'parent_type' in obj_dict:
            # non config-root child
            parent_type = obj_dict['parent_type']
            parent_method_type = parent_type.replace('-', '_')
            parent_fq_name = obj_dict['fq_name'][:-1]
            obj_cols['parent_type'] = json.dumps(parent_type)
            parent_uuid = self.fq_name_to_uuid(parent_method_type, parent_fq_name)
            self._create_child(bch, parent_method_type, parent_uuid, 'floating_ip_pool', obj_ids['uuid'])

        # Properties
        field = obj_dict.get('floating_ip_pool_prefixes', None)
        if field:
            self._create_prop(bch, obj_ids['uuid'], 'floating_ip_pool_prefixes', field)

        field = obj_dict.get('id_perms', None)
        field['created'] = datetime.datetime.now().isoformat()
        field['last_modified'] = field['created']
        if field:
            self._create_prop(bch, obj_ids['uuid'], 'id_perms', field)


        # References

        bch.insert(obj_ids['uuid'], obj_cols)
        bch.send()

        # Update fqname table
        fq_name_str = ':'.join(obj_dict['fq_name'])
        fq_name_cols = {fq_name_str + ':' + obj_ids['uuid']: json.dumps(None)}
        self._obj_fq_name_cf.insert('floating_ip_pool', fq_name_cols)

        return (True, '')
    #end _cassandra_floating_ip_pool_create

    def _cassandra_floating_ip_pool_read(self, obj_uuid, field_names = None):
        obj_uuid_cf = self._obj_uuid_cf
        obj_cols_iter = obj_uuid_cf.xget(obj_uuid, include_timestamp = True)
        # TODO optimize this if needed
        obj_cols = {}
        for col in obj_cols_iter:
            # col-name = value + tstamp
            obj_cols[col[0]] = {'value': col[1][0], 'tstamp': col[1][1]}
            # TODO use compile RE
            if re.match('parent:', col[0]):
                (_, _, parent_uuid) = col[0].split(':')

        if not obj_cols:
            raise common.exceptions.NoIdError(obj_uuid)

        result = {}
        # Name info
        result['fq_name'] = json.loads(obj_cols['fq_name']['value'])
        if 'parent_type' in obj_cols:
            # non config-root child
            parent_type = json.loads(obj_cols['parent_type']['value'])
            result['parent_type'] = parent_type
            try:
                result['parent_uuid'] = parent_uuid
                result['parent_href'] = self._db_client_mgr.generate_url(parent_type, parent_uuid)
            except common.exceptions.NoIdError:
                err_msg = 'Unknown uuid for parent ' + result['fq_name'][-2]
                return (False, err_msg)

        for col_name in obj_cols.keys():
            # TODO use compiled RE
            if re.match('prop:', col_name):
                (_, prop_name) = col_name.split(':')
                result[prop_name] = json.loads(obj_cols[col_name]['value'])

            # TODO use compiled RE
            if re.match('children:', col_name):
                (_, child_type, child_uuid) = col_name.split(':')
                child_tstamp = obj_cols[col_name]['tstamp']
                try:
                    self._read_child(result, obj_uuid, child_type, child_uuid, child_tstamp)
                except common.exceptions.NoIdError:
                    continue

            # TODO use compiled RE
            if re.match('ref:', col_name):
                (_, ref_type, ref_uuid) = col_name.split(':')
                self._read_ref(result, obj_uuid, ref_type, ref_uuid, obj_cols[col_name]['value'])

            if re.match('backref:', col_name):
                (_, back_ref_type, back_ref_uuid) = col_name.split(':')
                try:
                    self._read_back_ref(result, obj_uuid, back_ref_type, back_ref_uuid, \
                                        obj_cols[col_name]['value'])
                except common.exceptions.NoIdError:
                    continue

        # for all column names

        if 'floating_ips' in result:
            # sort children; TODO do this based on schema
            sorted_children = sorted(result['floating_ips'], key = itemgetter('tstamp'))
            # re-write result's children without timestamp
            result['floating_ips'] = sorted_children
            [child.pop('tstamp') for child in result['floating_ips']]


        return (True, result)
    #end _cassandra_floating_ip_pool_read

    def _cassandra_floating_ip_pool_update(self, obj_uuid, dummy_old_obj_dict, new_obj_dict):
        # Grab ref-uuids and properties in new version
        new_ref_infos = {}

        new_props = {}
        if 'floating_ip_pool_prefixes' in new_obj_dict:
            new_props['floating_ip_pool_prefixes'] = new_obj_dict['floating_ip_pool_prefixes']
        if 'id_perms' in new_obj_dict:
            new_props['id_perms'] = new_obj_dict['id_perms']
        # Gather column values for obj and updates to backrefs
        # in a batch and write it at the end
        obj_uuid_cf = self._obj_uuid_cf
        obj_cols_iter = obj_uuid_cf.xget(obj_uuid)
        # TODO optimize this (converts tuple to dict)
        obj_cols = {}
        for col_info in obj_cols_iter:
            obj_cols[col_info[0]] = col_info[1]

        bch = obj_uuid_cf.batch()
        for col_name in obj_cols.keys():
            # TODO use compiled RE
            if re.match('prop:', col_name):
                (_, prop_name) = col_name.split(':')
                if prop_name == 'id_perms':
                    # id-perms always has to be updated for last-mod timestamp
                    # get it from request dict(or from db if not in request dict)
                    new_id_perms = new_obj_dict.get(prop_name, json.loads(obj_cols[col_name]))
                    new_id_perms['last_modified'] = datetime.datetime.now().isoformat()
                    new_props['id_perms'] = new_id_perms
                    self._update_prop(bch, obj_uuid, 'id_perms', new_props)
                elif prop_name in new_obj_dict:
                    self._update_prop(bch, obj_uuid, prop_name, new_props)

            # TODO use compiled RE
            if re.match('ref:', col_name):
                (_, ref_type, ref_uuid) = col_name.split(':')
                self._update_ref(bch, 'floating_ip_pool', obj_uuid, ref_type, ref_uuid, new_ref_infos)
        # for all column names

        # create new refs
        for ref_type in new_ref_infos.keys():
            for ref_uuid in new_ref_infos[ref_type].keys():
                ref_data = new_ref_infos[ref_type][ref_uuid]
                self._create_ref(bch, 'floating_ip_pool', obj_uuid, ref_type, ref_uuid, ref_data)

        # create new props
        for prop_name in new_props.keys():
            self._create_prop(bch, obj_uuid, prop_name, new_props[prop_name])

        bch.send()

        return (True, '')
    #end _cassandra_floating_ip_pool_update

    def _cassandra_floating_ip_pool_list(self, parent_uuid):
        children_fq_names = []
        if not parent_uuid:
            # grab all resources of this type
            obj_fq_name_cf = self._obj_fq_name_cf
            col_name_iter = obj_fq_name_cf.xget('floating_ip_pool')
            for (col_name, col_val) in col_name_iter:
                fq_name = col_name.split(':')[:-1]
                children_fq_names.append(fq_name)
        else:
            # go from parent to child
            obj_uuid_cf = self._obj_uuid_cf
            col_start = 'children:floating_ip_pool:'
            col_fin = 'children:floating_ip_pool;'
            col_name_iter = obj_uuid_cf.xget(parent_uuid, column_start = col_start, \
                                column_finish = col_fin, include_timestamp = True)

            unsorted_fq_names = []
            for col in col_name_iter:
                col_name = col[0]
                col_val_ts = col[1]
                child_uuid = col_name.split(':')[2]
                child_fq_name = self.uuid_to_fq_name(child_uuid)
                tstamp = col_val_ts[1]
                unsorted_fq_names.append({'fq_name': child_fq_name, 'tstamp': tstamp})

                # sort children; TODO do this based on schema
                sorted_children = sorted(unsorted_fq_names, key = itemgetter('tstamp'))
                # re-write result's children without timestamp
                children_fq_names = [child['fq_name'] for child in sorted_children]

        return (True, children_fq_names)
    #end _cassandra_floating_ip_pool_list

    def _cassandra_floating_ip_pool_delete(self, obj_uuid):
        obj_uuid_cf = self._obj_uuid_cf
        fq_name = json.loads(obj_uuid_cf.get(obj_uuid, columns = ['fq_name'])['fq_name'])
        bch = obj_uuid_cf.batch()

        # unlink from parent
        col_start = 'parent:'
        col_fin = 'parent;'
        col_name_iter = obj_uuid_cf.xget(obj_uuid, column_start = col_start, column_finish = col_fin)
        for (col_name, col_val) in col_name_iter:
            (_, parent_type, parent_uuid) = col_name.split(':')
            self._delete_child(bch, parent_type, parent_uuid, 'floating_ip_pool', obj_uuid)

        # remove refs
        col_start = 'ref:'
        col_fin = 'ref;'
        col_name_iter = obj_uuid_cf.xget(obj_uuid, column_start = col_start, column_finish = col_fin)
        for (col_name, col_val) in col_name_iter:
            (_, ref_type, ref_uuid) = col_name.split(':')
            self._delete_ref(bch, 'floating_ip_pool', obj_uuid, ref_type, ref_uuid)

        bch.remove(obj_uuid)
        bch.send()

        # Update fqname table
        fq_name_str = ':'.join(fq_name)
        fq_name_col = fq_name_str + ':' + obj_uuid
        self._obj_fq_name_cf.remove('floating_ip_pool', columns = [fq_name_col])


        return (True, '')
    #end _cassandra_floating_ip_pool_delete

    def _cassandra_physical_router_alloc(self, fq_name):
        return (True, '')
    #end _cassandra_physical_router_alloc

    def _cassandra_physical_router_create(self, obj_ids, obj_dict):
        # Gather column values for obj and updates to backrefs
        # in a batch and write it at the end
        bch = self._obj_uuid_cf.batch()

        obj_cols = {}
        obj_cols['fq_name'] = json.dumps(obj_dict['fq_name'])
        obj_cols['type'] = json.dumps('physical_router')
        if 'parent_type' in obj_dict:
            # non config-root child
            parent_type = obj_dict['parent_type']
            parent_method_type = parent_type.replace('-', '_')
            parent_fq_name = obj_dict['fq_name'][:-1]
            obj_cols['parent_type'] = json.dumps(parent_type)
            parent_uuid = self.fq_name_to_uuid(parent_method_type, parent_fq_name)
            self._create_child(bch, parent_method_type, parent_uuid, 'physical_router', obj_ids['uuid'])

        # Properties
        field = obj_dict.get('id_perms', None)
        field['created'] = datetime.datetime.now().isoformat()
        field['last_modified'] = field['created']
        if field:
            self._create_prop(bch, obj_ids['uuid'], 'id_perms', field)


        # References
        refs = obj_dict.get('bgp_router_refs', [])
        for ref in refs:
            ref_uuid = self.fq_name_to_uuid('bgp_router', ref['to'])
            ref_attr = ref.get('attr', None)
            ref_data = {'attr': ref_attr, 'is_weakref': False}
            self._create_ref(bch, 'physical_router', obj_ids['uuid'], 'bgp_router', ref_uuid, ref_data)

        bch.insert(obj_ids['uuid'], obj_cols)
        bch.send()

        # Update fqname table
        fq_name_str = ':'.join(obj_dict['fq_name'])
        fq_name_cols = {fq_name_str + ':' + obj_ids['uuid']: json.dumps(None)}
        self._obj_fq_name_cf.insert('physical_router', fq_name_cols)

        return (True, '')
    #end _cassandra_physical_router_create

    def _cassandra_physical_router_read(self, obj_uuid, field_names = None):
        obj_uuid_cf = self._obj_uuid_cf
        obj_cols_iter = obj_uuid_cf.xget(obj_uuid, include_timestamp = True)
        # TODO optimize this if needed
        obj_cols = {}
        for col in obj_cols_iter:
            # col-name = value + tstamp
            obj_cols[col[0]] = {'value': col[1][0], 'tstamp': col[1][1]}
            # TODO use compile RE
            if re.match('parent:', col[0]):
                (_, _, parent_uuid) = col[0].split(':')

        if not obj_cols:
            raise common.exceptions.NoIdError(obj_uuid)

        result = {}
        # Name info
        result['fq_name'] = json.loads(obj_cols['fq_name']['value'])
        if 'parent_type' in obj_cols:
            # non config-root child
            parent_type = json.loads(obj_cols['parent_type']['value'])
            result['parent_type'] = parent_type
            try:
                result['parent_uuid'] = parent_uuid
                result['parent_href'] = self._db_client_mgr.generate_url(parent_type, parent_uuid)
            except common.exceptions.NoIdError:
                err_msg = 'Unknown uuid for parent ' + result['fq_name'][-2]
                return (False, err_msg)

        for col_name in obj_cols.keys():
            # TODO use compiled RE
            if re.match('prop:', col_name):
                (_, prop_name) = col_name.split(':')
                result[prop_name] = json.loads(obj_cols[col_name]['value'])

            # TODO use compiled RE
            if re.match('children:', col_name):
                (_, child_type, child_uuid) = col_name.split(':')
                child_tstamp = obj_cols[col_name]['tstamp']
                try:
                    self._read_child(result, obj_uuid, child_type, child_uuid, child_tstamp)
                except common.exceptions.NoIdError:
                    continue

            # TODO use compiled RE
            if re.match('ref:', col_name):
                (_, ref_type, ref_uuid) = col_name.split(':')
                self._read_ref(result, obj_uuid, ref_type, ref_uuid, obj_cols[col_name]['value'])

            if re.match('backref:', col_name):
                (_, back_ref_type, back_ref_uuid) = col_name.split(':')
                try:
                    self._read_back_ref(result, obj_uuid, back_ref_type, back_ref_uuid, \
                                        obj_cols[col_name]['value'])
                except common.exceptions.NoIdError:
                    continue

        # for all column names

        if 'physical_interfaces' in result:
            # sort children; TODO do this based on schema
            sorted_children = sorted(result['physical_interfaces'], key = itemgetter('tstamp'))
            # re-write result's children without timestamp
            result['physical_interfaces'] = sorted_children
            [child.pop('tstamp') for child in result['physical_interfaces']]


        return (True, result)
    #end _cassandra_physical_router_read

    def _cassandra_physical_router_update(self, obj_uuid, dummy_old_obj_dict, new_obj_dict):
        # Grab ref-uuids and properties in new version
        new_ref_infos = {}

        if 'bgp_router_refs' in new_obj_dict:
            new_ref_infos['bgp_router'] = {}
            new_refs = new_obj_dict['bgp_router_refs']
            if new_refs:
                for new_ref in new_refs:
                    new_ref_uuid = self.fq_name_to_uuid('bgp_router', new_ref['to'])
                    new_ref_attr = new_ref.get('attr', None)
                    new_ref_data = {'attr': new_ref_attr, 'is_weakref': False}
                    new_ref_infos['bgp_router'][new_ref_uuid] = new_ref_data

        new_props = {}
        if 'id_perms' in new_obj_dict:
            new_props['id_perms'] = new_obj_dict['id_perms']
        # Gather column values for obj and updates to backrefs
        # in a batch and write it at the end
        obj_uuid_cf = self._obj_uuid_cf
        obj_cols_iter = obj_uuid_cf.xget(obj_uuid)
        # TODO optimize this (converts tuple to dict)
        obj_cols = {}
        for col_info in obj_cols_iter:
            obj_cols[col_info[0]] = col_info[1]

        bch = obj_uuid_cf.batch()
        for col_name in obj_cols.keys():
            # TODO use compiled RE
            if re.match('prop:', col_name):
                (_, prop_name) = col_name.split(':')
                if prop_name == 'id_perms':
                    # id-perms always has to be updated for last-mod timestamp
                    # get it from request dict(or from db if not in request dict)
                    new_id_perms = new_obj_dict.get(prop_name, json.loads(obj_cols[col_name]))
                    new_id_perms['last_modified'] = datetime.datetime.now().isoformat()
                    new_props['id_perms'] = new_id_perms
                    self._update_prop(bch, obj_uuid, 'id_perms', new_props)
                elif prop_name in new_obj_dict:
                    self._update_prop(bch, obj_uuid, prop_name, new_props)

            # TODO use compiled RE
            if re.match('ref:', col_name):
                (_, ref_type, ref_uuid) = col_name.split(':')
                self._update_ref(bch, 'physical_router', obj_uuid, ref_type, ref_uuid, new_ref_infos)
        # for all column names

        # create new refs
        for ref_type in new_ref_infos.keys():
            for ref_uuid in new_ref_infos[ref_type].keys():
                ref_data = new_ref_infos[ref_type][ref_uuid]
                self._create_ref(bch, 'physical_router', obj_uuid, ref_type, ref_uuid, ref_data)

        # create new props
        for prop_name in new_props.keys():
            self._create_prop(bch, obj_uuid, prop_name, new_props[prop_name])

        bch.send()

        return (True, '')
    #end _cassandra_physical_router_update

    def _cassandra_physical_router_list(self, parent_uuid):
        children_fq_names = []
        if not parent_uuid:
            # grab all resources of this type
            obj_fq_name_cf = self._obj_fq_name_cf
            col_name_iter = obj_fq_name_cf.xget('physical_router')
            for (col_name, col_val) in col_name_iter:
                fq_name = col_name.split(':')[:-1]
                children_fq_names.append(fq_name)
        else:
            # go from parent to child
            obj_uuid_cf = self._obj_uuid_cf
            col_start = 'children:physical_router:'
            col_fin = 'children:physical_router;'
            col_name_iter = obj_uuid_cf.xget(parent_uuid, column_start = col_start, \
                                column_finish = col_fin, include_timestamp = True)

            unsorted_fq_names = []
            for col in col_name_iter:
                col_name = col[0]
                col_val_ts = col[1]
                child_uuid = col_name.split(':')[2]
                child_fq_name = self.uuid_to_fq_name(child_uuid)
                tstamp = col_val_ts[1]
                unsorted_fq_names.append({'fq_name': child_fq_name, 'tstamp': tstamp})

                # sort children; TODO do this based on schema
                sorted_children = sorted(unsorted_fq_names, key = itemgetter('tstamp'))
                # re-write result's children without timestamp
                children_fq_names = [child['fq_name'] for child in sorted_children]

        return (True, children_fq_names)
    #end _cassandra_physical_router_list

    def _cassandra_physical_router_delete(self, obj_uuid):
        obj_uuid_cf = self._obj_uuid_cf
        fq_name = json.loads(obj_uuid_cf.get(obj_uuid, columns = ['fq_name'])['fq_name'])
        bch = obj_uuid_cf.batch()

        # unlink from parent
        col_start = 'parent:'
        col_fin = 'parent;'
        col_name_iter = obj_uuid_cf.xget(obj_uuid, column_start = col_start, column_finish = col_fin)
        for (col_name, col_val) in col_name_iter:
            (_, parent_type, parent_uuid) = col_name.split(':')
            self._delete_child(bch, parent_type, parent_uuid, 'physical_router', obj_uuid)

        # remove refs
        col_start = 'ref:'
        col_fin = 'ref;'
        col_name_iter = obj_uuid_cf.xget(obj_uuid, column_start = col_start, column_finish = col_fin)
        for (col_name, col_val) in col_name_iter:
            (_, ref_type, ref_uuid) = col_name.split(':')
            self._delete_ref(bch, 'physical_router', obj_uuid, ref_type, ref_uuid)

        bch.remove(obj_uuid)
        bch.send()

        # Update fqname table
        fq_name_str = ':'.join(fq_name)
        fq_name_col = fq_name_str + ':' + obj_uuid
        self._obj_fq_name_cf.remove('physical_router', columns = [fq_name_col])


        return (True, '')
    #end _cassandra_physical_router_delete

    def _cassandra_bgp_router_alloc(self, fq_name):
        return (True, '')
    #end _cassandra_bgp_router_alloc

    def _cassandra_bgp_router_create(self, obj_ids, obj_dict):
        # Gather column values for obj and updates to backrefs
        # in a batch and write it at the end
        bch = self._obj_uuid_cf.batch()

        obj_cols = {}
        obj_cols['fq_name'] = json.dumps(obj_dict['fq_name'])
        obj_cols['type'] = json.dumps('bgp_router')
        if 'parent_type' in obj_dict:
            # non config-root child
            parent_type = obj_dict['parent_type']
            parent_method_type = parent_type.replace('-', '_')
            parent_fq_name = obj_dict['fq_name'][:-1]
            obj_cols['parent_type'] = json.dumps(parent_type)
            parent_uuid = self.fq_name_to_uuid(parent_method_type, parent_fq_name)
            self._create_child(bch, parent_method_type, parent_uuid, 'bgp_router', obj_ids['uuid'])

        # Properties
        field = obj_dict.get('bgp_router_parameters', None)
        if field:
            self._create_prop(bch, obj_ids['uuid'], 'bgp_router_parameters', field)

        field = obj_dict.get('id_perms', None)
        field['created'] = datetime.datetime.now().isoformat()
        field['last_modified'] = field['created']
        if field:
            self._create_prop(bch, obj_ids['uuid'], 'id_perms', field)


        # References
        refs = obj_dict.get('bgp_router_refs', [])
        for ref in refs:
            ref_uuid = self.fq_name_to_uuid('bgp_router', ref['to'])
            ref_attr = ref.get('attr', None)
            ref_data = {'attr': ref_attr, 'is_weakref': False}
            self._create_ref(bch, 'bgp_router', obj_ids['uuid'], 'bgp_router', ref_uuid, ref_data)

        bch.insert(obj_ids['uuid'], obj_cols)
        bch.send()

        # Update fqname table
        fq_name_str = ':'.join(obj_dict['fq_name'])
        fq_name_cols = {fq_name_str + ':' + obj_ids['uuid']: json.dumps(None)}
        self._obj_fq_name_cf.insert('bgp_router', fq_name_cols)

        return (True, '')
    #end _cassandra_bgp_router_create

    def _cassandra_bgp_router_read(self, obj_uuid, field_names = None):
        obj_uuid_cf = self._obj_uuid_cf
        obj_cols_iter = obj_uuid_cf.xget(obj_uuid, include_timestamp = True)
        # TODO optimize this if needed
        obj_cols = {}
        for col in obj_cols_iter:
            # col-name = value + tstamp
            obj_cols[col[0]] = {'value': col[1][0], 'tstamp': col[1][1]}
            # TODO use compile RE
            if re.match('parent:', col[0]):
                (_, _, parent_uuid) = col[0].split(':')

        if not obj_cols:
            raise common.exceptions.NoIdError(obj_uuid)

        result = {}
        # Name info
        result['fq_name'] = json.loads(obj_cols['fq_name']['value'])
        if 'parent_type' in obj_cols:
            # non config-root child
            parent_type = json.loads(obj_cols['parent_type']['value'])
            result['parent_type'] = parent_type
            try:
                result['parent_uuid'] = parent_uuid
                result['parent_href'] = self._db_client_mgr.generate_url(parent_type, parent_uuid)
            except common.exceptions.NoIdError:
                err_msg = 'Unknown uuid for parent ' + result['fq_name'][-2]
                return (False, err_msg)

        for col_name in obj_cols.keys():
            # TODO use compiled RE
            if re.match('prop:', col_name):
                (_, prop_name) = col_name.split(':')
                result[prop_name] = json.loads(obj_cols[col_name]['value'])

            # TODO use compiled RE
            if re.match('children:', col_name):
                (_, child_type, child_uuid) = col_name.split(':')
                child_tstamp = obj_cols[col_name]['tstamp']
                try:
                    self._read_child(result, obj_uuid, child_type, child_uuid, child_tstamp)
                except common.exceptions.NoIdError:
                    continue

            # TODO use compiled RE
            if re.match('ref:', col_name):
                (_, ref_type, ref_uuid) = col_name.split(':')
                self._read_ref(result, obj_uuid, ref_type, ref_uuid, obj_cols[col_name]['value'])

            if re.match('backref:', col_name):
                (_, back_ref_type, back_ref_uuid) = col_name.split(':')
                try:
                    self._read_back_ref(result, obj_uuid, back_ref_type, back_ref_uuid, \
                                        obj_cols[col_name]['value'])
                except common.exceptions.NoIdError:
                    continue

        # for all column names


        return (True, result)
    #end _cassandra_bgp_router_read

    def _cassandra_bgp_router_update(self, obj_uuid, dummy_old_obj_dict, new_obj_dict):
        # Grab ref-uuids and properties in new version
        new_ref_infos = {}

        if 'bgp_router_refs' in new_obj_dict:
            new_ref_infos['bgp_router'] = {}
            new_refs = new_obj_dict['bgp_router_refs']
            if new_refs:
                for new_ref in new_refs:
                    new_ref_uuid = self.fq_name_to_uuid('bgp_router', new_ref['to'])
                    new_ref_attr = new_ref.get('attr', None)
                    new_ref_data = {'attr': new_ref_attr, 'is_weakref': False}
                    new_ref_infos['bgp_router'][new_ref_uuid] = new_ref_data

        new_props = {}
        if 'bgp_router_parameters' in new_obj_dict:
            new_props['bgp_router_parameters'] = new_obj_dict['bgp_router_parameters']
        if 'id_perms' in new_obj_dict:
            new_props['id_perms'] = new_obj_dict['id_perms']
        # Gather column values for obj and updates to backrefs
        # in a batch and write it at the end
        obj_uuid_cf = self._obj_uuid_cf
        obj_cols_iter = obj_uuid_cf.xget(obj_uuid)
        # TODO optimize this (converts tuple to dict)
        obj_cols = {}
        for col_info in obj_cols_iter:
            obj_cols[col_info[0]] = col_info[1]

        bch = obj_uuid_cf.batch()
        for col_name in obj_cols.keys():
            # TODO use compiled RE
            if re.match('prop:', col_name):
                (_, prop_name) = col_name.split(':')
                if prop_name == 'id_perms':
                    # id-perms always has to be updated for last-mod timestamp
                    # get it from request dict(or from db if not in request dict)
                    new_id_perms = new_obj_dict.get(prop_name, json.loads(obj_cols[col_name]))
                    new_id_perms['last_modified'] = datetime.datetime.now().isoformat()
                    new_props['id_perms'] = new_id_perms
                    self._update_prop(bch, obj_uuid, 'id_perms', new_props)
                elif prop_name in new_obj_dict:
                    self._update_prop(bch, obj_uuid, prop_name, new_props)

            # TODO use compiled RE
            if re.match('ref:', col_name):
                (_, ref_type, ref_uuid) = col_name.split(':')
                self._update_ref(bch, 'bgp_router', obj_uuid, ref_type, ref_uuid, new_ref_infos)
        # for all column names

        # create new refs
        for ref_type in new_ref_infos.keys():
            for ref_uuid in new_ref_infos[ref_type].keys():
                ref_data = new_ref_infos[ref_type][ref_uuid]
                self._create_ref(bch, 'bgp_router', obj_uuid, ref_type, ref_uuid, ref_data)

        # create new props
        for prop_name in new_props.keys():
            self._create_prop(bch, obj_uuid, prop_name, new_props[prop_name])

        bch.send()

        return (True, '')
    #end _cassandra_bgp_router_update

    def _cassandra_bgp_router_list(self, parent_uuid):
        children_fq_names = []
        if not parent_uuid:
            # grab all resources of this type
            obj_fq_name_cf = self._obj_fq_name_cf
            col_name_iter = obj_fq_name_cf.xget('bgp_router')
            for (col_name, col_val) in col_name_iter:
                fq_name = col_name.split(':')[:-1]
                children_fq_names.append(fq_name)
        else:
            # go from parent to child
            obj_uuid_cf = self._obj_uuid_cf
            col_start = 'children:bgp_router:'
            col_fin = 'children:bgp_router;'
            col_name_iter = obj_uuid_cf.xget(parent_uuid, column_start = col_start, \
                                column_finish = col_fin, include_timestamp = True)

            unsorted_fq_names = []
            for col in col_name_iter:
                col_name = col[0]
                col_val_ts = col[1]
                child_uuid = col_name.split(':')[2]
                child_fq_name = self.uuid_to_fq_name(child_uuid)
                tstamp = col_val_ts[1]
                unsorted_fq_names.append({'fq_name': child_fq_name, 'tstamp': tstamp})

                # sort children; TODO do this based on schema
                sorted_children = sorted(unsorted_fq_names, key = itemgetter('tstamp'))
                # re-write result's children without timestamp
                children_fq_names = [child['fq_name'] for child in sorted_children]

        return (True, children_fq_names)
    #end _cassandra_bgp_router_list

    def _cassandra_bgp_router_delete(self, obj_uuid):
        obj_uuid_cf = self._obj_uuid_cf
        fq_name = json.loads(obj_uuid_cf.get(obj_uuid, columns = ['fq_name'])['fq_name'])
        bch = obj_uuid_cf.batch()

        # unlink from parent
        col_start = 'parent:'
        col_fin = 'parent;'
        col_name_iter = obj_uuid_cf.xget(obj_uuid, column_start = col_start, column_finish = col_fin)
        for (col_name, col_val) in col_name_iter:
            (_, parent_type, parent_uuid) = col_name.split(':')
            self._delete_child(bch, parent_type, parent_uuid, 'bgp_router', obj_uuid)

        # remove refs
        col_start = 'ref:'
        col_fin = 'ref;'
        col_name_iter = obj_uuid_cf.xget(obj_uuid, column_start = col_start, column_finish = col_fin)
        for (col_name, col_val) in col_name_iter:
            (_, ref_type, ref_uuid) = col_name.split(':')
            self._delete_ref(bch, 'bgp_router', obj_uuid, ref_type, ref_uuid)

        bch.remove(obj_uuid)
        bch.send()

        # Update fqname table
        fq_name_str = ':'.join(fq_name)
        fq_name_col = fq_name_str + ':' + obj_uuid
        self._obj_fq_name_cf.remove('bgp_router', columns = [fq_name_col])


        return (True, '')
    #end _cassandra_bgp_router_delete

    def _cassandra_virtual_router_alloc(self, fq_name):
        return (True, '')
    #end _cassandra_virtual_router_alloc

    def _cassandra_virtual_router_create(self, obj_ids, obj_dict):
        # Gather column values for obj and updates to backrefs
        # in a batch and write it at the end
        bch = self._obj_uuid_cf.batch()

        obj_cols = {}
        obj_cols['fq_name'] = json.dumps(obj_dict['fq_name'])
        obj_cols['type'] = json.dumps('virtual_router')
        if 'parent_type' in obj_dict:
            # non config-root child
            parent_type = obj_dict['parent_type']
            parent_method_type = parent_type.replace('-', '_')
            parent_fq_name = obj_dict['fq_name'][:-1]
            obj_cols['parent_type'] = json.dumps(parent_type)
            parent_uuid = self.fq_name_to_uuid(parent_method_type, parent_fq_name)
            self._create_child(bch, parent_method_type, parent_uuid, 'virtual_router', obj_ids['uuid'])

        # Properties
        field = obj_dict.get('virtual_router_ip_address', None)
        if field:
            self._create_prop(bch, obj_ids['uuid'], 'virtual_router_ip_address', field)

        field = obj_dict.get('id_perms', None)
        field['created'] = datetime.datetime.now().isoformat()
        field['last_modified'] = field['created']
        if field:
            self._create_prop(bch, obj_ids['uuid'], 'id_perms', field)


        # References
        refs = obj_dict.get('bgp_router_refs', [])
        for ref in refs:
            ref_uuid = self.fq_name_to_uuid('bgp_router', ref['to'])
            ref_attr = ref.get('attr', None)
            ref_data = {'attr': ref_attr, 'is_weakref': False}
            self._create_ref(bch, 'virtual_router', obj_ids['uuid'], 'bgp_router', ref_uuid, ref_data)
        refs = obj_dict.get('virtual_machine_refs', [])
        for ref in refs:
            ref_uuid = self.fq_name_to_uuid('virtual_machine', ref['to'])
            ref_attr = ref.get('attr', None)
            ref_data = {'attr': ref_attr, 'is_weakref': False}
            self._create_ref(bch, 'virtual_router', obj_ids['uuid'], 'virtual_machine', ref_uuid, ref_data)

        bch.insert(obj_ids['uuid'], obj_cols)
        bch.send()

        # Update fqname table
        fq_name_str = ':'.join(obj_dict['fq_name'])
        fq_name_cols = {fq_name_str + ':' + obj_ids['uuid']: json.dumps(None)}
        self._obj_fq_name_cf.insert('virtual_router', fq_name_cols)

        return (True, '')
    #end _cassandra_virtual_router_create

    def _cassandra_virtual_router_read(self, obj_uuid, field_names = None):
        obj_uuid_cf = self._obj_uuid_cf
        obj_cols_iter = obj_uuid_cf.xget(obj_uuid, include_timestamp = True)
        # TODO optimize this if needed
        obj_cols = {}
        for col in obj_cols_iter:
            # col-name = value + tstamp
            obj_cols[col[0]] = {'value': col[1][0], 'tstamp': col[1][1]}
            # TODO use compile RE
            if re.match('parent:', col[0]):
                (_, _, parent_uuid) = col[0].split(':')

        if not obj_cols:
            raise common.exceptions.NoIdError(obj_uuid)

        result = {}
        # Name info
        result['fq_name'] = json.loads(obj_cols['fq_name']['value'])
        if 'parent_type' in obj_cols:
            # non config-root child
            parent_type = json.loads(obj_cols['parent_type']['value'])
            result['parent_type'] = parent_type
            try:
                result['parent_uuid'] = parent_uuid
                result['parent_href'] = self._db_client_mgr.generate_url(parent_type, parent_uuid)
            except common.exceptions.NoIdError:
                err_msg = 'Unknown uuid for parent ' + result['fq_name'][-2]
                return (False, err_msg)

        for col_name in obj_cols.keys():
            # TODO use compiled RE
            if re.match('prop:', col_name):
                (_, prop_name) = col_name.split(':')
                result[prop_name] = json.loads(obj_cols[col_name]['value'])

            # TODO use compiled RE
            if re.match('children:', col_name):
                (_, child_type, child_uuid) = col_name.split(':')
                child_tstamp = obj_cols[col_name]['tstamp']
                try:
                    self._read_child(result, obj_uuid, child_type, child_uuid, child_tstamp)
                except common.exceptions.NoIdError:
                    continue

            # TODO use compiled RE
            if re.match('ref:', col_name):
                (_, ref_type, ref_uuid) = col_name.split(':')
                self._read_ref(result, obj_uuid, ref_type, ref_uuid, obj_cols[col_name]['value'])

            if re.match('backref:', col_name):
                (_, back_ref_type, back_ref_uuid) = col_name.split(':')
                try:
                    self._read_back_ref(result, obj_uuid, back_ref_type, back_ref_uuid, \
                                        obj_cols[col_name]['value'])
                except common.exceptions.NoIdError:
                    continue

        # for all column names


        return (True, result)
    #end _cassandra_virtual_router_read

    def _cassandra_virtual_router_update(self, obj_uuid, dummy_old_obj_dict, new_obj_dict):
        # Grab ref-uuids and properties in new version
        new_ref_infos = {}

        if 'bgp_router_refs' in new_obj_dict:
            new_ref_infos['bgp_router'] = {}
            new_refs = new_obj_dict['bgp_router_refs']
            if new_refs:
                for new_ref in new_refs:
                    new_ref_uuid = self.fq_name_to_uuid('bgp_router', new_ref['to'])
                    new_ref_attr = new_ref.get('attr', None)
                    new_ref_data = {'attr': new_ref_attr, 'is_weakref': False}
                    new_ref_infos['bgp_router'][new_ref_uuid] = new_ref_data

        if 'virtual_machine_refs' in new_obj_dict:
            new_ref_infos['virtual_machine'] = {}
            new_refs = new_obj_dict['virtual_machine_refs']
            if new_refs:
                for new_ref in new_refs:
                    new_ref_uuid = self.fq_name_to_uuid('virtual_machine', new_ref['to'])
                    new_ref_attr = new_ref.get('attr', None)
                    new_ref_data = {'attr': new_ref_attr, 'is_weakref': False}
                    new_ref_infos['virtual_machine'][new_ref_uuid] = new_ref_data

        new_props = {}
        if 'virtual_router_ip_address' in new_obj_dict:
            new_props['virtual_router_ip_address'] = new_obj_dict['virtual_router_ip_address']
        if 'id_perms' in new_obj_dict:
            new_props['id_perms'] = new_obj_dict['id_perms']
        # Gather column values for obj and updates to backrefs
        # in a batch and write it at the end
        obj_uuid_cf = self._obj_uuid_cf
        obj_cols_iter = obj_uuid_cf.xget(obj_uuid)
        # TODO optimize this (converts tuple to dict)
        obj_cols = {}
        for col_info in obj_cols_iter:
            obj_cols[col_info[0]] = col_info[1]

        bch = obj_uuid_cf.batch()
        for col_name in obj_cols.keys():
            # TODO use compiled RE
            if re.match('prop:', col_name):
                (_, prop_name) = col_name.split(':')
                if prop_name == 'id_perms':
                    # id-perms always has to be updated for last-mod timestamp
                    # get it from request dict(or from db if not in request dict)
                    new_id_perms = new_obj_dict.get(prop_name, json.loads(obj_cols[col_name]))
                    new_id_perms['last_modified'] = datetime.datetime.now().isoformat()
                    new_props['id_perms'] = new_id_perms
                    self._update_prop(bch, obj_uuid, 'id_perms', new_props)
                elif prop_name in new_obj_dict:
                    self._update_prop(bch, obj_uuid, prop_name, new_props)

            # TODO use compiled RE
            if re.match('ref:', col_name):
                (_, ref_type, ref_uuid) = col_name.split(':')
                self._update_ref(bch, 'virtual_router', obj_uuid, ref_type, ref_uuid, new_ref_infos)
        # for all column names

        # create new refs
        for ref_type in new_ref_infos.keys():
            for ref_uuid in new_ref_infos[ref_type].keys():
                ref_data = new_ref_infos[ref_type][ref_uuid]
                self._create_ref(bch, 'virtual_router', obj_uuid, ref_type, ref_uuid, ref_data)

        # create new props
        for prop_name in new_props.keys():
            self._create_prop(bch, obj_uuid, prop_name, new_props[prop_name])

        bch.send()

        return (True, '')
    #end _cassandra_virtual_router_update

    def _cassandra_virtual_router_list(self, parent_uuid):
        children_fq_names = []
        if not parent_uuid:
            # grab all resources of this type
            obj_fq_name_cf = self._obj_fq_name_cf
            col_name_iter = obj_fq_name_cf.xget('virtual_router')
            for (col_name, col_val) in col_name_iter:
                fq_name = col_name.split(':')[:-1]
                children_fq_names.append(fq_name)
        else:
            # go from parent to child
            obj_uuid_cf = self._obj_uuid_cf
            col_start = 'children:virtual_router:'
            col_fin = 'children:virtual_router;'
            col_name_iter = obj_uuid_cf.xget(parent_uuid, column_start = col_start, \
                                column_finish = col_fin, include_timestamp = True)

            unsorted_fq_names = []
            for col in col_name_iter:
                col_name = col[0]
                col_val_ts = col[1]
                child_uuid = col_name.split(':')[2]
                child_fq_name = self.uuid_to_fq_name(child_uuid)
                tstamp = col_val_ts[1]
                unsorted_fq_names.append({'fq_name': child_fq_name, 'tstamp': tstamp})

                # sort children; TODO do this based on schema
                sorted_children = sorted(unsorted_fq_names, key = itemgetter('tstamp'))
                # re-write result's children without timestamp
                children_fq_names = [child['fq_name'] for child in sorted_children]

        return (True, children_fq_names)
    #end _cassandra_virtual_router_list

    def _cassandra_virtual_router_delete(self, obj_uuid):
        obj_uuid_cf = self._obj_uuid_cf
        fq_name = json.loads(obj_uuid_cf.get(obj_uuid, columns = ['fq_name'])['fq_name'])
        bch = obj_uuid_cf.batch()

        # unlink from parent
        col_start = 'parent:'
        col_fin = 'parent;'
        col_name_iter = obj_uuid_cf.xget(obj_uuid, column_start = col_start, column_finish = col_fin)
        for (col_name, col_val) in col_name_iter:
            (_, parent_type, parent_uuid) = col_name.split(':')
            self._delete_child(bch, parent_type, parent_uuid, 'virtual_router', obj_uuid)

        # remove refs
        col_start = 'ref:'
        col_fin = 'ref;'
        col_name_iter = obj_uuid_cf.xget(obj_uuid, column_start = col_start, column_finish = col_fin)
        for (col_name, col_val) in col_name_iter:
            (_, ref_type, ref_uuid) = col_name.split(':')
            self._delete_ref(bch, 'virtual_router', obj_uuid, ref_type, ref_uuid)

        bch.remove(obj_uuid)
        bch.send()

        # Update fqname table
        fq_name_str = ':'.join(fq_name)
        fq_name_col = fq_name_str + ':' + obj_uuid
        self._obj_fq_name_cf.remove('virtual_router', columns = [fq_name_col])


        return (True, '')
    #end _cassandra_virtual_router_delete

    def _cassandra_config_root_alloc(self, fq_name):
        return (True, '')
    #end _cassandra_config_root_alloc

    def _cassandra_config_root_create(self, obj_ids, obj_dict):
        # Gather column values for obj and updates to backrefs
        # in a batch and write it at the end
        bch = self._obj_uuid_cf.batch()

        obj_cols = {}
        obj_cols['fq_name'] = json.dumps(obj_dict['fq_name'])
        obj_cols['type'] = json.dumps('config_root')

        # Properties
        field = obj_dict.get('id_perms', None)
        field['created'] = datetime.datetime.now().isoformat()
        field['last_modified'] = field['created']
        if field:
            self._create_prop(bch, obj_ids['uuid'], 'id_perms', field)


        # References

        bch.insert(obj_ids['uuid'], obj_cols)
        bch.send()

        # Update fqname table
        fq_name_str = ':'.join(obj_dict['fq_name'])
        fq_name_cols = {fq_name_str + ':' + obj_ids['uuid']: json.dumps(None)}
        self._obj_fq_name_cf.insert('config_root', fq_name_cols)

        return (True, '')
    #end _cassandra_config_root_create

    def _cassandra_config_root_read(self, obj_uuid, field_names = None):
        obj_uuid_cf = self._obj_uuid_cf
        obj_cols_iter = obj_uuid_cf.xget(obj_uuid, include_timestamp = True)
        # TODO optimize this if needed
        obj_cols = {}
        for col in obj_cols_iter:
            # col-name = value + tstamp
            obj_cols[col[0]] = {'value': col[1][0], 'tstamp': col[1][1]}
            # TODO use compile RE
            if re.match('parent:', col[0]):
                (_, _, parent_uuid) = col[0].split(':')

        if not obj_cols:
            raise common.exceptions.NoIdError(obj_uuid)

        result = {}
        # Name info
        result['fq_name'] = json.loads(obj_cols['fq_name']['value'])

        for col_name in obj_cols.keys():
            # TODO use compiled RE
            if re.match('prop:', col_name):
                (_, prop_name) = col_name.split(':')
                result[prop_name] = json.loads(obj_cols[col_name]['value'])

            # TODO use compiled RE
            if re.match('children:', col_name):
                (_, child_type, child_uuid) = col_name.split(':')
                child_tstamp = obj_cols[col_name]['tstamp']
                try:
                    self._read_child(result, obj_uuid, child_type, child_uuid, child_tstamp)
                except common.exceptions.NoIdError:
                    continue

            # TODO use compiled RE
            if re.match('ref:', col_name):
                (_, ref_type, ref_uuid) = col_name.split(':')
                self._read_ref(result, obj_uuid, ref_type, ref_uuid, obj_cols[col_name]['value'])

            if re.match('backref:', col_name):
                (_, back_ref_type, back_ref_uuid) = col_name.split(':')
                try:
                    self._read_back_ref(result, obj_uuid, back_ref_type, back_ref_uuid, \
                                        obj_cols[col_name]['value'])
                except common.exceptions.NoIdError:
                    continue

        # for all column names

        if 'global_system_configs' in result:
            # sort children; TODO do this based on schema
            sorted_children = sorted(result['global_system_configs'], key = itemgetter('tstamp'))
            # re-write result's children without timestamp
            result['global_system_configs'] = sorted_children
            [child.pop('tstamp') for child in result['global_system_configs']]

        if 'domains' in result:
            # sort children; TODO do this based on schema
            sorted_children = sorted(result['domains'], key = itemgetter('tstamp'))
            # re-write result's children without timestamp
            result['domains'] = sorted_children
            [child.pop('tstamp') for child in result['domains']]


        return (True, result)
    #end _cassandra_config_root_read

    def _cassandra_config_root_update(self, obj_uuid, dummy_old_obj_dict, new_obj_dict):
        # Grab ref-uuids and properties in new version
        new_ref_infos = {}

        new_props = {}
        if 'id_perms' in new_obj_dict:
            new_props['id_perms'] = new_obj_dict['id_perms']
        # Gather column values for obj and updates to backrefs
        # in a batch and write it at the end
        obj_uuid_cf = self._obj_uuid_cf
        obj_cols_iter = obj_uuid_cf.xget(obj_uuid)
        # TODO optimize this (converts tuple to dict)
        obj_cols = {}
        for col_info in obj_cols_iter:
            obj_cols[col_info[0]] = col_info[1]

        bch = obj_uuid_cf.batch()
        for col_name in obj_cols.keys():
            # TODO use compiled RE
            if re.match('prop:', col_name):
                (_, prop_name) = col_name.split(':')
                if prop_name == 'id_perms':
                    # id-perms always has to be updated for last-mod timestamp
                    # get it from request dict(or from db if not in request dict)
                    new_id_perms = new_obj_dict.get(prop_name, json.loads(obj_cols[col_name]))
                    new_id_perms['last_modified'] = datetime.datetime.now().isoformat()
                    new_props['id_perms'] = new_id_perms
                    self._update_prop(bch, obj_uuid, 'id_perms', new_props)
                elif prop_name in new_obj_dict:
                    self._update_prop(bch, obj_uuid, prop_name, new_props)

            # TODO use compiled RE
            if re.match('ref:', col_name):
                (_, ref_type, ref_uuid) = col_name.split(':')
                self._update_ref(bch, 'config_root', obj_uuid, ref_type, ref_uuid, new_ref_infos)
        # for all column names

        # create new refs
        for ref_type in new_ref_infos.keys():
            for ref_uuid in new_ref_infos[ref_type].keys():
                ref_data = new_ref_infos[ref_type][ref_uuid]
                self._create_ref(bch, 'config_root', obj_uuid, ref_type, ref_uuid, ref_data)

        # create new props
        for prop_name in new_props.keys():
            self._create_prop(bch, obj_uuid, prop_name, new_props[prop_name])

        bch.send()

        return (True, '')
    #end _cassandra_config_root_update

    def _cassandra_config_root_list(self, parent_uuid):
        children_fq_names = []
        if not parent_uuid:
            # grab all resources of this type
            obj_fq_name_cf = self._obj_fq_name_cf
            col_name_iter = obj_fq_name_cf.xget('config_root')
            for (col_name, col_val) in col_name_iter:
                fq_name = col_name.split(':')[:-1]
                children_fq_names.append(fq_name)
        else:
            # go from parent to child
            obj_uuid_cf = self._obj_uuid_cf
            col_start = 'children:config_root:'
            col_fin = 'children:config_root;'
            col_name_iter = obj_uuid_cf.xget(parent_uuid, column_start = col_start, \
                                column_finish = col_fin, include_timestamp = True)

            unsorted_fq_names = []
            for col in col_name_iter:
                col_name = col[0]
                col_val_ts = col[1]
                child_uuid = col_name.split(':')[2]
                child_fq_name = self.uuid_to_fq_name(child_uuid)
                tstamp = col_val_ts[1]
                unsorted_fq_names.append({'fq_name': child_fq_name, 'tstamp': tstamp})

                # sort children; TODO do this based on schema
                sorted_children = sorted(unsorted_fq_names, key = itemgetter('tstamp'))
                # re-write result's children without timestamp
                children_fq_names = [child['fq_name'] for child in sorted_children]

        return (True, children_fq_names)
    #end _cassandra_config_root_list

    def _cassandra_config_root_delete(self, obj_uuid):
        obj_uuid_cf = self._obj_uuid_cf
        fq_name = json.loads(obj_uuid_cf.get(obj_uuid, columns = ['fq_name'])['fq_name'])
        bch = obj_uuid_cf.batch()

        # unlink from parent
        col_start = 'parent:'
        col_fin = 'parent;'
        col_name_iter = obj_uuid_cf.xget(obj_uuid, column_start = col_start, column_finish = col_fin)
        for (col_name, col_val) in col_name_iter:
            (_, parent_type, parent_uuid) = col_name.split(':')
            self._delete_child(bch, parent_type, parent_uuid, 'config_root', obj_uuid)

        # remove refs
        col_start = 'ref:'
        col_fin = 'ref;'
        col_name_iter = obj_uuid_cf.xget(obj_uuid, column_start = col_start, column_finish = col_fin)
        for (col_name, col_val) in col_name_iter:
            (_, ref_type, ref_uuid) = col_name.split(':')
            self._delete_ref(bch, 'config_root', obj_uuid, ref_type, ref_uuid)

        bch.remove(obj_uuid)
        bch.send()

        # Update fqname table
        fq_name_str = ':'.join(fq_name)
        fq_name_col = fq_name_str + ':' + obj_uuid
        self._obj_fq_name_cf.remove('config_root', columns = [fq_name_col])


        return (True, '')
    #end _cassandra_config_root_delete

    def _cassandra_global_system_config_alloc(self, fq_name):
        return (True, '')
    #end _cassandra_global_system_config_alloc

    def _cassandra_global_system_config_create(self, obj_ids, obj_dict):
        # Gather column values for obj and updates to backrefs
        # in a batch and write it at the end
        bch = self._obj_uuid_cf.batch()

        obj_cols = {}
        obj_cols['fq_name'] = json.dumps(obj_dict['fq_name'])
        obj_cols['type'] = json.dumps('global_system_config')
        if 'parent_type' in obj_dict:
            # non config-root child
            parent_type = obj_dict['parent_type']
            parent_method_type = parent_type.replace('-', '_')
            parent_fq_name = obj_dict['fq_name'][:-1]
            obj_cols['parent_type'] = json.dumps(parent_type)
            parent_uuid = self.fq_name_to_uuid(parent_method_type, parent_fq_name)
            self._create_child(bch, parent_method_type, parent_uuid, 'global_system_config', obj_ids['uuid'])

        # Properties
        field = obj_dict.get('autonomous_system', None)
        if field:
            self._create_prop(bch, obj_ids['uuid'], 'autonomous_system', field)

        field = obj_dict.get('id_perms', None)
        field['created'] = datetime.datetime.now().isoformat()
        field['last_modified'] = field['created']
        if field:
            self._create_prop(bch, obj_ids['uuid'], 'id_perms', field)


        # References
        refs = obj_dict.get('bgp_router_refs', [])
        for ref in refs:
            ref_uuid = self.fq_name_to_uuid('bgp_router', ref['to'])
            ref_attr = ref.get('attr', None)
            ref_data = {'attr': ref_attr, 'is_weakref': False}
            self._create_ref(bch, 'global_system_config', obj_ids['uuid'], 'bgp_router', ref_uuid, ref_data)

        bch.insert(obj_ids['uuid'], obj_cols)
        bch.send()

        # Update fqname table
        fq_name_str = ':'.join(obj_dict['fq_name'])
        fq_name_cols = {fq_name_str + ':' + obj_ids['uuid']: json.dumps(None)}
        self._obj_fq_name_cf.insert('global_system_config', fq_name_cols)

        return (True, '')
    #end _cassandra_global_system_config_create

    def _cassandra_global_system_config_read(self, obj_uuid, field_names = None):
        obj_uuid_cf = self._obj_uuid_cf
        obj_cols_iter = obj_uuid_cf.xget(obj_uuid, include_timestamp = True)
        # TODO optimize this if needed
        obj_cols = {}
        for col in obj_cols_iter:
            # col-name = value + tstamp
            obj_cols[col[0]] = {'value': col[1][0], 'tstamp': col[1][1]}
            # TODO use compile RE
            if re.match('parent:', col[0]):
                (_, _, parent_uuid) = col[0].split(':')

        if not obj_cols:
            raise common.exceptions.NoIdError(obj_uuid)

        result = {}
        # Name info
        result['fq_name'] = json.loads(obj_cols['fq_name']['value'])
        if 'parent_type' in obj_cols:
            # non config-root child
            parent_type = json.loads(obj_cols['parent_type']['value'])
            result['parent_type'] = parent_type
            try:
                result['parent_uuid'] = parent_uuid
                result['parent_href'] = self._db_client_mgr.generate_url(parent_type, parent_uuid)
            except common.exceptions.NoIdError:
                err_msg = 'Unknown uuid for parent ' + result['fq_name'][-2]
                return (False, err_msg)

        for col_name in obj_cols.keys():
            # TODO use compiled RE
            if re.match('prop:', col_name):
                (_, prop_name) = col_name.split(':')
                result[prop_name] = json.loads(obj_cols[col_name]['value'])

            # TODO use compiled RE
            if re.match('children:', col_name):
                (_, child_type, child_uuid) = col_name.split(':')
                child_tstamp = obj_cols[col_name]['tstamp']
                try:
                    self._read_child(result, obj_uuid, child_type, child_uuid, child_tstamp)
                except common.exceptions.NoIdError:
                    continue

            # TODO use compiled RE
            if re.match('ref:', col_name):
                (_, ref_type, ref_uuid) = col_name.split(':')
                self._read_ref(result, obj_uuid, ref_type, ref_uuid, obj_cols[col_name]['value'])

            if re.match('backref:', col_name):
                (_, back_ref_type, back_ref_uuid) = col_name.split(':')
                try:
                    self._read_back_ref(result, obj_uuid, back_ref_type, back_ref_uuid, \
                                        obj_cols[col_name]['value'])
                except common.exceptions.NoIdError:
                    continue

        # for all column names

        if 'physical_routers' in result:
            # sort children; TODO do this based on schema
            sorted_children = sorted(result['physical_routers'], key = itemgetter('tstamp'))
            # re-write result's children without timestamp
            result['physical_routers'] = sorted_children
            [child.pop('tstamp') for child in result['physical_routers']]

        if 'virtual_routers' in result:
            # sort children; TODO do this based on schema
            sorted_children = sorted(result['virtual_routers'], key = itemgetter('tstamp'))
            # re-write result's children without timestamp
            result['virtual_routers'] = sorted_children
            [child.pop('tstamp') for child in result['virtual_routers']]


        return (True, result)
    #end _cassandra_global_system_config_read

    def _cassandra_global_system_config_update(self, obj_uuid, dummy_old_obj_dict, new_obj_dict):
        # Grab ref-uuids and properties in new version
        new_ref_infos = {}

        if 'bgp_router_refs' in new_obj_dict:
            new_ref_infos['bgp_router'] = {}
            new_refs = new_obj_dict['bgp_router_refs']
            if new_refs:
                for new_ref in new_refs:
                    new_ref_uuid = self.fq_name_to_uuid('bgp_router', new_ref['to'])
                    new_ref_attr = new_ref.get('attr', None)
                    new_ref_data = {'attr': new_ref_attr, 'is_weakref': False}
                    new_ref_infos['bgp_router'][new_ref_uuid] = new_ref_data

        new_props = {}
        if 'autonomous_system' in new_obj_dict:
            new_props['autonomous_system'] = new_obj_dict['autonomous_system']
        if 'id_perms' in new_obj_dict:
            new_props['id_perms'] = new_obj_dict['id_perms']
        # Gather column values for obj and updates to backrefs
        # in a batch and write it at the end
        obj_uuid_cf = self._obj_uuid_cf
        obj_cols_iter = obj_uuid_cf.xget(obj_uuid)
        # TODO optimize this (converts tuple to dict)
        obj_cols = {}
        for col_info in obj_cols_iter:
            obj_cols[col_info[0]] = col_info[1]

        bch = obj_uuid_cf.batch()
        for col_name in obj_cols.keys():
            # TODO use compiled RE
            if re.match('prop:', col_name):
                (_, prop_name) = col_name.split(':')
                if prop_name == 'id_perms':
                    # id-perms always has to be updated for last-mod timestamp
                    # get it from request dict(or from db if not in request dict)
                    new_id_perms = new_obj_dict.get(prop_name, json.loads(obj_cols[col_name]))
                    new_id_perms['last_modified'] = datetime.datetime.now().isoformat()
                    new_props['id_perms'] = new_id_perms
                    self._update_prop(bch, obj_uuid, 'id_perms', new_props)
                elif prop_name in new_obj_dict:
                    self._update_prop(bch, obj_uuid, prop_name, new_props)

            # TODO use compiled RE
            if re.match('ref:', col_name):
                (_, ref_type, ref_uuid) = col_name.split(':')
                self._update_ref(bch, 'global_system_config', obj_uuid, ref_type, ref_uuid, new_ref_infos)
        # for all column names

        # create new refs
        for ref_type in new_ref_infos.keys():
            for ref_uuid in new_ref_infos[ref_type].keys():
                ref_data = new_ref_infos[ref_type][ref_uuid]
                self._create_ref(bch, 'global_system_config', obj_uuid, ref_type, ref_uuid, ref_data)

        # create new props
        for prop_name in new_props.keys():
            self._create_prop(bch, obj_uuid, prop_name, new_props[prop_name])

        bch.send()

        return (True, '')
    #end _cassandra_global_system_config_update

    def _cassandra_global_system_config_list(self, parent_uuid):
        children_fq_names = []
        if not parent_uuid:
            # grab all resources of this type
            obj_fq_name_cf = self._obj_fq_name_cf
            col_name_iter = obj_fq_name_cf.xget('global_system_config')
            for (col_name, col_val) in col_name_iter:
                fq_name = col_name.split(':')[:-1]
                children_fq_names.append(fq_name)
        else:
            # go from parent to child
            obj_uuid_cf = self._obj_uuid_cf
            col_start = 'children:global_system_config:'
            col_fin = 'children:global_system_config;'
            col_name_iter = obj_uuid_cf.xget(parent_uuid, column_start = col_start, \
                                column_finish = col_fin, include_timestamp = True)

            unsorted_fq_names = []
            for col in col_name_iter:
                col_name = col[0]
                col_val_ts = col[1]
                child_uuid = col_name.split(':')[2]
                child_fq_name = self.uuid_to_fq_name(child_uuid)
                tstamp = col_val_ts[1]
                unsorted_fq_names.append({'fq_name': child_fq_name, 'tstamp': tstamp})

                # sort children; TODO do this based on schema
                sorted_children = sorted(unsorted_fq_names, key = itemgetter('tstamp'))
                # re-write result's children without timestamp
                children_fq_names = [child['fq_name'] for child in sorted_children]

        return (True, children_fq_names)
    #end _cassandra_global_system_config_list

    def _cassandra_global_system_config_delete(self, obj_uuid):
        obj_uuid_cf = self._obj_uuid_cf
        fq_name = json.loads(obj_uuid_cf.get(obj_uuid, columns = ['fq_name'])['fq_name'])
        bch = obj_uuid_cf.batch()

        # unlink from parent
        col_start = 'parent:'
        col_fin = 'parent;'
        col_name_iter = obj_uuid_cf.xget(obj_uuid, column_start = col_start, column_finish = col_fin)
        for (col_name, col_val) in col_name_iter:
            (_, parent_type, parent_uuid) = col_name.split(':')
            self._delete_child(bch, parent_type, parent_uuid, 'global_system_config', obj_uuid)

        # remove refs
        col_start = 'ref:'
        col_fin = 'ref;'
        col_name_iter = obj_uuid_cf.xget(obj_uuid, column_start = col_start, column_finish = col_fin)
        for (col_name, col_val) in col_name_iter:
            (_, ref_type, ref_uuid) = col_name.split(':')
            self._delete_ref(bch, 'global_system_config', obj_uuid, ref_type, ref_uuid)

        bch.remove(obj_uuid)
        bch.send()

        # Update fqname table
        fq_name_str = ':'.join(fq_name)
        fq_name_col = fq_name_str + ':' + obj_uuid
        self._obj_fq_name_cf.remove('global_system_config', columns = [fq_name_col])


        return (True, '')
    #end _cassandra_global_system_config_delete

    def _cassandra_namespace_alloc(self, fq_name):
        return (True, '')
    #end _cassandra_namespace_alloc

    def _cassandra_namespace_create(self, obj_ids, obj_dict):
        # Gather column values for obj and updates to backrefs
        # in a batch and write it at the end
        bch = self._obj_uuid_cf.batch()

        obj_cols = {}
        obj_cols['fq_name'] = json.dumps(obj_dict['fq_name'])
        obj_cols['type'] = json.dumps('namespace')
        if 'parent_type' in obj_dict:
            # non config-root child
            parent_type = obj_dict['parent_type']
            parent_method_type = parent_type.replace('-', '_')
            parent_fq_name = obj_dict['fq_name'][:-1]
            obj_cols['parent_type'] = json.dumps(parent_type)
            parent_uuid = self.fq_name_to_uuid(parent_method_type, parent_fq_name)
            self._create_child(bch, parent_method_type, parent_uuid, 'namespace', obj_ids['uuid'])

        # Properties
        field = obj_dict.get('namespace_cidr', None)
        if field:
            self._create_prop(bch, obj_ids['uuid'], 'namespace_cidr', field)

        field = obj_dict.get('id_perms', None)
        field['created'] = datetime.datetime.now().isoformat()
        field['last_modified'] = field['created']
        if field:
            self._create_prop(bch, obj_ids['uuid'], 'id_perms', field)


        # References

        bch.insert(obj_ids['uuid'], obj_cols)
        bch.send()

        # Update fqname table
        fq_name_str = ':'.join(obj_dict['fq_name'])
        fq_name_cols = {fq_name_str + ':' + obj_ids['uuid']: json.dumps(None)}
        self._obj_fq_name_cf.insert('namespace', fq_name_cols)

        return (True, '')
    #end _cassandra_namespace_create

    def _cassandra_namespace_read(self, obj_uuid, field_names = None):
        obj_uuid_cf = self._obj_uuid_cf
        obj_cols_iter = obj_uuid_cf.xget(obj_uuid, include_timestamp = True)
        # TODO optimize this if needed
        obj_cols = {}
        for col in obj_cols_iter:
            # col-name = value + tstamp
            obj_cols[col[0]] = {'value': col[1][0], 'tstamp': col[1][1]}
            # TODO use compile RE
            if re.match('parent:', col[0]):
                (_, _, parent_uuid) = col[0].split(':')

        if not obj_cols:
            raise common.exceptions.NoIdError(obj_uuid)

        result = {}
        # Name info
        result['fq_name'] = json.loads(obj_cols['fq_name']['value'])
        if 'parent_type' in obj_cols:
            # non config-root child
            parent_type = json.loads(obj_cols['parent_type']['value'])
            result['parent_type'] = parent_type
            try:
                result['parent_uuid'] = parent_uuid
                result['parent_href'] = self._db_client_mgr.generate_url(parent_type, parent_uuid)
            except common.exceptions.NoIdError:
                err_msg = 'Unknown uuid for parent ' + result['fq_name'][-2]
                return (False, err_msg)

        for col_name in obj_cols.keys():
            # TODO use compiled RE
            if re.match('prop:', col_name):
                (_, prop_name) = col_name.split(':')
                result[prop_name] = json.loads(obj_cols[col_name]['value'])

            # TODO use compiled RE
            if re.match('children:', col_name):
                (_, child_type, child_uuid) = col_name.split(':')
                child_tstamp = obj_cols[col_name]['tstamp']
                try:
                    self._read_child(result, obj_uuid, child_type, child_uuid, child_tstamp)
                except common.exceptions.NoIdError:
                    continue

            # TODO use compiled RE
            if re.match('ref:', col_name):
                (_, ref_type, ref_uuid) = col_name.split(':')
                self._read_ref(result, obj_uuid, ref_type, ref_uuid, obj_cols[col_name]['value'])

            if re.match('backref:', col_name):
                (_, back_ref_type, back_ref_uuid) = col_name.split(':')
                try:
                    self._read_back_ref(result, obj_uuid, back_ref_type, back_ref_uuid, \
                                        obj_cols[col_name]['value'])
                except common.exceptions.NoIdError:
                    continue

        # for all column names


        return (True, result)
    #end _cassandra_namespace_read

    def _cassandra_namespace_update(self, obj_uuid, dummy_old_obj_dict, new_obj_dict):
        # Grab ref-uuids and properties in new version
        new_ref_infos = {}

        new_props = {}
        if 'namespace_cidr' in new_obj_dict:
            new_props['namespace_cidr'] = new_obj_dict['namespace_cidr']
        if 'id_perms' in new_obj_dict:
            new_props['id_perms'] = new_obj_dict['id_perms']
        # Gather column values for obj and updates to backrefs
        # in a batch and write it at the end
        obj_uuid_cf = self._obj_uuid_cf
        obj_cols_iter = obj_uuid_cf.xget(obj_uuid)
        # TODO optimize this (converts tuple to dict)
        obj_cols = {}
        for col_info in obj_cols_iter:
            obj_cols[col_info[0]] = col_info[1]

        bch = obj_uuid_cf.batch()
        for col_name in obj_cols.keys():
            # TODO use compiled RE
            if re.match('prop:', col_name):
                (_, prop_name) = col_name.split(':')
                if prop_name == 'id_perms':
                    # id-perms always has to be updated for last-mod timestamp
                    # get it from request dict(or from db if not in request dict)
                    new_id_perms = new_obj_dict.get(prop_name, json.loads(obj_cols[col_name]))
                    new_id_perms['last_modified'] = datetime.datetime.now().isoformat()
                    new_props['id_perms'] = new_id_perms
                    self._update_prop(bch, obj_uuid, 'id_perms', new_props)
                elif prop_name in new_obj_dict:
                    self._update_prop(bch, obj_uuid, prop_name, new_props)

            # TODO use compiled RE
            if re.match('ref:', col_name):
                (_, ref_type, ref_uuid) = col_name.split(':')
                self._update_ref(bch, 'namespace', obj_uuid, ref_type, ref_uuid, new_ref_infos)
        # for all column names

        # create new refs
        for ref_type in new_ref_infos.keys():
            for ref_uuid in new_ref_infos[ref_type].keys():
                ref_data = new_ref_infos[ref_type][ref_uuid]
                self._create_ref(bch, 'namespace', obj_uuid, ref_type, ref_uuid, ref_data)

        # create new props
        for prop_name in new_props.keys():
            self._create_prop(bch, obj_uuid, prop_name, new_props[prop_name])

        bch.send()

        return (True, '')
    #end _cassandra_namespace_update

    def _cassandra_namespace_list(self, parent_uuid):
        children_fq_names = []
        if not parent_uuid:
            # grab all resources of this type
            obj_fq_name_cf = self._obj_fq_name_cf
            col_name_iter = obj_fq_name_cf.xget('namespace')
            for (col_name, col_val) in col_name_iter:
                fq_name = col_name.split(':')[:-1]
                children_fq_names.append(fq_name)
        else:
            # go from parent to child
            obj_uuid_cf = self._obj_uuid_cf
            col_start = 'children:namespace:'
            col_fin = 'children:namespace;'
            col_name_iter = obj_uuid_cf.xget(parent_uuid, column_start = col_start, \
                                column_finish = col_fin, include_timestamp = True)

            unsorted_fq_names = []
            for col in col_name_iter:
                col_name = col[0]
                col_val_ts = col[1]
                child_uuid = col_name.split(':')[2]
                child_fq_name = self.uuid_to_fq_name(child_uuid)
                tstamp = col_val_ts[1]
                unsorted_fq_names.append({'fq_name': child_fq_name, 'tstamp': tstamp})

                # sort children; TODO do this based on schema
                sorted_children = sorted(unsorted_fq_names, key = itemgetter('tstamp'))
                # re-write result's children without timestamp
                children_fq_names = [child['fq_name'] for child in sorted_children]

        return (True, children_fq_names)
    #end _cassandra_namespace_list

    def _cassandra_namespace_delete(self, obj_uuid):
        obj_uuid_cf = self._obj_uuid_cf
        fq_name = json.loads(obj_uuid_cf.get(obj_uuid, columns = ['fq_name'])['fq_name'])
        bch = obj_uuid_cf.batch()

        # unlink from parent
        col_start = 'parent:'
        col_fin = 'parent;'
        col_name_iter = obj_uuid_cf.xget(obj_uuid, column_start = col_start, column_finish = col_fin)
        for (col_name, col_val) in col_name_iter:
            (_, parent_type, parent_uuid) = col_name.split(':')
            self._delete_child(bch, parent_type, parent_uuid, 'namespace', obj_uuid)

        # remove refs
        col_start = 'ref:'
        col_fin = 'ref;'
        col_name_iter = obj_uuid_cf.xget(obj_uuid, column_start = col_start, column_finish = col_fin)
        for (col_name, col_val) in col_name_iter:
            (_, ref_type, ref_uuid) = col_name.split(':')
            self._delete_ref(bch, 'namespace', obj_uuid, ref_type, ref_uuid)

        bch.remove(obj_uuid)
        bch.send()

        # Update fqname table
        fq_name_str = ':'.join(fq_name)
        fq_name_col = fq_name_str + ':' + obj_uuid
        self._obj_fq_name_cf.remove('namespace', columns = [fq_name_col])


        return (True, '')
    #end _cassandra_namespace_delete

    def _cassandra_physical_interface_alloc(self, fq_name):
        return (True, '')
    #end _cassandra_physical_interface_alloc

    def _cassandra_physical_interface_create(self, obj_ids, obj_dict):
        # Gather column values for obj and updates to backrefs
        # in a batch and write it at the end
        bch = self._obj_uuid_cf.batch()

        obj_cols = {}
        obj_cols['fq_name'] = json.dumps(obj_dict['fq_name'])
        obj_cols['type'] = json.dumps('physical_interface')
        if 'parent_type' in obj_dict:
            # non config-root child
            parent_type = obj_dict['parent_type']
            parent_method_type = parent_type.replace('-', '_')
            parent_fq_name = obj_dict['fq_name'][:-1]
            obj_cols['parent_type'] = json.dumps(parent_type)
            parent_uuid = self.fq_name_to_uuid(parent_method_type, parent_fq_name)
            self._create_child(bch, parent_method_type, parent_uuid, 'physical_interface', obj_ids['uuid'])

        # Properties
        field = obj_dict.get('id_perms', None)
        field['created'] = datetime.datetime.now().isoformat()
        field['last_modified'] = field['created']
        if field:
            self._create_prop(bch, obj_ids['uuid'], 'id_perms', field)


        # References

        bch.insert(obj_ids['uuid'], obj_cols)
        bch.send()

        # Update fqname table
        fq_name_str = ':'.join(obj_dict['fq_name'])
        fq_name_cols = {fq_name_str + ':' + obj_ids['uuid']: json.dumps(None)}
        self._obj_fq_name_cf.insert('physical_interface', fq_name_cols)

        return (True, '')
    #end _cassandra_physical_interface_create

    def _cassandra_physical_interface_read(self, obj_uuid, field_names = None):
        obj_uuid_cf = self._obj_uuid_cf
        obj_cols_iter = obj_uuid_cf.xget(obj_uuid, include_timestamp = True)
        # TODO optimize this if needed
        obj_cols = {}
        for col in obj_cols_iter:
            # col-name = value + tstamp
            obj_cols[col[0]] = {'value': col[1][0], 'tstamp': col[1][1]}
            # TODO use compile RE
            if re.match('parent:', col[0]):
                (_, _, parent_uuid) = col[0].split(':')

        if not obj_cols:
            raise common.exceptions.NoIdError(obj_uuid)

        result = {}
        # Name info
        result['fq_name'] = json.loads(obj_cols['fq_name']['value'])
        if 'parent_type' in obj_cols:
            # non config-root child
            parent_type = json.loads(obj_cols['parent_type']['value'])
            result['parent_type'] = parent_type
            try:
                result['parent_uuid'] = parent_uuid
                result['parent_href'] = self._db_client_mgr.generate_url(parent_type, parent_uuid)
            except common.exceptions.NoIdError:
                err_msg = 'Unknown uuid for parent ' + result['fq_name'][-2]
                return (False, err_msg)

        for col_name in obj_cols.keys():
            # TODO use compiled RE
            if re.match('prop:', col_name):
                (_, prop_name) = col_name.split(':')
                result[prop_name] = json.loads(obj_cols[col_name]['value'])

            # TODO use compiled RE
            if re.match('children:', col_name):
                (_, child_type, child_uuid) = col_name.split(':')
                child_tstamp = obj_cols[col_name]['tstamp']
                try:
                    self._read_child(result, obj_uuid, child_type, child_uuid, child_tstamp)
                except common.exceptions.NoIdError:
                    continue

            # TODO use compiled RE
            if re.match('ref:', col_name):
                (_, ref_type, ref_uuid) = col_name.split(':')
                self._read_ref(result, obj_uuid, ref_type, ref_uuid, obj_cols[col_name]['value'])

            if re.match('backref:', col_name):
                (_, back_ref_type, back_ref_uuid) = col_name.split(':')
                try:
                    self._read_back_ref(result, obj_uuid, back_ref_type, back_ref_uuid, \
                                        obj_cols[col_name]['value'])
                except common.exceptions.NoIdError:
                    continue

        # for all column names

        if 'logical_interfaces' in result:
            # sort children; TODO do this based on schema
            sorted_children = sorted(result['logical_interfaces'], key = itemgetter('tstamp'))
            # re-write result's children without timestamp
            result['logical_interfaces'] = sorted_children
            [child.pop('tstamp') for child in result['logical_interfaces']]


        return (True, result)
    #end _cassandra_physical_interface_read

    def _cassandra_physical_interface_update(self, obj_uuid, dummy_old_obj_dict, new_obj_dict):
        # Grab ref-uuids and properties in new version
        new_ref_infos = {}

        new_props = {}
        if 'id_perms' in new_obj_dict:
            new_props['id_perms'] = new_obj_dict['id_perms']
        # Gather column values for obj and updates to backrefs
        # in a batch and write it at the end
        obj_uuid_cf = self._obj_uuid_cf
        obj_cols_iter = obj_uuid_cf.xget(obj_uuid)
        # TODO optimize this (converts tuple to dict)
        obj_cols = {}
        for col_info in obj_cols_iter:
            obj_cols[col_info[0]] = col_info[1]

        bch = obj_uuid_cf.batch()
        for col_name in obj_cols.keys():
            # TODO use compiled RE
            if re.match('prop:', col_name):
                (_, prop_name) = col_name.split(':')
                if prop_name == 'id_perms':
                    # id-perms always has to be updated for last-mod timestamp
                    # get it from request dict(or from db if not in request dict)
                    new_id_perms = new_obj_dict.get(prop_name, json.loads(obj_cols[col_name]))
                    new_id_perms['last_modified'] = datetime.datetime.now().isoformat()
                    new_props['id_perms'] = new_id_perms
                    self._update_prop(bch, obj_uuid, 'id_perms', new_props)
                elif prop_name in new_obj_dict:
                    self._update_prop(bch, obj_uuid, prop_name, new_props)

            # TODO use compiled RE
            if re.match('ref:', col_name):
                (_, ref_type, ref_uuid) = col_name.split(':')
                self._update_ref(bch, 'physical_interface', obj_uuid, ref_type, ref_uuid, new_ref_infos)
        # for all column names

        # create new refs
        for ref_type in new_ref_infos.keys():
            for ref_uuid in new_ref_infos[ref_type].keys():
                ref_data = new_ref_infos[ref_type][ref_uuid]
                self._create_ref(bch, 'physical_interface', obj_uuid, ref_type, ref_uuid, ref_data)

        # create new props
        for prop_name in new_props.keys():
            self._create_prop(bch, obj_uuid, prop_name, new_props[prop_name])

        bch.send()

        return (True, '')
    #end _cassandra_physical_interface_update

    def _cassandra_physical_interface_list(self, parent_uuid):
        children_fq_names = []
        if not parent_uuid:
            # grab all resources of this type
            obj_fq_name_cf = self._obj_fq_name_cf
            col_name_iter = obj_fq_name_cf.xget('physical_interface')
            for (col_name, col_val) in col_name_iter:
                fq_name = col_name.split(':')[:-1]
                children_fq_names.append(fq_name)
        else:
            # go from parent to child
            obj_uuid_cf = self._obj_uuid_cf
            col_start = 'children:physical_interface:'
            col_fin = 'children:physical_interface;'
            col_name_iter = obj_uuid_cf.xget(parent_uuid, column_start = col_start, \
                                column_finish = col_fin, include_timestamp = True)

            unsorted_fq_names = []
            for col in col_name_iter:
                col_name = col[0]
                col_val_ts = col[1]
                child_uuid = col_name.split(':')[2]
                child_fq_name = self.uuid_to_fq_name(child_uuid)
                tstamp = col_val_ts[1]
                unsorted_fq_names.append({'fq_name': child_fq_name, 'tstamp': tstamp})

                # sort children; TODO do this based on schema
                sorted_children = sorted(unsorted_fq_names, key = itemgetter('tstamp'))
                # re-write result's children without timestamp
                children_fq_names = [child['fq_name'] for child in sorted_children]

        return (True, children_fq_names)
    #end _cassandra_physical_interface_list

    def _cassandra_physical_interface_delete(self, obj_uuid):
        obj_uuid_cf = self._obj_uuid_cf
        fq_name = json.loads(obj_uuid_cf.get(obj_uuid, columns = ['fq_name'])['fq_name'])
        bch = obj_uuid_cf.batch()

        # unlink from parent
        col_start = 'parent:'
        col_fin = 'parent;'
        col_name_iter = obj_uuid_cf.xget(obj_uuid, column_start = col_start, column_finish = col_fin)
        for (col_name, col_val) in col_name_iter:
            (_, parent_type, parent_uuid) = col_name.split(':')
            self._delete_child(bch, parent_type, parent_uuid, 'physical_interface', obj_uuid)

        # remove refs
        col_start = 'ref:'
        col_fin = 'ref;'
        col_name_iter = obj_uuid_cf.xget(obj_uuid, column_start = col_start, column_finish = col_fin)
        for (col_name, col_val) in col_name_iter:
            (_, ref_type, ref_uuid) = col_name.split(':')
            self._delete_ref(bch, 'physical_interface', obj_uuid, ref_type, ref_uuid)

        bch.remove(obj_uuid)
        bch.send()

        # Update fqname table
        fq_name_str = ':'.join(fq_name)
        fq_name_col = fq_name_str + ':' + obj_uuid
        self._obj_fq_name_cf.remove('physical_interface', columns = [fq_name_col])


        return (True, '')
    #end _cassandra_physical_interface_delete

    def _cassandra_access_control_list_alloc(self, fq_name):
        return (True, '')
    #end _cassandra_access_control_list_alloc

    def _cassandra_access_control_list_create(self, obj_ids, obj_dict):
        # Gather column values for obj and updates to backrefs
        # in a batch and write it at the end
        bch = self._obj_uuid_cf.batch()

        obj_cols = {}
        obj_cols['fq_name'] = json.dumps(obj_dict['fq_name'])
        obj_cols['type'] = json.dumps('access_control_list')
        if 'parent_type' in obj_dict:
            # non config-root child
            parent_type = obj_dict['parent_type']
            parent_method_type = parent_type.replace('-', '_')
            parent_fq_name = obj_dict['fq_name'][:-1]
            obj_cols['parent_type'] = json.dumps(parent_type)
            parent_uuid = self.fq_name_to_uuid(parent_method_type, parent_fq_name)
            self._create_child(bch, parent_method_type, parent_uuid, 'access_control_list', obj_ids['uuid'])

        # Properties
        field = obj_dict.get('access_control_list_entries', None)
        if field:
            self._create_prop(bch, obj_ids['uuid'], 'access_control_list_entries', field)

        field = obj_dict.get('id_perms', None)
        field['created'] = datetime.datetime.now().isoformat()
        field['last_modified'] = field['created']
        if field:
            self._create_prop(bch, obj_ids['uuid'], 'id_perms', field)


        # References

        bch.insert(obj_ids['uuid'], obj_cols)
        bch.send()

        # Update fqname table
        fq_name_str = ':'.join(obj_dict['fq_name'])
        fq_name_cols = {fq_name_str + ':' + obj_ids['uuid']: json.dumps(None)}
        self._obj_fq_name_cf.insert('access_control_list', fq_name_cols)

        return (True, '')
    #end _cassandra_access_control_list_create

    def _cassandra_access_control_list_read(self, obj_uuid, field_names = None):
        obj_uuid_cf = self._obj_uuid_cf
        obj_cols_iter = obj_uuid_cf.xget(obj_uuid, include_timestamp = True)
        # TODO optimize this if needed
        obj_cols = {}
        for col in obj_cols_iter:
            # col-name = value + tstamp
            obj_cols[col[0]] = {'value': col[1][0], 'tstamp': col[1][1]}
            # TODO use compile RE
            if re.match('parent:', col[0]):
                (_, _, parent_uuid) = col[0].split(':')

        if not obj_cols:
            raise common.exceptions.NoIdError(obj_uuid)

        result = {}
        # Name info
        result['fq_name'] = json.loads(obj_cols['fq_name']['value'])
        if 'parent_type' in obj_cols:
            # non config-root child
            parent_type = json.loads(obj_cols['parent_type']['value'])
            result['parent_type'] = parent_type
            try:
                result['parent_uuid'] = parent_uuid
                result['parent_href'] = self._db_client_mgr.generate_url(parent_type, parent_uuid)
            except common.exceptions.NoIdError:
                # ok for parent to go away since we are machine generated
                pass

        for col_name in obj_cols.keys():
            # TODO use compiled RE
            if re.match('prop:', col_name):
                (_, prop_name) = col_name.split(':')
                result[prop_name] = json.loads(obj_cols[col_name]['value'])

            # TODO use compiled RE
            if re.match('children:', col_name):
                (_, child_type, child_uuid) = col_name.split(':')
                child_tstamp = obj_cols[col_name]['tstamp']
                try:
                    self._read_child(result, obj_uuid, child_type, child_uuid, child_tstamp)
                except common.exceptions.NoIdError:
                    continue

            # TODO use compiled RE
            if re.match('ref:', col_name):
                (_, ref_type, ref_uuid) = col_name.split(':')
                self._read_ref(result, obj_uuid, ref_type, ref_uuid, obj_cols[col_name]['value'])

            if re.match('backref:', col_name):
                (_, back_ref_type, back_ref_uuid) = col_name.split(':')
                try:
                    self._read_back_ref(result, obj_uuid, back_ref_type, back_ref_uuid, \
                                        obj_cols[col_name]['value'])
                except common.exceptions.NoIdError:
                    continue

        # for all column names


        return (True, result)
    #end _cassandra_access_control_list_read

    def _cassandra_access_control_list_update(self, obj_uuid, dummy_old_obj_dict, new_obj_dict):
        # Grab ref-uuids and properties in new version
        new_ref_infos = {}

        new_props = {}
        if 'access_control_list_entries' in new_obj_dict:
            new_props['access_control_list_entries'] = new_obj_dict['access_control_list_entries']
        if 'id_perms' in new_obj_dict:
            new_props['id_perms'] = new_obj_dict['id_perms']
        # Gather column values for obj and updates to backrefs
        # in a batch and write it at the end
        obj_uuid_cf = self._obj_uuid_cf
        obj_cols_iter = obj_uuid_cf.xget(obj_uuid)
        # TODO optimize this (converts tuple to dict)
        obj_cols = {}
        for col_info in obj_cols_iter:
            obj_cols[col_info[0]] = col_info[1]

        bch = obj_uuid_cf.batch()
        for col_name in obj_cols.keys():
            # TODO use compiled RE
            if re.match('prop:', col_name):
                (_, prop_name) = col_name.split(':')
                if prop_name == 'id_perms':
                    # id-perms always has to be updated for last-mod timestamp
                    # get it from request dict(or from db if not in request dict)
                    new_id_perms = new_obj_dict.get(prop_name, json.loads(obj_cols[col_name]))
                    new_id_perms['last_modified'] = datetime.datetime.now().isoformat()
                    new_props['id_perms'] = new_id_perms
                    self._update_prop(bch, obj_uuid, 'id_perms', new_props)
                elif prop_name in new_obj_dict:
                    self._update_prop(bch, obj_uuid, prop_name, new_props)

            # TODO use compiled RE
            if re.match('ref:', col_name):
                (_, ref_type, ref_uuid) = col_name.split(':')
                self._update_ref(bch, 'access_control_list', obj_uuid, ref_type, ref_uuid, new_ref_infos)
        # for all column names

        # create new refs
        for ref_type in new_ref_infos.keys():
            for ref_uuid in new_ref_infos[ref_type].keys():
                ref_data = new_ref_infos[ref_type][ref_uuid]
                self._create_ref(bch, 'access_control_list', obj_uuid, ref_type, ref_uuid, ref_data)

        # create new props
        for prop_name in new_props.keys():
            self._create_prop(bch, obj_uuid, prop_name, new_props[prop_name])

        bch.send()

        return (True, '')
    #end _cassandra_access_control_list_update

    def _cassandra_access_control_list_list(self, parent_uuid):
        children_fq_names = []
        if not parent_uuid:
            # grab all resources of this type
            obj_fq_name_cf = self._obj_fq_name_cf
            col_name_iter = obj_fq_name_cf.xget('access_control_list')
            for (col_name, col_val) in col_name_iter:
                fq_name = col_name.split(':')[:-1]
                children_fq_names.append(fq_name)
        else:
            # go from parent to child
            obj_uuid_cf = self._obj_uuid_cf
            col_start = 'children:access_control_list:'
            col_fin = 'children:access_control_list;'
            col_name_iter = obj_uuid_cf.xget(parent_uuid, column_start = col_start, \
                                column_finish = col_fin, include_timestamp = True)

            unsorted_fq_names = []
            for col in col_name_iter:
                col_name = col[0]
                col_val_ts = col[1]
                child_uuid = col_name.split(':')[2]
                child_fq_name = self.uuid_to_fq_name(child_uuid)
                tstamp = col_val_ts[1]
                unsorted_fq_names.append({'fq_name': child_fq_name, 'tstamp': tstamp})

                # sort children; TODO do this based on schema
                sorted_children = sorted(unsorted_fq_names, key = itemgetter('tstamp'))
                # re-write result's children without timestamp
                children_fq_names = [child['fq_name'] for child in sorted_children]

        return (True, children_fq_names)
    #end _cassandra_access_control_list_list

    def _cassandra_access_control_list_delete(self, obj_uuid):
        obj_uuid_cf = self._obj_uuid_cf
        fq_name = json.loads(obj_uuid_cf.get(obj_uuid, columns = ['fq_name'])['fq_name'])
        bch = obj_uuid_cf.batch()

        # unlink from parent
        col_start = 'parent:'
        col_fin = 'parent;'
        col_name_iter = obj_uuid_cf.xget(obj_uuid, column_start = col_start, column_finish = col_fin)
        for (col_name, col_val) in col_name_iter:
            (_, parent_type, parent_uuid) = col_name.split(':')
            self._delete_child(bch, parent_type, parent_uuid, 'access_control_list', obj_uuid)

        # remove refs
        col_start = 'ref:'
        col_fin = 'ref;'
        col_name_iter = obj_uuid_cf.xget(obj_uuid, column_start = col_start, column_finish = col_fin)
        for (col_name, col_val) in col_name_iter:
            (_, ref_type, ref_uuid) = col_name.split(':')
            self._delete_ref(bch, 'access_control_list', obj_uuid, ref_type, ref_uuid)

        bch.remove(obj_uuid)
        bch.send()

        # Update fqname table
        fq_name_str = ':'.join(fq_name)
        fq_name_col = fq_name_str + ':' + obj_uuid
        self._obj_fq_name_cf.remove('access_control_list', columns = [fq_name_col])


        return (True, '')
    #end _cassandra_access_control_list_delete

    def _cassandra_virtual_DNS_alloc(self, fq_name):
        return (True, '')
    #end _cassandra_virtual_DNS_alloc

    def _cassandra_virtual_DNS_create(self, obj_ids, obj_dict):
        # Gather column values for obj and updates to backrefs
        # in a batch and write it at the end
        bch = self._obj_uuid_cf.batch()

        obj_cols = {}
        obj_cols['fq_name'] = json.dumps(obj_dict['fq_name'])
        obj_cols['type'] = json.dumps('virtual_DNS')
        if 'parent_type' in obj_dict:
            # non config-root child
            parent_type = obj_dict['parent_type']
            parent_method_type = parent_type.replace('-', '_')
            parent_fq_name = obj_dict['fq_name'][:-1]
            obj_cols['parent_type'] = json.dumps(parent_type)
            parent_uuid = self.fq_name_to_uuid(parent_method_type, parent_fq_name)
            self._create_child(bch, parent_method_type, parent_uuid, 'virtual_DNS', obj_ids['uuid'])

        # Properties
        field = obj_dict.get('virtual_DNS_data', None)
        if field:
            self._create_prop(bch, obj_ids['uuid'], 'virtual_DNS_data', field)

        field = obj_dict.get('id_perms', None)
        field['created'] = datetime.datetime.now().isoformat()
        field['last_modified'] = field['created']
        if field:
            self._create_prop(bch, obj_ids['uuid'], 'id_perms', field)


        # References

        bch.insert(obj_ids['uuid'], obj_cols)
        bch.send()

        # Update fqname table
        fq_name_str = ':'.join(obj_dict['fq_name'])
        fq_name_cols = {fq_name_str + ':' + obj_ids['uuid']: json.dumps(None)}
        self._obj_fq_name_cf.insert('virtual_DNS', fq_name_cols)

        return (True, '')
    #end _cassandra_virtual_DNS_create

    def _cassandra_virtual_DNS_read(self, obj_uuid, field_names = None):
        obj_uuid_cf = self._obj_uuid_cf
        obj_cols_iter = obj_uuid_cf.xget(obj_uuid, include_timestamp = True)
        # TODO optimize this if needed
        obj_cols = {}
        for col in obj_cols_iter:
            # col-name = value + tstamp
            obj_cols[col[0]] = {'value': col[1][0], 'tstamp': col[1][1]}
            # TODO use compile RE
            if re.match('parent:', col[0]):
                (_, _, parent_uuid) = col[0].split(':')

        if not obj_cols:
            raise common.exceptions.NoIdError(obj_uuid)

        result = {}
        # Name info
        result['fq_name'] = json.loads(obj_cols['fq_name']['value'])
        if 'parent_type' in obj_cols:
            # non config-root child
            parent_type = json.loads(obj_cols['parent_type']['value'])
            result['parent_type'] = parent_type
            try:
                result['parent_uuid'] = parent_uuid
                result['parent_href'] = self._db_client_mgr.generate_url(parent_type, parent_uuid)
            except common.exceptions.NoIdError:
                err_msg = 'Unknown uuid for parent ' + result['fq_name'][-2]
                return (False, err_msg)

        for col_name in obj_cols.keys():
            # TODO use compiled RE
            if re.match('prop:', col_name):
                (_, prop_name) = col_name.split(':')
                result[prop_name] = json.loads(obj_cols[col_name]['value'])

            # TODO use compiled RE
            if re.match('children:', col_name):
                (_, child_type, child_uuid) = col_name.split(':')
                child_tstamp = obj_cols[col_name]['tstamp']
                try:
                    self._read_child(result, obj_uuid, child_type, child_uuid, child_tstamp)
                except common.exceptions.NoIdError:
                    continue

            # TODO use compiled RE
            if re.match('ref:', col_name):
                (_, ref_type, ref_uuid) = col_name.split(':')
                self._read_ref(result, obj_uuid, ref_type, ref_uuid, obj_cols[col_name]['value'])

            if re.match('backref:', col_name):
                (_, back_ref_type, back_ref_uuid) = col_name.split(':')
                try:
                    self._read_back_ref(result, obj_uuid, back_ref_type, back_ref_uuid, \
                                        obj_cols[col_name]['value'])
                except common.exceptions.NoIdError:
                    continue

        # for all column names

        if 'virtual_DNS_records' in result:
            # sort children; TODO do this based on schema
            sorted_children = sorted(result['virtual_DNS_records'], key = itemgetter('tstamp'))
            # re-write result's children without timestamp
            result['virtual_DNS_records'] = sorted_children
            [child.pop('tstamp') for child in result['virtual_DNS_records']]


        return (True, result)
    #end _cassandra_virtual_DNS_read

    def _cassandra_virtual_DNS_update(self, obj_uuid, dummy_old_obj_dict, new_obj_dict):
        # Grab ref-uuids and properties in new version
        new_ref_infos = {}

        new_props = {}
        if 'virtual_DNS_data' in new_obj_dict:
            new_props['virtual_DNS_data'] = new_obj_dict['virtual_DNS_data']
        if 'id_perms' in new_obj_dict:
            new_props['id_perms'] = new_obj_dict['id_perms']
        # Gather column values for obj and updates to backrefs
        # in a batch and write it at the end
        obj_uuid_cf = self._obj_uuid_cf
        obj_cols_iter = obj_uuid_cf.xget(obj_uuid)
        # TODO optimize this (converts tuple to dict)
        obj_cols = {}
        for col_info in obj_cols_iter:
            obj_cols[col_info[0]] = col_info[1]

        bch = obj_uuid_cf.batch()
        for col_name in obj_cols.keys():
            # TODO use compiled RE
            if re.match('prop:', col_name):
                (_, prop_name) = col_name.split(':')
                if prop_name == 'id_perms':
                    # id-perms always has to be updated for last-mod timestamp
                    # get it from request dict(or from db if not in request dict)
                    new_id_perms = new_obj_dict.get(prop_name, json.loads(obj_cols[col_name]))
                    new_id_perms['last_modified'] = datetime.datetime.now().isoformat()
                    new_props['id_perms'] = new_id_perms
                    self._update_prop(bch, obj_uuid, 'id_perms', new_props)
                elif prop_name in new_obj_dict:
                    self._update_prop(bch, obj_uuid, prop_name, new_props)

            # TODO use compiled RE
            if re.match('ref:', col_name):
                (_, ref_type, ref_uuid) = col_name.split(':')
                self._update_ref(bch, 'virtual_DNS', obj_uuid, ref_type, ref_uuid, new_ref_infos)
        # for all column names

        # create new refs
        for ref_type in new_ref_infos.keys():
            for ref_uuid in new_ref_infos[ref_type].keys():
                ref_data = new_ref_infos[ref_type][ref_uuid]
                self._create_ref(bch, 'virtual_DNS', obj_uuid, ref_type, ref_uuid, ref_data)

        # create new props
        for prop_name in new_props.keys():
            self._create_prop(bch, obj_uuid, prop_name, new_props[prop_name])

        bch.send()

        return (True, '')
    #end _cassandra_virtual_DNS_update

    def _cassandra_virtual_DNS_list(self, parent_uuid):
        children_fq_names = []
        if not parent_uuid:
            # grab all resources of this type
            obj_fq_name_cf = self._obj_fq_name_cf
            col_name_iter = obj_fq_name_cf.xget('virtual_DNS')
            for (col_name, col_val) in col_name_iter:
                fq_name = col_name.split(':')[:-1]
                children_fq_names.append(fq_name)
        else:
            # go from parent to child
            obj_uuid_cf = self._obj_uuid_cf
            col_start = 'children:virtual_DNS:'
            col_fin = 'children:virtual_DNS;'
            col_name_iter = obj_uuid_cf.xget(parent_uuid, column_start = col_start, \
                                column_finish = col_fin, include_timestamp = True)

            unsorted_fq_names = []
            for col in col_name_iter:
                col_name = col[0]
                col_val_ts = col[1]
                child_uuid = col_name.split(':')[2]
                child_fq_name = self.uuid_to_fq_name(child_uuid)
                tstamp = col_val_ts[1]
                unsorted_fq_names.append({'fq_name': child_fq_name, 'tstamp': tstamp})

                # sort children; TODO do this based on schema
                sorted_children = sorted(unsorted_fq_names, key = itemgetter('tstamp'))
                # re-write result's children without timestamp
                children_fq_names = [child['fq_name'] for child in sorted_children]

        return (True, children_fq_names)
    #end _cassandra_virtual_DNS_list

    def _cassandra_virtual_DNS_delete(self, obj_uuid):
        obj_uuid_cf = self._obj_uuid_cf
        fq_name = json.loads(obj_uuid_cf.get(obj_uuid, columns = ['fq_name'])['fq_name'])
        bch = obj_uuid_cf.batch()

        # unlink from parent
        col_start = 'parent:'
        col_fin = 'parent;'
        col_name_iter = obj_uuid_cf.xget(obj_uuid, column_start = col_start, column_finish = col_fin)
        for (col_name, col_val) in col_name_iter:
            (_, parent_type, parent_uuid) = col_name.split(':')
            self._delete_child(bch, parent_type, parent_uuid, 'virtual_DNS', obj_uuid)

        # remove refs
        col_start = 'ref:'
        col_fin = 'ref;'
        col_name_iter = obj_uuid_cf.xget(obj_uuid, column_start = col_start, column_finish = col_fin)
        for (col_name, col_val) in col_name_iter:
            (_, ref_type, ref_uuid) = col_name.split(':')
            self._delete_ref(bch, 'virtual_DNS', obj_uuid, ref_type, ref_uuid)

        bch.remove(obj_uuid)
        bch.send()

        # Update fqname table
        fq_name_str = ':'.join(fq_name)
        fq_name_col = fq_name_str + ':' + obj_uuid
        self._obj_fq_name_cf.remove('virtual_DNS', columns = [fq_name_col])


        return (True, '')
    #end _cassandra_virtual_DNS_delete

    def _cassandra_customer_attachment_alloc(self, fq_name):
        return (True, '')
    #end _cassandra_customer_attachment_alloc

    def _cassandra_customer_attachment_create(self, obj_ids, obj_dict):
        # Gather column values for obj and updates to backrefs
        # in a batch and write it at the end
        bch = self._obj_uuid_cf.batch()

        obj_cols = {}
        obj_cols['fq_name'] = json.dumps(obj_dict['fq_name'])
        obj_cols['type'] = json.dumps('customer_attachment')

        # Properties
        field = obj_dict.get('attachment_address', None)
        if field:
            self._create_prop(bch, obj_ids['uuid'], 'attachment_address', field)

        field = obj_dict.get('id_perms', None)
        field['created'] = datetime.datetime.now().isoformat()
        field['last_modified'] = field['created']
        if field:
            self._create_prop(bch, obj_ids['uuid'], 'id_perms', field)


        # References
        refs = obj_dict.get('virtual_machine_interface_refs', [])
        for ref in refs:
            ref_uuid = self.fq_name_to_uuid('virtual_machine_interface', ref['to'])
            ref_attr = ref.get('attr', None)
            ref_data = {'attr': ref_attr, 'is_weakref': False}
            self._create_ref(bch, 'customer_attachment', obj_ids['uuid'], 'virtual_machine_interface', ref_uuid, ref_data)
        refs = obj_dict.get('floating_ip_refs', [])
        for ref in refs:
            ref_uuid = self.fq_name_to_uuid('floating_ip', ref['to'])
            ref_attr = ref.get('attr', None)
            ref_data = {'attr': ref_attr, 'is_weakref': False}
            self._create_ref(bch, 'customer_attachment', obj_ids['uuid'], 'floating_ip', ref_uuid, ref_data)

        bch.insert(obj_ids['uuid'], obj_cols)
        bch.send()

        # Update fqname table
        fq_name_str = ':'.join(obj_dict['fq_name'])
        fq_name_cols = {fq_name_str + ':' + obj_ids['uuid']: json.dumps(None)}
        self._obj_fq_name_cf.insert('customer_attachment', fq_name_cols)

        return (True, '')
    #end _cassandra_customer_attachment_create

    def _cassandra_customer_attachment_read(self, obj_uuid, field_names = None):
        obj_uuid_cf = self._obj_uuid_cf
        obj_cols_iter = obj_uuid_cf.xget(obj_uuid, include_timestamp = True)
        # TODO optimize this if needed
        obj_cols = {}
        for col in obj_cols_iter:
            # col-name = value + tstamp
            obj_cols[col[0]] = {'value': col[1][0], 'tstamp': col[1][1]}
            # TODO use compile RE
            if re.match('parent:', col[0]):
                (_, _, parent_uuid) = col[0].split(':')

        if not obj_cols:
            raise common.exceptions.NoIdError(obj_uuid)

        result = {}
        # Name info
        result['fq_name'] = json.loads(obj_cols['fq_name']['value'])

        for col_name in obj_cols.keys():
            # TODO use compiled RE
            if re.match('prop:', col_name):
                (_, prop_name) = col_name.split(':')
                result[prop_name] = json.loads(obj_cols[col_name]['value'])

            # TODO use compiled RE
            if re.match('children:', col_name):
                (_, child_type, child_uuid) = col_name.split(':')
                child_tstamp = obj_cols[col_name]['tstamp']
                try:
                    self._read_child(result, obj_uuid, child_type, child_uuid, child_tstamp)
                except common.exceptions.NoIdError:
                    continue

            # TODO use compiled RE
            if re.match('ref:', col_name):
                (_, ref_type, ref_uuid) = col_name.split(':')
                self._read_ref(result, obj_uuid, ref_type, ref_uuid, obj_cols[col_name]['value'])

            if re.match('backref:', col_name):
                (_, back_ref_type, back_ref_uuid) = col_name.split(':')
                try:
                    self._read_back_ref(result, obj_uuid, back_ref_type, back_ref_uuid, \
                                        obj_cols[col_name]['value'])
                except common.exceptions.NoIdError:
                    continue

        # for all column names


        return (True, result)
    #end _cassandra_customer_attachment_read

    def _cassandra_customer_attachment_update(self, obj_uuid, dummy_old_obj_dict, new_obj_dict):
        # Grab ref-uuids and properties in new version
        new_ref_infos = {}

        if 'virtual_machine_interface_refs' in new_obj_dict:
            new_ref_infos['virtual_machine_interface'] = {}
            new_refs = new_obj_dict['virtual_machine_interface_refs']
            if new_refs:
                for new_ref in new_refs:
                    new_ref_uuid = self.fq_name_to_uuid('virtual_machine_interface', new_ref['to'])
                    new_ref_attr = new_ref.get('attr', None)
                    new_ref_data = {'attr': new_ref_attr, 'is_weakref': False}
                    new_ref_infos['virtual_machine_interface'][new_ref_uuid] = new_ref_data

        if 'floating_ip_refs' in new_obj_dict:
            new_ref_infos['floating_ip'] = {}
            new_refs = new_obj_dict['floating_ip_refs']
            if new_refs:
                for new_ref in new_refs:
                    new_ref_uuid = self.fq_name_to_uuid('floating_ip', new_ref['to'])
                    new_ref_attr = new_ref.get('attr', None)
                    new_ref_data = {'attr': new_ref_attr, 'is_weakref': False}
                    new_ref_infos['floating_ip'][new_ref_uuid] = new_ref_data

        new_props = {}
        if 'attachment_address' in new_obj_dict:
            new_props['attachment_address'] = new_obj_dict['attachment_address']
        if 'id_perms' in new_obj_dict:
            new_props['id_perms'] = new_obj_dict['id_perms']
        # Gather column values for obj and updates to backrefs
        # in a batch and write it at the end
        obj_uuid_cf = self._obj_uuid_cf
        obj_cols_iter = obj_uuid_cf.xget(obj_uuid)
        # TODO optimize this (converts tuple to dict)
        obj_cols = {}
        for col_info in obj_cols_iter:
            obj_cols[col_info[0]] = col_info[1]

        bch = obj_uuid_cf.batch()
        for col_name in obj_cols.keys():
            # TODO use compiled RE
            if re.match('prop:', col_name):
                (_, prop_name) = col_name.split(':')
                if prop_name == 'id_perms':
                    # id-perms always has to be updated for last-mod timestamp
                    # get it from request dict(or from db if not in request dict)
                    new_id_perms = new_obj_dict.get(prop_name, json.loads(obj_cols[col_name]))
                    new_id_perms['last_modified'] = datetime.datetime.now().isoformat()
                    new_props['id_perms'] = new_id_perms
                    self._update_prop(bch, obj_uuid, 'id_perms', new_props)
                elif prop_name in new_obj_dict:
                    self._update_prop(bch, obj_uuid, prop_name, new_props)

            # TODO use compiled RE
            if re.match('ref:', col_name):
                (_, ref_type, ref_uuid) = col_name.split(':')
                self._update_ref(bch, 'customer_attachment', obj_uuid, ref_type, ref_uuid, new_ref_infos)
        # for all column names

        # create new refs
        for ref_type in new_ref_infos.keys():
            for ref_uuid in new_ref_infos[ref_type].keys():
                ref_data = new_ref_infos[ref_type][ref_uuid]
                self._create_ref(bch, 'customer_attachment', obj_uuid, ref_type, ref_uuid, ref_data)

        # create new props
        for prop_name in new_props.keys():
            self._create_prop(bch, obj_uuid, prop_name, new_props[prop_name])

        bch.send()

        return (True, '')
    #end _cassandra_customer_attachment_update

    def _cassandra_customer_attachment_list(self, parent_uuid):
        children_fq_names = []
        if not parent_uuid:
            # grab all resources of this type
            obj_fq_name_cf = self._obj_fq_name_cf
            col_name_iter = obj_fq_name_cf.xget('customer_attachment')
            for (col_name, col_val) in col_name_iter:
                fq_name = col_name.split(':')[:-1]
                children_fq_names.append(fq_name)
        else:
            # go from parent to child
            obj_uuid_cf = self._obj_uuid_cf
            col_start = 'children:customer_attachment:'
            col_fin = 'children:customer_attachment;'
            col_name_iter = obj_uuid_cf.xget(parent_uuid, column_start = col_start, \
                                column_finish = col_fin, include_timestamp = True)

            unsorted_fq_names = []
            for col in col_name_iter:
                col_name = col[0]
                col_val_ts = col[1]
                child_uuid = col_name.split(':')[2]
                child_fq_name = self.uuid_to_fq_name(child_uuid)
                tstamp = col_val_ts[1]
                unsorted_fq_names.append({'fq_name': child_fq_name, 'tstamp': tstamp})

                # sort children; TODO do this based on schema
                sorted_children = sorted(unsorted_fq_names, key = itemgetter('tstamp'))
                # re-write result's children without timestamp
                children_fq_names = [child['fq_name'] for child in sorted_children]

        return (True, children_fq_names)
    #end _cassandra_customer_attachment_list

    def _cassandra_customer_attachment_delete(self, obj_uuid):
        obj_uuid_cf = self._obj_uuid_cf
        fq_name = json.loads(obj_uuid_cf.get(obj_uuid, columns = ['fq_name'])['fq_name'])
        bch = obj_uuid_cf.batch()

        # unlink from parent
        col_start = 'parent:'
        col_fin = 'parent;'
        col_name_iter = obj_uuid_cf.xget(obj_uuid, column_start = col_start, column_finish = col_fin)
        for (col_name, col_val) in col_name_iter:
            (_, parent_type, parent_uuid) = col_name.split(':')
            self._delete_child(bch, parent_type, parent_uuid, 'customer_attachment', obj_uuid)

        # remove refs
        col_start = 'ref:'
        col_fin = 'ref;'
        col_name_iter = obj_uuid_cf.xget(obj_uuid, column_start = col_start, column_finish = col_fin)
        for (col_name, col_val) in col_name_iter:
            (_, ref_type, ref_uuid) = col_name.split(':')
            self._delete_ref(bch, 'customer_attachment', obj_uuid, ref_type, ref_uuid)

        bch.remove(obj_uuid)
        bch.send()

        # Update fqname table
        fq_name_str = ':'.join(fq_name)
        fq_name_col = fq_name_str + ':' + obj_uuid
        self._obj_fq_name_cf.remove('customer_attachment', columns = [fq_name_col])


        return (True, '')
    #end _cassandra_customer_attachment_delete

    def _cassandra_virtual_machine_alloc(self, fq_name):
        return (True, '')
    #end _cassandra_virtual_machine_alloc

    def _cassandra_virtual_machine_create(self, obj_ids, obj_dict):
        # Gather column values for obj and updates to backrefs
        # in a batch and write it at the end
        bch = self._obj_uuid_cf.batch()

        obj_cols = {}
        obj_cols['fq_name'] = json.dumps(obj_dict['fq_name'])
        obj_cols['type'] = json.dumps('virtual_machine')

        # Properties
        field = obj_dict.get('id_perms', None)
        field['created'] = datetime.datetime.now().isoformat()
        field['last_modified'] = field['created']
        if field:
            self._create_prop(bch, obj_ids['uuid'], 'id_perms', field)


        # References
        refs = obj_dict.get('security_group_refs', [])
        for ref in refs:
            ref_uuid = self.fq_name_to_uuid('security_group', ref['to'])
            ref_attr = ref.get('attr', None)
            ref_data = {'attr': ref_attr, 'is_weakref': False}
            self._create_ref(bch, 'virtual_machine', obj_ids['uuid'], 'security_group', ref_uuid, ref_data)
        refs = obj_dict.get('service_instance_refs', [])
        for ref in refs:
            ref_uuid = self.fq_name_to_uuid('service_instance', ref['to'])
            ref_attr = ref.get('attr', None)
            ref_data = {'attr': ref_attr, 'is_weakref': True}
            self._create_ref(bch, 'virtual_machine', obj_ids['uuid'], 'service_instance', ref_uuid, ref_data)

        bch.insert(obj_ids['uuid'], obj_cols)
        bch.send()

        # Update fqname table
        fq_name_str = ':'.join(obj_dict['fq_name'])
        fq_name_cols = {fq_name_str + ':' + obj_ids['uuid']: json.dumps(None)}
        self._obj_fq_name_cf.insert('virtual_machine', fq_name_cols)

        return (True, '')
    #end _cassandra_virtual_machine_create

    def _cassandra_virtual_machine_read(self, obj_uuid, field_names = None):
        obj_uuid_cf = self._obj_uuid_cf
        obj_cols_iter = obj_uuid_cf.xget(obj_uuid, include_timestamp = True)
        # TODO optimize this if needed
        obj_cols = {}
        for col in obj_cols_iter:
            # col-name = value + tstamp
            obj_cols[col[0]] = {'value': col[1][0], 'tstamp': col[1][1]}
            # TODO use compile RE
            if re.match('parent:', col[0]):
                (_, _, parent_uuid) = col[0].split(':')

        if not obj_cols:
            raise common.exceptions.NoIdError(obj_uuid)

        result = {}
        # Name info
        result['fq_name'] = json.loads(obj_cols['fq_name']['value'])

        for col_name in obj_cols.keys():
            # TODO use compiled RE
            if re.match('prop:', col_name):
                (_, prop_name) = col_name.split(':')
                result[prop_name] = json.loads(obj_cols[col_name]['value'])

            # TODO use compiled RE
            if re.match('children:', col_name):
                (_, child_type, child_uuid) = col_name.split(':')
                child_tstamp = obj_cols[col_name]['tstamp']
                try:
                    self._read_child(result, obj_uuid, child_type, child_uuid, child_tstamp)
                except common.exceptions.NoIdError:
                    continue

            # TODO use compiled RE
            if re.match('ref:', col_name):
                (_, ref_type, ref_uuid) = col_name.split(':')
                self._read_ref(result, obj_uuid, ref_type, ref_uuid, obj_cols[col_name]['value'])

            if re.match('backref:', col_name):
                (_, back_ref_type, back_ref_uuid) = col_name.split(':')
                try:
                    self._read_back_ref(result, obj_uuid, back_ref_type, back_ref_uuid, \
                                        obj_cols[col_name]['value'])
                except common.exceptions.NoIdError:
                    continue

        # for all column names

        if 'virtual_machine_interfaces' in result:
            # sort children; TODO do this based on schema
            sorted_children = sorted(result['virtual_machine_interfaces'], key = itemgetter('tstamp'))
            # re-write result's children without timestamp
            result['virtual_machine_interfaces'] = sorted_children
            [child.pop('tstamp') for child in result['virtual_machine_interfaces']]


        return (True, result)
    #end _cassandra_virtual_machine_read

    def _cassandra_virtual_machine_update(self, obj_uuid, dummy_old_obj_dict, new_obj_dict):
        # Grab ref-uuids and properties in new version
        new_ref_infos = {}

        if 'security_group_refs' in new_obj_dict:
            new_ref_infos['security_group'] = {}
            new_refs = new_obj_dict['security_group_refs']
            if new_refs:
                for new_ref in new_refs:
                    new_ref_uuid = self.fq_name_to_uuid('security_group', new_ref['to'])
                    new_ref_attr = new_ref.get('attr', None)
                    new_ref_data = {'attr': new_ref_attr, 'is_weakref': False}
                    new_ref_infos['security_group'][new_ref_uuid] = new_ref_data

        if 'service_instance_refs' in new_obj_dict:
            new_ref_infos['service_instance'] = {}
            new_refs = new_obj_dict['service_instance_refs']
            if new_refs:
                for new_ref in new_refs:
                    new_ref_uuid = self.fq_name_to_uuid('service_instance', new_ref['to'])
                    new_ref_attr = new_ref.get('attr', None)
                    new_ref_data = {'attr': new_ref_attr, 'is_weakref': True}
                    new_ref_infos['service_instance'][new_ref_uuid] = new_ref_data

        new_props = {}
        if 'id_perms' in new_obj_dict:
            new_props['id_perms'] = new_obj_dict['id_perms']
        # Gather column values for obj and updates to backrefs
        # in a batch and write it at the end
        obj_uuid_cf = self._obj_uuid_cf
        obj_cols_iter = obj_uuid_cf.xget(obj_uuid)
        # TODO optimize this (converts tuple to dict)
        obj_cols = {}
        for col_info in obj_cols_iter:
            obj_cols[col_info[0]] = col_info[1]

        bch = obj_uuid_cf.batch()
        for col_name in obj_cols.keys():
            # TODO use compiled RE
            if re.match('prop:', col_name):
                (_, prop_name) = col_name.split(':')
                if prop_name == 'id_perms':
                    # id-perms always has to be updated for last-mod timestamp
                    # get it from request dict(or from db if not in request dict)
                    new_id_perms = new_obj_dict.get(prop_name, json.loads(obj_cols[col_name]))
                    new_id_perms['last_modified'] = datetime.datetime.now().isoformat()
                    new_props['id_perms'] = new_id_perms
                    self._update_prop(bch, obj_uuid, 'id_perms', new_props)
                elif prop_name in new_obj_dict:
                    self._update_prop(bch, obj_uuid, prop_name, new_props)

            # TODO use compiled RE
            if re.match('ref:', col_name):
                (_, ref_type, ref_uuid) = col_name.split(':')
                self._update_ref(bch, 'virtual_machine', obj_uuid, ref_type, ref_uuid, new_ref_infos)
        # for all column names

        # create new refs
        for ref_type in new_ref_infos.keys():
            for ref_uuid in new_ref_infos[ref_type].keys():
                ref_data = new_ref_infos[ref_type][ref_uuid]
                self._create_ref(bch, 'virtual_machine', obj_uuid, ref_type, ref_uuid, ref_data)

        # create new props
        for prop_name in new_props.keys():
            self._create_prop(bch, obj_uuid, prop_name, new_props[prop_name])

        bch.send()

        return (True, '')
    #end _cassandra_virtual_machine_update

    def _cassandra_virtual_machine_list(self, parent_uuid):
        children_fq_names = []
        if not parent_uuid:
            # grab all resources of this type
            obj_fq_name_cf = self._obj_fq_name_cf
            col_name_iter = obj_fq_name_cf.xget('virtual_machine')
            for (col_name, col_val) in col_name_iter:
                fq_name = col_name.split(':')[:-1]
                children_fq_names.append(fq_name)
        else:
            # go from parent to child
            obj_uuid_cf = self._obj_uuid_cf
            col_start = 'children:virtual_machine:'
            col_fin = 'children:virtual_machine;'
            col_name_iter = obj_uuid_cf.xget(parent_uuid, column_start = col_start, \
                                column_finish = col_fin, include_timestamp = True)

            unsorted_fq_names = []
            for col in col_name_iter:
                col_name = col[0]
                col_val_ts = col[1]
                child_uuid = col_name.split(':')[2]
                child_fq_name = self.uuid_to_fq_name(child_uuid)
                tstamp = col_val_ts[1]
                unsorted_fq_names.append({'fq_name': child_fq_name, 'tstamp': tstamp})

                # sort children; TODO do this based on schema
                sorted_children = sorted(unsorted_fq_names, key = itemgetter('tstamp'))
                # re-write result's children without timestamp
                children_fq_names = [child['fq_name'] for child in sorted_children]

        return (True, children_fq_names)
    #end _cassandra_virtual_machine_list

    def _cassandra_virtual_machine_delete(self, obj_uuid):
        obj_uuid_cf = self._obj_uuid_cf
        fq_name = json.loads(obj_uuid_cf.get(obj_uuid, columns = ['fq_name'])['fq_name'])
        bch = obj_uuid_cf.batch()

        # unlink from parent
        col_start = 'parent:'
        col_fin = 'parent;'
        col_name_iter = obj_uuid_cf.xget(obj_uuid, column_start = col_start, column_finish = col_fin)
        for (col_name, col_val) in col_name_iter:
            (_, parent_type, parent_uuid) = col_name.split(':')
            self._delete_child(bch, parent_type, parent_uuid, 'virtual_machine', obj_uuid)

        # remove refs
        col_start = 'ref:'
        col_fin = 'ref;'
        col_name_iter = obj_uuid_cf.xget(obj_uuid, column_start = col_start, column_finish = col_fin)
        for (col_name, col_val) in col_name_iter:
            (_, ref_type, ref_uuid) = col_name.split(':')
            self._delete_ref(bch, 'virtual_machine', obj_uuid, ref_type, ref_uuid)

        bch.remove(obj_uuid)
        bch.send()

        # Update fqname table
        fq_name_str = ':'.join(fq_name)
        fq_name_col = fq_name_str + ':' + obj_uuid
        self._obj_fq_name_cf.remove('virtual_machine', columns = [fq_name_col])


        return (True, '')
    #end _cassandra_virtual_machine_delete

    def _cassandra_service_template_alloc(self, fq_name):
        return (True, '')
    #end _cassandra_service_template_alloc

    def _cassandra_service_template_create(self, obj_ids, obj_dict):
        # Gather column values for obj and updates to backrefs
        # in a batch and write it at the end
        bch = self._obj_uuid_cf.batch()

        obj_cols = {}
        obj_cols['fq_name'] = json.dumps(obj_dict['fq_name'])
        obj_cols['type'] = json.dumps('service_template')
        if 'parent_type' in obj_dict:
            # non config-root child
            parent_type = obj_dict['parent_type']
            parent_method_type = parent_type.replace('-', '_')
            parent_fq_name = obj_dict['fq_name'][:-1]
            obj_cols['parent_type'] = json.dumps(parent_type)
            parent_uuid = self.fq_name_to_uuid(parent_method_type, parent_fq_name)
            self._create_child(bch, parent_method_type, parent_uuid, 'service_template', obj_ids['uuid'])

        # Properties
        field = obj_dict.get('service_template_properties', None)
        if field:
            self._create_prop(bch, obj_ids['uuid'], 'service_template_properties', field)

        field = obj_dict.get('id_perms', None)
        field['created'] = datetime.datetime.now().isoformat()
        field['last_modified'] = field['created']
        if field:
            self._create_prop(bch, obj_ids['uuid'], 'id_perms', field)


        # References

        bch.insert(obj_ids['uuid'], obj_cols)
        bch.send()

        # Update fqname table
        fq_name_str = ':'.join(obj_dict['fq_name'])
        fq_name_cols = {fq_name_str + ':' + obj_ids['uuid']: json.dumps(None)}
        self._obj_fq_name_cf.insert('service_template', fq_name_cols)

        return (True, '')
    #end _cassandra_service_template_create

    def _cassandra_service_template_read(self, obj_uuid, field_names = None):
        obj_uuid_cf = self._obj_uuid_cf
        obj_cols_iter = obj_uuid_cf.xget(obj_uuid, include_timestamp = True)
        # TODO optimize this if needed
        obj_cols = {}
        for col in obj_cols_iter:
            # col-name = value + tstamp
            obj_cols[col[0]] = {'value': col[1][0], 'tstamp': col[1][1]}
            # TODO use compile RE
            if re.match('parent:', col[0]):
                (_, _, parent_uuid) = col[0].split(':')

        if not obj_cols:
            raise common.exceptions.NoIdError(obj_uuid)

        result = {}
        # Name info
        result['fq_name'] = json.loads(obj_cols['fq_name']['value'])
        if 'parent_type' in obj_cols:
            # non config-root child
            parent_type = json.loads(obj_cols['parent_type']['value'])
            result['parent_type'] = parent_type
            try:
                result['parent_uuid'] = parent_uuid
                result['parent_href'] = self._db_client_mgr.generate_url(parent_type, parent_uuid)
            except common.exceptions.NoIdError:
                err_msg = 'Unknown uuid for parent ' + result['fq_name'][-2]
                return (False, err_msg)

        for col_name in obj_cols.keys():
            # TODO use compiled RE
            if re.match('prop:', col_name):
                (_, prop_name) = col_name.split(':')
                result[prop_name] = json.loads(obj_cols[col_name]['value'])

            # TODO use compiled RE
            if re.match('children:', col_name):
                (_, child_type, child_uuid) = col_name.split(':')
                child_tstamp = obj_cols[col_name]['tstamp']
                try:
                    self._read_child(result, obj_uuid, child_type, child_uuid, child_tstamp)
                except common.exceptions.NoIdError:
                    continue

            # TODO use compiled RE
            if re.match('ref:', col_name):
                (_, ref_type, ref_uuid) = col_name.split(':')
                self._read_ref(result, obj_uuid, ref_type, ref_uuid, obj_cols[col_name]['value'])

            if re.match('backref:', col_name):
                (_, back_ref_type, back_ref_uuid) = col_name.split(':')
                try:
                    self._read_back_ref(result, obj_uuid, back_ref_type, back_ref_uuid, \
                                        obj_cols[col_name]['value'])
                except common.exceptions.NoIdError:
                    continue

        # for all column names


        return (True, result)
    #end _cassandra_service_template_read

    def _cassandra_service_template_update(self, obj_uuid, dummy_old_obj_dict, new_obj_dict):
        # Grab ref-uuids and properties in new version
        new_ref_infos = {}

        new_props = {}
        if 'service_template_properties' in new_obj_dict:
            new_props['service_template_properties'] = new_obj_dict['service_template_properties']
        if 'id_perms' in new_obj_dict:
            new_props['id_perms'] = new_obj_dict['id_perms']
        # Gather column values for obj and updates to backrefs
        # in a batch and write it at the end
        obj_uuid_cf = self._obj_uuid_cf
        obj_cols_iter = obj_uuid_cf.xget(obj_uuid)
        # TODO optimize this (converts tuple to dict)
        obj_cols = {}
        for col_info in obj_cols_iter:
            obj_cols[col_info[0]] = col_info[1]

        bch = obj_uuid_cf.batch()
        for col_name in obj_cols.keys():
            # TODO use compiled RE
            if re.match('prop:', col_name):
                (_, prop_name) = col_name.split(':')
                if prop_name == 'id_perms':
                    # id-perms always has to be updated for last-mod timestamp
                    # get it from request dict(or from db if not in request dict)
                    new_id_perms = new_obj_dict.get(prop_name, json.loads(obj_cols[col_name]))
                    new_id_perms['last_modified'] = datetime.datetime.now().isoformat()
                    new_props['id_perms'] = new_id_perms
                    self._update_prop(bch, obj_uuid, 'id_perms', new_props)
                elif prop_name in new_obj_dict:
                    self._update_prop(bch, obj_uuid, prop_name, new_props)

            # TODO use compiled RE
            if re.match('ref:', col_name):
                (_, ref_type, ref_uuid) = col_name.split(':')
                self._update_ref(bch, 'service_template', obj_uuid, ref_type, ref_uuid, new_ref_infos)
        # for all column names

        # create new refs
        for ref_type in new_ref_infos.keys():
            for ref_uuid in new_ref_infos[ref_type].keys():
                ref_data = new_ref_infos[ref_type][ref_uuid]
                self._create_ref(bch, 'service_template', obj_uuid, ref_type, ref_uuid, ref_data)

        # create new props
        for prop_name in new_props.keys():
            self._create_prop(bch, obj_uuid, prop_name, new_props[prop_name])

        bch.send()

        return (True, '')
    #end _cassandra_service_template_update

    def _cassandra_service_template_list(self, parent_uuid):
        children_fq_names = []
        if not parent_uuid:
            # grab all resources of this type
            obj_fq_name_cf = self._obj_fq_name_cf
            col_name_iter = obj_fq_name_cf.xget('service_template')
            for (col_name, col_val) in col_name_iter:
                fq_name = col_name.split(':')[:-1]
                children_fq_names.append(fq_name)
        else:
            # go from parent to child
            obj_uuid_cf = self._obj_uuid_cf
            col_start = 'children:service_template:'
            col_fin = 'children:service_template;'
            col_name_iter = obj_uuid_cf.xget(parent_uuid, column_start = col_start, \
                                column_finish = col_fin, include_timestamp = True)

            unsorted_fq_names = []
            for col in col_name_iter:
                col_name = col[0]
                col_val_ts = col[1]
                child_uuid = col_name.split(':')[2]
                child_fq_name = self.uuid_to_fq_name(child_uuid)
                tstamp = col_val_ts[1]
                unsorted_fq_names.append({'fq_name': child_fq_name, 'tstamp': tstamp})

                # sort children; TODO do this based on schema
                sorted_children = sorted(unsorted_fq_names, key = itemgetter('tstamp'))
                # re-write result's children without timestamp
                children_fq_names = [child['fq_name'] for child in sorted_children]

        return (True, children_fq_names)
    #end _cassandra_service_template_list

    def _cassandra_service_template_delete(self, obj_uuid):
        obj_uuid_cf = self._obj_uuid_cf
        fq_name = json.loads(obj_uuid_cf.get(obj_uuid, columns = ['fq_name'])['fq_name'])
        bch = obj_uuid_cf.batch()

        # unlink from parent
        col_start = 'parent:'
        col_fin = 'parent;'
        col_name_iter = obj_uuid_cf.xget(obj_uuid, column_start = col_start, column_finish = col_fin)
        for (col_name, col_val) in col_name_iter:
            (_, parent_type, parent_uuid) = col_name.split(':')
            self._delete_child(bch, parent_type, parent_uuid, 'service_template', obj_uuid)

        # remove refs
        col_start = 'ref:'
        col_fin = 'ref;'
        col_name_iter = obj_uuid_cf.xget(obj_uuid, column_start = col_start, column_finish = col_fin)
        for (col_name, col_val) in col_name_iter:
            (_, ref_type, ref_uuid) = col_name.split(':')
            self._delete_ref(bch, 'service_template', obj_uuid, ref_type, ref_uuid)

        bch.remove(obj_uuid)
        bch.send()

        # Update fqname table
        fq_name_str = ':'.join(fq_name)
        fq_name_col = fq_name_str + ':' + obj_uuid
        self._obj_fq_name_cf.remove('service_template', columns = [fq_name_col])


        return (True, '')
    #end _cassandra_service_template_delete

    def _cassandra_security_group_alloc(self, fq_name):
        return (True, '')
    #end _cassandra_security_group_alloc

    def _cassandra_security_group_create(self, obj_ids, obj_dict):
        # Gather column values for obj and updates to backrefs
        # in a batch and write it at the end
        bch = self._obj_uuid_cf.batch()

        obj_cols = {}
        obj_cols['fq_name'] = json.dumps(obj_dict['fq_name'])
        obj_cols['type'] = json.dumps('security_group')
        if 'parent_type' in obj_dict:
            # non config-root child
            parent_type = obj_dict['parent_type']
            parent_method_type = parent_type.replace('-', '_')
            parent_fq_name = obj_dict['fq_name'][:-1]
            obj_cols['parent_type'] = json.dumps(parent_type)
            parent_uuid = self.fq_name_to_uuid(parent_method_type, parent_fq_name)
            self._create_child(bch, parent_method_type, parent_uuid, 'security_group', obj_ids['uuid'])

        # Properties
        field = obj_dict.get('security_group_id', None)
        if field:
            self._create_prop(bch, obj_ids['uuid'], 'security_group_id', field)

        field = obj_dict.get('security_group_entries', None)
        if field:
            self._create_prop(bch, obj_ids['uuid'], 'security_group_entries', field)

        field = obj_dict.get('id_perms', None)
        field['created'] = datetime.datetime.now().isoformat()
        field['last_modified'] = field['created']
        if field:
            self._create_prop(bch, obj_ids['uuid'], 'id_perms', field)


        # References

        bch.insert(obj_ids['uuid'], obj_cols)
        bch.send()

        # Update fqname table
        fq_name_str = ':'.join(obj_dict['fq_name'])
        fq_name_cols = {fq_name_str + ':' + obj_ids['uuid']: json.dumps(None)}
        self._obj_fq_name_cf.insert('security_group', fq_name_cols)

        return (True, '')
    #end _cassandra_security_group_create

    def _cassandra_security_group_read(self, obj_uuid, field_names = None):
        obj_uuid_cf = self._obj_uuid_cf
        obj_cols_iter = obj_uuid_cf.xget(obj_uuid, include_timestamp = True)
        # TODO optimize this if needed
        obj_cols = {}
        for col in obj_cols_iter:
            # col-name = value + tstamp
            obj_cols[col[0]] = {'value': col[1][0], 'tstamp': col[1][1]}
            # TODO use compile RE
            if re.match('parent:', col[0]):
                (_, _, parent_uuid) = col[0].split(':')

        if not obj_cols:
            raise common.exceptions.NoIdError(obj_uuid)

        result = {}
        # Name info
        result['fq_name'] = json.loads(obj_cols['fq_name']['value'])
        if 'parent_type' in obj_cols:
            # non config-root child
            parent_type = json.loads(obj_cols['parent_type']['value'])
            result['parent_type'] = parent_type
            try:
                result['parent_uuid'] = parent_uuid
                result['parent_href'] = self._db_client_mgr.generate_url(parent_type, parent_uuid)
            except common.exceptions.NoIdError:
                err_msg = 'Unknown uuid for parent ' + result['fq_name'][-2]
                return (False, err_msg)

        for col_name in obj_cols.keys():
            # TODO use compiled RE
            if re.match('prop:', col_name):
                (_, prop_name) = col_name.split(':')
                result[prop_name] = json.loads(obj_cols[col_name]['value'])

            # TODO use compiled RE
            if re.match('children:', col_name):
                (_, child_type, child_uuid) = col_name.split(':')
                child_tstamp = obj_cols[col_name]['tstamp']
                try:
                    self._read_child(result, obj_uuid, child_type, child_uuid, child_tstamp)
                except common.exceptions.NoIdError:
                    continue

            # TODO use compiled RE
            if re.match('ref:', col_name):
                (_, ref_type, ref_uuid) = col_name.split(':')
                self._read_ref(result, obj_uuid, ref_type, ref_uuid, obj_cols[col_name]['value'])

            if re.match('backref:', col_name):
                (_, back_ref_type, back_ref_uuid) = col_name.split(':')
                try:
                    self._read_back_ref(result, obj_uuid, back_ref_type, back_ref_uuid, \
                                        obj_cols[col_name]['value'])
                except common.exceptions.NoIdError:
                    continue

        # for all column names


        return (True, result)
    #end _cassandra_security_group_read

    def _cassandra_security_group_update(self, obj_uuid, dummy_old_obj_dict, new_obj_dict):
        # Grab ref-uuids and properties in new version
        new_ref_infos = {}

        new_props = {}
        if 'security_group_id' in new_obj_dict:
            new_props['security_group_id'] = new_obj_dict['security_group_id']
        if 'security_group_entries' in new_obj_dict:
            new_props['security_group_entries'] = new_obj_dict['security_group_entries']
        if 'id_perms' in new_obj_dict:
            new_props['id_perms'] = new_obj_dict['id_perms']
        # Gather column values for obj and updates to backrefs
        # in a batch and write it at the end
        obj_uuid_cf = self._obj_uuid_cf
        obj_cols_iter = obj_uuid_cf.xget(obj_uuid)
        # TODO optimize this (converts tuple to dict)
        obj_cols = {}
        for col_info in obj_cols_iter:
            obj_cols[col_info[0]] = col_info[1]

        bch = obj_uuid_cf.batch()
        for col_name in obj_cols.keys():
            # TODO use compiled RE
            if re.match('prop:', col_name):
                (_, prop_name) = col_name.split(':')
                if prop_name == 'id_perms':
                    # id-perms always has to be updated for last-mod timestamp
                    # get it from request dict(or from db if not in request dict)
                    new_id_perms = new_obj_dict.get(prop_name, json.loads(obj_cols[col_name]))
                    new_id_perms['last_modified'] = datetime.datetime.now().isoformat()
                    new_props['id_perms'] = new_id_perms
                    self._update_prop(bch, obj_uuid, 'id_perms', new_props)
                elif prop_name in new_obj_dict:
                    self._update_prop(bch, obj_uuid, prop_name, new_props)

            # TODO use compiled RE
            if re.match('ref:', col_name):
                (_, ref_type, ref_uuid) = col_name.split(':')
                self._update_ref(bch, 'security_group', obj_uuid, ref_type, ref_uuid, new_ref_infos)
        # for all column names

        # create new refs
        for ref_type in new_ref_infos.keys():
            for ref_uuid in new_ref_infos[ref_type].keys():
                ref_data = new_ref_infos[ref_type][ref_uuid]
                self._create_ref(bch, 'security_group', obj_uuid, ref_type, ref_uuid, ref_data)

        # create new props
        for prop_name in new_props.keys():
            self._create_prop(bch, obj_uuid, prop_name, new_props[prop_name])

        bch.send()

        return (True, '')
    #end _cassandra_security_group_update

    def _cassandra_security_group_list(self, parent_uuid):
        children_fq_names = []
        if not parent_uuid:
            # grab all resources of this type
            obj_fq_name_cf = self._obj_fq_name_cf
            col_name_iter = obj_fq_name_cf.xget('security_group')
            for (col_name, col_val) in col_name_iter:
                fq_name = col_name.split(':')[:-1]
                children_fq_names.append(fq_name)
        else:
            # go from parent to child
            obj_uuid_cf = self._obj_uuid_cf
            col_start = 'children:security_group:'
            col_fin = 'children:security_group;'
            col_name_iter = obj_uuid_cf.xget(parent_uuid, column_start = col_start, \
                                column_finish = col_fin, include_timestamp = True)

            unsorted_fq_names = []
            for col in col_name_iter:
                col_name = col[0]
                col_val_ts = col[1]
                child_uuid = col_name.split(':')[2]
                child_fq_name = self.uuid_to_fq_name(child_uuid)
                tstamp = col_val_ts[1]
                unsorted_fq_names.append({'fq_name': child_fq_name, 'tstamp': tstamp})

                # sort children; TODO do this based on schema
                sorted_children = sorted(unsorted_fq_names, key = itemgetter('tstamp'))
                # re-write result's children without timestamp
                children_fq_names = [child['fq_name'] for child in sorted_children]

        return (True, children_fq_names)
    #end _cassandra_security_group_list

    def _cassandra_security_group_delete(self, obj_uuid):
        obj_uuid_cf = self._obj_uuid_cf
        fq_name = json.loads(obj_uuid_cf.get(obj_uuid, columns = ['fq_name'])['fq_name'])
        bch = obj_uuid_cf.batch()

        # unlink from parent
        col_start = 'parent:'
        col_fin = 'parent;'
        col_name_iter = obj_uuid_cf.xget(obj_uuid, column_start = col_start, column_finish = col_fin)
        for (col_name, col_val) in col_name_iter:
            (_, parent_type, parent_uuid) = col_name.split(':')
            self._delete_child(bch, parent_type, parent_uuid, 'security_group', obj_uuid)

        # remove refs
        col_start = 'ref:'
        col_fin = 'ref;'
        col_name_iter = obj_uuid_cf.xget(obj_uuid, column_start = col_start, column_finish = col_fin)
        for (col_name, col_val) in col_name_iter:
            (_, ref_type, ref_uuid) = col_name.split(':')
            self._delete_ref(bch, 'security_group', obj_uuid, ref_type, ref_uuid)

        bch.remove(obj_uuid)
        bch.send()

        # Update fqname table
        fq_name_str = ':'.join(fq_name)
        fq_name_col = fq_name_str + ':' + obj_uuid
        self._obj_fq_name_cf.remove('security_group', columns = [fq_name_col])


        return (True, '')
    #end _cassandra_security_group_delete

    def _cassandra_provider_attachment_alloc(self, fq_name):
        return (True, '')
    #end _cassandra_provider_attachment_alloc

    def _cassandra_provider_attachment_create(self, obj_ids, obj_dict):
        # Gather column values for obj and updates to backrefs
        # in a batch and write it at the end
        bch = self._obj_uuid_cf.batch()

        obj_cols = {}
        obj_cols['fq_name'] = json.dumps(obj_dict['fq_name'])
        obj_cols['type'] = json.dumps('provider_attachment')

        # Properties
        field = obj_dict.get('id_perms', None)
        field['created'] = datetime.datetime.now().isoformat()
        field['last_modified'] = field['created']
        if field:
            self._create_prop(bch, obj_ids['uuid'], 'id_perms', field)


        # References
        refs = obj_dict.get('virtual_router_refs', [])
        for ref in refs:
            ref_uuid = self.fq_name_to_uuid('virtual_router', ref['to'])
            ref_attr = ref.get('attr', None)
            ref_data = {'attr': ref_attr, 'is_weakref': False}
            self._create_ref(bch, 'provider_attachment', obj_ids['uuid'], 'virtual_router', ref_uuid, ref_data)

        bch.insert(obj_ids['uuid'], obj_cols)
        bch.send()

        # Update fqname table
        fq_name_str = ':'.join(obj_dict['fq_name'])
        fq_name_cols = {fq_name_str + ':' + obj_ids['uuid']: json.dumps(None)}
        self._obj_fq_name_cf.insert('provider_attachment', fq_name_cols)

        return (True, '')
    #end _cassandra_provider_attachment_create

    def _cassandra_provider_attachment_read(self, obj_uuid, field_names = None):
        obj_uuid_cf = self._obj_uuid_cf
        obj_cols_iter = obj_uuid_cf.xget(obj_uuid, include_timestamp = True)
        # TODO optimize this if needed
        obj_cols = {}
        for col in obj_cols_iter:
            # col-name = value + tstamp
            obj_cols[col[0]] = {'value': col[1][0], 'tstamp': col[1][1]}
            # TODO use compile RE
            if re.match('parent:', col[0]):
                (_, _, parent_uuid) = col[0].split(':')

        if not obj_cols:
            raise common.exceptions.NoIdError(obj_uuid)

        result = {}
        # Name info
        result['fq_name'] = json.loads(obj_cols['fq_name']['value'])

        for col_name in obj_cols.keys():
            # TODO use compiled RE
            if re.match('prop:', col_name):
                (_, prop_name) = col_name.split(':')
                result[prop_name] = json.loads(obj_cols[col_name]['value'])

            # TODO use compiled RE
            if re.match('children:', col_name):
                (_, child_type, child_uuid) = col_name.split(':')
                child_tstamp = obj_cols[col_name]['tstamp']
                try:
                    self._read_child(result, obj_uuid, child_type, child_uuid, child_tstamp)
                except common.exceptions.NoIdError:
                    continue

            # TODO use compiled RE
            if re.match('ref:', col_name):
                (_, ref_type, ref_uuid) = col_name.split(':')
                self._read_ref(result, obj_uuid, ref_type, ref_uuid, obj_cols[col_name]['value'])

            if re.match('backref:', col_name):
                (_, back_ref_type, back_ref_uuid) = col_name.split(':')
                try:
                    self._read_back_ref(result, obj_uuid, back_ref_type, back_ref_uuid, \
                                        obj_cols[col_name]['value'])
                except common.exceptions.NoIdError:
                    continue

        # for all column names


        return (True, result)
    #end _cassandra_provider_attachment_read

    def _cassandra_provider_attachment_update(self, obj_uuid, dummy_old_obj_dict, new_obj_dict):
        # Grab ref-uuids and properties in new version
        new_ref_infos = {}

        if 'virtual_router_refs' in new_obj_dict:
            new_ref_infos['virtual_router'] = {}
            new_refs = new_obj_dict['virtual_router_refs']
            if new_refs:
                for new_ref in new_refs:
                    new_ref_uuid = self.fq_name_to_uuid('virtual_router', new_ref['to'])
                    new_ref_attr = new_ref.get('attr', None)
                    new_ref_data = {'attr': new_ref_attr, 'is_weakref': False}
                    new_ref_infos['virtual_router'][new_ref_uuid] = new_ref_data

        new_props = {}
        if 'id_perms' in new_obj_dict:
            new_props['id_perms'] = new_obj_dict['id_perms']
        # Gather column values for obj and updates to backrefs
        # in a batch and write it at the end
        obj_uuid_cf = self._obj_uuid_cf
        obj_cols_iter = obj_uuid_cf.xget(obj_uuid)
        # TODO optimize this (converts tuple to dict)
        obj_cols = {}
        for col_info in obj_cols_iter:
            obj_cols[col_info[0]] = col_info[1]

        bch = obj_uuid_cf.batch()
        for col_name in obj_cols.keys():
            # TODO use compiled RE
            if re.match('prop:', col_name):
                (_, prop_name) = col_name.split(':')
                if prop_name == 'id_perms':
                    # id-perms always has to be updated for last-mod timestamp
                    # get it from request dict(or from db if not in request dict)
                    new_id_perms = new_obj_dict.get(prop_name, json.loads(obj_cols[col_name]))
                    new_id_perms['last_modified'] = datetime.datetime.now().isoformat()
                    new_props['id_perms'] = new_id_perms
                    self._update_prop(bch, obj_uuid, 'id_perms', new_props)
                elif prop_name in new_obj_dict:
                    self._update_prop(bch, obj_uuid, prop_name, new_props)

            # TODO use compiled RE
            if re.match('ref:', col_name):
                (_, ref_type, ref_uuid) = col_name.split(':')
                self._update_ref(bch, 'provider_attachment', obj_uuid, ref_type, ref_uuid, new_ref_infos)
        # for all column names

        # create new refs
        for ref_type in new_ref_infos.keys():
            for ref_uuid in new_ref_infos[ref_type].keys():
                ref_data = new_ref_infos[ref_type][ref_uuid]
                self._create_ref(bch, 'provider_attachment', obj_uuid, ref_type, ref_uuid, ref_data)

        # create new props
        for prop_name in new_props.keys():
            self._create_prop(bch, obj_uuid, prop_name, new_props[prop_name])

        bch.send()

        return (True, '')
    #end _cassandra_provider_attachment_update

    def _cassandra_provider_attachment_list(self, parent_uuid):
        children_fq_names = []
        if not parent_uuid:
            # grab all resources of this type
            obj_fq_name_cf = self._obj_fq_name_cf
            col_name_iter = obj_fq_name_cf.xget('provider_attachment')
            for (col_name, col_val) in col_name_iter:
                fq_name = col_name.split(':')[:-1]
                children_fq_names.append(fq_name)
        else:
            # go from parent to child
            obj_uuid_cf = self._obj_uuid_cf
            col_start = 'children:provider_attachment:'
            col_fin = 'children:provider_attachment;'
            col_name_iter = obj_uuid_cf.xget(parent_uuid, column_start = col_start, \
                                column_finish = col_fin, include_timestamp = True)

            unsorted_fq_names = []
            for col in col_name_iter:
                col_name = col[0]
                col_val_ts = col[1]
                child_uuid = col_name.split(':')[2]
                child_fq_name = self.uuid_to_fq_name(child_uuid)
                tstamp = col_val_ts[1]
                unsorted_fq_names.append({'fq_name': child_fq_name, 'tstamp': tstamp})

                # sort children; TODO do this based on schema
                sorted_children = sorted(unsorted_fq_names, key = itemgetter('tstamp'))
                # re-write result's children without timestamp
                children_fq_names = [child['fq_name'] for child in sorted_children]

        return (True, children_fq_names)
    #end _cassandra_provider_attachment_list

    def _cassandra_provider_attachment_delete(self, obj_uuid):
        obj_uuid_cf = self._obj_uuid_cf
        fq_name = json.loads(obj_uuid_cf.get(obj_uuid, columns = ['fq_name'])['fq_name'])
        bch = obj_uuid_cf.batch()

        # unlink from parent
        col_start = 'parent:'
        col_fin = 'parent;'
        col_name_iter = obj_uuid_cf.xget(obj_uuid, column_start = col_start, column_finish = col_fin)
        for (col_name, col_val) in col_name_iter:
            (_, parent_type, parent_uuid) = col_name.split(':')
            self._delete_child(bch, parent_type, parent_uuid, 'provider_attachment', obj_uuid)

        # remove refs
        col_start = 'ref:'
        col_fin = 'ref;'
        col_name_iter = obj_uuid_cf.xget(obj_uuid, column_start = col_start, column_finish = col_fin)
        for (col_name, col_val) in col_name_iter:
            (_, ref_type, ref_uuid) = col_name.split(':')
            self._delete_ref(bch, 'provider_attachment', obj_uuid, ref_type, ref_uuid)

        bch.remove(obj_uuid)
        bch.send()

        # Update fqname table
        fq_name_str = ':'.join(fq_name)
        fq_name_col = fq_name_str + ':' + obj_uuid
        self._obj_fq_name_cf.remove('provider_attachment', columns = [fq_name_col])


        return (True, '')
    #end _cassandra_provider_attachment_delete

    def _cassandra_network_ipam_alloc(self, fq_name):
        return (True, '')
    #end _cassandra_network_ipam_alloc

    def _cassandra_network_ipam_create(self, obj_ids, obj_dict):
        # Gather column values for obj and updates to backrefs
        # in a batch and write it at the end
        bch = self._obj_uuid_cf.batch()

        obj_cols = {}
        obj_cols['fq_name'] = json.dumps(obj_dict['fq_name'])
        obj_cols['type'] = json.dumps('network_ipam')
        if 'parent_type' in obj_dict:
            # non config-root child
            parent_type = obj_dict['parent_type']
            parent_method_type = parent_type.replace('-', '_')
            parent_fq_name = obj_dict['fq_name'][:-1]
            obj_cols['parent_type'] = json.dumps(parent_type)
            parent_uuid = self.fq_name_to_uuid(parent_method_type, parent_fq_name)
            self._create_child(bch, parent_method_type, parent_uuid, 'network_ipam', obj_ids['uuid'])

        # Properties
        field = obj_dict.get('network_ipam_mgmt', None)
        if field:
            self._create_prop(bch, obj_ids['uuid'], 'network_ipam_mgmt', field)

        field = obj_dict.get('id_perms', None)
        field['created'] = datetime.datetime.now().isoformat()
        field['last_modified'] = field['created']
        if field:
            self._create_prop(bch, obj_ids['uuid'], 'id_perms', field)


        # References
        refs = obj_dict.get('virtual_DNS_refs', [])
        for ref in refs:
            ref_uuid = self.fq_name_to_uuid('virtual_DNS', ref['to'])
            ref_attr = ref.get('attr', None)
            ref_data = {'attr': ref_attr, 'is_weakref': False}
            self._create_ref(bch, 'network_ipam', obj_ids['uuid'], 'virtual_DNS', ref_uuid, ref_data)

        bch.insert(obj_ids['uuid'], obj_cols)
        bch.send()

        # Update fqname table
        fq_name_str = ':'.join(obj_dict['fq_name'])
        fq_name_cols = {fq_name_str + ':' + obj_ids['uuid']: json.dumps(None)}
        self._obj_fq_name_cf.insert('network_ipam', fq_name_cols)

        return (True, '')
    #end _cassandra_network_ipam_create

    def _cassandra_network_ipam_read(self, obj_uuid, field_names = None):
        obj_uuid_cf = self._obj_uuid_cf
        obj_cols_iter = obj_uuid_cf.xget(obj_uuid, include_timestamp = True)
        # TODO optimize this if needed
        obj_cols = {}
        for col in obj_cols_iter:
            # col-name = value + tstamp
            obj_cols[col[0]] = {'value': col[1][0], 'tstamp': col[1][1]}
            # TODO use compile RE
            if re.match('parent:', col[0]):
                (_, _, parent_uuid) = col[0].split(':')

        if not obj_cols:
            raise common.exceptions.NoIdError(obj_uuid)

        result = {}
        # Name info
        result['fq_name'] = json.loads(obj_cols['fq_name']['value'])
        if 'parent_type' in obj_cols:
            # non config-root child
            parent_type = json.loads(obj_cols['parent_type']['value'])
            result['parent_type'] = parent_type
            try:
                result['parent_uuid'] = parent_uuid
                result['parent_href'] = self._db_client_mgr.generate_url(parent_type, parent_uuid)
            except common.exceptions.NoIdError:
                err_msg = 'Unknown uuid for parent ' + result['fq_name'][-2]
                return (False, err_msg)

        for col_name in obj_cols.keys():
            # TODO use compiled RE
            if re.match('prop:', col_name):
                (_, prop_name) = col_name.split(':')
                result[prop_name] = json.loads(obj_cols[col_name]['value'])

            # TODO use compiled RE
            if re.match('children:', col_name):
                (_, child_type, child_uuid) = col_name.split(':')
                child_tstamp = obj_cols[col_name]['tstamp']
                try:
                    self._read_child(result, obj_uuid, child_type, child_uuid, child_tstamp)
                except common.exceptions.NoIdError:
                    continue

            # TODO use compiled RE
            if re.match('ref:', col_name):
                (_, ref_type, ref_uuid) = col_name.split(':')
                self._read_ref(result, obj_uuid, ref_type, ref_uuid, obj_cols[col_name]['value'])

            if re.match('backref:', col_name):
                (_, back_ref_type, back_ref_uuid) = col_name.split(':')
                try:
                    self._read_back_ref(result, obj_uuid, back_ref_type, back_ref_uuid, \
                                        obj_cols[col_name]['value'])
                except common.exceptions.NoIdError:
                    continue

        # for all column names


        return (True, result)
    #end _cassandra_network_ipam_read

    def _cassandra_network_ipam_update(self, obj_uuid, dummy_old_obj_dict, new_obj_dict):
        # Grab ref-uuids and properties in new version
        new_ref_infos = {}

        if 'virtual_DNS_refs' in new_obj_dict:
            new_ref_infos['virtual_DNS'] = {}
            new_refs = new_obj_dict['virtual_DNS_refs']
            if new_refs:
                for new_ref in new_refs:
                    new_ref_uuid = self.fq_name_to_uuid('virtual_DNS', new_ref['to'])
                    new_ref_attr = new_ref.get('attr', None)
                    new_ref_data = {'attr': new_ref_attr, 'is_weakref': False}
                    new_ref_infos['virtual_DNS'][new_ref_uuid] = new_ref_data

        new_props = {}
        if 'network_ipam_mgmt' in new_obj_dict:
            new_props['network_ipam_mgmt'] = new_obj_dict['network_ipam_mgmt']
        if 'id_perms' in new_obj_dict:
            new_props['id_perms'] = new_obj_dict['id_perms']
        # Gather column values for obj and updates to backrefs
        # in a batch and write it at the end
        obj_uuid_cf = self._obj_uuid_cf
        obj_cols_iter = obj_uuid_cf.xget(obj_uuid)
        # TODO optimize this (converts tuple to dict)
        obj_cols = {}
        for col_info in obj_cols_iter:
            obj_cols[col_info[0]] = col_info[1]

        bch = obj_uuid_cf.batch()
        for col_name in obj_cols.keys():
            # TODO use compiled RE
            if re.match('prop:', col_name):
                (_, prop_name) = col_name.split(':')
                if prop_name == 'id_perms':
                    # id-perms always has to be updated for last-mod timestamp
                    # get it from request dict(or from db if not in request dict)
                    new_id_perms = new_obj_dict.get(prop_name, json.loads(obj_cols[col_name]))
                    new_id_perms['last_modified'] = datetime.datetime.now().isoformat()
                    new_props['id_perms'] = new_id_perms
                    self._update_prop(bch, obj_uuid, 'id_perms', new_props)
                elif prop_name in new_obj_dict:
                    self._update_prop(bch, obj_uuid, prop_name, new_props)

            # TODO use compiled RE
            if re.match('ref:', col_name):
                (_, ref_type, ref_uuid) = col_name.split(':')
                self._update_ref(bch, 'network_ipam', obj_uuid, ref_type, ref_uuid, new_ref_infos)
        # for all column names

        # create new refs
        for ref_type in new_ref_infos.keys():
            for ref_uuid in new_ref_infos[ref_type].keys():
                ref_data = new_ref_infos[ref_type][ref_uuid]
                self._create_ref(bch, 'network_ipam', obj_uuid, ref_type, ref_uuid, ref_data)

        # create new props
        for prop_name in new_props.keys():
            self._create_prop(bch, obj_uuid, prop_name, new_props[prop_name])

        bch.send()

        return (True, '')
    #end _cassandra_network_ipam_update

    def _cassandra_network_ipam_list(self, parent_uuid):
        children_fq_names = []
        if not parent_uuid:
            # grab all resources of this type
            obj_fq_name_cf = self._obj_fq_name_cf
            col_name_iter = obj_fq_name_cf.xget('network_ipam')
            for (col_name, col_val) in col_name_iter:
                fq_name = col_name.split(':')[:-1]
                children_fq_names.append(fq_name)
        else:
            # go from parent to child
            obj_uuid_cf = self._obj_uuid_cf
            col_start = 'children:network_ipam:'
            col_fin = 'children:network_ipam;'
            col_name_iter = obj_uuid_cf.xget(parent_uuid, column_start = col_start, \
                                column_finish = col_fin, include_timestamp = True)

            unsorted_fq_names = []
            for col in col_name_iter:
                col_name = col[0]
                col_val_ts = col[1]
                child_uuid = col_name.split(':')[2]
                child_fq_name = self.uuid_to_fq_name(child_uuid)
                tstamp = col_val_ts[1]
                unsorted_fq_names.append({'fq_name': child_fq_name, 'tstamp': tstamp})

                # sort children; TODO do this based on schema
                sorted_children = sorted(unsorted_fq_names, key = itemgetter('tstamp'))
                # re-write result's children without timestamp
                children_fq_names = [child['fq_name'] for child in sorted_children]

        return (True, children_fq_names)
    #end _cassandra_network_ipam_list

    def _cassandra_network_ipam_delete(self, obj_uuid):
        obj_uuid_cf = self._obj_uuid_cf
        fq_name = json.loads(obj_uuid_cf.get(obj_uuid, columns = ['fq_name'])['fq_name'])
        bch = obj_uuid_cf.batch()

        # unlink from parent
        col_start = 'parent:'
        col_fin = 'parent;'
        col_name_iter = obj_uuid_cf.xget(obj_uuid, column_start = col_start, column_finish = col_fin)
        for (col_name, col_val) in col_name_iter:
            (_, parent_type, parent_uuid) = col_name.split(':')
            self._delete_child(bch, parent_type, parent_uuid, 'network_ipam', obj_uuid)

        # remove refs
        col_start = 'ref:'
        col_fin = 'ref;'
        col_name_iter = obj_uuid_cf.xget(obj_uuid, column_start = col_start, column_finish = col_fin)
        for (col_name, col_val) in col_name_iter:
            (_, ref_type, ref_uuid) = col_name.split(':')
            self._delete_ref(bch, 'network_ipam', obj_uuid, ref_type, ref_uuid)

        bch.remove(obj_uuid)
        bch.send()

        # Update fqname table
        fq_name_str = ':'.join(fq_name)
        fq_name_col = fq_name_str + ':' + obj_uuid
        self._obj_fq_name_cf.remove('network_ipam', columns = [fq_name_col])


        return (True, '')
    #end _cassandra_network_ipam_delete

    def _cassandra_virtual_network_alloc(self, fq_name):
        return (True, '')
    #end _cassandra_virtual_network_alloc

    def _cassandra_virtual_network_create(self, obj_ids, obj_dict):
        # Gather column values for obj and updates to backrefs
        # in a batch and write it at the end
        bch = self._obj_uuid_cf.batch()

        obj_cols = {}
        obj_cols['fq_name'] = json.dumps(obj_dict['fq_name'])
        obj_cols['type'] = json.dumps('virtual_network')
        if 'parent_type' in obj_dict:
            # non config-root child
            parent_type = obj_dict['parent_type']
            parent_method_type = parent_type.replace('-', '_')
            parent_fq_name = obj_dict['fq_name'][:-1]
            obj_cols['parent_type'] = json.dumps(parent_type)
            parent_uuid = self.fq_name_to_uuid(parent_method_type, parent_fq_name)
            self._create_child(bch, parent_method_type, parent_uuid, 'virtual_network', obj_ids['uuid'])

        # Properties
        field = obj_dict.get('virtual_network_properties', None)
        if field:
            self._create_prop(bch, obj_ids['uuid'], 'virtual_network_properties', field)

        field = obj_dict.get('route_target_list', None)
        if field:
            self._create_prop(bch, obj_ids['uuid'], 'route_target_list', field)

        field = obj_dict.get('route_table', None)
        if field:
            self._create_prop(bch, obj_ids['uuid'], 'route_table', field)

        field = obj_dict.get('id_perms', None)
        field['created'] = datetime.datetime.now().isoformat()
        field['last_modified'] = field['created']
        if field:
            self._create_prop(bch, obj_ids['uuid'], 'id_perms', field)


        # References
        refs = obj_dict.get('network_ipam_refs', [])
        for ref in refs:
            ref_uuid = self.fq_name_to_uuid('network_ipam', ref['to'])
            ref_attr = ref.get('attr', None)
            ref_data = {'attr': ref_attr, 'is_weakref': False}
            self._create_ref(bch, 'virtual_network', obj_ids['uuid'], 'network_ipam', ref_uuid, ref_data)
        refs = obj_dict.get('network_policy_refs', [])
        for ref in refs:
            ref_uuid = self.fq_name_to_uuid('network_policy', ref['to'])
            ref_attr = ref.get('attr', None)
            ref_data = {'attr': ref_attr, 'is_weakref': False}
            self._create_ref(bch, 'virtual_network', obj_ids['uuid'], 'network_policy', ref_uuid, ref_data)

        bch.insert(obj_ids['uuid'], obj_cols)
        bch.send()

        # Update fqname table
        fq_name_str = ':'.join(obj_dict['fq_name'])
        fq_name_cols = {fq_name_str + ':' + obj_ids['uuid']: json.dumps(None)}
        self._obj_fq_name_cf.insert('virtual_network', fq_name_cols)

        return (True, '')
    #end _cassandra_virtual_network_create

    def _cassandra_virtual_network_read(self, obj_uuid, field_names = None):
        obj_uuid_cf = self._obj_uuid_cf
        obj_cols_iter = obj_uuid_cf.xget(obj_uuid, include_timestamp = True)
        # TODO optimize this if needed
        obj_cols = {}
        for col in obj_cols_iter:
            # col-name = value + tstamp
            obj_cols[col[0]] = {'value': col[1][0], 'tstamp': col[1][1]}
            # TODO use compile RE
            if re.match('parent:', col[0]):
                (_, _, parent_uuid) = col[0].split(':')

        if not obj_cols:
            raise common.exceptions.NoIdError(obj_uuid)

        result = {}
        # Name info
        result['fq_name'] = json.loads(obj_cols['fq_name']['value'])
        if 'parent_type' in obj_cols:
            # non config-root child
            parent_type = json.loads(obj_cols['parent_type']['value'])
            result['parent_type'] = parent_type
            try:
                result['parent_uuid'] = parent_uuid
                result['parent_href'] = self._db_client_mgr.generate_url(parent_type, parent_uuid)
            except common.exceptions.NoIdError:
                err_msg = 'Unknown uuid for parent ' + result['fq_name'][-2]
                return (False, err_msg)

        for col_name in obj_cols.keys():
            # TODO use compiled RE
            if re.match('prop:', col_name):
                (_, prop_name) = col_name.split(':')
                result[prop_name] = json.loads(obj_cols[col_name]['value'])

            # TODO use compiled RE
            if re.match('children:', col_name):
                (_, child_type, child_uuid) = col_name.split(':')
                child_tstamp = obj_cols[col_name]['tstamp']
                try:
                    self._read_child(result, obj_uuid, child_type, child_uuid, child_tstamp)
                except common.exceptions.NoIdError:
                    continue

            # TODO use compiled RE
            if re.match('ref:', col_name):
                (_, ref_type, ref_uuid) = col_name.split(':')
                self._read_ref(result, obj_uuid, ref_type, ref_uuid, obj_cols[col_name]['value'])

            if re.match('backref:', col_name):
                (_, back_ref_type, back_ref_uuid) = col_name.split(':')
                try:
                    self._read_back_ref(result, obj_uuid, back_ref_type, back_ref_uuid, \
                                        obj_cols[col_name]['value'])
                except common.exceptions.NoIdError:
                    continue

        # for all column names

        if 'access_control_lists' in result:
            # sort children; TODO do this based on schema
            sorted_children = sorted(result['access_control_lists'], key = itemgetter('tstamp'))
            # re-write result's children without timestamp
            result['access_control_lists'] = sorted_children
            [child.pop('tstamp') for child in result['access_control_lists']]

        if 'floating_ip_pools' in result:
            # sort children; TODO do this based on schema
            sorted_children = sorted(result['floating_ip_pools'], key = itemgetter('tstamp'))
            # re-write result's children without timestamp
            result['floating_ip_pools'] = sorted_children
            [child.pop('tstamp') for child in result['floating_ip_pools']]

        if 'routing_instances' in result:
            # sort children; TODO do this based on schema
            sorted_children = sorted(result['routing_instances'], key = itemgetter('tstamp'))
            # re-write result's children without timestamp
            result['routing_instances'] = sorted_children
            [child.pop('tstamp') for child in result['routing_instances']]


        return (True, result)
    #end _cassandra_virtual_network_read

    def _cassandra_virtual_network_update(self, obj_uuid, dummy_old_obj_dict, new_obj_dict):
        # Grab ref-uuids and properties in new version
        new_ref_infos = {}

        if 'network_ipam_refs' in new_obj_dict:
            new_ref_infos['network_ipam'] = {}
            new_refs = new_obj_dict['network_ipam_refs']
            if new_refs:
                for new_ref in new_refs:
                    new_ref_uuid = self.fq_name_to_uuid('network_ipam', new_ref['to'])
                    new_ref_attr = new_ref.get('attr', None)
                    new_ref_data = {'attr': new_ref_attr, 'is_weakref': False}
                    new_ref_infos['network_ipam'][new_ref_uuid] = new_ref_data

        if 'network_policy_refs' in new_obj_dict:
            new_ref_infos['network_policy'] = {}
            new_refs = new_obj_dict['network_policy_refs']
            if new_refs:
                for new_ref in new_refs:
                    new_ref_uuid = self.fq_name_to_uuid('network_policy', new_ref['to'])
                    new_ref_attr = new_ref.get('attr', None)
                    new_ref_data = {'attr': new_ref_attr, 'is_weakref': False}
                    new_ref_infos['network_policy'][new_ref_uuid] = new_ref_data

        new_props = {}
        if 'virtual_network_properties' in new_obj_dict:
            new_props['virtual_network_properties'] = new_obj_dict['virtual_network_properties']
        if 'route_target_list' in new_obj_dict:
            new_props['route_target_list'] = new_obj_dict['route_target_list']
        if 'route_table' in new_obj_dict:
            new_props['route_table'] = new_obj_dict['route_table']
        if 'id_perms' in new_obj_dict:
            new_props['id_perms'] = new_obj_dict['id_perms']
        # Gather column values for obj and updates to backrefs
        # in a batch and write it at the end
        obj_uuid_cf = self._obj_uuid_cf
        obj_cols_iter = obj_uuid_cf.xget(obj_uuid)
        # TODO optimize this (converts tuple to dict)
        obj_cols = {}
        for col_info in obj_cols_iter:
            obj_cols[col_info[0]] = col_info[1]

        bch = obj_uuid_cf.batch()
        for col_name in obj_cols.keys():
            # TODO use compiled RE
            if re.match('prop:', col_name):
                (_, prop_name) = col_name.split(':')
                if prop_name == 'id_perms':
                    # id-perms always has to be updated for last-mod timestamp
                    # get it from request dict(or from db if not in request dict)
                    new_id_perms = new_obj_dict.get(prop_name, json.loads(obj_cols[col_name]))
                    new_id_perms['last_modified'] = datetime.datetime.now().isoformat()
                    new_props['id_perms'] = new_id_perms
                    self._update_prop(bch, obj_uuid, 'id_perms', new_props)
                elif prop_name in new_obj_dict:
                    self._update_prop(bch, obj_uuid, prop_name, new_props)

            # TODO use compiled RE
            if re.match('ref:', col_name):
                (_, ref_type, ref_uuid) = col_name.split(':')
                self._update_ref(bch, 'virtual_network', obj_uuid, ref_type, ref_uuid, new_ref_infos)
        # for all column names

        # create new refs
        for ref_type in new_ref_infos.keys():
            for ref_uuid in new_ref_infos[ref_type].keys():
                ref_data = new_ref_infos[ref_type][ref_uuid]
                self._create_ref(bch, 'virtual_network', obj_uuid, ref_type, ref_uuid, ref_data)

        # create new props
        for prop_name in new_props.keys():
            self._create_prop(bch, obj_uuid, prop_name, new_props[prop_name])

        bch.send()

        return (True, '')
    #end _cassandra_virtual_network_update

    def _cassandra_virtual_network_list(self, parent_uuid):
        children_fq_names = []
        if not parent_uuid:
            # grab all resources of this type
            obj_fq_name_cf = self._obj_fq_name_cf
            col_name_iter = obj_fq_name_cf.xget('virtual_network')
            for (col_name, col_val) in col_name_iter:
                fq_name = col_name.split(':')[:-1]
                children_fq_names.append(fq_name)
        else:
            # go from parent to child
            obj_uuid_cf = self._obj_uuid_cf
            col_start = 'children:virtual_network:'
            col_fin = 'children:virtual_network;'
            col_name_iter = obj_uuid_cf.xget(parent_uuid, column_start = col_start, \
                                column_finish = col_fin, include_timestamp = True)

            unsorted_fq_names = []
            for col in col_name_iter:
                col_name = col[0]
                col_val_ts = col[1]
                child_uuid = col_name.split(':')[2]
                child_fq_name = self.uuid_to_fq_name(child_uuid)
                tstamp = col_val_ts[1]
                unsorted_fq_names.append({'fq_name': child_fq_name, 'tstamp': tstamp})

                # sort children; TODO do this based on schema
                sorted_children = sorted(unsorted_fq_names, key = itemgetter('tstamp'))
                # re-write result's children without timestamp
                children_fq_names = [child['fq_name'] for child in sorted_children]

        return (True, children_fq_names)
    #end _cassandra_virtual_network_list

    def _cassandra_virtual_network_delete(self, obj_uuid):
        obj_uuid_cf = self._obj_uuid_cf
        fq_name = json.loads(obj_uuid_cf.get(obj_uuid, columns = ['fq_name'])['fq_name'])
        bch = obj_uuid_cf.batch()

        # unlink from parent
        col_start = 'parent:'
        col_fin = 'parent;'
        col_name_iter = obj_uuid_cf.xget(obj_uuid, column_start = col_start, column_finish = col_fin)
        for (col_name, col_val) in col_name_iter:
            (_, parent_type, parent_uuid) = col_name.split(':')
            self._delete_child(bch, parent_type, parent_uuid, 'virtual_network', obj_uuid)

        # remove refs
        col_start = 'ref:'
        col_fin = 'ref;'
        col_name_iter = obj_uuid_cf.xget(obj_uuid, column_start = col_start, column_finish = col_fin)
        for (col_name, col_val) in col_name_iter:
            (_, ref_type, ref_uuid) = col_name.split(':')
            self._delete_ref(bch, 'virtual_network', obj_uuid, ref_type, ref_uuid)

        bch.remove(obj_uuid)
        bch.send()

        # Update fqname table
        fq_name_str = ':'.join(fq_name)
        fq_name_col = fq_name_str + ':' + obj_uuid
        self._obj_fq_name_cf.remove('virtual_network', columns = [fq_name_col])


        return (True, '')
    #end _cassandra_virtual_network_delete

    def _cassandra_project_alloc(self, fq_name):
        return (True, '')
    #end _cassandra_project_alloc

    def _cassandra_project_create(self, obj_ids, obj_dict):
        # Gather column values for obj and updates to backrefs
        # in a batch and write it at the end
        bch = self._obj_uuid_cf.batch()

        obj_cols = {}
        obj_cols['fq_name'] = json.dumps(obj_dict['fq_name'])
        obj_cols['type'] = json.dumps('project')
        if 'parent_type' in obj_dict:
            # non config-root child
            parent_type = obj_dict['parent_type']
            parent_method_type = parent_type.replace('-', '_')
            parent_fq_name = obj_dict['fq_name'][:-1]
            obj_cols['parent_type'] = json.dumps(parent_type)
            parent_uuid = self.fq_name_to_uuid(parent_method_type, parent_fq_name)
            self._create_child(bch, parent_method_type, parent_uuid, 'project', obj_ids['uuid'])

        # Properties
        field = obj_dict.get('id_perms', None)
        field['created'] = datetime.datetime.now().isoformat()
        field['last_modified'] = field['created']
        if field:
            self._create_prop(bch, obj_ids['uuid'], 'id_perms', field)


        # References
        refs = obj_dict.get('namespace_refs', [])
        for ref in refs:
            ref_uuid = self.fq_name_to_uuid('namespace', ref['to'])
            ref_attr = ref.get('attr', None)
            ref_data = {'attr': ref_attr, 'is_weakref': False}
            self._create_ref(bch, 'project', obj_ids['uuid'], 'namespace', ref_uuid, ref_data)
        refs = obj_dict.get('floating_ip_pool_refs', [])
        for ref in refs:
            ref_uuid = self.fq_name_to_uuid('floating_ip_pool', ref['to'])
            ref_attr = ref.get('attr', None)
            ref_data = {'attr': ref_attr, 'is_weakref': False}
            self._create_ref(bch, 'project', obj_ids['uuid'], 'floating_ip_pool', ref_uuid, ref_data)

        bch.insert(obj_ids['uuid'], obj_cols)
        bch.send()

        # Update fqname table
        fq_name_str = ':'.join(obj_dict['fq_name'])
        fq_name_cols = {fq_name_str + ':' + obj_ids['uuid']: json.dumps(None)}
        self._obj_fq_name_cf.insert('project', fq_name_cols)

        return (True, '')
    #end _cassandra_project_create

    def _cassandra_project_read(self, obj_uuid, field_names = None):
        obj_uuid_cf = self._obj_uuid_cf
        obj_cols_iter = obj_uuid_cf.xget(obj_uuid, include_timestamp = True)
        # TODO optimize this if needed
        obj_cols = {}
        for col in obj_cols_iter:
            # col-name = value + tstamp
            obj_cols[col[0]] = {'value': col[1][0], 'tstamp': col[1][1]}
            # TODO use compile RE
            if re.match('parent:', col[0]):
                (_, _, parent_uuid) = col[0].split(':')

        if not obj_cols:
            raise common.exceptions.NoIdError(obj_uuid)

        result = {}
        # Name info
        result['fq_name'] = json.loads(obj_cols['fq_name']['value'])
        if 'parent_type' in obj_cols:
            # non config-root child
            parent_type = json.loads(obj_cols['parent_type']['value'])
            result['parent_type'] = parent_type
            try:
                result['parent_uuid'] = parent_uuid
                result['parent_href'] = self._db_client_mgr.generate_url(parent_type, parent_uuid)
            except common.exceptions.NoIdError:
                err_msg = 'Unknown uuid for parent ' + result['fq_name'][-2]
                return (False, err_msg)

        for col_name in obj_cols.keys():
            # TODO use compiled RE
            if re.match('prop:', col_name):
                (_, prop_name) = col_name.split(':')
                result[prop_name] = json.loads(obj_cols[col_name]['value'])

            # TODO use compiled RE
            if re.match('children:', col_name):
                (_, child_type, child_uuid) = col_name.split(':')
                child_tstamp = obj_cols[col_name]['tstamp']
                try:
                    self._read_child(result, obj_uuid, child_type, child_uuid, child_tstamp)
                except common.exceptions.NoIdError:
                    continue

            # TODO use compiled RE
            if re.match('ref:', col_name):
                (_, ref_type, ref_uuid) = col_name.split(':')
                self._read_ref(result, obj_uuid, ref_type, ref_uuid, obj_cols[col_name]['value'])

            if re.match('backref:', col_name):
                (_, back_ref_type, back_ref_uuid) = col_name.split(':')
                try:
                    self._read_back_ref(result, obj_uuid, back_ref_type, back_ref_uuid, \
                                        obj_cols[col_name]['value'])
                except common.exceptions.NoIdError:
                    continue

        # for all column names

        if 'security_groups' in result:
            # sort children; TODO do this based on schema
            sorted_children = sorted(result['security_groups'], key = itemgetter('tstamp'))
            # re-write result's children without timestamp
            result['security_groups'] = sorted_children
            [child.pop('tstamp') for child in result['security_groups']]

        if 'virtual_networks' in result:
            # sort children; TODO do this based on schema
            sorted_children = sorted(result['virtual_networks'], key = itemgetter('tstamp'))
            # re-write result's children without timestamp
            result['virtual_networks'] = sorted_children
            [child.pop('tstamp') for child in result['virtual_networks']]

        if 'network_ipams' in result:
            # sort children; TODO do this based on schema
            sorted_children = sorted(result['network_ipams'], key = itemgetter('tstamp'))
            # re-write result's children without timestamp
            result['network_ipams'] = sorted_children
            [child.pop('tstamp') for child in result['network_ipams']]

        if 'network_policys' in result:
            # sort children; TODO do this based on schema
            sorted_children = sorted(result['network_policys'], key = itemgetter('tstamp'))
            # re-write result's children without timestamp
            result['network_policys'] = sorted_children
            [child.pop('tstamp') for child in result['network_policys']]

        if 'service_instances' in result:
            # sort children; TODO do this based on schema
            sorted_children = sorted(result['service_instances'], key = itemgetter('tstamp'))
            # re-write result's children without timestamp
            result['service_instances'] = sorted_children
            [child.pop('tstamp') for child in result['service_instances']]


        return (True, result)
    #end _cassandra_project_read

    def _cassandra_project_update(self, obj_uuid, dummy_old_obj_dict, new_obj_dict):
        # Grab ref-uuids and properties in new version
        new_ref_infos = {}

        if 'namespace_refs' in new_obj_dict:
            new_ref_infos['namespace'] = {}
            new_refs = new_obj_dict['namespace_refs']
            if new_refs:
                for new_ref in new_refs:
                    new_ref_uuid = self.fq_name_to_uuid('namespace', new_ref['to'])
                    new_ref_attr = new_ref.get('attr', None)
                    new_ref_data = {'attr': new_ref_attr, 'is_weakref': False}
                    new_ref_infos['namespace'][new_ref_uuid] = new_ref_data

        if 'floating_ip_pool_refs' in new_obj_dict:
            new_ref_infos['floating_ip_pool'] = {}
            new_refs = new_obj_dict['floating_ip_pool_refs']
            if new_refs:
                for new_ref in new_refs:
                    new_ref_uuid = self.fq_name_to_uuid('floating_ip_pool', new_ref['to'])
                    new_ref_attr = new_ref.get('attr', None)
                    new_ref_data = {'attr': new_ref_attr, 'is_weakref': False}
                    new_ref_infos['floating_ip_pool'][new_ref_uuid] = new_ref_data

        new_props = {}
        if 'id_perms' in new_obj_dict:
            new_props['id_perms'] = new_obj_dict['id_perms']
        # Gather column values for obj and updates to backrefs
        # in a batch and write it at the end
        obj_uuid_cf = self._obj_uuid_cf
        obj_cols_iter = obj_uuid_cf.xget(obj_uuid)
        # TODO optimize this (converts tuple to dict)
        obj_cols = {}
        for col_info in obj_cols_iter:
            obj_cols[col_info[0]] = col_info[1]

        bch = obj_uuid_cf.batch()
        for col_name in obj_cols.keys():
            # TODO use compiled RE
            if re.match('prop:', col_name):
                (_, prop_name) = col_name.split(':')
                if prop_name == 'id_perms':
                    # id-perms always has to be updated for last-mod timestamp
                    # get it from request dict(or from db if not in request dict)
                    new_id_perms = new_obj_dict.get(prop_name, json.loads(obj_cols[col_name]))
                    new_id_perms['last_modified'] = datetime.datetime.now().isoformat()
                    new_props['id_perms'] = new_id_perms
                    self._update_prop(bch, obj_uuid, 'id_perms', new_props)
                elif prop_name in new_obj_dict:
                    self._update_prop(bch, obj_uuid, prop_name, new_props)

            # TODO use compiled RE
            if re.match('ref:', col_name):
                (_, ref_type, ref_uuid) = col_name.split(':')
                self._update_ref(bch, 'project', obj_uuid, ref_type, ref_uuid, new_ref_infos)
        # for all column names

        # create new refs
        for ref_type in new_ref_infos.keys():
            for ref_uuid in new_ref_infos[ref_type].keys():
                ref_data = new_ref_infos[ref_type][ref_uuid]
                self._create_ref(bch, 'project', obj_uuid, ref_type, ref_uuid, ref_data)

        # create new props
        for prop_name in new_props.keys():
            self._create_prop(bch, obj_uuid, prop_name, new_props[prop_name])

        bch.send()

        return (True, '')
    #end _cassandra_project_update

    def _cassandra_project_list(self, parent_uuid):
        children_fq_names = []
        if not parent_uuid:
            # grab all resources of this type
            obj_fq_name_cf = self._obj_fq_name_cf
            col_name_iter = obj_fq_name_cf.xget('project')
            for (col_name, col_val) in col_name_iter:
                fq_name = col_name.split(':')[:-1]
                children_fq_names.append(fq_name)
        else:
            # go from parent to child
            obj_uuid_cf = self._obj_uuid_cf
            col_start = 'children:project:'
            col_fin = 'children:project;'
            col_name_iter = obj_uuid_cf.xget(parent_uuid, column_start = col_start, \
                                column_finish = col_fin, include_timestamp = True)

            unsorted_fq_names = []
            for col in col_name_iter:
                col_name = col[0]
                col_val_ts = col[1]
                child_uuid = col_name.split(':')[2]
                child_fq_name = self.uuid_to_fq_name(child_uuid)
                tstamp = col_val_ts[1]
                unsorted_fq_names.append({'fq_name': child_fq_name, 'tstamp': tstamp})

                # sort children; TODO do this based on schema
                sorted_children = sorted(unsorted_fq_names, key = itemgetter('tstamp'))
                # re-write result's children without timestamp
                children_fq_names = [child['fq_name'] for child in sorted_children]

        return (True, children_fq_names)
    #end _cassandra_project_list

    def _cassandra_project_delete(self, obj_uuid):
        obj_uuid_cf = self._obj_uuid_cf
        fq_name = json.loads(obj_uuid_cf.get(obj_uuid, columns = ['fq_name'])['fq_name'])
        bch = obj_uuid_cf.batch()

        # unlink from parent
        col_start = 'parent:'
        col_fin = 'parent;'
        col_name_iter = obj_uuid_cf.xget(obj_uuid, column_start = col_start, column_finish = col_fin)
        for (col_name, col_val) in col_name_iter:
            (_, parent_type, parent_uuid) = col_name.split(':')
            self._delete_child(bch, parent_type, parent_uuid, 'project', obj_uuid)

        # remove refs
        col_start = 'ref:'
        col_fin = 'ref;'
        col_name_iter = obj_uuid_cf.xget(obj_uuid, column_start = col_start, column_finish = col_fin)
        for (col_name, col_val) in col_name_iter:
            (_, ref_type, ref_uuid) = col_name.split(':')
            self._delete_ref(bch, 'project', obj_uuid, ref_type, ref_uuid)

        bch.remove(obj_uuid)
        bch.send()

        # Update fqname table
        fq_name_str = ':'.join(fq_name)
        fq_name_col = fq_name_str + ':' + obj_uuid
        self._obj_fq_name_cf.remove('project', columns = [fq_name_col])


        return (True, '')
    #end _cassandra_project_delete

    def _cassandra_logical_interface_alloc(self, fq_name):
        return (True, '')
    #end _cassandra_logical_interface_alloc

    def _cassandra_logical_interface_create(self, obj_ids, obj_dict):
        # Gather column values for obj and updates to backrefs
        # in a batch and write it at the end
        bch = self._obj_uuid_cf.batch()

        obj_cols = {}
        obj_cols['fq_name'] = json.dumps(obj_dict['fq_name'])
        obj_cols['type'] = json.dumps('logical_interface')
        if 'parent_type' in obj_dict:
            # non config-root child
            parent_type = obj_dict['parent_type']
            parent_method_type = parent_type.replace('-', '_')
            parent_fq_name = obj_dict['fq_name'][:-1]
            obj_cols['parent_type'] = json.dumps(parent_type)
            parent_uuid = self.fq_name_to_uuid(parent_method_type, parent_fq_name)
            self._create_child(bch, parent_method_type, parent_uuid, 'logical_interface', obj_ids['uuid'])

        # Properties
        field = obj_dict.get('id_perms', None)
        field['created'] = datetime.datetime.now().isoformat()
        field['last_modified'] = field['created']
        if field:
            self._create_prop(bch, obj_ids['uuid'], 'id_perms', field)


        # References
        refs = obj_dict.get('virtual_network_refs', [])
        for ref in refs:
            ref_uuid = self.fq_name_to_uuid('virtual_network', ref['to'])
            ref_attr = ref.get('attr', None)
            ref_data = {'attr': ref_attr, 'is_weakref': False}
            self._create_ref(bch, 'logical_interface', obj_ids['uuid'], 'virtual_network', ref_uuid, ref_data)

        bch.insert(obj_ids['uuid'], obj_cols)
        bch.send()

        # Update fqname table
        fq_name_str = ':'.join(obj_dict['fq_name'])
        fq_name_cols = {fq_name_str + ':' + obj_ids['uuid']: json.dumps(None)}
        self._obj_fq_name_cf.insert('logical_interface', fq_name_cols)

        return (True, '')
    #end _cassandra_logical_interface_create

    def _cassandra_logical_interface_read(self, obj_uuid, field_names = None):
        obj_uuid_cf = self._obj_uuid_cf
        obj_cols_iter = obj_uuid_cf.xget(obj_uuid, include_timestamp = True)
        # TODO optimize this if needed
        obj_cols = {}
        for col in obj_cols_iter:
            # col-name = value + tstamp
            obj_cols[col[0]] = {'value': col[1][0], 'tstamp': col[1][1]}
            # TODO use compile RE
            if re.match('parent:', col[0]):
                (_, _, parent_uuid) = col[0].split(':')

        if not obj_cols:
            raise common.exceptions.NoIdError(obj_uuid)

        result = {}
        # Name info
        result['fq_name'] = json.loads(obj_cols['fq_name']['value'])
        if 'parent_type' in obj_cols:
            # non config-root child
            parent_type = json.loads(obj_cols['parent_type']['value'])
            result['parent_type'] = parent_type
            try:
                result['parent_uuid'] = parent_uuid
                result['parent_href'] = self._db_client_mgr.generate_url(parent_type, parent_uuid)
            except common.exceptions.NoIdError:
                err_msg = 'Unknown uuid for parent ' + result['fq_name'][-2]
                return (False, err_msg)

        for col_name in obj_cols.keys():
            # TODO use compiled RE
            if re.match('prop:', col_name):
                (_, prop_name) = col_name.split(':')
                result[prop_name] = json.loads(obj_cols[col_name]['value'])

            # TODO use compiled RE
            if re.match('children:', col_name):
                (_, child_type, child_uuid) = col_name.split(':')
                child_tstamp = obj_cols[col_name]['tstamp']
                try:
                    self._read_child(result, obj_uuid, child_type, child_uuid, child_tstamp)
                except common.exceptions.NoIdError:
                    continue

            # TODO use compiled RE
            if re.match('ref:', col_name):
                (_, ref_type, ref_uuid) = col_name.split(':')
                self._read_ref(result, obj_uuid, ref_type, ref_uuid, obj_cols[col_name]['value'])

            if re.match('backref:', col_name):
                (_, back_ref_type, back_ref_uuid) = col_name.split(':')
                try:
                    self._read_back_ref(result, obj_uuid, back_ref_type, back_ref_uuid, \
                                        obj_cols[col_name]['value'])
                except common.exceptions.NoIdError:
                    continue

        # for all column names


        return (True, result)
    #end _cassandra_logical_interface_read

    def _cassandra_logical_interface_update(self, obj_uuid, dummy_old_obj_dict, new_obj_dict):
        # Grab ref-uuids and properties in new version
        new_ref_infos = {}

        if 'virtual_network_refs' in new_obj_dict:
            new_ref_infos['virtual_network'] = {}
            new_refs = new_obj_dict['virtual_network_refs']
            if new_refs:
                for new_ref in new_refs:
                    new_ref_uuid = self.fq_name_to_uuid('virtual_network', new_ref['to'])
                    new_ref_attr = new_ref.get('attr', None)
                    new_ref_data = {'attr': new_ref_attr, 'is_weakref': False}
                    new_ref_infos['virtual_network'][new_ref_uuid] = new_ref_data

        new_props = {}
        if 'id_perms' in new_obj_dict:
            new_props['id_perms'] = new_obj_dict['id_perms']
        # Gather column values for obj and updates to backrefs
        # in a batch and write it at the end
        obj_uuid_cf = self._obj_uuid_cf
        obj_cols_iter = obj_uuid_cf.xget(obj_uuid)
        # TODO optimize this (converts tuple to dict)
        obj_cols = {}
        for col_info in obj_cols_iter:
            obj_cols[col_info[0]] = col_info[1]

        bch = obj_uuid_cf.batch()
        for col_name in obj_cols.keys():
            # TODO use compiled RE
            if re.match('prop:', col_name):
                (_, prop_name) = col_name.split(':')
                if prop_name == 'id_perms':
                    # id-perms always has to be updated for last-mod timestamp
                    # get it from request dict(or from db if not in request dict)
                    new_id_perms = new_obj_dict.get(prop_name, json.loads(obj_cols[col_name]))
                    new_id_perms['last_modified'] = datetime.datetime.now().isoformat()
                    new_props['id_perms'] = new_id_perms
                    self._update_prop(bch, obj_uuid, 'id_perms', new_props)
                elif prop_name in new_obj_dict:
                    self._update_prop(bch, obj_uuid, prop_name, new_props)

            # TODO use compiled RE
            if re.match('ref:', col_name):
                (_, ref_type, ref_uuid) = col_name.split(':')
                self._update_ref(bch, 'logical_interface', obj_uuid, ref_type, ref_uuid, new_ref_infos)
        # for all column names

        # create new refs
        for ref_type in new_ref_infos.keys():
            for ref_uuid in new_ref_infos[ref_type].keys():
                ref_data = new_ref_infos[ref_type][ref_uuid]
                self._create_ref(bch, 'logical_interface', obj_uuid, ref_type, ref_uuid, ref_data)

        # create new props
        for prop_name in new_props.keys():
            self._create_prop(bch, obj_uuid, prop_name, new_props[prop_name])

        bch.send()

        return (True, '')
    #end _cassandra_logical_interface_update

    def _cassandra_logical_interface_list(self, parent_uuid):
        children_fq_names = []
        if not parent_uuid:
            # grab all resources of this type
            obj_fq_name_cf = self._obj_fq_name_cf
            col_name_iter = obj_fq_name_cf.xget('logical_interface')
            for (col_name, col_val) in col_name_iter:
                fq_name = col_name.split(':')[:-1]
                children_fq_names.append(fq_name)
        else:
            # go from parent to child
            obj_uuid_cf = self._obj_uuid_cf
            col_start = 'children:logical_interface:'
            col_fin = 'children:logical_interface;'
            col_name_iter = obj_uuid_cf.xget(parent_uuid, column_start = col_start, \
                                column_finish = col_fin, include_timestamp = True)

            unsorted_fq_names = []
            for col in col_name_iter:
                col_name = col[0]
                col_val_ts = col[1]
                child_uuid = col_name.split(':')[2]
                child_fq_name = self.uuid_to_fq_name(child_uuid)
                tstamp = col_val_ts[1]
                unsorted_fq_names.append({'fq_name': child_fq_name, 'tstamp': tstamp})

                # sort children; TODO do this based on schema
                sorted_children = sorted(unsorted_fq_names, key = itemgetter('tstamp'))
                # re-write result's children without timestamp
                children_fq_names = [child['fq_name'] for child in sorted_children]

        return (True, children_fq_names)
    #end _cassandra_logical_interface_list

    def _cassandra_logical_interface_delete(self, obj_uuid):
        obj_uuid_cf = self._obj_uuid_cf
        fq_name = json.loads(obj_uuid_cf.get(obj_uuid, columns = ['fq_name'])['fq_name'])
        bch = obj_uuid_cf.batch()

        # unlink from parent
        col_start = 'parent:'
        col_fin = 'parent;'
        col_name_iter = obj_uuid_cf.xget(obj_uuid, column_start = col_start, column_finish = col_fin)
        for (col_name, col_val) in col_name_iter:
            (_, parent_type, parent_uuid) = col_name.split(':')
            self._delete_child(bch, parent_type, parent_uuid, 'logical_interface', obj_uuid)

        # remove refs
        col_start = 'ref:'
        col_fin = 'ref;'
        col_name_iter = obj_uuid_cf.xget(obj_uuid, column_start = col_start, column_finish = col_fin)
        for (col_name, col_val) in col_name_iter:
            (_, ref_type, ref_uuid) = col_name.split(':')
            self._delete_ref(bch, 'logical_interface', obj_uuid, ref_type, ref_uuid)

        bch.remove(obj_uuid)
        bch.send()

        # Update fqname table
        fq_name_str = ':'.join(fq_name)
        fq_name_col = fq_name_str + ':' + obj_uuid
        self._obj_fq_name_cf.remove('logical_interface', columns = [fq_name_col])


        return (True, '')
    #end _cassandra_logical_interface_delete

    def _cassandra_routing_instance_alloc(self, fq_name):
        return (True, '')
    #end _cassandra_routing_instance_alloc

    def _cassandra_routing_instance_create(self, obj_ids, obj_dict):
        # Gather column values for obj and updates to backrefs
        # in a batch and write it at the end
        bch = self._obj_uuid_cf.batch()

        obj_cols = {}
        obj_cols['fq_name'] = json.dumps(obj_dict['fq_name'])
        obj_cols['type'] = json.dumps('routing_instance')
        if 'parent_type' in obj_dict:
            # non config-root child
            parent_type = obj_dict['parent_type']
            parent_method_type = parent_type.replace('-', '_')
            parent_fq_name = obj_dict['fq_name'][:-1]
            obj_cols['parent_type'] = json.dumps(parent_type)
            parent_uuid = self.fq_name_to_uuid(parent_method_type, parent_fq_name)
            self._create_child(bch, parent_method_type, parent_uuid, 'routing_instance', obj_ids['uuid'])

        # Properties
        field = obj_dict.get('static_route_entries', None)
        if field:
            self._create_prop(bch, obj_ids['uuid'], 'static_route_entries', field)

        field = obj_dict.get('service_chain_information', None)
        if field:
            self._create_prop(bch, obj_ids['uuid'], 'service_chain_information', field)

        field = obj_dict.get('default_ce_protocol', None)
        if field:
            self._create_prop(bch, obj_ids['uuid'], 'default_ce_protocol', field)

        field = obj_dict.get('id_perms', None)
        field['created'] = datetime.datetime.now().isoformat()
        field['last_modified'] = field['created']
        if field:
            self._create_prop(bch, obj_ids['uuid'], 'id_perms', field)


        # References
        refs = obj_dict.get('routing_instance_refs', [])
        for ref in refs:
            ref_uuid = self.fq_name_to_uuid('routing_instance', ref['to'])
            ref_attr = ref.get('attr', None)
            ref_data = {'attr': ref_attr, 'is_weakref': False}
            self._create_ref(bch, 'routing_instance', obj_ids['uuid'], 'routing_instance', ref_uuid, ref_data)
        refs = obj_dict.get('route_target_refs', [])
        for ref in refs:
            ref_uuid = self.fq_name_to_uuid('route_target', ref['to'])
            ref_attr = ref.get('attr', None)
            ref_data = {'attr': ref_attr, 'is_weakref': False}
            self._create_ref(bch, 'routing_instance', obj_ids['uuid'], 'route_target', ref_uuid, ref_data)

        bch.insert(obj_ids['uuid'], obj_cols)
        bch.send()

        # Update fqname table
        fq_name_str = ':'.join(obj_dict['fq_name'])
        fq_name_cols = {fq_name_str + ':' + obj_ids['uuid']: json.dumps(None)}
        self._obj_fq_name_cf.insert('routing_instance', fq_name_cols)

        return (True, '')
    #end _cassandra_routing_instance_create

    def _cassandra_routing_instance_read(self, obj_uuid, field_names = None):
        obj_uuid_cf = self._obj_uuid_cf
        obj_cols_iter = obj_uuid_cf.xget(obj_uuid, include_timestamp = True)
        # TODO optimize this if needed
        obj_cols = {}
        for col in obj_cols_iter:
            # col-name = value + tstamp
            obj_cols[col[0]] = {'value': col[1][0], 'tstamp': col[1][1]}
            # TODO use compile RE
            if re.match('parent:', col[0]):
                (_, _, parent_uuid) = col[0].split(':')

        if not obj_cols:
            raise common.exceptions.NoIdError(obj_uuid)

        result = {}
        # Name info
        result['fq_name'] = json.loads(obj_cols['fq_name']['value'])
        if 'parent_type' in obj_cols:
            # non config-root child
            parent_type = json.loads(obj_cols['parent_type']['value'])
            result['parent_type'] = parent_type
            try:
                result['parent_uuid'] = parent_uuid
                result['parent_href'] = self._db_client_mgr.generate_url(parent_type, parent_uuid)
            except common.exceptions.NoIdError:
                # ok for parent to go away since we are machine generated
                pass

        for col_name in obj_cols.keys():
            # TODO use compiled RE
            if re.match('prop:', col_name):
                (_, prop_name) = col_name.split(':')
                result[prop_name] = json.loads(obj_cols[col_name]['value'])

            # TODO use compiled RE
            if re.match('children:', col_name):
                (_, child_type, child_uuid) = col_name.split(':')
                child_tstamp = obj_cols[col_name]['tstamp']
                try:
                    self._read_child(result, obj_uuid, child_type, child_uuid, child_tstamp)
                except common.exceptions.NoIdError:
                    continue

            # TODO use compiled RE
            if re.match('ref:', col_name):
                (_, ref_type, ref_uuid) = col_name.split(':')
                self._read_ref(result, obj_uuid, ref_type, ref_uuid, obj_cols[col_name]['value'])

            if re.match('backref:', col_name):
                (_, back_ref_type, back_ref_uuid) = col_name.split(':')
                try:
                    self._read_back_ref(result, obj_uuid, back_ref_type, back_ref_uuid, \
                                        obj_cols[col_name]['value'])
                except common.exceptions.NoIdError:
                    continue

        # for all column names

        if 'bgp_routers' in result:
            # sort children; TODO do this based on schema
            sorted_children = sorted(result['bgp_routers'], key = itemgetter('tstamp'))
            # re-write result's children without timestamp
            result['bgp_routers'] = sorted_children
            [child.pop('tstamp') for child in result['bgp_routers']]


        return (True, result)
    #end _cassandra_routing_instance_read

    def _cassandra_routing_instance_update(self, obj_uuid, dummy_old_obj_dict, new_obj_dict):
        # Grab ref-uuids and properties in new version
        new_ref_infos = {}

        if 'routing_instance_refs' in new_obj_dict:
            new_ref_infos['routing_instance'] = {}
            new_refs = new_obj_dict['routing_instance_refs']
            if new_refs:
                for new_ref in new_refs:
                    new_ref_uuid = self.fq_name_to_uuid('routing_instance', new_ref['to'])
                    new_ref_attr = new_ref.get('attr', None)
                    new_ref_data = {'attr': new_ref_attr, 'is_weakref': False}
                    new_ref_infos['routing_instance'][new_ref_uuid] = new_ref_data

        if 'route_target_refs' in new_obj_dict:
            new_ref_infos['route_target'] = {}
            new_refs = new_obj_dict['route_target_refs']
            if new_refs:
                for new_ref in new_refs:
                    new_ref_uuid = self.fq_name_to_uuid('route_target', new_ref['to'])
                    new_ref_attr = new_ref.get('attr', None)
                    new_ref_data = {'attr': new_ref_attr, 'is_weakref': False}
                    new_ref_infos['route_target'][new_ref_uuid] = new_ref_data

        new_props = {}
        if 'static_route_entries' in new_obj_dict:
            new_props['static_route_entries'] = new_obj_dict['static_route_entries']
        if 'service_chain_information' in new_obj_dict:
            new_props['service_chain_information'] = new_obj_dict['service_chain_information']
        if 'default_ce_protocol' in new_obj_dict:
            new_props['default_ce_protocol'] = new_obj_dict['default_ce_protocol']
        if 'id_perms' in new_obj_dict:
            new_props['id_perms'] = new_obj_dict['id_perms']
        # Gather column values for obj and updates to backrefs
        # in a batch and write it at the end
        obj_uuid_cf = self._obj_uuid_cf
        obj_cols_iter = obj_uuid_cf.xget(obj_uuid)
        # TODO optimize this (converts tuple to dict)
        obj_cols = {}
        for col_info in obj_cols_iter:
            obj_cols[col_info[0]] = col_info[1]

        bch = obj_uuid_cf.batch()
        for col_name in obj_cols.keys():
            # TODO use compiled RE
            if re.match('prop:', col_name):
                (_, prop_name) = col_name.split(':')
                if prop_name == 'id_perms':
                    # id-perms always has to be updated for last-mod timestamp
                    # get it from request dict(or from db if not in request dict)
                    new_id_perms = new_obj_dict.get(prop_name, json.loads(obj_cols[col_name]))
                    new_id_perms['last_modified'] = datetime.datetime.now().isoformat()
                    new_props['id_perms'] = new_id_perms
                    self._update_prop(bch, obj_uuid, 'id_perms', new_props)
                elif prop_name in new_obj_dict:
                    self._update_prop(bch, obj_uuid, prop_name, new_props)

            # TODO use compiled RE
            if re.match('ref:', col_name):
                (_, ref_type, ref_uuid) = col_name.split(':')
                self._update_ref(bch, 'routing_instance', obj_uuid, ref_type, ref_uuid, new_ref_infos)
        # for all column names

        # create new refs
        for ref_type in new_ref_infos.keys():
            for ref_uuid in new_ref_infos[ref_type].keys():
                ref_data = new_ref_infos[ref_type][ref_uuid]
                self._create_ref(bch, 'routing_instance', obj_uuid, ref_type, ref_uuid, ref_data)

        # create new props
        for prop_name in new_props.keys():
            self._create_prop(bch, obj_uuid, prop_name, new_props[prop_name])

        bch.send()

        return (True, '')
    #end _cassandra_routing_instance_update

    def _cassandra_routing_instance_list(self, parent_uuid):
        children_fq_names = []
        if not parent_uuid:
            # grab all resources of this type
            obj_fq_name_cf = self._obj_fq_name_cf
            col_name_iter = obj_fq_name_cf.xget('routing_instance')
            for (col_name, col_val) in col_name_iter:
                fq_name = col_name.split(':')[:-1]
                children_fq_names.append(fq_name)
        else:
            # go from parent to child
            obj_uuid_cf = self._obj_uuid_cf
            col_start = 'children:routing_instance:'
            col_fin = 'children:routing_instance;'
            col_name_iter = obj_uuid_cf.xget(parent_uuid, column_start = col_start, \
                                column_finish = col_fin, include_timestamp = True)

            unsorted_fq_names = []
            for col in col_name_iter:
                col_name = col[0]
                col_val_ts = col[1]
                child_uuid = col_name.split(':')[2]
                child_fq_name = self.uuid_to_fq_name(child_uuid)
                tstamp = col_val_ts[1]
                unsorted_fq_names.append({'fq_name': child_fq_name, 'tstamp': tstamp})

                # sort children; TODO do this based on schema
                sorted_children = sorted(unsorted_fq_names, key = itemgetter('tstamp'))
                # re-write result's children without timestamp
                children_fq_names = [child['fq_name'] for child in sorted_children]

        return (True, children_fq_names)
    #end _cassandra_routing_instance_list

    def _cassandra_routing_instance_delete(self, obj_uuid):
        obj_uuid_cf = self._obj_uuid_cf
        fq_name = json.loads(obj_uuid_cf.get(obj_uuid, columns = ['fq_name'])['fq_name'])
        bch = obj_uuid_cf.batch()

        # unlink from parent
        col_start = 'parent:'
        col_fin = 'parent;'
        col_name_iter = obj_uuid_cf.xget(obj_uuid, column_start = col_start, column_finish = col_fin)
        for (col_name, col_val) in col_name_iter:
            (_, parent_type, parent_uuid) = col_name.split(':')
            self._delete_child(bch, parent_type, parent_uuid, 'routing_instance', obj_uuid)

        # remove refs
        col_start = 'ref:'
        col_fin = 'ref;'
        col_name_iter = obj_uuid_cf.xget(obj_uuid, column_start = col_start, column_finish = col_fin)
        for (col_name, col_val) in col_name_iter:
            (_, ref_type, ref_uuid) = col_name.split(':')
            self._delete_ref(bch, 'routing_instance', obj_uuid, ref_type, ref_uuid)

        bch.remove(obj_uuid)
        bch.send()

        # Update fqname table
        fq_name_str = ':'.join(fq_name)
        fq_name_col = fq_name_str + ':' + obj_uuid
        self._obj_fq_name_cf.remove('routing_instance', columns = [fq_name_col])


        return (True, '')
    #end _cassandra_routing_instance_delete

    def _cassandra_virtual_machine_interface_alloc(self, fq_name):
        return (True, '')
    #end _cassandra_virtual_machine_interface_alloc

    def _cassandra_virtual_machine_interface_create(self, obj_ids, obj_dict):
        # Gather column values for obj and updates to backrefs
        # in a batch and write it at the end
        bch = self._obj_uuid_cf.batch()

        obj_cols = {}
        obj_cols['fq_name'] = json.dumps(obj_dict['fq_name'])
        obj_cols['type'] = json.dumps('virtual_machine_interface')
        if 'parent_type' in obj_dict:
            # non config-root child
            parent_type = obj_dict['parent_type']
            parent_method_type = parent_type.replace('-', '_')
            parent_fq_name = obj_dict['fq_name'][:-1]
            obj_cols['parent_type'] = json.dumps(parent_type)
            parent_uuid = self.fq_name_to_uuid(parent_method_type, parent_fq_name)
            self._create_child(bch, parent_method_type, parent_uuid, 'virtual_machine_interface', obj_ids['uuid'])

        # Properties
        field = obj_dict.get('virtual_machine_interface_mac_addresses', None)
        if field:
            self._create_prop(bch, obj_ids['uuid'], 'virtual_machine_interface_mac_addresses', field)

        field = obj_dict.get('virtual_machine_interface_properties', None)
        if field:
            self._create_prop(bch, obj_ids['uuid'], 'virtual_machine_interface_properties', field)

        field = obj_dict.get('id_perms', None)
        field['created'] = datetime.datetime.now().isoformat()
        field['last_modified'] = field['created']
        if field:
            self._create_prop(bch, obj_ids['uuid'], 'id_perms', field)


        # References
        refs = obj_dict.get('virtual_network_refs', [])
        for ref in refs:
            ref_uuid = self.fq_name_to_uuid('virtual_network', ref['to'])
            ref_attr = ref.get('attr', None)
            ref_data = {'attr': ref_attr, 'is_weakref': False}
            self._create_ref(bch, 'virtual_machine_interface', obj_ids['uuid'], 'virtual_network', ref_uuid, ref_data)
        refs = obj_dict.get('routing_instance_refs', [])
        for ref in refs:
            ref_uuid = self.fq_name_to_uuid('routing_instance', ref['to'])
            ref_attr = ref.get('attr', None)
            ref_data = {'attr': ref_attr, 'is_weakref': False}
            self._create_ref(bch, 'virtual_machine_interface', obj_ids['uuid'], 'routing_instance', ref_uuid, ref_data)

        bch.insert(obj_ids['uuid'], obj_cols)
        bch.send()

        # Update fqname table
        fq_name_str = ':'.join(obj_dict['fq_name'])
        fq_name_cols = {fq_name_str + ':' + obj_ids['uuid']: json.dumps(None)}
        self._obj_fq_name_cf.insert('virtual_machine_interface', fq_name_cols)

        return (True, '')
    #end _cassandra_virtual_machine_interface_create

    def _cassandra_virtual_machine_interface_read(self, obj_uuid, field_names = None):
        obj_uuid_cf = self._obj_uuid_cf
        obj_cols_iter = obj_uuid_cf.xget(obj_uuid, include_timestamp = True)
        # TODO optimize this if needed
        obj_cols = {}
        for col in obj_cols_iter:
            # col-name = value + tstamp
            obj_cols[col[0]] = {'value': col[1][0], 'tstamp': col[1][1]}
            # TODO use compile RE
            if re.match('parent:', col[0]):
                (_, _, parent_uuid) = col[0].split(':')

        if not obj_cols:
            raise common.exceptions.NoIdError(obj_uuid)

        result = {}
        # Name info
        result['fq_name'] = json.loads(obj_cols['fq_name']['value'])
        if 'parent_type' in obj_cols:
            # non config-root child
            parent_type = json.loads(obj_cols['parent_type']['value'])
            result['parent_type'] = parent_type
            try:
                result['parent_uuid'] = parent_uuid
                result['parent_href'] = self._db_client_mgr.generate_url(parent_type, parent_uuid)
            except common.exceptions.NoIdError:
                err_msg = 'Unknown uuid for parent ' + result['fq_name'][-2]
                return (False, err_msg)

        for col_name in obj_cols.keys():
            # TODO use compiled RE
            if re.match('prop:', col_name):
                (_, prop_name) = col_name.split(':')
                result[prop_name] = json.loads(obj_cols[col_name]['value'])

            # TODO use compiled RE
            if re.match('children:', col_name):
                (_, child_type, child_uuid) = col_name.split(':')
                child_tstamp = obj_cols[col_name]['tstamp']
                try:
                    self._read_child(result, obj_uuid, child_type, child_uuid, child_tstamp)
                except common.exceptions.NoIdError:
                    continue

            # TODO use compiled RE
            if re.match('ref:', col_name):
                (_, ref_type, ref_uuid) = col_name.split(':')
                self._read_ref(result, obj_uuid, ref_type, ref_uuid, obj_cols[col_name]['value'])

            if re.match('backref:', col_name):
                (_, back_ref_type, back_ref_uuid) = col_name.split(':')
                try:
                    self._read_back_ref(result, obj_uuid, back_ref_type, back_ref_uuid, \
                                        obj_cols[col_name]['value'])
                except common.exceptions.NoIdError:
                    continue

        # for all column names


        return (True, result)
    #end _cassandra_virtual_machine_interface_read

    def _cassandra_virtual_machine_interface_update(self, obj_uuid, dummy_old_obj_dict, new_obj_dict):
        # Grab ref-uuids and properties in new version
        new_ref_infos = {}

        if 'virtual_network_refs' in new_obj_dict:
            new_ref_infos['virtual_network'] = {}
            new_refs = new_obj_dict['virtual_network_refs']
            if new_refs:
                for new_ref in new_refs:
                    new_ref_uuid = self.fq_name_to_uuid('virtual_network', new_ref['to'])
                    new_ref_attr = new_ref.get('attr', None)
                    new_ref_data = {'attr': new_ref_attr, 'is_weakref': False}
                    new_ref_infos['virtual_network'][new_ref_uuid] = new_ref_data

        if 'routing_instance_refs' in new_obj_dict:
            new_ref_infos['routing_instance'] = {}
            new_refs = new_obj_dict['routing_instance_refs']
            if new_refs:
                for new_ref in new_refs:
                    new_ref_uuid = self.fq_name_to_uuid('routing_instance', new_ref['to'])
                    new_ref_attr = new_ref.get('attr', None)
                    new_ref_data = {'attr': new_ref_attr, 'is_weakref': False}
                    new_ref_infos['routing_instance'][new_ref_uuid] = new_ref_data

        new_props = {}
        if 'virtual_machine_interface_mac_addresses' in new_obj_dict:
            new_props['virtual_machine_interface_mac_addresses'] = new_obj_dict['virtual_machine_interface_mac_addresses']
        if 'virtual_machine_interface_properties' in new_obj_dict:
            new_props['virtual_machine_interface_properties'] = new_obj_dict['virtual_machine_interface_properties']
        if 'id_perms' in new_obj_dict:
            new_props['id_perms'] = new_obj_dict['id_perms']
        # Gather column values for obj and updates to backrefs
        # in a batch and write it at the end
        obj_uuid_cf = self._obj_uuid_cf
        obj_cols_iter = obj_uuid_cf.xget(obj_uuid)
        # TODO optimize this (converts tuple to dict)
        obj_cols = {}
        for col_info in obj_cols_iter:
            obj_cols[col_info[0]] = col_info[1]

        bch = obj_uuid_cf.batch()
        for col_name in obj_cols.keys():
            # TODO use compiled RE
            if re.match('prop:', col_name):
                (_, prop_name) = col_name.split(':')
                if prop_name == 'id_perms':
                    # id-perms always has to be updated for last-mod timestamp
                    # get it from request dict(or from db if not in request dict)
                    new_id_perms = new_obj_dict.get(prop_name, json.loads(obj_cols[col_name]))
                    new_id_perms['last_modified'] = datetime.datetime.now().isoformat()
                    new_props['id_perms'] = new_id_perms
                    self._update_prop(bch, obj_uuid, 'id_perms', new_props)
                elif prop_name in new_obj_dict:
                    self._update_prop(bch, obj_uuid, prop_name, new_props)

            # TODO use compiled RE
            if re.match('ref:', col_name):
                (_, ref_type, ref_uuid) = col_name.split(':')
                self._update_ref(bch, 'virtual_machine_interface', obj_uuid, ref_type, ref_uuid, new_ref_infos)
        # for all column names

        # create new refs
        for ref_type in new_ref_infos.keys():
            for ref_uuid in new_ref_infos[ref_type].keys():
                ref_data = new_ref_infos[ref_type][ref_uuid]
                self._create_ref(bch, 'virtual_machine_interface', obj_uuid, ref_type, ref_uuid, ref_data)

        # create new props
        for prop_name in new_props.keys():
            self._create_prop(bch, obj_uuid, prop_name, new_props[prop_name])

        bch.send()

        return (True, '')
    #end _cassandra_virtual_machine_interface_update

    def _cassandra_virtual_machine_interface_list(self, parent_uuid):
        children_fq_names = []
        if not parent_uuid:
            # grab all resources of this type
            obj_fq_name_cf = self._obj_fq_name_cf
            col_name_iter = obj_fq_name_cf.xget('virtual_machine_interface')
            for (col_name, col_val) in col_name_iter:
                fq_name = col_name.split(':')[:-1]
                children_fq_names.append(fq_name)
        else:
            # go from parent to child
            obj_uuid_cf = self._obj_uuid_cf
            col_start = 'children:virtual_machine_interface:'
            col_fin = 'children:virtual_machine_interface;'
            col_name_iter = obj_uuid_cf.xget(parent_uuid, column_start = col_start, \
                                column_finish = col_fin, include_timestamp = True)

            unsorted_fq_names = []
            for col in col_name_iter:
                col_name = col[0]
                col_val_ts = col[1]
                child_uuid = col_name.split(':')[2]
                child_fq_name = self.uuid_to_fq_name(child_uuid)
                tstamp = col_val_ts[1]
                unsorted_fq_names.append({'fq_name': child_fq_name, 'tstamp': tstamp})

                # sort children; TODO do this based on schema
                sorted_children = sorted(unsorted_fq_names, key = itemgetter('tstamp'))
                # re-write result's children without timestamp
                children_fq_names = [child['fq_name'] for child in sorted_children]

        return (True, children_fq_names)
    #end _cassandra_virtual_machine_interface_list

    def _cassandra_virtual_machine_interface_delete(self, obj_uuid):
        obj_uuid_cf = self._obj_uuid_cf
        fq_name = json.loads(obj_uuid_cf.get(obj_uuid, columns = ['fq_name'])['fq_name'])
        bch = obj_uuid_cf.batch()

        # unlink from parent
        col_start = 'parent:'
        col_fin = 'parent;'
        col_name_iter = obj_uuid_cf.xget(obj_uuid, column_start = col_start, column_finish = col_fin)
        for (col_name, col_val) in col_name_iter:
            (_, parent_type, parent_uuid) = col_name.split(':')
            self._delete_child(bch, parent_type, parent_uuid, 'virtual_machine_interface', obj_uuid)

        # remove refs
        col_start = 'ref:'
        col_fin = 'ref;'
        col_name_iter = obj_uuid_cf.xget(obj_uuid, column_start = col_start, column_finish = col_fin)
        for (col_name, col_val) in col_name_iter:
            (_, ref_type, ref_uuid) = col_name.split(':')
            self._delete_ref(bch, 'virtual_machine_interface', obj_uuid, ref_type, ref_uuid)

        bch.remove(obj_uuid)
        bch.send()

        # Update fqname table
        fq_name_str = ':'.join(fq_name)
        fq_name_col = fq_name_str + ':' + obj_uuid
        self._obj_fq_name_cf.remove('virtual_machine_interface', columns = [fq_name_col])


        return (True, '')
    #end _cassandra_virtual_machine_interface_delete


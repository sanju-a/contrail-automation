"""
This module defines the classes for types defined in :doc:`vnc_cfg.xsd`
"""
import json
from generatedssuper import *
class MacAddressesType(GeneratedsSuper):
    """
    MacAddressesType class definition from :doc:`vnc_cfg.xsd`
    """
    subclass = None
    superclass = None
    def __init__(self, mac_address=None, **kwargs):
        if (mac_address is None) or (mac_address == []):
            self.mac_address = []
        else:
            self.mac_address = mac_address
    def factory(*args_, **kwargs_):
        if MacAddressesType.subclass:
            return MacAddressesType.subclass(*args_, **kwargs_)
        else:
            return MacAddressesType(*args_, **kwargs_)
    factory = staticmethod(factory)
    def get_mac_address(self): return self.mac_address
    def set_mac_address(self, mac_address): self.mac_address = mac_address
    def add_mac_address(self, value): self.mac_address.append(value)
    def insert_mac_address(self, index, value): self.mac_address[index] = value
    @classmethod
    def populate (cls, *a, **kwa):
        obj = cls (*a, **kwa)
        obj.set_mac_address (obj.populate_string ("mac_address"))
        return obj
    def export(self, outfile, level=1, namespace_='', name_='MacAddressesType', namespacedef_='', pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        showIndent(outfile, level, pretty_print)
        outfile.write('<%s%s%s' % (namespace_, name_, namespacedef_ and ' ' + namespacedef_ or '', ))
        already_processed = []
        self.exportAttributes(outfile, level, already_processed, namespace_, name_='MacAddressesType')
        if self.hasContent_():
            outfile.write('>%s' % (eol_, ))
            self.exportChildren(outfile, level + 1, namespace_, name_, pretty_print=pretty_print)
            showIndent(outfile, level, pretty_print)
            outfile.write('</%s%s>%s' % (namespace_, name_, eol_))
        else:
            outfile.write('/>%s' % (eol_, ))
    def exportAttributes(self, outfile, level, already_processed, namespace_='', name_='MacAddressesType'):
        pass
    def exportChildren(self, outfile, level, namespace_='', name_='MacAddressesType', fromsubclass_=False, pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        for mac_address_ in self.mac_address:
            showIndent(outfile, level, pretty_print)
            outfile.write('<%smac-address>%s</%smac-address>%s' % (namespace_, self.gds_format_string(quote_xml(mac_address_).encode(ExternalEncoding), input_name='mac-address'), namespace_, eol_))
    def hasContent_(self):
        if (
            self.mac_address
            ):
            return True
        else:
            return False
    def exportLiteral(self, outfile, level, name_='MacAddressesType'):
        level += 1
        self.exportLiteralAttributes(outfile, level, [], name_)
        if self.hasContent_():
            self.exportLiteralChildren(outfile, level, name_)
    def exportLiteralAttributes(self, outfile, level, already_processed, name_):
        pass
    def exportLiteralChildren(self, outfile, level, name_):
        showIndent(outfile, level)
        outfile.write('mac_address=[\n')
        level += 1
        for mac_address_ in self.mac_address:
            showIndent(outfile, level)
            outfile.write('%s,\n' % quote_python(mac_address_).encode(ExternalEncoding))
        level -= 1
        showIndent(outfile, level)
        outfile.write('],\n')
    def exportDict(self, name_='MacAddressesType'):
        obj_json = json.dumps(self, default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        obj_dict = json.loads(obj_json)
        return {name_: obj_dict}
    def build(self, node):
        self.buildAttributes(node, node.attrib, [])
        for child in node:
            nodeName_ = Tag_pattern_.match(child.tag).groups()[-1]
            self.buildChildren(child, node, nodeName_)
    def buildAttributes(self, node, attrs, already_processed):
        pass
    def buildChildren(self, child_, node, nodeName_, fromsubclass_=False):
        if nodeName_ == 'mac-address':
            mac_address_ = child_.text
            mac_address_ = self.gds_validate_string(mac_address_, node, 'mac_address')
            self.mac_address.append(mac_address_)
# end class MacAddressesType


class mac_address(GeneratedsSuper):
    """
    mac_address class definition from :doc:`vnc_cfg.xsd`
    """
    subclass = None
    superclass = None
    def __init__(self, **kwargs):
        pass
    def factory(*args_, **kwargs_):
        if mac_address.subclass:
            return mac_address.subclass(*args_, **kwargs_)
        else:
            return mac_address(*args_, **kwargs_)
    factory = staticmethod(factory)
    @classmethod
    def populate (cls, *a, **kwa):
        obj = cls (*a, **kwa)
        return obj
    def export(self, outfile, level=1, namespace_='', name_='mac-address', namespacedef_='', pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        showIndent(outfile, level, pretty_print)
        outfile.write('<%s%s%s' % (namespace_, name_, namespacedef_ and ' ' + namespacedef_ or '', ))
        already_processed = []
        self.exportAttributes(outfile, level, already_processed, namespace_, name_='mac-address')
        if self.hasContent_():
            outfile.write('>%s' % (eol_, ))
            self.exportChildren(outfile, level + 1, namespace_, name_, pretty_print=pretty_print)
            outfile.write('</%s%s>%s' % (namespace_, name_, eol_))
        else:
            outfile.write('/>%s' % (eol_, ))
    def exportAttributes(self, outfile, level, already_processed, namespace_='', name_='mac-address'):
        pass
    def exportChildren(self, outfile, level, namespace_='', name_='mac-address', fromsubclass_=False, pretty_print=True):
        pass
    def hasContent_(self):
        if (

            ):
            return True
        else:
            return False
    def exportLiteral(self, outfile, level, name_='mac-address'):
        level += 1
        self.exportLiteralAttributes(outfile, level, [], name_)
        if self.hasContent_():
            self.exportLiteralChildren(outfile, level, name_)
    def exportLiteralAttributes(self, outfile, level, already_processed, name_):
        pass
    def exportLiteralChildren(self, outfile, level, name_):
        pass
    def exportDict(self, name_='mac-address'):
        obj_json = json.dumps(self, default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        obj_dict = json.loads(obj_json)
        return {name_: obj_dict}
    def build(self, node):
        self.buildAttributes(node, node.attrib, [])
        for child in node:
            nodeName_ = Tag_pattern_.match(child.tag).groups()[-1]
            self.buildChildren(child, node, nodeName_)
    def buildAttributes(self, node, attrs, already_processed):
        pass
    def buildChildren(self, child_, node, nodeName_, fromsubclass_=False):
        pass
# end class mac_address


class IpAddressesType(GeneratedsSuper):
    """
    IpAddressesType class definition from :doc:`vnc_cfg.xsd`
    """
    subclass = None
    superclass = None
    def __init__(self, ip_address=None, **kwargs):
        if (ip_address is None) or (ip_address == []):
            self.ip_address = []
        else:
            self.ip_address = ip_address
    def factory(*args_, **kwargs_):
        if IpAddressesType.subclass:
            return IpAddressesType.subclass(*args_, **kwargs_)
        else:
            return IpAddressesType(*args_, **kwargs_)
    factory = staticmethod(factory)
    def get_ip_address(self): return self.ip_address
    def set_ip_address(self, ip_address): self.ip_address = ip_address
    def add_ip_address(self, value): self.ip_address.append(value)
    def insert_ip_address(self, index, value): self.ip_address[index] = value
    def validate_IpAddressType(self, value):
        # Validate type IpAddressType, a restriction on xsd:string.
        pass
    @classmethod
    def populate (cls, *a, **kwa):
        obj = cls (*a, **kwa)
        obj.set_ip_address (obj.populate_string ("ip_address"))
        return obj
    def export(self, outfile, level=1, namespace_='', name_='IpAddressesType', namespacedef_='', pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        showIndent(outfile, level, pretty_print)
        outfile.write('<%s%s%s' % (namespace_, name_, namespacedef_ and ' ' + namespacedef_ or '', ))
        already_processed = []
        self.exportAttributes(outfile, level, already_processed, namespace_, name_='IpAddressesType')
        if self.hasContent_():
            outfile.write('>%s' % (eol_, ))
            self.exportChildren(outfile, level + 1, namespace_, name_, pretty_print=pretty_print)
            showIndent(outfile, level, pretty_print)
            outfile.write('</%s%s>%s' % (namespace_, name_, eol_))
        else:
            outfile.write('/>%s' % (eol_, ))
    def exportAttributes(self, outfile, level, already_processed, namespace_='', name_='IpAddressesType'):
        pass
    def exportChildren(self, outfile, level, namespace_='', name_='IpAddressesType', fromsubclass_=False, pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        for ip_address_ in self.ip_address:
            showIndent(outfile, level, pretty_print)
            outfile.write('<%sip-address>%s</%sip-address>%s' % (namespace_, self.gds_format_string(quote_xml(ip_address_).encode(ExternalEncoding), input_name='ip-address'), namespace_, eol_))
    def hasContent_(self):
        if (
            self.ip_address
            ):
            return True
        else:
            return False
    def exportLiteral(self, outfile, level, name_='IpAddressesType'):
        level += 1
        self.exportLiteralAttributes(outfile, level, [], name_)
        if self.hasContent_():
            self.exportLiteralChildren(outfile, level, name_)
    def exportLiteralAttributes(self, outfile, level, already_processed, name_):
        pass
    def exportLiteralChildren(self, outfile, level, name_):
        showIndent(outfile, level)
        outfile.write('ip_address=[\n')
        level += 1
        for ip_address_ in self.ip_address:
            showIndent(outfile, level)
            outfile.write('%s,\n' % quote_python(ip_address_).encode(ExternalEncoding))
        level -= 1
        showIndent(outfile, level)
        outfile.write('],\n')
    def exportDict(self, name_='IpAddressesType'):
        obj_json = json.dumps(self, default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        obj_dict = json.loads(obj_json)
        return {name_: obj_dict}
    def build(self, node):
        self.buildAttributes(node, node.attrib, [])
        for child in node:
            nodeName_ = Tag_pattern_.match(child.tag).groups()[-1]
            self.buildChildren(child, node, nodeName_)
    def buildAttributes(self, node, attrs, already_processed):
        pass
    def buildChildren(self, child_, node, nodeName_, fromsubclass_=False):
        if nodeName_ == 'ip-address':
            ip_address_ = child_.text
            ip_address_ = self.gds_validate_string(ip_address_, node, 'ip_address')
            self.ip_address.append(ip_address_)
            self.validate_IpAddressType(self.ip_address)    # validate type IpAddressType
# end class IpAddressesType


class SubnetType(GeneratedsSuper):
    """
    SubnetType class definition from :doc:`vnc_cfg.xsd`
    """
    subclass = None
    superclass = None
    def __init__(self, ip_prefix=None, ip_prefix_len=None, **kwargs):
        self.ip_prefix = ip_prefix
        self.ip_prefix_len = ip_prefix_len
    def factory(*args_, **kwargs_):
        if SubnetType.subclass:
            return SubnetType.subclass(*args_, **kwargs_)
        else:
            return SubnetType(*args_, **kwargs_)
    factory = staticmethod(factory)
    def get_ip_prefix(self): return self.ip_prefix
    def set_ip_prefix(self, ip_prefix): self.ip_prefix = ip_prefix
    def get_ip_prefix_len(self): return self.ip_prefix_len
    def set_ip_prefix_len(self, ip_prefix_len): self.ip_prefix_len = ip_prefix_len
    @classmethod
    def populate (cls, *a, **kwa):
        obj = cls (*a, **kwa)
        obj.set_ip_prefix (obj.populate_string ("ip_prefix"))
        obj.set_ip_prefix_len (obj.populate_integer ("ip_prefix_len"))
        return obj
    def export(self, outfile, level=1, namespace_='', name_='SubnetType', namespacedef_='', pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        showIndent(outfile, level, pretty_print)
        outfile.write('<%s%s%s' % (namespace_, name_, namespacedef_ and ' ' + namespacedef_ or '', ))
        already_processed = []
        self.exportAttributes(outfile, level, already_processed, namespace_, name_='SubnetType')
        if self.hasContent_():
            outfile.write('>%s' % (eol_, ))
            self.exportChildren(outfile, level + 1, namespace_, name_, pretty_print=pretty_print)
            showIndent(outfile, level, pretty_print)
            outfile.write('</%s%s>%s' % (namespace_, name_, eol_))
        else:
            outfile.write('/>%s' % (eol_, ))
    def exportAttributes(self, outfile, level, already_processed, namespace_='', name_='SubnetType'):
        pass
    def exportChildren(self, outfile, level, namespace_='', name_='SubnetType', fromsubclass_=False, pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        if self.ip_prefix is not None:
            showIndent(outfile, level, pretty_print)
            outfile.write('<%sip-prefix>%s</%sip-prefix>%s' % (namespace_, self.gds_format_string(quote_xml(self.ip_prefix).encode(ExternalEncoding), input_name='ip-prefix'), namespace_, eol_))
        if self.ip_prefix_len is not None:
            showIndent(outfile, level, pretty_print)
            outfile.write('<%sip-prefix-len>%s</%sip-prefix-len>%s' % (namespace_, self.gds_format_integer(self.ip_prefix_len, input_name='ip-prefix-len'), namespace_, eol_))
    def hasContent_(self):
        if (
            self.ip_prefix is not None or
            self.ip_prefix_len is not None
            ):
            return True
        else:
            return False
    def exportLiteral(self, outfile, level, name_='SubnetType'):
        level += 1
        self.exportLiteralAttributes(outfile, level, [], name_)
        if self.hasContent_():
            self.exportLiteralChildren(outfile, level, name_)
    def exportLiteralAttributes(self, outfile, level, already_processed, name_):
        pass
    def exportLiteralChildren(self, outfile, level, name_):
        if self.ip_prefix is not None:
            showIndent(outfile, level)
            outfile.write('ip_prefix=%s,\n' % quote_python(self.ip_prefix).encode(ExternalEncoding))
        if self.ip_prefix_len is not None:
            showIndent(outfile, level)
            outfile.write('ip_prefix_len=%d,\n' % self.ip_prefix_len)
    def exportDict(self, name_='SubnetType'):
        obj_json = json.dumps(self, default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        obj_dict = json.loads(obj_json)
        return {name_: obj_dict}
    def build(self, node):
        self.buildAttributes(node, node.attrib, [])
        for child in node:
            nodeName_ = Tag_pattern_.match(child.tag).groups()[-1]
            self.buildChildren(child, node, nodeName_)
    def buildAttributes(self, node, attrs, already_processed):
        pass
    def buildChildren(self, child_, node, nodeName_, fromsubclass_=False):
        if nodeName_ == 'ip-prefix':
            ip_prefix_ = child_.text
            ip_prefix_ = self.gds_validate_string(ip_prefix_, node, 'ip_prefix')
            self.ip_prefix = ip_prefix_
        elif nodeName_ == 'ip-prefix-len':
            sval_ = child_.text
            try:
                ival_ = int(sval_)
            except (TypeError, ValueError), exp:
                raise_parse_error(child_, 'requires integer: %s' % exp)
            ival_ = self.gds_validate_integer(ival_, node, 'ip_prefix_len')
            self.ip_prefix_len = ival_
# end class SubnetType


class UuidType(GeneratedsSuper):
    """
    UuidType class definition from :doc:`vnc_cfg.xsd`
    """
    subclass = None
    superclass = None
    def __init__(self, uuid_mslong=None, uuid_lslong=None, **kwargs):
        self.uuid_mslong = uuid_mslong
        self.uuid_lslong = uuid_lslong
    def factory(*args_, **kwargs_):
        if UuidType.subclass:
            return UuidType.subclass(*args_, **kwargs_)
        else:
            return UuidType(*args_, **kwargs_)
    factory = staticmethod(factory)
    def get_uuid_mslong(self): return self.uuid_mslong
    def set_uuid_mslong(self, uuid_mslong): self.uuid_mslong = uuid_mslong
    def get_uuid_lslong(self): return self.uuid_lslong
    def set_uuid_lslong(self, uuid_lslong): self.uuid_lslong = uuid_lslong
    @classmethod
    def populate (cls, *a, **kwa):
        obj = cls (*a, **kwa)
        obj.set_uuid_mslong (obj.populate_unsignedLong ("uuid_mslong"))
        obj.set_uuid_lslong (obj.populate_unsignedLong ("uuid_lslong"))
        return obj
    def export(self, outfile, level=1, namespace_='', name_='UuidType', namespacedef_='', pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        showIndent(outfile, level, pretty_print)
        outfile.write('<%s%s%s' % (namespace_, name_, namespacedef_ and ' ' + namespacedef_ or '', ))
        already_processed = []
        self.exportAttributes(outfile, level, already_processed, namespace_, name_='UuidType')
        if self.hasContent_():
            outfile.write('>%s' % (eol_, ))
            self.exportChildren(outfile, level + 1, namespace_, name_, pretty_print=pretty_print)
            showIndent(outfile, level, pretty_print)
            outfile.write('</%s%s>%s' % (namespace_, name_, eol_))
        else:
            outfile.write('/>%s' % (eol_, ))
    def exportAttributes(self, outfile, level, already_processed, namespace_='', name_='UuidType'):
        pass
    def exportChildren(self, outfile, level, namespace_='', name_='UuidType', fromsubclass_=False, pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        if self.uuid_mslong is not None:
            showIndent(outfile, level, pretty_print)
            outfile.write('<%suuid-mslong>%s</%suuid-mslong>%s' % (namespace_, self.gds_format_integer(self.uuid_mslong, input_name='uuid-mslong'), namespace_, eol_))
        if self.uuid_lslong is not None:
            showIndent(outfile, level, pretty_print)
            outfile.write('<%suuid-lslong>%s</%suuid-lslong>%s' % (namespace_, self.gds_format_integer(self.uuid_lslong, input_name='uuid-lslong'), namespace_, eol_))
    def hasContent_(self):
        if (
            self.uuid_mslong is not None or
            self.uuid_lslong is not None
            ):
            return True
        else:
            return False
    def exportLiteral(self, outfile, level, name_='UuidType'):
        level += 1
        self.exportLiteralAttributes(outfile, level, [], name_)
        if self.hasContent_():
            self.exportLiteralChildren(outfile, level, name_)
    def exportLiteralAttributes(self, outfile, level, already_processed, name_):
        pass
    def exportLiteralChildren(self, outfile, level, name_):
        if self.uuid_mslong is not None:
            showIndent(outfile, level)
            outfile.write('uuid_mslong=%d,\n' % self.uuid_mslong)
        if self.uuid_lslong is not None:
            showIndent(outfile, level)
            outfile.write('uuid_lslong=%d,\n' % self.uuid_lslong)
    def exportDict(self, name_='UuidType'):
        obj_json = json.dumps(self, default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        obj_dict = json.loads(obj_json)
        return {name_: obj_dict}
    def build(self, node):
        self.buildAttributes(node, node.attrib, [])
        for child in node:
            nodeName_ = Tag_pattern_.match(child.tag).groups()[-1]
            self.buildChildren(child, node, nodeName_)
    def buildAttributes(self, node, attrs, already_processed):
        pass
    def buildChildren(self, child_, node, nodeName_, fromsubclass_=False):
        if nodeName_ == 'uuid-mslong':
            sval_ = child_.text
            try:
                ival_ = int(sval_)
            except (TypeError, ValueError), exp:
                raise_parse_error(child_, 'requires integer: %s' % exp)
            ival_ = self.gds_validate_integer(ival_, node, 'uuid_mslong')
            self.uuid_mslong = ival_
        elif nodeName_ == 'uuid-lslong':
            sval_ = child_.text
            try:
                ival_ = int(sval_)
            except (TypeError, ValueError), exp:
                raise_parse_error(child_, 'requires integer: %s' % exp)
            ival_ = self.gds_validate_integer(ival_, node, 'uuid_lslong')
            self.uuid_lslong = ival_
# end class UuidType


class SequenceType(GeneratedsSuper):
    """
    SequenceType class definition from :doc:`vnc_cfg.xsd`
    """
    subclass = None
    superclass = None
    def __init__(self, major=None, minor=None, **kwargs):
        self.major = major
        self.minor = minor
    def factory(*args_, **kwargs_):
        if SequenceType.subclass:
            return SequenceType.subclass(*args_, **kwargs_)
        else:
            return SequenceType(*args_, **kwargs_)
    factory = staticmethod(factory)
    def get_major(self): return self.major
    def set_major(self, major): self.major = major
    def get_minor(self): return self.minor
    def set_minor(self, minor): self.minor = minor
    @classmethod
    def populate (cls, *a, **kwa):
        obj = cls (*a, **kwa)
        obj.set_major (obj.populate_integer ("major"))
        obj.set_minor (obj.populate_integer ("minor"))
        return obj
    def export(self, outfile, level=1, namespace_='', name_='SequenceType', namespacedef_='', pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        showIndent(outfile, level, pretty_print)
        outfile.write('<%s%s%s' % (namespace_, name_, namespacedef_ and ' ' + namespacedef_ or '', ))
        already_processed = []
        self.exportAttributes(outfile, level, already_processed, namespace_, name_='SequenceType')
        if self.hasContent_():
            outfile.write('>%s' % (eol_, ))
            self.exportChildren(outfile, level + 1, namespace_, name_, pretty_print=pretty_print)
            showIndent(outfile, level, pretty_print)
            outfile.write('</%s%s>%s' % (namespace_, name_, eol_))
        else:
            outfile.write('/>%s' % (eol_, ))
    def exportAttributes(self, outfile, level, already_processed, namespace_='', name_='SequenceType'):
        pass
    def exportChildren(self, outfile, level, namespace_='', name_='SequenceType', fromsubclass_=False, pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        if self.major is not None:
            showIndent(outfile, level, pretty_print)
            outfile.write('<%smajor>%s</%smajor>%s' % (namespace_, self.gds_format_integer(self.major, input_name='major'), namespace_, eol_))
        if self.minor is not None:
            showIndent(outfile, level, pretty_print)
            outfile.write('<%sminor>%s</%sminor>%s' % (namespace_, self.gds_format_integer(self.minor, input_name='minor'), namespace_, eol_))
    def hasContent_(self):
        if (
            self.major is not None or
            self.minor is not None
            ):
            return True
        else:
            return False
    def exportLiteral(self, outfile, level, name_='SequenceType'):
        level += 1
        self.exportLiteralAttributes(outfile, level, [], name_)
        if self.hasContent_():
            self.exportLiteralChildren(outfile, level, name_)
    def exportLiteralAttributes(self, outfile, level, already_processed, name_):
        pass
    def exportLiteralChildren(self, outfile, level, name_):
        if self.major is not None:
            showIndent(outfile, level)
            outfile.write('major=%d,\n' % self.major)
        if self.minor is not None:
            showIndent(outfile, level)
            outfile.write('minor=%d,\n' % self.minor)
    def exportDict(self, name_='SequenceType'):
        obj_json = json.dumps(self, default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        obj_dict = json.loads(obj_json)
        return {name_: obj_dict}
    def build(self, node):
        self.buildAttributes(node, node.attrib, [])
        for child in node:
            nodeName_ = Tag_pattern_.match(child.tag).groups()[-1]
            self.buildChildren(child, node, nodeName_)
    def buildAttributes(self, node, attrs, already_processed):
        pass
    def buildChildren(self, child_, node, nodeName_, fromsubclass_=False):
        if nodeName_ == 'major':
            sval_ = child_.text
            try:
                ival_ = int(sval_)
            except (TypeError, ValueError), exp:
                raise_parse_error(child_, 'requires integer: %s' % exp)
            ival_ = self.gds_validate_integer(ival_, node, 'major')
            self.major = ival_
        elif nodeName_ == 'minor':
            sval_ = child_.text
            try:
                ival_ = int(sval_)
            except (TypeError, ValueError), exp:
                raise_parse_error(child_, 'requires integer: %s' % exp)
            ival_ = self.gds_validate_integer(ival_, node, 'minor')
            self.minor = ival_
# end class SequenceType


class TimerType(GeneratedsSuper):
    """
    TimerType class definition from :doc:`vnc_cfg.xsd`
    """
    subclass = None
    superclass = None
    def __init__(self, start_time=None, on_interval=None, off_interval=None, end_time=None, **kwargs):
        self.start_time = start_time
        self.on_interval = on_interval
        self.off_interval = off_interval
        self.end_time = end_time
    def factory(*args_, **kwargs_):
        if TimerType.subclass:
            return TimerType.subclass(*args_, **kwargs_)
        else:
            return TimerType(*args_, **kwargs_)
    factory = staticmethod(factory)
    def get_start_time(self): return self.start_time
    def set_start_time(self, start_time): self.start_time = start_time
    def get_on_interval(self): return self.on_interval
    def set_on_interval(self, on_interval): self.on_interval = on_interval
    def get_off_interval(self): return self.off_interval
    def set_off_interval(self, off_interval): self.off_interval = off_interval
    def get_end_time(self): return self.end_time
    def set_end_time(self, end_time): self.end_time = end_time
    @classmethod
    def populate (cls, *a, **kwa):
        obj = cls (*a, **kwa)
        obj.set_start_time (obj.populate_dateTime ("start_time"))
        obj.set_on_interval (obj.populate_time ("on_interval"))
        obj.set_off_interval (obj.populate_time ("off_interval"))
        obj.set_end_time (obj.populate_dateTime ("end_time"))
        return obj
    def export(self, outfile, level=1, namespace_='', name_='TimerType', namespacedef_='', pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        showIndent(outfile, level, pretty_print)
        outfile.write('<%s%s%s' % (namespace_, name_, namespacedef_ and ' ' + namespacedef_ or '', ))
        already_processed = []
        self.exportAttributes(outfile, level, already_processed, namespace_, name_='TimerType')
        if self.hasContent_():
            outfile.write('>%s' % (eol_, ))
            self.exportChildren(outfile, level + 1, namespace_, name_, pretty_print=pretty_print)
            showIndent(outfile, level, pretty_print)
            outfile.write('</%s%s>%s' % (namespace_, name_, eol_))
        else:
            outfile.write('/>%s' % (eol_, ))
    def exportAttributes(self, outfile, level, already_processed, namespace_='', name_='TimerType'):
        pass
    def exportChildren(self, outfile, level, namespace_='', name_='TimerType', fromsubclass_=False, pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        if self.start_time is not None:
            showIndent(outfile, level, pretty_print)
            outfile.write('<%sstart-time>%s</%sstart-time>%s' % (namespace_, self.gds_format_string(quote_xml(self.start_time).encode(ExternalEncoding), input_name='start-time'), namespace_, eol_))
        if self.on_interval is not None:
            showIndent(outfile, level, pretty_print)
            outfile.write('<%son-interval>%s</%son-interval>%s' % (namespace_, self.gds_format_string(quote_xml(self.on_interval).encode(ExternalEncoding), input_name='on-interval'), namespace_, eol_))
        if self.off_interval is not None:
            showIndent(outfile, level, pretty_print)
            outfile.write('<%soff-interval>%s</%soff-interval>%s' % (namespace_, self.gds_format_string(quote_xml(self.off_interval).encode(ExternalEncoding), input_name='off-interval'), namespace_, eol_))
        if self.end_time is not None:
            showIndent(outfile, level, pretty_print)
            outfile.write('<%send-time>%s</%send-time>%s' % (namespace_, self.gds_format_string(quote_xml(self.end_time).encode(ExternalEncoding), input_name='end-time'), namespace_, eol_))
    def hasContent_(self):
        if (
            self.start_time is not None or
            self.on_interval is not None or
            self.off_interval is not None or
            self.end_time is not None
            ):
            return True
        else:
            return False
    def exportLiteral(self, outfile, level, name_='TimerType'):
        level += 1
        self.exportLiteralAttributes(outfile, level, [], name_)
        if self.hasContent_():
            self.exportLiteralChildren(outfile, level, name_)
    def exportLiteralAttributes(self, outfile, level, already_processed, name_):
        pass
    def exportLiteralChildren(self, outfile, level, name_):
        if self.start_time is not None:
            showIndent(outfile, level)
            outfile.write('start_time=%s,\n' % quote_python(self.start_time).encode(ExternalEncoding))
        if self.on_interval is not None:
            showIndent(outfile, level)
            outfile.write('on_interval=%s,\n' % quote_python(self.on_interval).encode(ExternalEncoding))
        if self.off_interval is not None:
            showIndent(outfile, level)
            outfile.write('off_interval=%s,\n' % quote_python(self.off_interval).encode(ExternalEncoding))
        if self.end_time is not None:
            showIndent(outfile, level)
            outfile.write('end_time=%s,\n' % quote_python(self.end_time).encode(ExternalEncoding))
    def exportDict(self, name_='TimerType'):
        obj_json = json.dumps(self, default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        obj_dict = json.loads(obj_json)
        return {name_: obj_dict}
    def build(self, node):
        self.buildAttributes(node, node.attrib, [])
        for child in node:
            nodeName_ = Tag_pattern_.match(child.tag).groups()[-1]
            self.buildChildren(child, node, nodeName_)
    def buildAttributes(self, node, attrs, already_processed):
        pass
    def buildChildren(self, child_, node, nodeName_, fromsubclass_=False):
        if nodeName_ == 'start-time':
            start_time_ = child_.text
            start_time_ = self.gds_validate_string(start_time_, node, 'start_time')
            self.start_time = start_time_
        elif nodeName_ == 'on-interval':
            on_interval_ = child_.text
            on_interval_ = self.gds_validate_string(on_interval_, node, 'on_interval')
            self.on_interval = on_interval_
        elif nodeName_ == 'off-interval':
            off_interval_ = child_.text
            off_interval_ = self.gds_validate_string(off_interval_, node, 'off_interval')
            self.off_interval = off_interval_
        elif nodeName_ == 'end-time':
            end_time_ = child_.text
            end_time_ = self.gds_validate_string(end_time_, node, 'end_time')
            self.end_time = end_time_
# end class TimerType


class VirtualNetworkPolicyType(GeneratedsSuper):
    """
    VirtualNetworkPolicyType class definition from :doc:`vnc_cfg.xsd`
    """
    subclass = None
    superclass = None
    def __init__(self, sequence=None, timer=None, **kwargs):
        if isinstance(sequence, dict):
            obj = SequenceType(**sequence)
            self.sequence = obj
        else:
            self.sequence = sequence
        if isinstance(timer, dict):
            obj = TimerType(**timer)
            self.timer = obj
        else:
            self.timer = timer
    def factory(*args_, **kwargs_):
        if VirtualNetworkPolicyType.subclass:
            return VirtualNetworkPolicyType.subclass(*args_, **kwargs_)
        else:
            return VirtualNetworkPolicyType(*args_, **kwargs_)
    factory = staticmethod(factory)
    def get_sequence(self): return self.sequence
    def set_sequence(self, sequence): self.sequence = sequence
    def get_timer(self): return self.timer
    def set_timer(self, timer): self.timer = timer
    @classmethod
    def populate (cls, *a, **kwa):
        obj = cls (*a, **kwa)
        obj.set_sequence (SequenceType.populate ())
        obj.set_timer (TimerType.populate ())
        return obj
    def export(self, outfile, level=1, namespace_='', name_='VirtualNetworkPolicyType', namespacedef_='', pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        showIndent(outfile, level, pretty_print)
        outfile.write('<%s%s%s' % (namespace_, name_, namespacedef_ and ' ' + namespacedef_ or '', ))
        already_processed = []
        self.exportAttributes(outfile, level, already_processed, namespace_, name_='VirtualNetworkPolicyType')
        if self.hasContent_():
            outfile.write('>%s' % (eol_, ))
            self.exportChildren(outfile, level + 1, namespace_, name_, pretty_print=pretty_print)
            showIndent(outfile, level, pretty_print)
            outfile.write('</%s%s>%s' % (namespace_, name_, eol_))
        else:
            outfile.write('/>%s' % (eol_, ))
    def exportAttributes(self, outfile, level, already_processed, namespace_='', name_='VirtualNetworkPolicyType'):
        pass
    def exportChildren(self, outfile, level, namespace_='', name_='VirtualNetworkPolicyType', fromsubclass_=False, pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        if self.sequence is not None:
            self.sequence.export(outfile, level, namespace_, name_='sequence', pretty_print=pretty_print)
        if self.timer is not None:
            self.timer.export(outfile, level, namespace_, name_='timer', pretty_print=pretty_print)
    def hasContent_(self):
        if (
            self.sequence is not None or
            self.timer is not None
            ):
            return True
        else:
            return False
    def exportLiteral(self, outfile, level, name_='VirtualNetworkPolicyType'):
        level += 1
        self.exportLiteralAttributes(outfile, level, [], name_)
        if self.hasContent_():
            self.exportLiteralChildren(outfile, level, name_)
    def exportLiteralAttributes(self, outfile, level, already_processed, name_):
        pass
    def exportLiteralChildren(self, outfile, level, name_):
        if self.sequence is not None:
            showIndent(outfile, level)
            outfile.write('sequence=model_.SequenceType(\n')
            self.sequence.exportLiteral(outfile, level, name_='sequence')
            showIndent(outfile, level)
            outfile.write('),\n')
        if self.timer is not None:
            showIndent(outfile, level)
            outfile.write('timer=model_.TimerType(\n')
            self.timer.exportLiteral(outfile, level, name_='timer')
            showIndent(outfile, level)
            outfile.write('),\n')
    def exportDict(self, name_='VirtualNetworkPolicyType'):
        obj_json = json.dumps(self, default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        obj_dict = json.loads(obj_json)
        return {name_: obj_dict}
    def build(self, node):
        self.buildAttributes(node, node.attrib, [])
        for child in node:
            nodeName_ = Tag_pattern_.match(child.tag).groups()[-1]
            self.buildChildren(child, node, nodeName_)
    def buildAttributes(self, node, attrs, already_processed):
        pass
    def buildChildren(self, child_, node, nodeName_, fromsubclass_=False):
        if nodeName_ == 'sequence':
            obj_ = SequenceType.factory()
            obj_.build(child_)
            self.set_sequence(obj_)
        elif nodeName_ == 'timer':
            obj_ = TimerType.factory()
            obj_.build(child_)
            self.set_timer(obj_)
# end class VirtualNetworkPolicyType


class AddressType(GeneratedsSuper):
    """
    AddressType class definition from :doc:`vnc_cfg.xsd`
    """
    subclass = None
    superclass = None
    def __init__(self, subnet=None, virtual_network=None, security_group=None, **kwargs):
        if isinstance(subnet, dict):
            obj = SubnetType(**subnet)
            self.subnet = obj
        else:
            self.subnet = subnet
        self.virtual_network = virtual_network
        self.security_group = security_group
    def factory(*args_, **kwargs_):
        if AddressType.subclass:
            return AddressType.subclass(*args_, **kwargs_)
        else:
            return AddressType(*args_, **kwargs_)
    factory = staticmethod(factory)
    def get_subnet(self): return self.subnet
    def set_subnet(self, subnet): self.subnet = subnet
    def get_virtual_network(self): return self.virtual_network
    def set_virtual_network(self, virtual_network): self.virtual_network = virtual_network
    def get_security_group(self): return self.security_group
    def set_security_group(self, security_group): self.security_group = security_group
    @classmethod
    def populate (cls, *a, **kwa):
        obj = cls (*a, **kwa)
        obj.set_subnet (SubnetType.populate ())
        obj.set_virtual_network (obj.populate_string ("virtual_network"))
        obj.set_security_group (obj.populate_string ("security_group"))
        return obj
    def export(self, outfile, level=1, namespace_='', name_='AddressType', namespacedef_='', pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        showIndent(outfile, level, pretty_print)
        outfile.write('<%s%s%s' % (namespace_, name_, namespacedef_ and ' ' + namespacedef_ or '', ))
        already_processed = []
        self.exportAttributes(outfile, level, already_processed, namespace_, name_='AddressType')
        if self.hasContent_():
            outfile.write('>%s' % (eol_, ))
            self.exportChildren(outfile, level + 1, namespace_, name_, pretty_print=pretty_print)
            showIndent(outfile, level, pretty_print)
            outfile.write('</%s%s>%s' % (namespace_, name_, eol_))
        else:
            outfile.write('/>%s' % (eol_, ))
    def exportAttributes(self, outfile, level, already_processed, namespace_='', name_='AddressType'):
        pass
    def exportChildren(self, outfile, level, namespace_='', name_='AddressType', fromsubclass_=False, pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        if self.subnet is not None:
            self.subnet.export(outfile, level, namespace_, name_='subnet', pretty_print=pretty_print)
        if self.virtual_network is not None:
            showIndent(outfile, level, pretty_print)
            outfile.write('<%svirtual-network>%s</%svirtual-network>%s' % (namespace_, self.gds_format_string(quote_xml(self.virtual_network).encode(ExternalEncoding), input_name='virtual-network'), namespace_, eol_))
        if self.security_group is not None:
            showIndent(outfile, level, pretty_print)
            outfile.write('<%ssecurity-group>%s</%ssecurity-group>%s' % (namespace_, self.gds_format_string(quote_xml(self.security_group).encode(ExternalEncoding), input_name='security-group'), namespace_, eol_))
    def hasContent_(self):
        if (
            self.subnet is not None or
            self.virtual_network is not None or
            self.security_group is not None
            ):
            return True
        else:
            return False
    def exportLiteral(self, outfile, level, name_='AddressType'):
        level += 1
        self.exportLiteralAttributes(outfile, level, [], name_)
        if self.hasContent_():
            self.exportLiteralChildren(outfile, level, name_)
    def exportLiteralAttributes(self, outfile, level, already_processed, name_):
        pass
    def exportLiteralChildren(self, outfile, level, name_):
        if self.subnet is not None:
            showIndent(outfile, level)
            outfile.write('subnet=model_.SubnetType(\n')
            self.subnet.exportLiteral(outfile, level, name_='subnet')
            showIndent(outfile, level)
            outfile.write('),\n')
        if self.virtual_network is not None:
            showIndent(outfile, level)
            outfile.write('virtual_network=%s,\n' % quote_python(self.virtual_network).encode(ExternalEncoding))
        if self.security_group is not None:
            showIndent(outfile, level)
            outfile.write('security_group=%s,\n' % quote_python(self.security_group).encode(ExternalEncoding))
    def exportDict(self, name_='AddressType'):
        obj_json = json.dumps(self, default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        obj_dict = json.loads(obj_json)
        return {name_: obj_dict}
    def build(self, node):
        self.buildAttributes(node, node.attrib, [])
        for child in node:
            nodeName_ = Tag_pattern_.match(child.tag).groups()[-1]
            self.buildChildren(child, node, nodeName_)
    def buildAttributes(self, node, attrs, already_processed):
        pass
    def buildChildren(self, child_, node, nodeName_, fromsubclass_=False):
        if nodeName_ == 'subnet':
            obj_ = SubnetType.factory()
            obj_.build(child_)
            self.set_subnet(obj_)
        elif nodeName_ == 'virtual-network':
            virtual_network_ = child_.text
            virtual_network_ = self.gds_validate_string(virtual_network_, node, 'virtual_network')
            self.virtual_network = virtual_network_
        elif nodeName_ == 'security-group':
            security_group_ = child_.text
            security_group_ = self.gds_validate_string(security_group_, node, 'security_group')
            self.security_group = security_group_
# end class AddressType


class PortType(GeneratedsSuper):
    """
    PortType class definition from :doc:`vnc_cfg.xsd`
    """
    subclass = None
    superclass = None
    def __init__(self, start_port=None, end_port=None, **kwargs):
        self.start_port = start_port
        self.end_port = end_port
    def factory(*args_, **kwargs_):
        if PortType.subclass:
            return PortType.subclass(*args_, **kwargs_)
        else:
            return PortType(*args_, **kwargs_)
    factory = staticmethod(factory)
    def get_start_port(self): return self.start_port
    def set_start_port(self, start_port): self.start_port = start_port
    def get_end_port(self): return self.end_port
    def set_end_port(self, end_port): self.end_port = end_port
    @classmethod
    def populate (cls, *a, **kwa):
        obj = cls (*a, **kwa)
        obj.set_start_port (obj.populate_integer ("start_port"))
        obj.set_end_port (obj.populate_integer ("end_port"))
        return obj
    def export(self, outfile, level=1, namespace_='', name_='PortType', namespacedef_='', pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        showIndent(outfile, level, pretty_print)
        outfile.write('<%s%s%s' % (namespace_, name_, namespacedef_ and ' ' + namespacedef_ or '', ))
        already_processed = []
        self.exportAttributes(outfile, level, already_processed, namespace_, name_='PortType')
        if self.hasContent_():
            outfile.write('>%s' % (eol_, ))
            self.exportChildren(outfile, level + 1, namespace_, name_, pretty_print=pretty_print)
            showIndent(outfile, level, pretty_print)
            outfile.write('</%s%s>%s' % (namespace_, name_, eol_))
        else:
            outfile.write('/>%s' % (eol_, ))
    def exportAttributes(self, outfile, level, already_processed, namespace_='', name_='PortType'):
        pass
    def exportChildren(self, outfile, level, namespace_='', name_='PortType', fromsubclass_=False, pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        if self.start_port is not None:
            showIndent(outfile, level, pretty_print)
            outfile.write('<%sstart-port>%s</%sstart-port>%s' % (namespace_, self.gds_format_integer(self.start_port, input_name='start-port'), namespace_, eol_))
        if self.end_port is not None:
            showIndent(outfile, level, pretty_print)
            outfile.write('<%send-port>%s</%send-port>%s' % (namespace_, self.gds_format_integer(self.end_port, input_name='end-port'), namespace_, eol_))
    def hasContent_(self):
        if (
            self.start_port is not None or
            self.end_port is not None
            ):
            return True
        else:
            return False
    def exportLiteral(self, outfile, level, name_='PortType'):
        level += 1
        self.exportLiteralAttributes(outfile, level, [], name_)
        if self.hasContent_():
            self.exportLiteralChildren(outfile, level, name_)
    def exportLiteralAttributes(self, outfile, level, already_processed, name_):
        pass
    def exportLiteralChildren(self, outfile, level, name_):
        if self.start_port is not None:
            showIndent(outfile, level)
            outfile.write('start_port=%d,\n' % self.start_port)
        if self.end_port is not None:
            showIndent(outfile, level)
            outfile.write('end_port=%d,\n' % self.end_port)
    def exportDict(self, name_='PortType'):
        obj_json = json.dumps(self, default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        obj_dict = json.loads(obj_json)
        return {name_: obj_dict}
    def build(self, node):
        self.buildAttributes(node, node.attrib, [])
        for child in node:
            nodeName_ = Tag_pattern_.match(child.tag).groups()[-1]
            self.buildChildren(child, node, nodeName_)
    def buildAttributes(self, node, attrs, already_processed):
        pass
    def buildChildren(self, child_, node, nodeName_, fromsubclass_=False):
        if nodeName_ == 'start-port':
            sval_ = child_.text
            try:
                ival_ = int(sval_)
            except (TypeError, ValueError), exp:
                raise_parse_error(child_, 'requires integer: %s' % exp)
            ival_ = self.gds_validate_integer(ival_, node, 'start_port')
            self.start_port = ival_
        elif nodeName_ == 'end-port':
            sval_ = child_.text
            try:
                ival_ = int(sval_)
            except (TypeError, ValueError), exp:
                raise_parse_error(child_, 'requires integer: %s' % exp)
            ival_ = self.gds_validate_integer(ival_, node, 'end_port')
            self.end_port = ival_
# end class PortType


class MatchConditionType(GeneratedsSuper):
    """
    MatchConditionType class definition from :doc:`vnc_cfg.xsd`
    """
    subclass = None
    superclass = None
    def __init__(self, protocol=None, src_address=None, src_port=None, dst_address=None, dst_port=None, **kwargs):
        self.protocol = protocol
        if isinstance(src_address, dict):
            obj = AddressType(**src_address)
            self.src_address = obj
        else:
            self.src_address = src_address
        if isinstance(src_port, dict):
            obj = PortType(**src_port)
            self.src_port = obj
        else:
            self.src_port = src_port
        if isinstance(dst_address, dict):
            obj = AddressType(**dst_address)
            self.dst_address = obj
        else:
            self.dst_address = dst_address
        if isinstance(dst_port, dict):
            obj = PortType(**dst_port)
            self.dst_port = obj
        else:
            self.dst_port = dst_port
    def factory(*args_, **kwargs_):
        if MatchConditionType.subclass:
            return MatchConditionType.subclass(*args_, **kwargs_)
        else:
            return MatchConditionType(*args_, **kwargs_)
    factory = staticmethod(factory)
    def get_protocol(self): return self.protocol
    def set_protocol(self, protocol): self.protocol = protocol
    def validate_ProtocolType(self, value):
        # Validate type ProtocolType, a restriction on xsd:string.
        pass
    def get_src_address(self): return self.src_address
    def set_src_address(self, src_address): self.src_address = src_address
    def get_src_port(self): return self.src_port
    def set_src_port(self, src_port): self.src_port = src_port
    def get_dst_address(self): return self.dst_address
    def set_dst_address(self, dst_address): self.dst_address = dst_address
    def get_dst_port(self): return self.dst_port
    def set_dst_port(self, dst_port): self.dst_port = dst_port
    @classmethod
    def populate (cls, *a, **kwa):
        obj = cls (*a, **kwa)
        obj.set_protocol (obj.populate_string ("protocol"))
        obj.set_src_address (AddressType.populate ())
        obj.set_src_port (PortType.populate ())
        obj.set_dst_address (AddressType.populate ())
        obj.set_dst_port (PortType.populate ())
        return obj
    def export(self, outfile, level=1, namespace_='', name_='MatchConditionType', namespacedef_='', pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        showIndent(outfile, level, pretty_print)
        outfile.write('<%s%s%s' % (namespace_, name_, namespacedef_ and ' ' + namespacedef_ or '', ))
        already_processed = []
        self.exportAttributes(outfile, level, already_processed, namespace_, name_='MatchConditionType')
        if self.hasContent_():
            outfile.write('>%s' % (eol_, ))
            self.exportChildren(outfile, level + 1, namespace_, name_, pretty_print=pretty_print)
            showIndent(outfile, level, pretty_print)
            outfile.write('</%s%s>%s' % (namespace_, name_, eol_))
        else:
            outfile.write('/>%s' % (eol_, ))
    def exportAttributes(self, outfile, level, already_processed, namespace_='', name_='MatchConditionType'):
        pass
    def exportChildren(self, outfile, level, namespace_='', name_='MatchConditionType', fromsubclass_=False, pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        if self.protocol is not None:
            showIndent(outfile, level, pretty_print)
            outfile.write('<%sprotocol>%s</%sprotocol>%s' % (namespace_, self.gds_format_string(quote_xml(self.protocol).encode(ExternalEncoding), input_name='protocol'), namespace_, eol_))
        if self.src_address is not None:
            self.src_address.export(outfile, level, namespace_, name_='src-address', pretty_print=pretty_print)
        if self.src_port is not None:
            self.src_port.export(outfile, level, namespace_, name_='src-port', pretty_print=pretty_print)
        if self.dst_address is not None:
            self.dst_address.export(outfile, level, namespace_, name_='dst-address', pretty_print=pretty_print)
        if self.dst_port is not None:
            self.dst_port.export(outfile, level, namespace_, name_='dst-port', pretty_print=pretty_print)
    def hasContent_(self):
        if (
            self.protocol is not None or
            self.src_address is not None or
            self.src_port is not None or
            self.dst_address is not None or
            self.dst_port is not None
            ):
            return True
        else:
            return False
    def exportLiteral(self, outfile, level, name_='MatchConditionType'):
        level += 1
        self.exportLiteralAttributes(outfile, level, [], name_)
        if self.hasContent_():
            self.exportLiteralChildren(outfile, level, name_)
    def exportLiteralAttributes(self, outfile, level, already_processed, name_):
        pass
    def exportLiteralChildren(self, outfile, level, name_):
        if self.protocol is not None:
            showIndent(outfile, level)
            outfile.write('protocol=%s,\n' % quote_python(self.protocol).encode(ExternalEncoding))
        if self.src_address is not None:
            showIndent(outfile, level)
            outfile.write('src_address=model_.AddressType(\n')
            self.src_address.exportLiteral(outfile, level, name_='src_address')
            showIndent(outfile, level)
            outfile.write('),\n')
        if self.src_port is not None:
            showIndent(outfile, level)
            outfile.write('src_port=model_.PortType(\n')
            self.src_port.exportLiteral(outfile, level, name_='src_port')
            showIndent(outfile, level)
            outfile.write('),\n')
        if self.dst_address is not None:
            showIndent(outfile, level)
            outfile.write('dst_address=model_.AddressType(\n')
            self.dst_address.exportLiteral(outfile, level, name_='dst_address')
            showIndent(outfile, level)
            outfile.write('),\n')
        if self.dst_port is not None:
            showIndent(outfile, level)
            outfile.write('dst_port=model_.PortType(\n')
            self.dst_port.exportLiteral(outfile, level, name_='dst_port')
            showIndent(outfile, level)
            outfile.write('),\n')
    def exportDict(self, name_='MatchConditionType'):
        obj_json = json.dumps(self, default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        obj_dict = json.loads(obj_json)
        return {name_: obj_dict}
    def build(self, node):
        self.buildAttributes(node, node.attrib, [])
        for child in node:
            nodeName_ = Tag_pattern_.match(child.tag).groups()[-1]
            self.buildChildren(child, node, nodeName_)
    def buildAttributes(self, node, attrs, already_processed):
        pass
    def buildChildren(self, child_, node, nodeName_, fromsubclass_=False):
        if nodeName_ == 'protocol':
            protocol_ = child_.text
            protocol_ = self.gds_validate_string(protocol_, node, 'protocol')
            self.protocol = protocol_
            self.validate_ProtocolType(self.protocol)    # validate type ProtocolType
        elif nodeName_ == 'src-address':
            obj_ = AddressType.factory()
            obj_.build(child_)
            self.set_src_address(obj_)
        elif nodeName_ == 'src-port':
            obj_ = PortType.factory()
            obj_.build(child_)
            self.set_src_port(obj_)
        elif nodeName_ == 'dst-address':
            obj_ = AddressType.factory()
            obj_.build(child_)
            self.set_dst_address(obj_)
        elif nodeName_ == 'dst-port':
            obj_ = PortType.factory()
            obj_.build(child_)
            self.set_dst_port(obj_)
# end class MatchConditionType


class MirrorActionType(GeneratedsSuper):
    """
    MirrorActionType class definition from :doc:`vnc_cfg.xsd`
    """
    subclass = None
    superclass = None
    def __init__(self, analyzer_name=None, encapsulation=None, analyzer_ip_address=None, routing_instance=None, udp_port=None, **kwargs):
        self.analyzer_name = analyzer_name
        self.encapsulation = encapsulation
        self.analyzer_ip_address = analyzer_ip_address
        self.routing_instance = routing_instance
        self.udp_port = udp_port
    def factory(*args_, **kwargs_):
        if MirrorActionType.subclass:
            return MirrorActionType.subclass(*args_, **kwargs_)
        else:
            return MirrorActionType(*args_, **kwargs_)
    factory = staticmethod(factory)
    def get_analyzer_name(self): return self.analyzer_name
    def set_analyzer_name(self, analyzer_name): self.analyzer_name = analyzer_name
    def get_encapsulation(self): return self.encapsulation
    def set_encapsulation(self, encapsulation): self.encapsulation = encapsulation
    def get_analyzer_ip_address(self): return self.analyzer_ip_address
    def set_analyzer_ip_address(self, analyzer_ip_address): self.analyzer_ip_address = analyzer_ip_address
    def validate_IpAddress(self, value):
        # Validate type IpAddress, a restriction on xsd:string.
        pass
    def get_routing_instance(self): return self.routing_instance
    def set_routing_instance(self, routing_instance): self.routing_instance = routing_instance
    def get_udp_port(self): return self.udp_port
    def set_udp_port(self, udp_port): self.udp_port = udp_port
    @classmethod
    def populate (cls, *a, **kwa):
        obj = cls (*a, **kwa)
        obj.set_analyzer_name (obj.populate_string ("analyzer_name"))
        obj.set_encapsulation (obj.populate_string ("encapsulation"))
        obj.set_analyzer_ip_address (obj.populate_string ("analyzer_ip_address"))
        obj.set_routing_instance (obj.populate_string ("routing_instance"))
        obj.set_udp_port (obj.populate_integer ("udp_port"))
        return obj
    def export(self, outfile, level=1, namespace_='', name_='MirrorActionType', namespacedef_='', pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        showIndent(outfile, level, pretty_print)
        outfile.write('<%s%s%s' % (namespace_, name_, namespacedef_ and ' ' + namespacedef_ or '', ))
        already_processed = []
        self.exportAttributes(outfile, level, already_processed, namespace_, name_='MirrorActionType')
        if self.hasContent_():
            outfile.write('>%s' % (eol_, ))
            self.exportChildren(outfile, level + 1, namespace_, name_, pretty_print=pretty_print)
            showIndent(outfile, level, pretty_print)
            outfile.write('</%s%s>%s' % (namespace_, name_, eol_))
        else:
            outfile.write('/>%s' % (eol_, ))
    def exportAttributes(self, outfile, level, already_processed, namespace_='', name_='MirrorActionType'):
        pass
    def exportChildren(self, outfile, level, namespace_='', name_='MirrorActionType', fromsubclass_=False, pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        if self.analyzer_name is not None:
            showIndent(outfile, level, pretty_print)
            outfile.write('<%sanalyzer-name>%s</%sanalyzer-name>%s' % (namespace_, self.gds_format_string(quote_xml(self.analyzer_name).encode(ExternalEncoding), input_name='analyzer-name'), namespace_, eol_))
        if self.encapsulation is not None:
            showIndent(outfile, level, pretty_print)
            outfile.write('<%sencapsulation>%s</%sencapsulation>%s' % (namespace_, self.gds_format_string(quote_xml(self.encapsulation).encode(ExternalEncoding), input_name='encapsulation'), namespace_, eol_))
        if self.analyzer_ip_address is not None:
            showIndent(outfile, level, pretty_print)
            outfile.write('<%sanalyzer-ip-address>%s</%sanalyzer-ip-address>%s' % (namespace_, self.gds_format_string(quote_xml(self.analyzer_ip_address).encode(ExternalEncoding), input_name='analyzer-ip-address'), namespace_, eol_))
        if self.routing_instance is not None:
            showIndent(outfile, level, pretty_print)
            outfile.write('<%srouting-instance>%s</%srouting-instance>%s' % (namespace_, self.gds_format_string(quote_xml(self.routing_instance).encode(ExternalEncoding), input_name='routing-instance'), namespace_, eol_))
        if self.udp_port is not None:
            showIndent(outfile, level, pretty_print)
            outfile.write('<%sudp-port>%s</%sudp-port>%s' % (namespace_, self.gds_format_integer(self.udp_port, input_name='udp-port'), namespace_, eol_))
    def hasContent_(self):
        if (
            self.analyzer_name is not None or
            self.encapsulation is not None or
            self.analyzer_ip_address is not None or
            self.routing_instance is not None or
            self.udp_port is not None
            ):
            return True
        else:
            return False
    def exportLiteral(self, outfile, level, name_='MirrorActionType'):
        level += 1
        self.exportLiteralAttributes(outfile, level, [], name_)
        if self.hasContent_():
            self.exportLiteralChildren(outfile, level, name_)
    def exportLiteralAttributes(self, outfile, level, already_processed, name_):
        pass
    def exportLiteralChildren(self, outfile, level, name_):
        if self.analyzer_name is not None:
            showIndent(outfile, level)
            outfile.write('analyzer_name=%s,\n' % quote_python(self.analyzer_name).encode(ExternalEncoding))
        if self.encapsulation is not None:
            showIndent(outfile, level)
            outfile.write('encapsulation=%s,\n' % quote_python(self.encapsulation).encode(ExternalEncoding))
        if self.analyzer_ip_address is not None:
            showIndent(outfile, level)
            outfile.write('analyzer_ip_address=%s,\n' % quote_python(self.analyzer_ip_address).encode(ExternalEncoding))
        if self.routing_instance is not None:
            showIndent(outfile, level)
            outfile.write('routing_instance=%s,\n' % quote_python(self.routing_instance).encode(ExternalEncoding))
        if self.udp_port is not None:
            showIndent(outfile, level)
            outfile.write('udp_port=%d,\n' % self.udp_port)
    def exportDict(self, name_='MirrorActionType'):
        obj_json = json.dumps(self, default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        obj_dict = json.loads(obj_json)
        return {name_: obj_dict}
    def build(self, node):
        self.buildAttributes(node, node.attrib, [])
        for child in node:
            nodeName_ = Tag_pattern_.match(child.tag).groups()[-1]
            self.buildChildren(child, node, nodeName_)
    def buildAttributes(self, node, attrs, already_processed):
        pass
    def buildChildren(self, child_, node, nodeName_, fromsubclass_=False):
        if nodeName_ == 'analyzer-name':
            analyzer_name_ = child_.text
            analyzer_name_ = self.gds_validate_string(analyzer_name_, node, 'analyzer_name')
            self.analyzer_name = analyzer_name_
        elif nodeName_ == 'encapsulation':
            encapsulation_ = child_.text
            encapsulation_ = self.gds_validate_string(encapsulation_, node, 'encapsulation')
            self.encapsulation = encapsulation_
        elif nodeName_ == 'analyzer-ip-address':
            analyzer_ip_address_ = child_.text
            analyzer_ip_address_ = self.gds_validate_string(analyzer_ip_address_, node, 'analyzer_ip_address')
            self.analyzer_ip_address = analyzer_ip_address_
            self.validate_IpAddress(self.analyzer_ip_address)    # validate type IpAddress
        elif nodeName_ == 'routing-instance':
            routing_instance_ = child_.text
            routing_instance_ = self.gds_validate_string(routing_instance_, node, 'routing_instance')
            self.routing_instance = routing_instance_
        elif nodeName_ == 'udp-port':
            sval_ = child_.text
            try:
                ival_ = int(sval_)
            except (TypeError, ValueError), exp:
                raise_parse_error(child_, 'requires integer: %s' % exp)
            ival_ = self.gds_validate_integer(ival_, node, 'udp_port')
            self.udp_port = ival_
# end class MirrorActionType


class ActionListType(GeneratedsSuper):
    """
    ActionListType class definition from :doc:`vnc_cfg.xsd`
    """
    subclass = None
    superclass = None
    def __init__(self, simple_action=None, gateway_name=None, service_chain_type=None, apply_service=None, mirror_to=None, **kwargs):
        self.simple_action = simple_action
        self.gateway_name = gateway_name
        self.service_chain_type = service_chain_type
        if (apply_service is None) or (apply_service == []):
            self.apply_service = []
        else:
            self.apply_service = apply_service
        if isinstance(mirror_to, dict):
            obj = MirrorActionType(**mirror_to)
            self.mirror_to = obj
        else:
            self.mirror_to = mirror_to
    def factory(*args_, **kwargs_):
        if ActionListType.subclass:
            return ActionListType.subclass(*args_, **kwargs_)
        else:
            return ActionListType(*args_, **kwargs_)
    factory = staticmethod(factory)
    def get_simple_action(self): return self.simple_action
    def set_simple_action(self, simple_action): self.simple_action = simple_action
    def validate_SimpleActionType(self, value):
        # Validate type SimpleActionType, a restriction on xsd:string.
        pass
    def get_gateway_name(self): return self.gateway_name
    def set_gateway_name(self, gateway_name): self.gateway_name = gateway_name
    def get_service_chain_type(self): return self.service_chain_type
    def set_service_chain_type(self, service_chain_type): self.service_chain_type = service_chain_type
    def validate_ServiceChainType(self, value):
        # Validate type ServiceChainType, a restriction on xsd:string.
        pass
    def get_apply_service(self): return self.apply_service
    def set_apply_service(self, apply_service): self.apply_service = apply_service
    def add_apply_service(self, value): self.apply_service.append(value)
    def insert_apply_service(self, index, value): self.apply_service[index] = value
    def get_mirror_to(self): return self.mirror_to
    def set_mirror_to(self, mirror_to): self.mirror_to = mirror_to
    @classmethod
    def populate (cls, *a, **kwa):
        obj = cls (*a, **kwa)
        obj.set_simple_action (obj.populate_string ("simple_action"))
        obj.set_gateway_name (obj.populate_string ("gateway_name"))
        obj.set_service_chain_type (obj.populate_string ("service_chain_type"))
        obj.set_apply_service (obj.populate_string ("apply_service"))
        obj.set_mirror_to (MirrorActionType.populate ())
        return obj
    def export(self, outfile, level=1, namespace_='', name_='ActionListType', namespacedef_='', pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        showIndent(outfile, level, pretty_print)
        outfile.write('<%s%s%s' % (namespace_, name_, namespacedef_ and ' ' + namespacedef_ or '', ))
        already_processed = []
        self.exportAttributes(outfile, level, already_processed, namespace_, name_='ActionListType')
        if self.hasContent_():
            outfile.write('>%s' % (eol_, ))
            self.exportChildren(outfile, level + 1, namespace_, name_, pretty_print=pretty_print)
            showIndent(outfile, level, pretty_print)
            outfile.write('</%s%s>%s' % (namespace_, name_, eol_))
        else:
            outfile.write('/>%s' % (eol_, ))
    def exportAttributes(self, outfile, level, already_processed, namespace_='', name_='ActionListType'):
        pass
    def exportChildren(self, outfile, level, namespace_='', name_='ActionListType', fromsubclass_=False, pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        if self.simple_action is not None:
            showIndent(outfile, level, pretty_print)
            outfile.write('<%ssimple-action>%s</%ssimple-action>%s' % (namespace_, self.gds_format_string(quote_xml(self.simple_action).encode(ExternalEncoding), input_name='simple-action'), namespace_, eol_))
        if self.gateway_name is not None:
            showIndent(outfile, level, pretty_print)
            outfile.write('<%sgateway-name>%s</%sgateway-name>%s' % (namespace_, self.gds_format_string(quote_xml(self.gateway_name).encode(ExternalEncoding), input_name='gateway-name'), namespace_, eol_))
        if self.service_chain_type is not None:
            showIndent(outfile, level, pretty_print)
            outfile.write('<%sservice-chain-type>%s</%sservice-chain-type>%s' % (namespace_, self.gds_format_string(quote_xml(self.service_chain_type).encode(ExternalEncoding), input_name='service-chain-type'), namespace_, eol_))
        for apply_service_ in self.apply_service:
            showIndent(outfile, level, pretty_print)
            outfile.write('<%sapply-service>%s</%sapply-service>%s' % (namespace_, self.gds_format_string(quote_xml(apply_service_).encode(ExternalEncoding), input_name='apply-service'), namespace_, eol_))
        if self.mirror_to is not None:
            self.mirror_to.export(outfile, level, namespace_, name_='mirror-to', pretty_print=pretty_print)
    def hasContent_(self):
        if (
            self.simple_action is not None or
            self.gateway_name is not None or
            self.service_chain_type is not None or
            self.apply_service or
            self.mirror_to is not None
            ):
            return True
        else:
            return False
    def exportLiteral(self, outfile, level, name_='ActionListType'):
        level += 1
        self.exportLiteralAttributes(outfile, level, [], name_)
        if self.hasContent_():
            self.exportLiteralChildren(outfile, level, name_)
    def exportLiteralAttributes(self, outfile, level, already_processed, name_):
        pass
    def exportLiteralChildren(self, outfile, level, name_):
        if self.simple_action is not None:
            showIndent(outfile, level)
            outfile.write('simple_action=%s,\n' % quote_python(self.simple_action).encode(ExternalEncoding))
        if self.gateway_name is not None:
            showIndent(outfile, level)
            outfile.write('gateway_name=%s,\n' % quote_python(self.gateway_name).encode(ExternalEncoding))
        if self.service_chain_type is not None:
            showIndent(outfile, level)
            outfile.write('service_chain_type=%s,\n' % quote_python(self.service_chain_type).encode(ExternalEncoding))
        showIndent(outfile, level)
        outfile.write('apply_service=[\n')
        level += 1
        for apply_service_ in self.apply_service:
            showIndent(outfile, level)
            outfile.write('%s,\n' % quote_python(apply_service_).encode(ExternalEncoding))
        level -= 1
        showIndent(outfile, level)
        outfile.write('],\n')
        if self.mirror_to is not None:
            showIndent(outfile, level)
            outfile.write('mirror_to=model_.MirrorActionType(\n')
            self.mirror_to.exportLiteral(outfile, level, name_='mirror_to')
            showIndent(outfile, level)
            outfile.write('),\n')
    def exportDict(self, name_='ActionListType'):
        obj_json = json.dumps(self, default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        obj_dict = json.loads(obj_json)
        return {name_: obj_dict}
    def build(self, node):
        self.buildAttributes(node, node.attrib, [])
        for child in node:
            nodeName_ = Tag_pattern_.match(child.tag).groups()[-1]
            self.buildChildren(child, node, nodeName_)
    def buildAttributes(self, node, attrs, already_processed):
        pass
    def buildChildren(self, child_, node, nodeName_, fromsubclass_=False):
        if nodeName_ == 'simple-action':
            simple_action_ = child_.text
            simple_action_ = self.gds_validate_string(simple_action_, node, 'simple_action')
            self.simple_action = simple_action_
            self.validate_SimpleActionType(self.simple_action)    # validate type SimpleActionType
        elif nodeName_ == 'gateway-name':
            gateway_name_ = child_.text
            gateway_name_ = self.gds_validate_string(gateway_name_, node, 'gateway_name')
            self.gateway_name = gateway_name_
        elif nodeName_ == 'service-chain-type':
            service_chain_type_ = child_.text
            service_chain_type_ = self.gds_validate_string(service_chain_type_, node, 'service_chain_type')
            self.service_chain_type = service_chain_type_
            self.validate_ServiceChainType(self.service_chain_type)    # validate type ServiceChainType
        elif nodeName_ == 'apply-service':
            apply_service_ = child_.text
            apply_service_ = self.gds_validate_string(apply_service_, node, 'apply_service')
            self.apply_service.append(apply_service_)
        elif nodeName_ == 'mirror-to':
            obj_ = MirrorActionType.factory()
            obj_.build(child_)
            self.set_mirror_to(obj_)
# end class ActionListType


class AclRuleType(GeneratedsSuper):
    """
    AclRuleType class definition from :doc:`vnc_cfg.xsd`
    """
    subclass = None
    superclass = None
    def __init__(self, match_condition=None, action_list=None, **kwargs):
        if isinstance(match_condition, dict):
            obj = MatchConditionType(**match_condition)
            self.match_condition = obj
        else:
            self.match_condition = match_condition
        if isinstance(action_list, dict):
            obj = ActionListType(**action_list)
            self.action_list = obj
        else:
            self.action_list = action_list
    def factory(*args_, **kwargs_):
        if AclRuleType.subclass:
            return AclRuleType.subclass(*args_, **kwargs_)
        else:
            return AclRuleType(*args_, **kwargs_)
    factory = staticmethod(factory)
    def get_match_condition(self): return self.match_condition
    def set_match_condition(self, match_condition): self.match_condition = match_condition
    def get_action_list(self): return self.action_list
    def set_action_list(self, action_list): self.action_list = action_list
    @classmethod
    def populate (cls, *a, **kwa):
        obj = cls (*a, **kwa)
        obj.set_match_condition (MatchConditionType.populate ())
        obj.set_action_list (ActionListType.populate ())
        return obj
    def export(self, outfile, level=1, namespace_='', name_='AclRuleType', namespacedef_='', pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        showIndent(outfile, level, pretty_print)
        outfile.write('<%s%s%s' % (namespace_, name_, namespacedef_ and ' ' + namespacedef_ or '', ))
        already_processed = []
        self.exportAttributes(outfile, level, already_processed, namespace_, name_='AclRuleType')
        if self.hasContent_():
            outfile.write('>%s' % (eol_, ))
            self.exportChildren(outfile, level + 1, namespace_, name_, pretty_print=pretty_print)
            showIndent(outfile, level, pretty_print)
            outfile.write('</%s%s>%s' % (namespace_, name_, eol_))
        else:
            outfile.write('/>%s' % (eol_, ))
    def exportAttributes(self, outfile, level, already_processed, namespace_='', name_='AclRuleType'):
        pass
    def exportChildren(self, outfile, level, namespace_='', name_='AclRuleType', fromsubclass_=False, pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        if self.match_condition is not None:
            self.match_condition.export(outfile, level, namespace_, name_='match-condition', pretty_print=pretty_print)
        if self.action_list is not None:
            self.action_list.export(outfile, level, namespace_, name_='action-list', pretty_print=pretty_print)
    def hasContent_(self):
        if (
            self.match_condition is not None or
            self.action_list is not None
            ):
            return True
        else:
            return False
    def exportLiteral(self, outfile, level, name_='AclRuleType'):
        level += 1
        self.exportLiteralAttributes(outfile, level, [], name_)
        if self.hasContent_():
            self.exportLiteralChildren(outfile, level, name_)
    def exportLiteralAttributes(self, outfile, level, already_processed, name_):
        pass
    def exportLiteralChildren(self, outfile, level, name_):
        if self.match_condition is not None:
            showIndent(outfile, level)
            outfile.write('match_condition=model_.MatchConditionType(\n')
            self.match_condition.exportLiteral(outfile, level, name_='match_condition')
            showIndent(outfile, level)
            outfile.write('),\n')
        if self.action_list is not None:
            showIndent(outfile, level)
            outfile.write('action_list=model_.ActionListType(\n')
            self.action_list.exportLiteral(outfile, level, name_='action_list')
            showIndent(outfile, level)
            outfile.write('),\n')
    def exportDict(self, name_='AclRuleType'):
        obj_json = json.dumps(self, default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        obj_dict = json.loads(obj_json)
        return {name_: obj_dict}
    def build(self, node):
        self.buildAttributes(node, node.attrib, [])
        for child in node:
            nodeName_ = Tag_pattern_.match(child.tag).groups()[-1]
            self.buildChildren(child, node, nodeName_)
    def buildAttributes(self, node, attrs, already_processed):
        pass
    def buildChildren(self, child_, node, nodeName_, fromsubclass_=False):
        if nodeName_ == 'match-condition':
            obj_ = MatchConditionType.factory()
            obj_.build(child_)
            self.set_match_condition(obj_)
        elif nodeName_ == 'action-list':
            obj_ = ActionListType.factory()
            obj_.build(child_)
            self.set_action_list(obj_)
# end class AclRuleType


class AclEntriesType(GeneratedsSuper):
    """
    AclEntriesType class definition from :doc:`vnc_cfg.xsd`
    """
    subclass = None
    superclass = None
    def __init__(self, dynamic=None, acl_rule=None, **kwargs):
        self.dynamic = dynamic
        if (acl_rule is None) or (acl_rule == []):
            self.acl_rule = []
        else:
            if isinstance(acl_rule[0], dict):
                objs = [AclRuleType(**elem) for elem in acl_rule]
                self.acl_rule = objs
            else:
                self.acl_rule = acl_rule
    def factory(*args_, **kwargs_):
        if AclEntriesType.subclass:
            return AclEntriesType.subclass(*args_, **kwargs_)
        else:
            return AclEntriesType(*args_, **kwargs_)
    factory = staticmethod(factory)
    def get_dynamic(self): return self.dynamic
    def set_dynamic(self, dynamic): self.dynamic = dynamic
    def get_acl_rule(self): return self.acl_rule
    def set_acl_rule(self, acl_rule): self.acl_rule = acl_rule
    def add_acl_rule(self, value): self.acl_rule.append(value)
    def insert_acl_rule(self, index, value): self.acl_rule[index] = value
    @classmethod
    def populate (cls, *a, **kwa):
        obj = cls (*a, **kwa)
        obj.set_dynamic (obj.populate_boolean ("dynamic"))
        obj.set_acl_rule (AclRuleType.populate ())
        return obj
    def export(self, outfile, level=1, namespace_='', name_='AclEntriesType', namespacedef_='', pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        showIndent(outfile, level, pretty_print)
        outfile.write('<%s%s%s' % (namespace_, name_, namespacedef_ and ' ' + namespacedef_ or '', ))
        already_processed = []
        self.exportAttributes(outfile, level, already_processed, namespace_, name_='AclEntriesType')
        if self.hasContent_():
            outfile.write('>%s' % (eol_, ))
            self.exportChildren(outfile, level + 1, namespace_, name_, pretty_print=pretty_print)
            showIndent(outfile, level, pretty_print)
            outfile.write('</%s%s>%s' % (namespace_, name_, eol_))
        else:
            outfile.write('/>%s' % (eol_, ))
    def exportAttributes(self, outfile, level, already_processed, namespace_='', name_='AclEntriesType'):
        pass
    def exportChildren(self, outfile, level, namespace_='', name_='AclEntriesType', fromsubclass_=False, pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        if self.dynamic is not None:
            showIndent(outfile, level, pretty_print)
            outfile.write('<%sdynamic>%s</%sdynamic>%s' % (namespace_, self.gds_format_boolean(self.gds_str_lower(str(self.dynamic)), input_name='dynamic'), namespace_, eol_))
        for acl_rule_ in self.acl_rule:
            if isinstance(acl_rule_, dict):
                acl_rule_ = AclRuleType(**acl_rule_)
            acl_rule_.export(outfile, level, namespace_, name_='acl-rule', pretty_print=pretty_print)
    def hasContent_(self):
        if (
            self.dynamic is not None or
            self.acl_rule
            ):
            return True
        else:
            return False
    def exportLiteral(self, outfile, level, name_='AclEntriesType'):
        level += 1
        self.exportLiteralAttributes(outfile, level, [], name_)
        if self.hasContent_():
            self.exportLiteralChildren(outfile, level, name_)
    def exportLiteralAttributes(self, outfile, level, already_processed, name_):
        pass
    def exportLiteralChildren(self, outfile, level, name_):
        if self.dynamic is not None:
            showIndent(outfile, level)
            outfile.write('dynamic=%s,\n' % self.dynamic)
        showIndent(outfile, level)
        outfile.write('acl_rule=[\n')
        level += 1
        for acl_rule_ in self.acl_rule:
            showIndent(outfile, level)
            outfile.write('model_.AclRuleType(\n')
            acl_rule_.exportLiteral(outfile, level, name_='AclRuleType')
            showIndent(outfile, level)
            outfile.write('),\n')
        level -= 1
        showIndent(outfile, level)
        outfile.write('],\n')
    def exportDict(self, name_='AclEntriesType'):
        obj_json = json.dumps(self, default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        obj_dict = json.loads(obj_json)
        return {name_: obj_dict}
    def build(self, node):
        self.buildAttributes(node, node.attrib, [])
        for child in node:
            nodeName_ = Tag_pattern_.match(child.tag).groups()[-1]
            self.buildChildren(child, node, nodeName_)
    def buildAttributes(self, node, attrs, already_processed):
        pass
    def buildChildren(self, child_, node, nodeName_, fromsubclass_=False):
        if nodeName_ == 'dynamic':
            sval_ = child_.text
            if sval_ in ('true', '1'):
                ival_ = True
            elif sval_ in ('false', '0'):
                ival_ = False
            else:
                raise_parse_error(child_, 'requires boolean')
            ival_ = self.gds_validate_boolean(ival_, node, 'dynamic')
            self.dynamic = ival_
        elif nodeName_ == 'acl-rule':
            obj_ = AclRuleType.factory()
            obj_.build(child_)
            self.acl_rule.append(obj_)
# end class AclEntriesType


class PolicyRuleType(GeneratedsSuper):
    """
    PolicyRuleType class definition from :doc:`vnc_cfg.xsd`
    """
    subclass = None
    superclass = None
    def __init__(self, rule_sequence=None, rule_uuid=None, direction=None, simple_action=None, protocol=None, src_addresses=None, src_ports=None, application=None, dst_addresses=None, dst_ports=None, action_list=None, **kwargs):
        if isinstance(rule_sequence, dict):
            obj = SequenceType(**rule_sequence)
            self.rule_sequence = obj
        else:
            self.rule_sequence = rule_sequence
        self.rule_uuid = rule_uuid
        self.direction = direction
        self.simple_action = simple_action
        self.protocol = protocol
        if (src_addresses is None) or (src_addresses == []):
            self.src_addresses = []
        else:
            if isinstance(src_addresses[0], dict):
                objs = [AddressType(**elem) for elem in src_addresses]
                self.src_addresses = objs
            else:
                self.src_addresses = src_addresses
        if (src_ports is None) or (src_ports == []):
            self.src_ports = []
        else:
            if isinstance(src_ports[0], dict):
                objs = [PortType(**elem) for elem in src_ports]
                self.src_ports = objs
            else:
                self.src_ports = src_ports
        if (application is None) or (application == []):
            self.application = []
        else:
            self.application = application
        if (dst_addresses is None) or (dst_addresses == []):
            self.dst_addresses = []
        else:
            if isinstance(dst_addresses[0], dict):
                objs = [AddressType(**elem) for elem in dst_addresses]
                self.dst_addresses = objs
            else:
                self.dst_addresses = dst_addresses
        if (dst_ports is None) or (dst_ports == []):
            self.dst_ports = []
        else:
            if isinstance(dst_ports[0], dict):
                objs = [PortType(**elem) for elem in dst_ports]
                self.dst_ports = objs
            else:
                self.dst_ports = dst_ports
        if isinstance(action_list, dict):
            obj = ActionListType(**action_list)
            self.action_list = obj
        else:
            self.action_list = action_list
    def factory(*args_, **kwargs_):
        if PolicyRuleType.subclass:
            return PolicyRuleType.subclass(*args_, **kwargs_)
        else:
            return PolicyRuleType(*args_, **kwargs_)
    factory = staticmethod(factory)
    def get_rule_sequence(self): return self.rule_sequence
    def set_rule_sequence(self, rule_sequence): self.rule_sequence = rule_sequence
    def get_rule_uuid(self): return self.rule_uuid
    def set_rule_uuid(self, rule_uuid): self.rule_uuid = rule_uuid
    def get_direction(self): return self.direction
    def set_direction(self, direction): self.direction = direction
    def validate_DirectionType(self, value):
        # Validate type DirectionType, a restriction on xsd:string.
        pass
    def get_simple_action(self): return self.simple_action
    def set_simple_action(self, simple_action): self.simple_action = simple_action
    def validate_SimpleActionType(self, value):
        # Validate type SimpleActionType, a restriction on xsd:string.
        pass
    def get_protocol(self): return self.protocol
    def set_protocol(self, protocol): self.protocol = protocol
    def validate_ProtocolType(self, value):
        # Validate type ProtocolType, a restriction on xsd:string.
        pass
    def get_src_addresses(self): return self.src_addresses
    def set_src_addresses(self, src_addresses): self.src_addresses = src_addresses
    def add_src_addresses(self, value): self.src_addresses.append(value)
    def insert_src_addresses(self, index, value): self.src_addresses[index] = value
    def get_src_ports(self): return self.src_ports
    def set_src_ports(self, src_ports): self.src_ports = src_ports
    def add_src_ports(self, value): self.src_ports.append(value)
    def insert_src_ports(self, index, value): self.src_ports[index] = value
    def get_application(self): return self.application
    def set_application(self, application): self.application = application
    def add_application(self, value): self.application.append(value)
    def insert_application(self, index, value): self.application[index] = value
    def get_dst_addresses(self): return self.dst_addresses
    def set_dst_addresses(self, dst_addresses): self.dst_addresses = dst_addresses
    def add_dst_addresses(self, value): self.dst_addresses.append(value)
    def insert_dst_addresses(self, index, value): self.dst_addresses[index] = value
    def get_dst_ports(self): return self.dst_ports
    def set_dst_ports(self, dst_ports): self.dst_ports = dst_ports
    def add_dst_ports(self, value): self.dst_ports.append(value)
    def insert_dst_ports(self, index, value): self.dst_ports[index] = value
    def get_action_list(self): return self.action_list
    def set_action_list(self, action_list): self.action_list = action_list
    @classmethod
    def populate (cls, *a, **kwa):
        obj = cls (*a, **kwa)
        obj.set_rule_sequence (SequenceType.populate ())
        obj.set_rule_uuid (obj.populate_string ("rule_uuid"))
        obj.set_direction (obj.populate_string ("direction"))
        obj.set_simple_action (obj.populate_string ("simple_action"))
        obj.set_protocol (obj.populate_string ("protocol"))
        obj.set_src_addresses (AddressType.populate ())
        obj.set_src_ports (PortType.populate ())
        obj.set_application (obj.populate_string ("application"))
        obj.set_dst_addresses (AddressType.populate ())
        obj.set_dst_ports (PortType.populate ())
        obj.set_action_list (ActionListType.populate ())
        return obj
    def export(self, outfile, level=1, namespace_='', name_='PolicyRuleType', namespacedef_='', pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        showIndent(outfile, level, pretty_print)
        outfile.write('<%s%s%s' % (namespace_, name_, namespacedef_ and ' ' + namespacedef_ or '', ))
        already_processed = []
        self.exportAttributes(outfile, level, already_processed, namespace_, name_='PolicyRuleType')
        if self.hasContent_():
            outfile.write('>%s' % (eol_, ))
            self.exportChildren(outfile, level + 1, namespace_, name_, pretty_print=pretty_print)
            showIndent(outfile, level, pretty_print)
            outfile.write('</%s%s>%s' % (namespace_, name_, eol_))
        else:
            outfile.write('/>%s' % (eol_, ))
    def exportAttributes(self, outfile, level, already_processed, namespace_='', name_='PolicyRuleType'):
        pass
    def exportChildren(self, outfile, level, namespace_='', name_='PolicyRuleType', fromsubclass_=False, pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        if self.rule_sequence is not None:
            self.rule_sequence.export(outfile, level, namespace_, name_='rule-sequence', pretty_print=pretty_print)
        if self.rule_uuid is not None:
            showIndent(outfile, level, pretty_print)
            outfile.write('<%srule-uuid>%s</%srule-uuid>%s' % (namespace_, self.gds_format_string(quote_xml(self.rule_uuid).encode(ExternalEncoding), input_name='rule-uuid'), namespace_, eol_))
        if self.direction is not None:
            showIndent(outfile, level, pretty_print)
            outfile.write('<%sdirection>%s</%sdirection>%s' % (namespace_, self.gds_format_string(quote_xml(self.direction).encode(ExternalEncoding), input_name='direction'), namespace_, eol_))
        if self.simple_action is not None:
            showIndent(outfile, level, pretty_print)
            outfile.write('<%ssimple-action>%s</%ssimple-action>%s' % (namespace_, self.gds_format_string(quote_xml(self.simple_action).encode(ExternalEncoding), input_name='simple-action'), namespace_, eol_))
        if self.protocol is not None:
            showIndent(outfile, level, pretty_print)
            outfile.write('<%sprotocol>%s</%sprotocol>%s' % (namespace_, self.gds_format_string(quote_xml(self.protocol).encode(ExternalEncoding), input_name='protocol'), namespace_, eol_))
        for src_addresses_ in self.src_addresses:
            if isinstance(src_addresses_, dict):
                src_addresses_ = AddressType(**src_addresses_)
            src_addresses_.export(outfile, level, namespace_, name_='src-addresses', pretty_print=pretty_print)
        for src_ports_ in self.src_ports:
            if isinstance(src_ports_, dict):
                src_ports_ = PortType(**src_ports_)
            src_ports_.export(outfile, level, namespace_, name_='src-ports', pretty_print=pretty_print)
        for application_ in self.application:
            showIndent(outfile, level, pretty_print)
            outfile.write('<%sapplication>%s</%sapplication>%s' % (namespace_, self.gds_format_string(quote_xml(application_).encode(ExternalEncoding), input_name='application'), namespace_, eol_))
        for dst_addresses_ in self.dst_addresses:
            if isinstance(dst_addresses_, dict):
                dst_addresses_ = AddressType(**dst_addresses_)
            dst_addresses_.export(outfile, level, namespace_, name_='dst-addresses', pretty_print=pretty_print)
        for dst_ports_ in self.dst_ports:
            if isinstance(dst_ports_, dict):
                dst_ports_ = PortType(**dst_ports_)
            dst_ports_.export(outfile, level, namespace_, name_='dst-ports', pretty_print=pretty_print)
        if self.action_list is not None:
            self.action_list.export(outfile, level, namespace_, name_='action-list', pretty_print=pretty_print)
    def hasContent_(self):
        if (
            self.rule_sequence is not None or
            self.rule_uuid is not None or
            self.direction is not None or
            self.simple_action is not None or
            self.protocol is not None or
            self.src_addresses or
            self.src_ports or
            self.application or
            self.dst_addresses or
            self.dst_ports or
            self.action_list is not None
            ):
            return True
        else:
            return False
    def exportLiteral(self, outfile, level, name_='PolicyRuleType'):
        level += 1
        self.exportLiteralAttributes(outfile, level, [], name_)
        if self.hasContent_():
            self.exportLiteralChildren(outfile, level, name_)
    def exportLiteralAttributes(self, outfile, level, already_processed, name_):
        pass
    def exportLiteralChildren(self, outfile, level, name_):
        if self.rule_sequence is not None:
            showIndent(outfile, level)
            outfile.write('rule_sequence=model_.SequenceType(\n')
            self.rule_sequence.exportLiteral(outfile, level, name_='rule_sequence')
            showIndent(outfile, level)
            outfile.write('),\n')
        if self.rule_uuid is not None:
            showIndent(outfile, level)
            outfile.write('rule_uuid=%s,\n' % quote_python(self.rule_uuid).encode(ExternalEncoding))
        if self.direction is not None:
            showIndent(outfile, level)
            outfile.write('direction=%s,\n' % quote_python(self.direction).encode(ExternalEncoding))
        if self.simple_action is not None:
            showIndent(outfile, level)
            outfile.write('simple_action=%s,\n' % quote_python(self.simple_action).encode(ExternalEncoding))
        if self.protocol is not None:
            showIndent(outfile, level)
            outfile.write('protocol=%s,\n' % quote_python(self.protocol).encode(ExternalEncoding))
        showIndent(outfile, level)
        outfile.write('src_addresses=[\n')
        level += 1
        for src_addresses_ in self.src_addresses:
            showIndent(outfile, level)
            outfile.write('model_.AddressType(\n')
            src_addresses_.exportLiteral(outfile, level, name_='AddressType')
            showIndent(outfile, level)
            outfile.write('),\n')
        level -= 1
        showIndent(outfile, level)
        outfile.write('],\n')
        showIndent(outfile, level)
        outfile.write('src_ports=[\n')
        level += 1
        for src_ports_ in self.src_ports:
            showIndent(outfile, level)
            outfile.write('model_.PortType(\n')
            src_ports_.exportLiteral(outfile, level, name_='PortType')
            showIndent(outfile, level)
            outfile.write('),\n')
        level -= 1
        showIndent(outfile, level)
        outfile.write('],\n')
        showIndent(outfile, level)
        outfile.write('application=[\n')
        level += 1
        for application_ in self.application:
            showIndent(outfile, level)
            outfile.write('%s,\n' % quote_python(application_).encode(ExternalEncoding))
        level -= 1
        showIndent(outfile, level)
        outfile.write('],\n')
        showIndent(outfile, level)
        outfile.write('dst_addresses=[\n')
        level += 1
        for dst_addresses_ in self.dst_addresses:
            showIndent(outfile, level)
            outfile.write('model_.AddressType(\n')
            dst_addresses_.exportLiteral(outfile, level, name_='AddressType')
            showIndent(outfile, level)
            outfile.write('),\n')
        level -= 1
        showIndent(outfile, level)
        outfile.write('],\n')
        showIndent(outfile, level)
        outfile.write('dst_ports=[\n')
        level += 1
        for dst_ports_ in self.dst_ports:
            showIndent(outfile, level)
            outfile.write('model_.PortType(\n')
            dst_ports_.exportLiteral(outfile, level, name_='PortType')
            showIndent(outfile, level)
            outfile.write('),\n')
        level -= 1
        showIndent(outfile, level)
        outfile.write('],\n')
        if self.action_list is not None:
            showIndent(outfile, level)
            outfile.write('action_list=model_.ActionListType(\n')
            self.action_list.exportLiteral(outfile, level, name_='action_list')
            showIndent(outfile, level)
            outfile.write('),\n')
    def exportDict(self, name_='PolicyRuleType'):
        obj_json = json.dumps(self, default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        obj_dict = json.loads(obj_json)
        return {name_: obj_dict}
    def build(self, node):
        self.buildAttributes(node, node.attrib, [])
        for child in node:
            nodeName_ = Tag_pattern_.match(child.tag).groups()[-1]
            self.buildChildren(child, node, nodeName_)
    def buildAttributes(self, node, attrs, already_processed):
        pass
    def buildChildren(self, child_, node, nodeName_, fromsubclass_=False):
        if nodeName_ == 'rule-sequence':
            obj_ = SequenceType.factory()
            obj_.build(child_)
            self.set_rule_sequence(obj_)
        elif nodeName_ == 'rule-uuid':
            rule_uuid_ = child_.text
            rule_uuid_ = self.gds_validate_string(rule_uuid_, node, 'rule_uuid')
            self.rule_uuid = rule_uuid_
        elif nodeName_ == 'direction':
            direction_ = child_.text
            direction_ = self.gds_validate_string(direction_, node, 'direction')
            self.direction = direction_
            self.validate_DirectionType(self.direction)    # validate type DirectionType
        elif nodeName_ == 'simple-action':
            simple_action_ = child_.text
            simple_action_ = self.gds_validate_string(simple_action_, node, 'simple_action')
            self.simple_action = simple_action_
            self.validate_SimpleActionType(self.simple_action)    # validate type SimpleActionType
        elif nodeName_ == 'protocol':
            protocol_ = child_.text
            protocol_ = self.gds_validate_string(protocol_, node, 'protocol')
            self.protocol = protocol_
            self.validate_ProtocolType(self.protocol)    # validate type ProtocolType
        elif nodeName_ == 'src-addresses':
            obj_ = AddressType.factory()
            obj_.build(child_)
            self.src_addresses.append(obj_)
        elif nodeName_ == 'src-ports':
            obj_ = PortType.factory()
            obj_.build(child_)
            self.src_ports.append(obj_)
        elif nodeName_ == 'application':
            application_ = child_.text
            application_ = self.gds_validate_string(application_, node, 'application')
            self.application.append(application_)
        elif nodeName_ == 'dst-addresses':
            obj_ = AddressType.factory()
            obj_.build(child_)
            self.dst_addresses.append(obj_)
        elif nodeName_ == 'dst-ports':
            obj_ = PortType.factory()
            obj_.build(child_)
            self.dst_ports.append(obj_)
        elif nodeName_ == 'action-list':
            obj_ = ActionListType.factory()
            obj_.build(child_)
            self.set_action_list(obj_)
# end class PolicyRuleType


class PolicyEntriesType(GeneratedsSuper):
    """
    PolicyEntriesType class definition from :doc:`vnc_cfg.xsd`
    """
    subclass = None
    superclass = None
    def __init__(self, policy_rule=None, **kwargs):
        if (policy_rule is None) or (policy_rule == []):
            self.policy_rule = []
        else:
            if isinstance(policy_rule[0], dict):
                objs = [PolicyRuleType(**elem) for elem in policy_rule]
                self.policy_rule = objs
            else:
                self.policy_rule = policy_rule
    def factory(*args_, **kwargs_):
        if PolicyEntriesType.subclass:
            return PolicyEntriesType.subclass(*args_, **kwargs_)
        else:
            return PolicyEntriesType(*args_, **kwargs_)
    factory = staticmethod(factory)
    def get_policy_rule(self): return self.policy_rule
    def set_policy_rule(self, policy_rule): self.policy_rule = policy_rule
    def add_policy_rule(self, value): self.policy_rule.append(value)
    def insert_policy_rule(self, index, value): self.policy_rule[index] = value
    @classmethod
    def populate (cls, *a, **kwa):
        obj = cls (*a, **kwa)
        obj.set_policy_rule (PolicyRuleType.populate ())
        return obj
    def export(self, outfile, level=1, namespace_='', name_='PolicyEntriesType', namespacedef_='', pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        showIndent(outfile, level, pretty_print)
        outfile.write('<%s%s%s' % (namespace_, name_, namespacedef_ and ' ' + namespacedef_ or '', ))
        already_processed = []
        self.exportAttributes(outfile, level, already_processed, namespace_, name_='PolicyEntriesType')
        if self.hasContent_():
            outfile.write('>%s' % (eol_, ))
            self.exportChildren(outfile, level + 1, namespace_, name_, pretty_print=pretty_print)
            showIndent(outfile, level, pretty_print)
            outfile.write('</%s%s>%s' % (namespace_, name_, eol_))
        else:
            outfile.write('/>%s' % (eol_, ))
    def exportAttributes(self, outfile, level, already_processed, namespace_='', name_='PolicyEntriesType'):
        pass
    def exportChildren(self, outfile, level, namespace_='', name_='PolicyEntriesType', fromsubclass_=False, pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        for policy_rule_ in self.policy_rule:
            if isinstance(policy_rule_, dict):
                policy_rule_ = PolicyRuleType(**policy_rule_)
            policy_rule_.export(outfile, level, namespace_, name_='policy-rule', pretty_print=pretty_print)
    def hasContent_(self):
        if (
            self.policy_rule
            ):
            return True
        else:
            return False
    def exportLiteral(self, outfile, level, name_='PolicyEntriesType'):
        level += 1
        self.exportLiteralAttributes(outfile, level, [], name_)
        if self.hasContent_():
            self.exportLiteralChildren(outfile, level, name_)
    def exportLiteralAttributes(self, outfile, level, already_processed, name_):
        pass
    def exportLiteralChildren(self, outfile, level, name_):
        showIndent(outfile, level)
        outfile.write('policy_rule=[\n')
        level += 1
        for policy_rule_ in self.policy_rule:
            showIndent(outfile, level)
            outfile.write('model_.PolicyRuleType(\n')
            policy_rule_.exportLiteral(outfile, level, name_='PolicyRuleType')
            showIndent(outfile, level)
            outfile.write('),\n')
        level -= 1
        showIndent(outfile, level)
        outfile.write('],\n')
    def exportDict(self, name_='PolicyEntriesType'):
        obj_json = json.dumps(self, default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        obj_dict = json.loads(obj_json)
        return {name_: obj_dict}
    def build(self, node):
        self.buildAttributes(node, node.attrib, [])
        for child in node:
            nodeName_ = Tag_pattern_.match(child.tag).groups()[-1]
            self.buildChildren(child, node, nodeName_)
    def buildAttributes(self, node, attrs, already_processed):
        pass
    def buildChildren(self, child_, node, nodeName_, fromsubclass_=False):
        if nodeName_ == 'policy-rule':
            obj_ = PolicyRuleType.factory()
            obj_.build(child_)
            self.policy_rule.append(obj_)
# end class PolicyEntriesType


class ApiAccessType(GeneratedsSuper):
    """
    ApiAccessType class definition from :doc:`vnc_cfg.xsd`
    """
    subclass = None
    superclass = None
    def __init__(self, api_name=None, permissions=None, **kwargs):
        self.api_name = api_name
        if isinstance(permissions, dict):
            obj = PermType(**permissions)
            self.permissions = obj
        else:
            self.permissions = permissions
    def factory(*args_, **kwargs_):
        if ApiAccessType.subclass:
            return ApiAccessType.subclass(*args_, **kwargs_)
        else:
            return ApiAccessType(*args_, **kwargs_)
    factory = staticmethod(factory)
    def get_api_name(self): return self.api_name
    def set_api_name(self, api_name): self.api_name = api_name
    def get_permissions(self): return self.permissions
    def set_permissions(self, permissions): self.permissions = permissions
    @classmethod
    def populate (cls, *a, **kwa):
        obj = cls (*a, **kwa)
        obj.set_api_name (obj.populate_string ("api_name"))
        obj.set_permissions (PermType.populate ())
        return obj
    def export(self, outfile, level=1, namespace_='', name_='ApiAccessType', namespacedef_='', pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        showIndent(outfile, level, pretty_print)
        outfile.write('<%s%s%s' % (namespace_, name_, namespacedef_ and ' ' + namespacedef_ or '', ))
        already_processed = []
        self.exportAttributes(outfile, level, already_processed, namespace_, name_='ApiAccessType')
        if self.hasContent_():
            outfile.write('>%s' % (eol_, ))
            self.exportChildren(outfile, level + 1, namespace_, name_, pretty_print=pretty_print)
            showIndent(outfile, level, pretty_print)
            outfile.write('</%s%s>%s' % (namespace_, name_, eol_))
        else:
            outfile.write('/>%s' % (eol_, ))
    def exportAttributes(self, outfile, level, already_processed, namespace_='', name_='ApiAccessType'):
        pass
    def exportChildren(self, outfile, level, namespace_='', name_='ApiAccessType', fromsubclass_=False, pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        if self.api_name is not None:
            showIndent(outfile, level, pretty_print)
            outfile.write('<%sapi-name>%s</%sapi-name>%s' % (namespace_, self.gds_format_string(quote_xml(self.api_name).encode(ExternalEncoding), input_name='api-name'), namespace_, eol_))
        if self.permissions is not None:
            self.permissions.export(outfile, level, namespace_, name_='permissions', pretty_print=pretty_print)
    def hasContent_(self):
        if (
            self.api_name is not None or
            self.permissions is not None
            ):
            return True
        else:
            return False
    def exportLiteral(self, outfile, level, name_='ApiAccessType'):
        level += 1
        self.exportLiteralAttributes(outfile, level, [], name_)
        if self.hasContent_():
            self.exportLiteralChildren(outfile, level, name_)
    def exportLiteralAttributes(self, outfile, level, already_processed, name_):
        pass
    def exportLiteralChildren(self, outfile, level, name_):
        if self.api_name is not None:
            showIndent(outfile, level)
            outfile.write('api_name=%s,\n' % quote_python(self.api_name).encode(ExternalEncoding))
        if self.permissions is not None:
            showIndent(outfile, level)
            outfile.write('permissions=model_.PermType(\n')
            self.permissions.exportLiteral(outfile, level, name_='permissions')
            showIndent(outfile, level)
            outfile.write('),\n')
    def exportDict(self, name_='ApiAccessType'):
        obj_json = json.dumps(self, default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        obj_dict = json.loads(obj_json)
        return {name_: obj_dict}
    def build(self, node):
        self.buildAttributes(node, node.attrib, [])
        for child in node:
            nodeName_ = Tag_pattern_.match(child.tag).groups()[-1]
            self.buildChildren(child, node, nodeName_)
    def buildAttributes(self, node, attrs, already_processed):
        pass
    def buildChildren(self, child_, node, nodeName_, fromsubclass_=False):
        if nodeName_ == 'api-name':
            api_name_ = child_.text
            api_name_ = self.gds_validate_string(api_name_, node, 'api_name')
            self.api_name = api_name_
        elif nodeName_ == 'permissions':
            obj_ = PermType.factory()
            obj_.build(child_)
            self.set_permissions(obj_)
# end class ApiAccessType


class ApiAccessListType(GeneratedsSuper):
    """
    ApiAccessListType class definition from :doc:`vnc_cfg.xsd`
    """
    subclass = None
    superclass = None
    def __init__(self, api_access=None, **kwargs):
        if (api_access is None) or (api_access == []):
            self.api_access = []
        else:
            if isinstance(api_access[0], dict):
                objs = [ApiAccessType(**elem) for elem in api_access]
                self.api_access = objs
            else:
                self.api_access = api_access
    def factory(*args_, **kwargs_):
        if ApiAccessListType.subclass:
            return ApiAccessListType.subclass(*args_, **kwargs_)
        else:
            return ApiAccessListType(*args_, **kwargs_)
    factory = staticmethod(factory)
    def get_api_access(self): return self.api_access
    def set_api_access(self, api_access): self.api_access = api_access
    def add_api_access(self, value): self.api_access.append(value)
    def insert_api_access(self, index, value): self.api_access[index] = value
    @classmethod
    def populate (cls, *a, **kwa):
        obj = cls (*a, **kwa)
        obj.set_api_access (ApiAccessType.populate ())
        return obj
    def export(self, outfile, level=1, namespace_='', name_='ApiAccessListType', namespacedef_='', pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        showIndent(outfile, level, pretty_print)
        outfile.write('<%s%s%s' % (namespace_, name_, namespacedef_ and ' ' + namespacedef_ or '', ))
        already_processed = []
        self.exportAttributes(outfile, level, already_processed, namespace_, name_='ApiAccessListType')
        if self.hasContent_():
            outfile.write('>%s' % (eol_, ))
            self.exportChildren(outfile, level + 1, namespace_, name_, pretty_print=pretty_print)
            showIndent(outfile, level, pretty_print)
            outfile.write('</%s%s>%s' % (namespace_, name_, eol_))
        else:
            outfile.write('/>%s' % (eol_, ))
    def exportAttributes(self, outfile, level, already_processed, namespace_='', name_='ApiAccessListType'):
        pass
    def exportChildren(self, outfile, level, namespace_='', name_='ApiAccessListType', fromsubclass_=False, pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        for api_access_ in self.api_access:
            if isinstance(api_access_, dict):
                api_access_ = ApiAccessType(**api_access_)
            api_access_.export(outfile, level, namespace_, name_='api-access', pretty_print=pretty_print)
    def hasContent_(self):
        if (
            self.api_access
            ):
            return True
        else:
            return False
    def exportLiteral(self, outfile, level, name_='ApiAccessListType'):
        level += 1
        self.exportLiteralAttributes(outfile, level, [], name_)
        if self.hasContent_():
            self.exportLiteralChildren(outfile, level, name_)
    def exportLiteralAttributes(self, outfile, level, already_processed, name_):
        pass
    def exportLiteralChildren(self, outfile, level, name_):
        showIndent(outfile, level)
        outfile.write('api_access=[\n')
        level += 1
        for api_access_ in self.api_access:
            showIndent(outfile, level)
            outfile.write('model_.ApiAccessType(\n')
            api_access_.exportLiteral(outfile, level, name_='ApiAccessType')
            showIndent(outfile, level)
            outfile.write('),\n')
        level -= 1
        showIndent(outfile, level)
        outfile.write('],\n')
    def exportDict(self, name_='ApiAccessListType'):
        obj_json = json.dumps(self, default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        obj_dict = json.loads(obj_json)
        return {name_: obj_dict}
    def build(self, node):
        self.buildAttributes(node, node.attrib, [])
        for child in node:
            nodeName_ = Tag_pattern_.match(child.tag).groups()[-1]
            self.buildChildren(child, node, nodeName_)
    def buildAttributes(self, node, attrs, already_processed):
        pass
    def buildChildren(self, child_, node, nodeName_, fromsubclass_=False):
        if nodeName_ == 'api-access':
            obj_ = ApiAccessType.factory()
            obj_.build(child_)
            self.api_access.append(obj_)
# end class ApiAccessListType


class DhcpOptionType(GeneratedsSuper):
    """
    DhcpOptionType class definition from :doc:`vnc_cfg.xsd`
    """
    subclass = None
    superclass = None
    def __init__(self, dhcp_option_name=None, dhcp_option_value=None, **kwargs):
        self.dhcp_option_name = dhcp_option_name
        self.dhcp_option_value = dhcp_option_value
    def factory(*args_, **kwargs_):
        if DhcpOptionType.subclass:
            return DhcpOptionType.subclass(*args_, **kwargs_)
        else:
            return DhcpOptionType(*args_, **kwargs_)
    factory = staticmethod(factory)
    def get_dhcp_option_name(self): return self.dhcp_option_name
    def set_dhcp_option_name(self, dhcp_option_name): self.dhcp_option_name = dhcp_option_name
    def get_dhcp_option_value(self): return self.dhcp_option_value
    def set_dhcp_option_value(self, dhcp_option_value): self.dhcp_option_value = dhcp_option_value
    @classmethod
    def populate (cls, *a, **kwa):
        obj = cls (*a, **kwa)
        obj.set_dhcp_option_name (obj.populate_string ("dhcp_option_name"))
        obj.set_dhcp_option_value (obj.populate_string ("dhcp_option_value"))
        return obj
    def export(self, outfile, level=1, namespace_='', name_='DhcpOptionType', namespacedef_='', pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        showIndent(outfile, level, pretty_print)
        outfile.write('<%s%s%s' % (namespace_, name_, namespacedef_ and ' ' + namespacedef_ or '', ))
        already_processed = []
        self.exportAttributes(outfile, level, already_processed, namespace_, name_='DhcpOptionType')
        if self.hasContent_():
            outfile.write('>%s' % (eol_, ))
            self.exportChildren(outfile, level + 1, namespace_, name_, pretty_print=pretty_print)
            showIndent(outfile, level, pretty_print)
            outfile.write('</%s%s>%s' % (namespace_, name_, eol_))
        else:
            outfile.write('/>%s' % (eol_, ))
    def exportAttributes(self, outfile, level, already_processed, namespace_='', name_='DhcpOptionType'):
        pass
    def exportChildren(self, outfile, level, namespace_='', name_='DhcpOptionType', fromsubclass_=False, pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        if self.dhcp_option_name is not None:
            showIndent(outfile, level, pretty_print)
            outfile.write('<%sdhcp-option-name>%s</%sdhcp-option-name>%s' % (namespace_, self.gds_format_string(quote_xml(self.dhcp_option_name).encode(ExternalEncoding), input_name='dhcp-option-name'), namespace_, eol_))
        if self.dhcp_option_value is not None:
            showIndent(outfile, level, pretty_print)
            outfile.write('<%sdhcp-option-value>%s</%sdhcp-option-value>%s' % (namespace_, self.gds_format_string(quote_xml(self.dhcp_option_value).encode(ExternalEncoding), input_name='dhcp-option-value'), namespace_, eol_))
    def hasContent_(self):
        if (
            self.dhcp_option_name is not None or
            self.dhcp_option_value is not None
            ):
            return True
        else:
            return False
    def exportLiteral(self, outfile, level, name_='DhcpOptionType'):
        level += 1
        self.exportLiteralAttributes(outfile, level, [], name_)
        if self.hasContent_():
            self.exportLiteralChildren(outfile, level, name_)
    def exportLiteralAttributes(self, outfile, level, already_processed, name_):
        pass
    def exportLiteralChildren(self, outfile, level, name_):
        if self.dhcp_option_name is not None:
            showIndent(outfile, level)
            outfile.write('dhcp_option_name=%s,\n' % quote_python(self.dhcp_option_name).encode(ExternalEncoding))
        if self.dhcp_option_value is not None:
            showIndent(outfile, level)
            outfile.write('dhcp_option_value=%s,\n' % quote_python(self.dhcp_option_value).encode(ExternalEncoding))
    def exportDict(self, name_='DhcpOptionType'):
        obj_json = json.dumps(self, default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        obj_dict = json.loads(obj_json)
        return {name_: obj_dict}
    def build(self, node):
        self.buildAttributes(node, node.attrib, [])
        for child in node:
            nodeName_ = Tag_pattern_.match(child.tag).groups()[-1]
            self.buildChildren(child, node, nodeName_)
    def buildAttributes(self, node, attrs, already_processed):
        pass
    def buildChildren(self, child_, node, nodeName_, fromsubclass_=False):
        if nodeName_ == 'dhcp-option-name':
            dhcp_option_name_ = child_.text
            dhcp_option_name_ = self.gds_validate_string(dhcp_option_name_, node, 'dhcp_option_name')
            self.dhcp_option_name = dhcp_option_name_
        elif nodeName_ == 'dhcp-option-value':
            dhcp_option_value_ = child_.text
            dhcp_option_value_ = self.gds_validate_string(dhcp_option_value_, node, 'dhcp_option_value')
            self.dhcp_option_value = dhcp_option_value_
# end class DhcpOptionType


class DhcpOptionsListType(GeneratedsSuper):
    """
    DhcpOptionsListType class definition from :doc:`vnc_cfg.xsd`
    """
    subclass = None
    superclass = None
    def __init__(self, dhcp_option=None, **kwargs):
        if (dhcp_option is None) or (dhcp_option == []):
            self.dhcp_option = []
        else:
            if isinstance(dhcp_option[0], dict):
                objs = [DhcpOptionType(**elem) for elem in dhcp_option]
                self.dhcp_option = objs
            else:
                self.dhcp_option = dhcp_option
    def factory(*args_, **kwargs_):
        if DhcpOptionsListType.subclass:
            return DhcpOptionsListType.subclass(*args_, **kwargs_)
        else:
            return DhcpOptionsListType(*args_, **kwargs_)
    factory = staticmethod(factory)
    def get_dhcp_option(self): return self.dhcp_option
    def set_dhcp_option(self, dhcp_option): self.dhcp_option = dhcp_option
    def add_dhcp_option(self, value): self.dhcp_option.append(value)
    def insert_dhcp_option(self, index, value): self.dhcp_option[index] = value
    @classmethod
    def populate (cls, *a, **kwa):
        obj = cls (*a, **kwa)
        obj.set_dhcp_option (DhcpOptionType.populate ())
        return obj
    def export(self, outfile, level=1, namespace_='', name_='DhcpOptionsListType', namespacedef_='', pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        showIndent(outfile, level, pretty_print)
        outfile.write('<%s%s%s' % (namespace_, name_, namespacedef_ and ' ' + namespacedef_ or '', ))
        already_processed = []
        self.exportAttributes(outfile, level, already_processed, namespace_, name_='DhcpOptionsListType')
        if self.hasContent_():
            outfile.write('>%s' % (eol_, ))
            self.exportChildren(outfile, level + 1, namespace_, name_, pretty_print=pretty_print)
            showIndent(outfile, level, pretty_print)
            outfile.write('</%s%s>%s' % (namespace_, name_, eol_))
        else:
            outfile.write('/>%s' % (eol_, ))
    def exportAttributes(self, outfile, level, already_processed, namespace_='', name_='DhcpOptionsListType'):
        pass
    def exportChildren(self, outfile, level, namespace_='', name_='DhcpOptionsListType', fromsubclass_=False, pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        for dhcp_option_ in self.dhcp_option:
            if isinstance(dhcp_option_, dict):
                dhcp_option_ = DhcpOptionType(**dhcp_option_)
            dhcp_option_.export(outfile, level, namespace_, name_='dhcp-option', pretty_print=pretty_print)
    def hasContent_(self):
        if (
            self.dhcp_option
            ):
            return True
        else:
            return False
    def exportLiteral(self, outfile, level, name_='DhcpOptionsListType'):
        level += 1
        self.exportLiteralAttributes(outfile, level, [], name_)
        if self.hasContent_():
            self.exportLiteralChildren(outfile, level, name_)
    def exportLiteralAttributes(self, outfile, level, already_processed, name_):
        pass
    def exportLiteralChildren(self, outfile, level, name_):
        showIndent(outfile, level)
        outfile.write('dhcp_option=[\n')
        level += 1
        for dhcp_option_ in self.dhcp_option:
            showIndent(outfile, level)
            outfile.write('model_.DhcpOptionType(\n')
            dhcp_option_.exportLiteral(outfile, level, name_='DhcpOptionType')
            showIndent(outfile, level)
            outfile.write('),\n')
        level -= 1
        showIndent(outfile, level)
        outfile.write('],\n')
    def exportDict(self, name_='DhcpOptionsListType'):
        obj_json = json.dumps(self, default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        obj_dict = json.loads(obj_json)
        return {name_: obj_dict}
    def build(self, node):
        self.buildAttributes(node, node.attrib, [])
        for child in node:
            nodeName_ = Tag_pattern_.match(child.tag).groups()[-1]
            self.buildChildren(child, node, nodeName_)
    def buildAttributes(self, node, attrs, already_processed):
        pass
    def buildChildren(self, child_, node, nodeName_, fromsubclass_=False):
        if nodeName_ == 'dhcp-option':
            obj_ = DhcpOptionType.factory()
            obj_.build(child_)
            self.dhcp_option.append(obj_)
# end class DhcpOptionsListType


class IpamDnsAddressType(GeneratedsSuper):
    """
    IpamDnsAddressType class definition from :doc:`vnc_cfg.xsd`
    """
    subclass = None
    superclass = None
    def __init__(self, tenant_dns_server_address=None, virtual_dns_server_name=None, **kwargs):
        if isinstance(tenant_dns_server_address, dict):
            obj = IpAddressesType(**tenant_dns_server_address)
            self.tenant_dns_server_address = obj
        else:
            self.tenant_dns_server_address = tenant_dns_server_address
        self.virtual_dns_server_name = virtual_dns_server_name
    def factory(*args_, **kwargs_):
        if IpamDnsAddressType.subclass:
            return IpamDnsAddressType.subclass(*args_, **kwargs_)
        else:
            return IpamDnsAddressType(*args_, **kwargs_)
    factory = staticmethod(factory)
    def get_tenant_dns_server_address(self): return self.tenant_dns_server_address
    def set_tenant_dns_server_address(self, tenant_dns_server_address): self.tenant_dns_server_address = tenant_dns_server_address
    def get_virtual_dns_server_name(self): return self.virtual_dns_server_name
    def set_virtual_dns_server_name(self, virtual_dns_server_name): self.virtual_dns_server_name = virtual_dns_server_name
    @classmethod
    def populate (cls, *a, **kwa):
        obj = cls (*a, **kwa)
        obj.set_tenant_dns_server_address (IpAddressesType.populate ())
        obj.set_virtual_dns_server_name (obj.populate_string ("virtual_dns_server_name"))
        return obj
    def export(self, outfile, level=1, namespace_='', name_='IpamDnsAddressType', namespacedef_='', pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        showIndent(outfile, level, pretty_print)
        outfile.write('<%s%s%s' % (namespace_, name_, namespacedef_ and ' ' + namespacedef_ or '', ))
        already_processed = []
        self.exportAttributes(outfile, level, already_processed, namespace_, name_='IpamDnsAddressType')
        if self.hasContent_():
            outfile.write('>%s' % (eol_, ))
            self.exportChildren(outfile, level + 1, namespace_, name_, pretty_print=pretty_print)
            showIndent(outfile, level, pretty_print)
            outfile.write('</%s%s>%s' % (namespace_, name_, eol_))
        else:
            outfile.write('/>%s' % (eol_, ))
    def exportAttributes(self, outfile, level, already_processed, namespace_='', name_='IpamDnsAddressType'):
        pass
    def exportChildren(self, outfile, level, namespace_='', name_='IpamDnsAddressType', fromsubclass_=False, pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        if self.tenant_dns_server_address is not None:
            self.tenant_dns_server_address.export(outfile, level, namespace_, name_='tenant-dns-server-address', pretty_print=pretty_print)
        if self.virtual_dns_server_name is not None:
            showIndent(outfile, level, pretty_print)
            outfile.write('<%svirtual-dns-server-name>%s</%svirtual-dns-server-name>%s' % (namespace_, self.gds_format_string(quote_xml(self.virtual_dns_server_name).encode(ExternalEncoding), input_name='virtual-dns-server-name'), namespace_, eol_))
    def hasContent_(self):
        if (
            self.tenant_dns_server_address is not None or
            self.virtual_dns_server_name is not None
            ):
            return True
        else:
            return False
    def exportLiteral(self, outfile, level, name_='IpamDnsAddressType'):
        level += 1
        self.exportLiteralAttributes(outfile, level, [], name_)
        if self.hasContent_():
            self.exportLiteralChildren(outfile, level, name_)
    def exportLiteralAttributes(self, outfile, level, already_processed, name_):
        pass
    def exportLiteralChildren(self, outfile, level, name_):
        if self.tenant_dns_server_address is not None:
            showIndent(outfile, level)
            outfile.write('tenant_dns_server_address=model_.IpAddressesType(\n')
            self.tenant_dns_server_address.exportLiteral(outfile, level, name_='tenant_dns_server_address')
            showIndent(outfile, level)
            outfile.write('),\n')
        if self.virtual_dns_server_name is not None:
            showIndent(outfile, level)
            outfile.write('virtual_dns_server_name=%s,\n' % quote_python(self.virtual_dns_server_name).encode(ExternalEncoding))
    def exportDict(self, name_='IpamDnsAddressType'):
        obj_json = json.dumps(self, default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        obj_dict = json.loads(obj_json)
        return {name_: obj_dict}
    def build(self, node):
        self.buildAttributes(node, node.attrib, [])
        for child in node:
            nodeName_ = Tag_pattern_.match(child.tag).groups()[-1]
            self.buildChildren(child, node, nodeName_)
    def buildAttributes(self, node, attrs, already_processed):
        pass
    def buildChildren(self, child_, node, nodeName_, fromsubclass_=False):
        if nodeName_ == 'tenant-dns-server-address':
            obj_ = IpAddressesType.factory()
            obj_.build(child_)
            self.set_tenant_dns_server_address(obj_)
        elif nodeName_ == 'virtual-dns-server-name':
            virtual_dns_server_name_ = child_.text
            virtual_dns_server_name_ = self.gds_validate_string(virtual_dns_server_name_, node, 'virtual_dns_server_name')
            self.virtual_dns_server_name = virtual_dns_server_name_
# end class IpamDnsAddressType


class IpamType(GeneratedsSuper):
    """
    IpamType class definition from :doc:`vnc_cfg.xsd`
    """
    subclass = None
    superclass = None
    def __init__(self, ipam_method=None, ipam_dns_method=None, ipam_dns_server=None, dhcp_option_list=None, cidr_block=None, **kwargs):
        self.ipam_method = ipam_method
        self.ipam_dns_method = ipam_dns_method
        if isinstance(ipam_dns_server, dict):
            obj = IpamDnsAddressType(**ipam_dns_server)
            self.ipam_dns_server = obj
        else:
            self.ipam_dns_server = ipam_dns_server
        if isinstance(dhcp_option_list, dict):
            obj = DhcpOptionsListType(**dhcp_option_list)
            self.dhcp_option_list = obj
        else:
            self.dhcp_option_list = dhcp_option_list
        if isinstance(cidr_block, dict):
            obj = SubnetType(**cidr_block)
            self.cidr_block = obj
        else:
            self.cidr_block = cidr_block
    def factory(*args_, **kwargs_):
        if IpamType.subclass:
            return IpamType.subclass(*args_, **kwargs_)
        else:
            return IpamType(*args_, **kwargs_)
    factory = staticmethod(factory)
    def get_ipam_method(self): return self.ipam_method
    def set_ipam_method(self, ipam_method): self.ipam_method = ipam_method
    def validate_IpamMethodType(self, value):
        # Validate type IpamMethodType, a restriction on xsd:string.
        pass
    def get_ipam_dns_method(self): return self.ipam_dns_method
    def set_ipam_dns_method(self, ipam_dns_method): self.ipam_dns_method = ipam_dns_method
    def validate_IpamDnsMethodType(self, value):
        # Validate type IpamDnsMethodType, a restriction on xsd:string.
        pass
    def get_ipam_dns_server(self): return self.ipam_dns_server
    def set_ipam_dns_server(self, ipam_dns_server): self.ipam_dns_server = ipam_dns_server
    def get_dhcp_option_list(self): return self.dhcp_option_list
    def set_dhcp_option_list(self, dhcp_option_list): self.dhcp_option_list = dhcp_option_list
    def get_cidr_block(self): return self.cidr_block
    def set_cidr_block(self, cidr_block): self.cidr_block = cidr_block
    @classmethod
    def populate (cls, *a, **kwa):
        obj = cls (*a, **kwa)
        obj.set_ipam_method (obj.populate_string ("ipam_method"))
        obj.set_ipam_dns_method (obj.populate_string ("ipam_dns_method"))
        obj.set_ipam_dns_server (IpamDnsAddressType.populate ())
        obj.set_dhcp_option_list (DhcpOptionsListType.populate ())
        obj.set_cidr_block (SubnetType.populate ())
        return obj
    def export(self, outfile, level=1, namespace_='', name_='IpamType', namespacedef_='', pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        showIndent(outfile, level, pretty_print)
        outfile.write('<%s%s%s' % (namespace_, name_, namespacedef_ and ' ' + namespacedef_ or '', ))
        already_processed = []
        self.exportAttributes(outfile, level, already_processed, namespace_, name_='IpamType')
        if self.hasContent_():
            outfile.write('>%s' % (eol_, ))
            self.exportChildren(outfile, level + 1, namespace_, name_, pretty_print=pretty_print)
            showIndent(outfile, level, pretty_print)
            outfile.write('</%s%s>%s' % (namespace_, name_, eol_))
        else:
            outfile.write('/>%s' % (eol_, ))
    def exportAttributes(self, outfile, level, already_processed, namespace_='', name_='IpamType'):
        pass
    def exportChildren(self, outfile, level, namespace_='', name_='IpamType', fromsubclass_=False, pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        if self.ipam_method is not None:
            showIndent(outfile, level, pretty_print)
            outfile.write('<%sipam-method>%s</%sipam-method>%s' % (namespace_, self.gds_format_string(quote_xml(self.ipam_method).encode(ExternalEncoding), input_name='ipam-method'), namespace_, eol_))
        if self.ipam_dns_method is not None:
            showIndent(outfile, level, pretty_print)
            outfile.write('<%sipam-dns-method>%s</%sipam-dns-method>%s' % (namespace_, self.gds_format_string(quote_xml(self.ipam_dns_method).encode(ExternalEncoding), input_name='ipam-dns-method'), namespace_, eol_))
        if self.ipam_dns_server is not None:
            self.ipam_dns_server.export(outfile, level, namespace_, name_='ipam-dns-server', pretty_print=pretty_print)
        if self.dhcp_option_list is not None:
            self.dhcp_option_list.export(outfile, level, namespace_, name_='dhcp-option-list', pretty_print=pretty_print)
        if self.cidr_block is not None:
            self.cidr_block.export(outfile, level, namespace_, name_='cidr-block', pretty_print=pretty_print)
    def hasContent_(self):
        if (
            self.ipam_method is not None or
            self.ipam_dns_method is not None or
            self.ipam_dns_server is not None or
            self.dhcp_option_list is not None or
            self.cidr_block is not None
            ):
            return True
        else:
            return False
    def exportLiteral(self, outfile, level, name_='IpamType'):
        level += 1
        self.exportLiteralAttributes(outfile, level, [], name_)
        if self.hasContent_():
            self.exportLiteralChildren(outfile, level, name_)
    def exportLiteralAttributes(self, outfile, level, already_processed, name_):
        pass
    def exportLiteralChildren(self, outfile, level, name_):
        if self.ipam_method is not None:
            showIndent(outfile, level)
            outfile.write('ipam_method=%s,\n' % quote_python(self.ipam_method).encode(ExternalEncoding))
        if self.ipam_dns_method is not None:
            showIndent(outfile, level)
            outfile.write('ipam_dns_method=%s,\n' % quote_python(self.ipam_dns_method).encode(ExternalEncoding))
        if self.ipam_dns_server is not None:
            showIndent(outfile, level)
            outfile.write('ipam_dns_server=model_.IpamDnsAddressType(\n')
            self.ipam_dns_server.exportLiteral(outfile, level, name_='ipam_dns_server')
            showIndent(outfile, level)
            outfile.write('),\n')
        if self.dhcp_option_list is not None:
            showIndent(outfile, level)
            outfile.write('dhcp_option_list=model_.DhcpOptionsListType(\n')
            self.dhcp_option_list.exportLiteral(outfile, level, name_='dhcp_option_list')
            showIndent(outfile, level)
            outfile.write('),\n')
        if self.cidr_block is not None:
            showIndent(outfile, level)
            outfile.write('cidr_block=model_.SubnetType(\n')
            self.cidr_block.exportLiteral(outfile, level, name_='cidr_block')
            showIndent(outfile, level)
            outfile.write('),\n')
    def exportDict(self, name_='IpamType'):
        obj_json = json.dumps(self, default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        obj_dict = json.loads(obj_json)
        return {name_: obj_dict}
    def build(self, node):
        self.buildAttributes(node, node.attrib, [])
        for child in node:
            nodeName_ = Tag_pattern_.match(child.tag).groups()[-1]
            self.buildChildren(child, node, nodeName_)
    def buildAttributes(self, node, attrs, already_processed):
        pass
    def buildChildren(self, child_, node, nodeName_, fromsubclass_=False):
        if nodeName_ == 'ipam-method':
            ipam_method_ = child_.text
            ipam_method_ = self.gds_validate_string(ipam_method_, node, 'ipam_method')
            self.ipam_method = ipam_method_
            self.validate_IpamMethodType(self.ipam_method)    # validate type IpamMethodType
        elif nodeName_ == 'ipam-dns-method':
            ipam_dns_method_ = child_.text
            ipam_dns_method_ = self.gds_validate_string(ipam_dns_method_, node, 'ipam_dns_method')
            self.ipam_dns_method = ipam_dns_method_
            self.validate_IpamDnsMethodType(self.ipam_dns_method)    # validate type IpamDnsMethodType
        elif nodeName_ == 'ipam-dns-server':
            obj_ = IpamDnsAddressType.factory()
            obj_.build(child_)
            self.set_ipam_dns_server(obj_)
        elif nodeName_ == 'dhcp-option-list':
            obj_ = DhcpOptionsListType.factory()
            obj_.build(child_)
            self.set_dhcp_option_list(obj_)
        elif nodeName_ == 'cidr-block':
            obj_ = SubnetType.factory()
            obj_.build(child_)
            self.set_cidr_block(obj_)
# end class IpamType


class VirtualDnsType(GeneratedsSuper):
    """
    VirtualDnsType class definition from :doc:`vnc_cfg.xsd`
    """
    subclass = None
    superclass = None
    def __init__(self, domain_name=None, dynamic_records_from_client=None, record_order=None, default_ttl_seconds=None, next_virtual_DNS=None, **kwargs):
        self.domain_name = domain_name
        self.dynamic_records_from_client = dynamic_records_from_client
        self.record_order = record_order
        self.default_ttl_seconds = default_ttl_seconds
        self.next_virtual_DNS = next_virtual_DNS
    def factory(*args_, **kwargs_):
        if VirtualDnsType.subclass:
            return VirtualDnsType.subclass(*args_, **kwargs_)
        else:
            return VirtualDnsType(*args_, **kwargs_)
    factory = staticmethod(factory)
    def get_domain_name(self): return self.domain_name
    def set_domain_name(self, domain_name): self.domain_name = domain_name
    def get_dynamic_records_from_client(self): return self.dynamic_records_from_client
    def set_dynamic_records_from_client(self, dynamic_records_from_client): self.dynamic_records_from_client = dynamic_records_from_client
    def get_record_order(self): return self.record_order
    def set_record_order(self, record_order): self.record_order = record_order
    def validate_DnsRecordOrderType(self, value):
        # Validate type DnsRecordOrderType, a restriction on xsd:string.
        pass
    def get_default_ttl_seconds(self): return self.default_ttl_seconds
    def set_default_ttl_seconds(self, default_ttl_seconds): self.default_ttl_seconds = default_ttl_seconds
    def get_next_virtual_DNS(self): return self.next_virtual_DNS
    def set_next_virtual_DNS(self, next_virtual_DNS): self.next_virtual_DNS = next_virtual_DNS
    @classmethod
    def populate (cls, *a, **kwa):
        obj = cls (*a, **kwa)
        obj.set_domain_name (obj.populate_string ("domain_name"))
        obj.set_dynamic_records_from_client (obj.populate_boolean ("dynamic_records_from_client"))
        obj.set_record_order (obj.populate_string ("record_order"))
        obj.set_default_ttl_seconds (obj.populate_integer ("default_ttl_seconds"))
        obj.set_next_virtual_DNS (obj.populate_string ("next_virtual_DNS"))
        return obj
    def export(self, outfile, level=1, namespace_='', name_='VirtualDnsType', namespacedef_='', pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        showIndent(outfile, level, pretty_print)
        outfile.write('<%s%s%s' % (namespace_, name_, namespacedef_ and ' ' + namespacedef_ or '', ))
        already_processed = []
        self.exportAttributes(outfile, level, already_processed, namespace_, name_='VirtualDnsType')
        if self.hasContent_():
            outfile.write('>%s' % (eol_, ))
            self.exportChildren(outfile, level + 1, namespace_, name_, pretty_print=pretty_print)
            showIndent(outfile, level, pretty_print)
            outfile.write('</%s%s>%s' % (namespace_, name_, eol_))
        else:
            outfile.write('/>%s' % (eol_, ))
    def exportAttributes(self, outfile, level, already_processed, namespace_='', name_='VirtualDnsType'):
        pass
    def exportChildren(self, outfile, level, namespace_='', name_='VirtualDnsType', fromsubclass_=False, pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        if self.domain_name is not None:
            showIndent(outfile, level, pretty_print)
            outfile.write('<%sdomain-name>%s</%sdomain-name>%s' % (namespace_, self.gds_format_string(quote_xml(self.domain_name).encode(ExternalEncoding), input_name='domain-name'), namespace_, eol_))
        if self.dynamic_records_from_client is not None:
            showIndent(outfile, level, pretty_print)
            outfile.write('<%sdynamic-records-from-client>%s</%sdynamic-records-from-client>%s' % (namespace_, self.gds_format_boolean(self.gds_str_lower(str(self.dynamic_records_from_client)), input_name='dynamic-records-from-client'), namespace_, eol_))
        if self.record_order is not None:
            showIndent(outfile, level, pretty_print)
            outfile.write('<%srecord-order>%s</%srecord-order>%s' % (namespace_, self.gds_format_string(quote_xml(self.record_order).encode(ExternalEncoding), input_name='record-order'), namespace_, eol_))
        if self.default_ttl_seconds is not None:
            showIndent(outfile, level, pretty_print)
            outfile.write('<%sdefault-ttl-seconds>%s</%sdefault-ttl-seconds>%s' % (namespace_, self.gds_format_integer(self.default_ttl_seconds, input_name='default-ttl-seconds'), namespace_, eol_))
        if self.next_virtual_DNS is not None:
            showIndent(outfile, level, pretty_print)
            outfile.write('<%snext-virtual-DNS>%s</%snext-virtual-DNS>%s' % (namespace_, self.gds_format_string(quote_xml(self.next_virtual_DNS).encode(ExternalEncoding), input_name='next-virtual-DNS'), namespace_, eol_))
    def hasContent_(self):
        if (
            self.domain_name is not None or
            self.dynamic_records_from_client is not None or
            self.record_order is not None or
            self.default_ttl_seconds is not None or
            self.next_virtual_DNS is not None
            ):
            return True
        else:
            return False
    def exportLiteral(self, outfile, level, name_='VirtualDnsType'):
        level += 1
        self.exportLiteralAttributes(outfile, level, [], name_)
        if self.hasContent_():
            self.exportLiteralChildren(outfile, level, name_)
    def exportLiteralAttributes(self, outfile, level, already_processed, name_):
        pass
    def exportLiteralChildren(self, outfile, level, name_):
        if self.domain_name is not None:
            showIndent(outfile, level)
            outfile.write('domain_name=%s,\n' % quote_python(self.domain_name).encode(ExternalEncoding))
        if self.dynamic_records_from_client is not None:
            showIndent(outfile, level)
            outfile.write('dynamic_records_from_client=%s,\n' % self.dynamic_records_from_client)
        if self.record_order is not None:
            showIndent(outfile, level)
            outfile.write('record_order=%s,\n' % quote_python(self.record_order).encode(ExternalEncoding))
        if self.default_ttl_seconds is not None:
            showIndent(outfile, level)
            outfile.write('default_ttl_seconds=%d,\n' % self.default_ttl_seconds)
        if self.next_virtual_DNS is not None:
            showIndent(outfile, level)
            outfile.write('next_virtual_DNS=%s,\n' % quote_python(self.next_virtual_DNS).encode(ExternalEncoding))
    def exportDict(self, name_='VirtualDnsType'):
        obj_json = json.dumps(self, default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        obj_dict = json.loads(obj_json)
        return {name_: obj_dict}
    def build(self, node):
        self.buildAttributes(node, node.attrib, [])
        for child in node:
            nodeName_ = Tag_pattern_.match(child.tag).groups()[-1]
            self.buildChildren(child, node, nodeName_)
    def buildAttributes(self, node, attrs, already_processed):
        pass
    def buildChildren(self, child_, node, nodeName_, fromsubclass_=False):
        if nodeName_ == 'domain-name':
            domain_name_ = child_.text
            domain_name_ = self.gds_validate_string(domain_name_, node, 'domain_name')
            self.domain_name = domain_name_
        elif nodeName_ == 'dynamic-records-from-client':
            sval_ = child_.text
            if sval_ in ('true', '1'):
                ival_ = True
            elif sval_ in ('false', '0'):
                ival_ = False
            else:
                raise_parse_error(child_, 'requires boolean')
            ival_ = self.gds_validate_boolean(ival_, node, 'dynamic_records_from_client')
            self.dynamic_records_from_client = ival_
        elif nodeName_ == 'record-order':
            record_order_ = child_.text
            record_order_ = self.gds_validate_string(record_order_, node, 'record_order')
            self.record_order = record_order_
            self.validate_DnsRecordOrderType(self.record_order)    # validate type DnsRecordOrderType
        elif nodeName_ == 'default-ttl-seconds':
            sval_ = child_.text
            try:
                ival_ = int(sval_)
            except (TypeError, ValueError), exp:
                raise_parse_error(child_, 'requires integer: %s' % exp)
            ival_ = self.gds_validate_integer(ival_, node, 'default_ttl_seconds')
            self.default_ttl_seconds = ival_
        elif nodeName_ == 'next-virtual-DNS':
            next_virtual_DNS_ = child_.text
            next_virtual_DNS_ = self.gds_validate_string(next_virtual_DNS_, node, 'next_virtual_DNS')
            self.next_virtual_DNS = next_virtual_DNS_
# end class VirtualDnsType


class VirtualDnsRecordType(GeneratedsSuper):
    """
    VirtualDnsRecordType class definition from :doc:`vnc_cfg.xsd`
    """
    subclass = None
    superclass = None
    def __init__(self, record_name=None, record_type=None, record_class=None, record_data=None, record_ttl_seconds=None, **kwargs):
        self.record_name = record_name
        self.record_type = record_type
        self.record_class = record_class
        self.record_data = record_data
        self.record_ttl_seconds = record_ttl_seconds
    def factory(*args_, **kwargs_):
        if VirtualDnsRecordType.subclass:
            return VirtualDnsRecordType.subclass(*args_, **kwargs_)
        else:
            return VirtualDnsRecordType(*args_, **kwargs_)
    factory = staticmethod(factory)
    def get_record_name(self): return self.record_name
    def set_record_name(self, record_name): self.record_name = record_name
    def get_record_type(self): return self.record_type
    def set_record_type(self, record_type): self.record_type = record_type
    def validate_DnsRecordTypeType(self, value):
        # Validate type DnsRecordTypeType, a restriction on xsd:string.
        pass
    def get_record_class(self): return self.record_class
    def set_record_class(self, record_class): self.record_class = record_class
    def validate_DnsRecordClassType(self, value):
        # Validate type DnsRecordClassType, a restriction on xsd:string.
        pass
    def get_record_data(self): return self.record_data
    def set_record_data(self, record_data): self.record_data = record_data
    def get_record_ttl_seconds(self): return self.record_ttl_seconds
    def set_record_ttl_seconds(self, record_ttl_seconds): self.record_ttl_seconds = record_ttl_seconds
    @classmethod
    def populate (cls, *a, **kwa):
        obj = cls (*a, **kwa)
        obj.set_record_name (obj.populate_string ("record_name"))
        obj.set_record_type (obj.populate_string ("record_type"))
        obj.set_record_class (obj.populate_string ("record_class"))
        obj.set_record_data (obj.populate_string ("record_data"))
        obj.set_record_ttl_seconds (obj.populate_integer ("record_ttl_seconds"))
        return obj
    def export(self, outfile, level=1, namespace_='', name_='VirtualDnsRecordType', namespacedef_='', pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        showIndent(outfile, level, pretty_print)
        outfile.write('<%s%s%s' % (namespace_, name_, namespacedef_ and ' ' + namespacedef_ or '', ))
        already_processed = []
        self.exportAttributes(outfile, level, already_processed, namespace_, name_='VirtualDnsRecordType')
        if self.hasContent_():
            outfile.write('>%s' % (eol_, ))
            self.exportChildren(outfile, level + 1, namespace_, name_, pretty_print=pretty_print)
            showIndent(outfile, level, pretty_print)
            outfile.write('</%s%s>%s' % (namespace_, name_, eol_))
        else:
            outfile.write('/>%s' % (eol_, ))
    def exportAttributes(self, outfile, level, already_processed, namespace_='', name_='VirtualDnsRecordType'):
        pass
    def exportChildren(self, outfile, level, namespace_='', name_='VirtualDnsRecordType', fromsubclass_=False, pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        if self.record_name is not None:
            showIndent(outfile, level, pretty_print)
            outfile.write('<%srecord-name>%s</%srecord-name>%s' % (namespace_, self.gds_format_string(quote_xml(self.record_name).encode(ExternalEncoding), input_name='record-name'), namespace_, eol_))
        if self.record_type is not None:
            showIndent(outfile, level, pretty_print)
            outfile.write('<%srecord-type>%s</%srecord-type>%s' % (namespace_, self.gds_format_string(quote_xml(self.record_type).encode(ExternalEncoding), input_name='record-type'), namespace_, eol_))
        if self.record_class is not None:
            showIndent(outfile, level, pretty_print)
            outfile.write('<%srecord-class>%s</%srecord-class>%s' % (namespace_, self.gds_format_string(quote_xml(self.record_class).encode(ExternalEncoding), input_name='record-class'), namespace_, eol_))
        if self.record_data is not None:
            showIndent(outfile, level, pretty_print)
            outfile.write('<%srecord-data>%s</%srecord-data>%s' % (namespace_, self.gds_format_string(quote_xml(self.record_data).encode(ExternalEncoding), input_name='record-data'), namespace_, eol_))
        if self.record_ttl_seconds is not None:
            showIndent(outfile, level, pretty_print)
            outfile.write('<%srecord-ttl-seconds>%s</%srecord-ttl-seconds>%s' % (namespace_, self.gds_format_integer(self.record_ttl_seconds, input_name='record-ttl-seconds'), namespace_, eol_))
    def hasContent_(self):
        if (
            self.record_name is not None or
            self.record_type is not None or
            self.record_class is not None or
            self.record_data is not None or
            self.record_ttl_seconds is not None
            ):
            return True
        else:
            return False
    def exportLiteral(self, outfile, level, name_='VirtualDnsRecordType'):
        level += 1
        self.exportLiteralAttributes(outfile, level, [], name_)
        if self.hasContent_():
            self.exportLiteralChildren(outfile, level, name_)
    def exportLiteralAttributes(self, outfile, level, already_processed, name_):
        pass
    def exportLiteralChildren(self, outfile, level, name_):
        if self.record_name is not None:
            showIndent(outfile, level)
            outfile.write('record_name=%s,\n' % quote_python(self.record_name).encode(ExternalEncoding))
        if self.record_type is not None:
            showIndent(outfile, level)
            outfile.write('record_type=%s,\n' % quote_python(self.record_type).encode(ExternalEncoding))
        if self.record_class is not None:
            showIndent(outfile, level)
            outfile.write('record_class=%s,\n' % quote_python(self.record_class).encode(ExternalEncoding))
        if self.record_data is not None:
            showIndent(outfile, level)
            outfile.write('record_data=%s,\n' % quote_python(self.record_data).encode(ExternalEncoding))
        if self.record_ttl_seconds is not None:
            showIndent(outfile, level)
            outfile.write('record_ttl_seconds=%d,\n' % self.record_ttl_seconds)
    def exportDict(self, name_='VirtualDnsRecordType'):
        obj_json = json.dumps(self, default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        obj_dict = json.loads(obj_json)
        return {name_: obj_dict}
    def build(self, node):
        self.buildAttributes(node, node.attrib, [])
        for child in node:
            nodeName_ = Tag_pattern_.match(child.tag).groups()[-1]
            self.buildChildren(child, node, nodeName_)
    def buildAttributes(self, node, attrs, already_processed):
        pass
    def buildChildren(self, child_, node, nodeName_, fromsubclass_=False):
        if nodeName_ == 'record-name':
            record_name_ = child_.text
            record_name_ = self.gds_validate_string(record_name_, node, 'record_name')
            self.record_name = record_name_
        elif nodeName_ == 'record-type':
            record_type_ = child_.text
            record_type_ = self.gds_validate_string(record_type_, node, 'record_type')
            self.record_type = record_type_
            self.validate_DnsRecordTypeType(self.record_type)    # validate type DnsRecordTypeType
        elif nodeName_ == 'record-class':
            record_class_ = child_.text
            record_class_ = self.gds_validate_string(record_class_, node, 'record_class')
            self.record_class = record_class_
            self.validate_DnsRecordClassType(self.record_class)    # validate type DnsRecordClassType
        elif nodeName_ == 'record-data':
            record_data_ = child_.text
            record_data_ = self.gds_validate_string(record_data_, node, 'record_data')
            self.record_data = record_data_
        elif nodeName_ == 'record-ttl-seconds':
            sval_ = child_.text
            try:
                ival_ = int(sval_)
            except (TypeError, ValueError), exp:
                raise_parse_error(child_, 'requires integer: %s' % exp)
            ival_ = self.gds_validate_integer(ival_, node, 'record_ttl_seconds')
            self.record_ttl_seconds = ival_
# end class VirtualDnsRecordType


class FloatingIpPoolType(GeneratedsSuper):
    """
    FloatingIpPoolType class definition from :doc:`vnc_cfg.xsd`
    """
    subclass = None
    superclass = None
    def __init__(self, subnet=None, **kwargs):
        if (subnet is None) or (subnet == []):
            self.subnet = []
        else:
            if isinstance(subnet[0], dict):
                objs = [SubnetType(**elem) for elem in subnet]
                self.subnet = objs
            else:
                self.subnet = subnet
    def factory(*args_, **kwargs_):
        if FloatingIpPoolType.subclass:
            return FloatingIpPoolType.subclass(*args_, **kwargs_)
        else:
            return FloatingIpPoolType(*args_, **kwargs_)
    factory = staticmethod(factory)
    def get_subnet(self): return self.subnet
    def set_subnet(self, subnet): self.subnet = subnet
    def add_subnet(self, value): self.subnet.append(value)
    def insert_subnet(self, index, value): self.subnet[index] = value
    @classmethod
    def populate (cls, *a, **kwa):
        obj = cls (*a, **kwa)
        obj.set_subnet (SubnetType.populate ())
        return obj
    def export(self, outfile, level=1, namespace_='', name_='FloatingIpPoolType', namespacedef_='', pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        showIndent(outfile, level, pretty_print)
        outfile.write('<%s%s%s' % (namespace_, name_, namespacedef_ and ' ' + namespacedef_ or '', ))
        already_processed = []
        self.exportAttributes(outfile, level, already_processed, namespace_, name_='FloatingIpPoolType')
        if self.hasContent_():
            outfile.write('>%s' % (eol_, ))
            self.exportChildren(outfile, level + 1, namespace_, name_, pretty_print=pretty_print)
            showIndent(outfile, level, pretty_print)
            outfile.write('</%s%s>%s' % (namespace_, name_, eol_))
        else:
            outfile.write('/>%s' % (eol_, ))
    def exportAttributes(self, outfile, level, already_processed, namespace_='', name_='FloatingIpPoolType'):
        pass
    def exportChildren(self, outfile, level, namespace_='', name_='FloatingIpPoolType', fromsubclass_=False, pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        for subnet_ in self.subnet:
            if isinstance(subnet_, dict):
                subnet_ = SubnetType(**subnet_)
            subnet_.export(outfile, level, namespace_, name_='subnet', pretty_print=pretty_print)
    def hasContent_(self):
        if (
            self.subnet
            ):
            return True
        else:
            return False
    def exportLiteral(self, outfile, level, name_='FloatingIpPoolType'):
        level += 1
        self.exportLiteralAttributes(outfile, level, [], name_)
        if self.hasContent_():
            self.exportLiteralChildren(outfile, level, name_)
    def exportLiteralAttributes(self, outfile, level, already_processed, name_):
        pass
    def exportLiteralChildren(self, outfile, level, name_):
        showIndent(outfile, level)
        outfile.write('subnet=[\n')
        level += 1
        for subnet_ in self.subnet:
            showIndent(outfile, level)
            outfile.write('model_.SubnetType(\n')
            subnet_.exportLiteral(outfile, level, name_='SubnetType')
            showIndent(outfile, level)
            outfile.write('),\n')
        level -= 1
        showIndent(outfile, level)
        outfile.write('],\n')
    def exportDict(self, name_='FloatingIpPoolType'):
        obj_json = json.dumps(self, default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        obj_dict = json.loads(obj_json)
        return {name_: obj_dict}
    def build(self, node):
        self.buildAttributes(node, node.attrib, [])
        for child in node:
            nodeName_ = Tag_pattern_.match(child.tag).groups()[-1]
            self.buildChildren(child, node, nodeName_)
    def buildAttributes(self, node, attrs, already_processed):
        pass
    def buildChildren(self, child_, node, nodeName_, fromsubclass_=False):
        if nodeName_ == 'subnet':
            obj_ = SubnetType.factory()
            obj_.build(child_)
            self.subnet.append(obj_)
# end class FloatingIpPoolType


class IpamSubnetType(GeneratedsSuper):
    """
    IpamSubnetType class definition from :doc:`vnc_cfg.xsd`
    """
    subclass = None
    superclass = None
    def __init__(self, subnet=None, default_gateway=None, **kwargs):
        if isinstance(subnet, dict):
            obj = SubnetType(**subnet)
            self.subnet = obj
        else:
            self.subnet = subnet
        self.default_gateway = default_gateway
    def factory(*args_, **kwargs_):
        if IpamSubnetType.subclass:
            return IpamSubnetType.subclass(*args_, **kwargs_)
        else:
            return IpamSubnetType(*args_, **kwargs_)
    factory = staticmethod(factory)
    def get_subnet(self): return self.subnet
    def set_subnet(self, subnet): self.subnet = subnet
    def get_default_gateway(self): return self.default_gateway
    def set_default_gateway(self, default_gateway): self.default_gateway = default_gateway
    def validate_IpAddressType(self, value):
        # Validate type IpAddressType, a restriction on xsd:string.
        pass
    @classmethod
    def populate (cls, *a, **kwa):
        obj = cls (*a, **kwa)
        obj.set_subnet (SubnetType.populate ())
        obj.set_default_gateway (obj.populate_string ("default_gateway"))
        return obj
    def export(self, outfile, level=1, namespace_='', name_='IpamSubnetType', namespacedef_='', pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        showIndent(outfile, level, pretty_print)
        outfile.write('<%s%s%s' % (namespace_, name_, namespacedef_ and ' ' + namespacedef_ or '', ))
        already_processed = []
        self.exportAttributes(outfile, level, already_processed, namespace_, name_='IpamSubnetType')
        if self.hasContent_():
            outfile.write('>%s' % (eol_, ))
            self.exportChildren(outfile, level + 1, namespace_, name_, pretty_print=pretty_print)
            showIndent(outfile, level, pretty_print)
            outfile.write('</%s%s>%s' % (namespace_, name_, eol_))
        else:
            outfile.write('/>%s' % (eol_, ))
    def exportAttributes(self, outfile, level, already_processed, namespace_='', name_='IpamSubnetType'):
        pass
    def exportChildren(self, outfile, level, namespace_='', name_='IpamSubnetType', fromsubclass_=False, pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        if self.subnet is not None:
            self.subnet.export(outfile, level, namespace_, name_='subnet', pretty_print=pretty_print)
        if self.default_gateway is not None:
            showIndent(outfile, level, pretty_print)
            outfile.write('<%sdefault-gateway>%s</%sdefault-gateway>%s' % (namespace_, self.gds_format_string(quote_xml(self.default_gateway).encode(ExternalEncoding), input_name='default-gateway'), namespace_, eol_))
    def hasContent_(self):
        if (
            self.subnet is not None or
            self.default_gateway is not None
            ):
            return True
        else:
            return False
    def exportLiteral(self, outfile, level, name_='IpamSubnetType'):
        level += 1
        self.exportLiteralAttributes(outfile, level, [], name_)
        if self.hasContent_():
            self.exportLiteralChildren(outfile, level, name_)
    def exportLiteralAttributes(self, outfile, level, already_processed, name_):
        pass
    def exportLiteralChildren(self, outfile, level, name_):
        if self.subnet is not None:
            showIndent(outfile, level)
            outfile.write('subnet=model_.SubnetType(\n')
            self.subnet.exportLiteral(outfile, level, name_='subnet')
            showIndent(outfile, level)
            outfile.write('),\n')
        if self.default_gateway is not None:
            showIndent(outfile, level)
            outfile.write('default_gateway=%s,\n' % quote_python(self.default_gateway).encode(ExternalEncoding))
    def exportDict(self, name_='IpamSubnetType'):
        obj_json = json.dumps(self, default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        obj_dict = json.loads(obj_json)
        return {name_: obj_dict}
    def build(self, node):
        self.buildAttributes(node, node.attrib, [])
        for child in node:
            nodeName_ = Tag_pattern_.match(child.tag).groups()[-1]
            self.buildChildren(child, node, nodeName_)
    def buildAttributes(self, node, attrs, already_processed):
        pass
    def buildChildren(self, child_, node, nodeName_, fromsubclass_=False):
        if nodeName_ == 'subnet':
            obj_ = SubnetType.factory()
            obj_.build(child_)
            self.set_subnet(obj_)
        elif nodeName_ == 'default-gateway':
            default_gateway_ = child_.text
            default_gateway_ = self.gds_validate_string(default_gateway_, node, 'default_gateway')
            self.default_gateway = default_gateway_
            self.validate_IpAddressType(self.default_gateway)    # validate type IpAddressType
# end class IpamSubnetType


class VnSubnetsType(GeneratedsSuper):
    """
    VnSubnetsType class definition from :doc:`vnc_cfg.xsd`
    """
    subclass = None
    superclass = None
    def __init__(self, ipam_subnets=None, **kwargs):
        if (ipam_subnets is None) or (ipam_subnets == []):
            self.ipam_subnets = []
        else:
            if isinstance(ipam_subnets[0], dict):
                objs = [IpamSubnetType(**elem) for elem in ipam_subnets]
                self.ipam_subnets = objs
            else:
                self.ipam_subnets = ipam_subnets
    def factory(*args_, **kwargs_):
        if VnSubnetsType.subclass:
            return VnSubnetsType.subclass(*args_, **kwargs_)
        else:
            return VnSubnetsType(*args_, **kwargs_)
    factory = staticmethod(factory)
    def get_ipam_subnets(self): return self.ipam_subnets
    def set_ipam_subnets(self, ipam_subnets): self.ipam_subnets = ipam_subnets
    def add_ipam_subnets(self, value): self.ipam_subnets.append(value)
    def insert_ipam_subnets(self, index, value): self.ipam_subnets[index] = value
    @classmethod
    def populate (cls, *a, **kwa):
        obj = cls (*a, **kwa)
        obj.set_ipam_subnets (IpamSubnetType.populate ())
        return obj
    def export(self, outfile, level=1, namespace_='', name_='VnSubnetsType', namespacedef_='', pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        showIndent(outfile, level, pretty_print)
        outfile.write('<%s%s%s' % (namespace_, name_, namespacedef_ and ' ' + namespacedef_ or '', ))
        already_processed = []
        self.exportAttributes(outfile, level, already_processed, namespace_, name_='VnSubnetsType')
        if self.hasContent_():
            outfile.write('>%s' % (eol_, ))
            self.exportChildren(outfile, level + 1, namespace_, name_, pretty_print=pretty_print)
            showIndent(outfile, level, pretty_print)
            outfile.write('</%s%s>%s' % (namespace_, name_, eol_))
        else:
            outfile.write('/>%s' % (eol_, ))
    def exportAttributes(self, outfile, level, already_processed, namespace_='', name_='VnSubnetsType'):
        pass
    def exportChildren(self, outfile, level, namespace_='', name_='VnSubnetsType', fromsubclass_=False, pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        for ipam_subnets_ in self.ipam_subnets:
            if isinstance(ipam_subnets_, dict):
                ipam_subnets_ = IpamSubnetType(**ipam_subnets_)
            ipam_subnets_.export(outfile, level, namespace_, name_='ipam-subnets', pretty_print=pretty_print)
    def hasContent_(self):
        if (
            self.ipam_subnets
            ):
            return True
        else:
            return False
    def exportLiteral(self, outfile, level, name_='VnSubnetsType'):
        level += 1
        self.exportLiteralAttributes(outfile, level, [], name_)
        if self.hasContent_():
            self.exportLiteralChildren(outfile, level, name_)
    def exportLiteralAttributes(self, outfile, level, already_processed, name_):
        pass
    def exportLiteralChildren(self, outfile, level, name_):
        showIndent(outfile, level)
        outfile.write('ipam_subnets=[\n')
        level += 1
        for ipam_subnets_ in self.ipam_subnets:
            showIndent(outfile, level)
            outfile.write('model_.IpamSubnetType(\n')
            ipam_subnets_.exportLiteral(outfile, level, name_='IpamSubnetType')
            showIndent(outfile, level)
            outfile.write('),\n')
        level -= 1
        showIndent(outfile, level)
        outfile.write('],\n')
    def exportDict(self, name_='VnSubnetsType'):
        obj_json = json.dumps(self, default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        obj_dict = json.loads(obj_json)
        return {name_: obj_dict}
    def build(self, node):
        self.buildAttributes(node, node.attrib, [])
        for child in node:
            nodeName_ = Tag_pattern_.match(child.tag).groups()[-1]
            self.buildChildren(child, node, nodeName_)
    def buildAttributes(self, node, attrs, already_processed):
        pass
    def buildChildren(self, child_, node, nodeName_, fromsubclass_=False):
        if nodeName_ == 'ipam-subnets':
            obj_ = IpamSubnetType.factory()
            obj_.build(child_)
            self.ipam_subnets.append(obj_)
# end class VnSubnetsType


class DomainLimitsType(GeneratedsSuper):
    """
    DomainLimitsType class definition from :doc:`vnc_cfg.xsd`
    """
    subclass = None
    superclass = None
    def __init__(self, project_limit=None, virtual_network_limit=None, security_group_limit=None, **kwargs):
        self.project_limit = project_limit
        self.virtual_network_limit = virtual_network_limit
        self.security_group_limit = security_group_limit
    def factory(*args_, **kwargs_):
        if DomainLimitsType.subclass:
            return DomainLimitsType.subclass(*args_, **kwargs_)
        else:
            return DomainLimitsType(*args_, **kwargs_)
    factory = staticmethod(factory)
    def get_project_limit(self): return self.project_limit
    def set_project_limit(self, project_limit): self.project_limit = project_limit
    def get_virtual_network_limit(self): return self.virtual_network_limit
    def set_virtual_network_limit(self, virtual_network_limit): self.virtual_network_limit = virtual_network_limit
    def get_security_group_limit(self): return self.security_group_limit
    def set_security_group_limit(self, security_group_limit): self.security_group_limit = security_group_limit
    @classmethod
    def populate (cls, *a, **kwa):
        obj = cls (*a, **kwa)
        obj.set_project_limit (obj.populate_integer ("project_limit"))
        obj.set_virtual_network_limit (obj.populate_integer ("virtual_network_limit"))
        obj.set_security_group_limit (obj.populate_integer ("security_group_limit"))
        return obj
    def export(self, outfile, level=1, namespace_='', name_='DomainLimitsType', namespacedef_='', pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        showIndent(outfile, level, pretty_print)
        outfile.write('<%s%s%s' % (namespace_, name_, namespacedef_ and ' ' + namespacedef_ or '', ))
        already_processed = []
        self.exportAttributes(outfile, level, already_processed, namespace_, name_='DomainLimitsType')
        if self.hasContent_():
            outfile.write('>%s' % (eol_, ))
            self.exportChildren(outfile, level + 1, namespace_, name_, pretty_print=pretty_print)
            showIndent(outfile, level, pretty_print)
            outfile.write('</%s%s>%s' % (namespace_, name_, eol_))
        else:
            outfile.write('/>%s' % (eol_, ))
    def exportAttributes(self, outfile, level, already_processed, namespace_='', name_='DomainLimitsType'):
        pass
    def exportChildren(self, outfile, level, namespace_='', name_='DomainLimitsType', fromsubclass_=False, pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        if self.project_limit is not None:
            showIndent(outfile, level, pretty_print)
            outfile.write('<%sproject-limit>%s</%sproject-limit>%s' % (namespace_, self.gds_format_integer(self.project_limit, input_name='project-limit'), namespace_, eol_))
        if self.virtual_network_limit is not None:
            showIndent(outfile, level, pretty_print)
            outfile.write('<%svirtual-network-limit>%s</%svirtual-network-limit>%s' % (namespace_, self.gds_format_integer(self.virtual_network_limit, input_name='virtual-network-limit'), namespace_, eol_))
        if self.security_group_limit is not None:
            showIndent(outfile, level, pretty_print)
            outfile.write('<%ssecurity-group-limit>%s</%ssecurity-group-limit>%s' % (namespace_, self.gds_format_integer(self.security_group_limit, input_name='security-group-limit'), namespace_, eol_))
    def hasContent_(self):
        if (
            self.project_limit is not None or
            self.virtual_network_limit is not None or
            self.security_group_limit is not None
            ):
            return True
        else:
            return False
    def exportLiteral(self, outfile, level, name_='DomainLimitsType'):
        level += 1
        self.exportLiteralAttributes(outfile, level, [], name_)
        if self.hasContent_():
            self.exportLiteralChildren(outfile, level, name_)
    def exportLiteralAttributes(self, outfile, level, already_processed, name_):
        pass
    def exportLiteralChildren(self, outfile, level, name_):
        if self.project_limit is not None:
            showIndent(outfile, level)
            outfile.write('project_limit=%d,\n' % self.project_limit)
        if self.virtual_network_limit is not None:
            showIndent(outfile, level)
            outfile.write('virtual_network_limit=%d,\n' % self.virtual_network_limit)
        if self.security_group_limit is not None:
            showIndent(outfile, level)
            outfile.write('security_group_limit=%d,\n' % self.security_group_limit)
    def exportDict(self, name_='DomainLimitsType'):
        obj_json = json.dumps(self, default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        obj_dict = json.loads(obj_json)
        return {name_: obj_dict}
    def build(self, node):
        self.buildAttributes(node, node.attrib, [])
        for child in node:
            nodeName_ = Tag_pattern_.match(child.tag).groups()[-1]
            self.buildChildren(child, node, nodeName_)
    def buildAttributes(self, node, attrs, already_processed):
        pass
    def buildChildren(self, child_, node, nodeName_, fromsubclass_=False):
        if nodeName_ == 'project-limit':
            sval_ = child_.text
            try:
                ival_ = int(sval_)
            except (TypeError, ValueError), exp:
                raise_parse_error(child_, 'requires integer: %s' % exp)
            ival_ = self.gds_validate_integer(ival_, node, 'project_limit')
            self.project_limit = ival_
        elif nodeName_ == 'virtual-network-limit':
            sval_ = child_.text
            try:
                ival_ = int(sval_)
            except (TypeError, ValueError), exp:
                raise_parse_error(child_, 'requires integer: %s' % exp)
            ival_ = self.gds_validate_integer(ival_, node, 'virtual_network_limit')
            self.virtual_network_limit = ival_
        elif nodeName_ == 'security-group-limit':
            sval_ = child_.text
            try:
                ival_ = int(sval_)
            except (TypeError, ValueError), exp:
                raise_parse_error(child_, 'requires integer: %s' % exp)
            ival_ = self.gds_validate_integer(ival_, node, 'security_group_limit')
            self.security_group_limit = ival_
# end class DomainLimitsType


class PermType(GeneratedsSuper):
    """
    PermType class definition from :doc:`vnc_cfg.xsd`
    """
    subclass = None
    superclass = None
    def __init__(self, owner=None, owner_access=None, group=None, group_access=None, other_access=None, **kwargs):
        self.owner = owner
        self.owner_access = owner_access
        self.group = group
        self.group_access = group_access
        self.other_access = other_access
    def factory(*args_, **kwargs_):
        if PermType.subclass:
            return PermType.subclass(*args_, **kwargs_)
        else:
            return PermType(*args_, **kwargs_)
    factory = staticmethod(factory)
    def get_owner(self): return self.owner
    def set_owner(self, owner): self.owner = owner
    def get_owner_access(self): return self.owner_access
    def set_owner_access(self, owner_access): self.owner_access = owner_access
    def validate_AccessType(self, value):
        # Validate type AccessType, a restriction on xsd:integer.
        pass
    def get_group(self): return self.group
    def set_group(self, group): self.group = group
    def get_group_access(self): return self.group_access
    def set_group_access(self, group_access): self.group_access = group_access
    def get_other_access(self): return self.other_access
    def set_other_access(self, other_access): self.other_access = other_access
    @classmethod
    def populate (cls, *a, **kwa):
        obj = cls (*a, **kwa)
        obj.set_owner (obj.populate_string ("owner"))
        obj.set_owner_access (obj.populate_integer ("owner_access"))
        obj.set_group (obj.populate_string ("group"))
        obj.set_group_access (obj.populate_integer ("group_access"))
        obj.set_other_access (obj.populate_integer ("other_access"))
        return obj
    def export(self, outfile, level=1, namespace_='', name_='PermType', namespacedef_='', pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        showIndent(outfile, level, pretty_print)
        outfile.write('<%s%s%s' % (namespace_, name_, namespacedef_ and ' ' + namespacedef_ or '', ))
        already_processed = []
        self.exportAttributes(outfile, level, already_processed, namespace_, name_='PermType')
        if self.hasContent_():
            outfile.write('>%s' % (eol_, ))
            self.exportChildren(outfile, level + 1, namespace_, name_, pretty_print=pretty_print)
            showIndent(outfile, level, pretty_print)
            outfile.write('</%s%s>%s' % (namespace_, name_, eol_))
        else:
            outfile.write('/>%s' % (eol_, ))
    def exportAttributes(self, outfile, level, already_processed, namespace_='', name_='PermType'):
        pass
    def exportChildren(self, outfile, level, namespace_='', name_='PermType', fromsubclass_=False, pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        if self.owner is not None:
            showIndent(outfile, level, pretty_print)
            outfile.write('<%sowner>%s</%sowner>%s' % (namespace_, self.gds_format_string(quote_xml(self.owner).encode(ExternalEncoding), input_name='owner'), namespace_, eol_))
        if self.owner_access is not None:
            showIndent(outfile, level, pretty_print)
            outfile.write('<%sowner-access>%s</%sowner-access>%s' % (namespace_, self.gds_format_integer(self.owner_access, input_name='owner-access'), namespace_, eol_))
        if self.group is not None:
            showIndent(outfile, level, pretty_print)
            outfile.write('<%sgroup>%s</%sgroup>%s' % (namespace_, self.gds_format_string(quote_xml(self.group).encode(ExternalEncoding), input_name='group'), namespace_, eol_))
        if self.group_access is not None:
            showIndent(outfile, level, pretty_print)
            outfile.write('<%sgroup-access>%s</%sgroup-access>%s' % (namespace_, self.gds_format_integer(self.group_access, input_name='group-access'), namespace_, eol_))
        if self.other_access is not None:
            showIndent(outfile, level, pretty_print)
            outfile.write('<%sother-access>%s</%sother-access>%s' % (namespace_, self.gds_format_integer(self.other_access, input_name='other-access'), namespace_, eol_))
    def hasContent_(self):
        if (
            self.owner is not None or
            self.owner_access is not None or
            self.group is not None or
            self.group_access is not None or
            self.other_access is not None
            ):
            return True
        else:
            return False
    def exportLiteral(self, outfile, level, name_='PermType'):
        level += 1
        self.exportLiteralAttributes(outfile, level, [], name_)
        if self.hasContent_():
            self.exportLiteralChildren(outfile, level, name_)
    def exportLiteralAttributes(self, outfile, level, already_processed, name_):
        pass
    def exportLiteralChildren(self, outfile, level, name_):
        if self.owner is not None:
            showIndent(outfile, level)
            outfile.write('owner=%s,\n' % quote_python(self.owner).encode(ExternalEncoding))
        if self.owner_access is not None:
            showIndent(outfile, level)
            outfile.write('owner_access=%d,\n' % self.owner_access)
        if self.group is not None:
            showIndent(outfile, level)
            outfile.write('group=%s,\n' % quote_python(self.group).encode(ExternalEncoding))
        if self.group_access is not None:
            showIndent(outfile, level)
            outfile.write('group_access=%d,\n' % self.group_access)
        if self.other_access is not None:
            showIndent(outfile, level)
            outfile.write('other_access=%d,\n' % self.other_access)
    def exportDict(self, name_='PermType'):
        obj_json = json.dumps(self, default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        obj_dict = json.loads(obj_json)
        return {name_: obj_dict}
    def build(self, node):
        self.buildAttributes(node, node.attrib, [])
        for child in node:
            nodeName_ = Tag_pattern_.match(child.tag).groups()[-1]
            self.buildChildren(child, node, nodeName_)
    def buildAttributes(self, node, attrs, already_processed):
        pass
    def buildChildren(self, child_, node, nodeName_, fromsubclass_=False):
        if nodeName_ == 'owner':
            owner_ = child_.text
            owner_ = self.gds_validate_string(owner_, node, 'owner')
            self.owner = owner_
        elif nodeName_ == 'owner-access':
            sval_ = child_.text
            try:
                ival_ = int(sval_)
            except (TypeError, ValueError), exp:
                raise_parse_error(child_, 'requires integer: %s' % exp)
            ival_ = self.gds_validate_integer(ival_, node, 'owner_access')
            self.owner_access = ival_
            self.validate_AccessType(self.owner_access)    # validate type AccessType
        elif nodeName_ == 'group':
            group_ = child_.text
            group_ = self.gds_validate_string(group_, node, 'group')
            self.group = group_
        elif nodeName_ == 'group-access':
            sval_ = child_.text
            try:
                ival_ = int(sval_)
            except (TypeError, ValueError), exp:
                raise_parse_error(child_, 'requires integer: %s' % exp)
            ival_ = self.gds_validate_integer(ival_, node, 'group_access')
            self.group_access = ival_
            self.validate_AccessType(self.group_access)    # validate type AccessType
        elif nodeName_ == 'other-access':
            sval_ = child_.text
            try:
                ival_ = int(sval_)
            except (TypeError, ValueError), exp:
                raise_parse_error(child_, 'requires integer: %s' % exp)
            ival_ = self.gds_validate_integer(ival_, node, 'other_access')
            self.other_access = ival_
            self.validate_AccessType(self.other_access)    # validate type AccessType
# end class PermType


class IdPermsType(GeneratedsSuper):
    """
    IdPermsType class definition from :doc:`vnc_cfg.xsd`
    """
    subclass = None
    superclass = None
    def __init__(self, permissions=None, uuid=None, enable=None, created=None, last_modified=None, description=None, **kwargs):
        if isinstance(permissions, dict):
            obj = PermType(**permissions)
            self.permissions = obj
        else:
            self.permissions = permissions
        if isinstance(uuid, dict):
            obj = UuidType(**uuid)
            self.uuid = obj
        else:
            self.uuid = uuid
        self.enable = enable
        self.created = created
        self.last_modified = last_modified
        self.description = description
    def factory(*args_, **kwargs_):
        if IdPermsType.subclass:
            return IdPermsType.subclass(*args_, **kwargs_)
        else:
            return IdPermsType(*args_, **kwargs_)
    factory = staticmethod(factory)
    def get_permissions(self): return self.permissions
    def set_permissions(self, permissions): self.permissions = permissions
    def get_uuid(self): return self.uuid
    def set_uuid(self, uuid): self.uuid = uuid
    def get_enable(self): return self.enable
    def set_enable(self, enable): self.enable = enable
    def get_created(self): return self.created
    def set_created(self, created): self.created = created
    def get_last_modified(self): return self.last_modified
    def set_last_modified(self, last_modified): self.last_modified = last_modified
    def get_description(self): return self.description
    def set_description(self, description): self.description = description
    @classmethod
    def populate (cls, *a, **kwa):
        obj = cls (*a, **kwa)
        obj.set_permissions (PermType.populate ())
        obj.set_uuid (UuidType.populate ())
        obj.set_enable (obj.populate_boolean ("enable"))
        obj.set_created (obj.populate_dateTime ("created"))
        obj.set_last_modified (obj.populate_dateTime ("last_modified"))
        obj.set_description (obj.populate_string ("description"))
        return obj
    def export(self, outfile, level=1, namespace_='', name_='IdPermsType', namespacedef_='', pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        showIndent(outfile, level, pretty_print)
        outfile.write('<%s%s%s' % (namespace_, name_, namespacedef_ and ' ' + namespacedef_ or '', ))
        already_processed = []
        self.exportAttributes(outfile, level, already_processed, namespace_, name_='IdPermsType')
        if self.hasContent_():
            outfile.write('>%s' % (eol_, ))
            self.exportChildren(outfile, level + 1, namespace_, name_, pretty_print=pretty_print)
            showIndent(outfile, level, pretty_print)
            outfile.write('</%s%s>%s' % (namespace_, name_, eol_))
        else:
            outfile.write('/>%s' % (eol_, ))
    def exportAttributes(self, outfile, level, already_processed, namespace_='', name_='IdPermsType'):
        pass
    def exportChildren(self, outfile, level, namespace_='', name_='IdPermsType', fromsubclass_=False, pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        if self.permissions is not None:
            self.permissions.export(outfile, level, namespace_, name_='permissions', pretty_print=pretty_print)
        if self.uuid is not None:
            self.uuid.export(outfile, level, namespace_, name_='uuid', pretty_print=pretty_print)
        if self.enable is not None:
            showIndent(outfile, level, pretty_print)
            outfile.write('<%senable>%s</%senable>%s' % (namespace_, self.gds_format_boolean(self.gds_str_lower(str(self.enable)), input_name='enable'), namespace_, eol_))
        if self.created is not None:
            showIndent(outfile, level, pretty_print)
            outfile.write('<%screated>%s</%screated>%s' % (namespace_, self.gds_format_string(quote_xml(self.created).encode(ExternalEncoding), input_name='created'), namespace_, eol_))
        if self.last_modified is not None:
            showIndent(outfile, level, pretty_print)
            outfile.write('<%slast-modified>%s</%slast-modified>%s' % (namespace_, self.gds_format_string(quote_xml(self.last_modified).encode(ExternalEncoding), input_name='last-modified'), namespace_, eol_))
        if self.description is not None:
            showIndent(outfile, level, pretty_print)
            outfile.write('<%sdescription>%s</%sdescription>%s' % (namespace_, self.gds_format_string(quote_xml(self.description).encode(ExternalEncoding), input_name='description'), namespace_, eol_))
    def hasContent_(self):
        if (
            self.permissions is not None or
            self.uuid is not None or
            self.enable is not None or
            self.created is not None or
            self.last_modified is not None or
            self.description is not None
            ):
            return True
        else:
            return False
    def exportLiteral(self, outfile, level, name_='IdPermsType'):
        level += 1
        self.exportLiteralAttributes(outfile, level, [], name_)
        if self.hasContent_():
            self.exportLiteralChildren(outfile, level, name_)
    def exportLiteralAttributes(self, outfile, level, already_processed, name_):
        pass
    def exportLiteralChildren(self, outfile, level, name_):
        if self.permissions is not None:
            showIndent(outfile, level)
            outfile.write('permissions=model_.PermType(\n')
            self.permissions.exportLiteral(outfile, level, name_='permissions')
            showIndent(outfile, level)
            outfile.write('),\n')
        if self.uuid is not None:
            showIndent(outfile, level)
            outfile.write('uuid=model_.UuidType(\n')
            self.uuid.exportLiteral(outfile, level, name_='uuid')
            showIndent(outfile, level)
            outfile.write('),\n')
        if self.enable is not None:
            showIndent(outfile, level)
            outfile.write('enable=%s,\n' % self.enable)
        if self.created is not None:
            showIndent(outfile, level)
            outfile.write('created=%s,\n' % quote_python(self.created).encode(ExternalEncoding))
        if self.last_modified is not None:
            showIndent(outfile, level)
            outfile.write('last_modified=%s,\n' % quote_python(self.last_modified).encode(ExternalEncoding))
        if self.description is not None:
            showIndent(outfile, level)
            outfile.write('description=%s,\n' % quote_python(self.description).encode(ExternalEncoding))
    def exportDict(self, name_='IdPermsType'):
        obj_json = json.dumps(self, default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        obj_dict = json.loads(obj_json)
        return {name_: obj_dict}
    def build(self, node):
        self.buildAttributes(node, node.attrib, [])
        for child in node:
            nodeName_ = Tag_pattern_.match(child.tag).groups()[-1]
            self.buildChildren(child, node, nodeName_)
    def buildAttributes(self, node, attrs, already_processed):
        pass
    def buildChildren(self, child_, node, nodeName_, fromsubclass_=False):
        if nodeName_ == 'permissions':
            obj_ = PermType.factory()
            obj_.build(child_)
            self.set_permissions(obj_)
        elif nodeName_ == 'uuid':
            obj_ = UuidType.factory()
            obj_.build(child_)
            self.set_uuid(obj_)
        elif nodeName_ == 'enable':
            sval_ = child_.text
            if sval_ in ('true', '1'):
                ival_ = True
            elif sval_ in ('false', '0'):
                ival_ = False
            else:
                raise_parse_error(child_, 'requires boolean')
            ival_ = self.gds_validate_boolean(ival_, node, 'enable')
            self.enable = ival_
        elif nodeName_ == 'created':
            created_ = child_.text
            created_ = self.gds_validate_string(created_, node, 'created')
            self.created = created_
        elif nodeName_ == 'last-modified':
            last_modified_ = child_.text
            last_modified_ = self.gds_validate_string(last_modified_, node, 'last_modified')
            self.last_modified = last_modified_
        elif nodeName_ == 'description':
            description_ = child_.text
            description_ = self.gds_validate_string(description_, node, 'description')
            self.description = description_
# end class IdPermsType


class config_root_global_system_config(GeneratedsSuper):
    """
    config_root_global_system_config class definition from :doc:`vnc_cfg.xsd`
    """
    subclass = None
    superclass = None
    def __init__(self, **kwargs):
        pass
    def factory(*args_, **kwargs_):
        if config_root_global_system_config.subclass:
            return config_root_global_system_config.subclass(*args_, **kwargs_)
        else:
            return config_root_global_system_config(*args_, **kwargs_)
    factory = staticmethod(factory)
    @classmethod
    def populate (cls, *a, **kwa):
        obj = cls (*a, **kwa)
        return obj
    def export(self, outfile, level=1, namespace_='', name_='config-root-global-system-config', namespacedef_='', pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        showIndent(outfile, level, pretty_print)
        outfile.write('<%s%s%s' % (namespace_, name_, namespacedef_ and ' ' + namespacedef_ or '', ))
        already_processed = []
        self.exportAttributes(outfile, level, already_processed, namespace_, name_='config-root-global-system-config')
        if self.hasContent_():
            outfile.write('>%s' % (eol_, ))
            self.exportChildren(outfile, level + 1, namespace_, name_, pretty_print=pretty_print)
            outfile.write('</%s%s>%s' % (namespace_, name_, eol_))
        else:
            outfile.write('/>%s' % (eol_, ))
    def exportAttributes(self, outfile, level, already_processed, namespace_='', name_='config-root-global-system-config'):
        pass
    def exportChildren(self, outfile, level, namespace_='', name_='config-root-global-system-config', fromsubclass_=False, pretty_print=True):
        pass
    def hasContent_(self):
        if (

            ):
            return True
        else:
            return False
    def exportLiteral(self, outfile, level, name_='config-root-global-system-config'):
        level += 1
        self.exportLiteralAttributes(outfile, level, [], name_)
        if self.hasContent_():
            self.exportLiteralChildren(outfile, level, name_)
    def exportLiteralAttributes(self, outfile, level, already_processed, name_):
        pass
    def exportLiteralChildren(self, outfile, level, name_):
        pass
    def exportDict(self, name_='config-root-global-system-config'):
        obj_json = json.dumps(self, default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        obj_dict = json.loads(obj_json)
        return {name_: obj_dict}
    def build(self, node):
        self.buildAttributes(node, node.attrib, [])
        for child in node:
            nodeName_ = Tag_pattern_.match(child.tag).groups()[-1]
            self.buildChildren(child, node, nodeName_)
    def buildAttributes(self, node, attrs, already_processed):
        pass
    def buildChildren(self, child_, node, nodeName_, fromsubclass_=False):
        pass
# end class config_root_global_system_config


class global_system_config_bgp_router(GeneratedsSuper):
    """
    global_system_config_bgp_router class definition from :doc:`vnc_cfg.xsd`
    """
    subclass = None
    superclass = None
    def __init__(self, **kwargs):
        pass
    def factory(*args_, **kwargs_):
        if global_system_config_bgp_router.subclass:
            return global_system_config_bgp_router.subclass(*args_, **kwargs_)
        else:
            return global_system_config_bgp_router(*args_, **kwargs_)
    factory = staticmethod(factory)
    @classmethod
    def populate (cls, *a, **kwa):
        obj = cls (*a, **kwa)
        return obj
    def export(self, outfile, level=1, namespace_='', name_='global-system-config-bgp-router', namespacedef_='', pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        showIndent(outfile, level, pretty_print)
        outfile.write('<%s%s%s' % (namespace_, name_, namespacedef_ and ' ' + namespacedef_ or '', ))
        already_processed = []
        self.exportAttributes(outfile, level, already_processed, namespace_, name_='global-system-config-bgp-router')
        if self.hasContent_():
            outfile.write('>%s' % (eol_, ))
            self.exportChildren(outfile, level + 1, namespace_, name_, pretty_print=pretty_print)
            outfile.write('</%s%s>%s' % (namespace_, name_, eol_))
        else:
            outfile.write('/>%s' % (eol_, ))
    def exportAttributes(self, outfile, level, already_processed, namespace_='', name_='global-system-config-bgp-router'):
        pass
    def exportChildren(self, outfile, level, namespace_='', name_='global-system-config-bgp-router', fromsubclass_=False, pretty_print=True):
        pass
    def hasContent_(self):
        if (

            ):
            return True
        else:
            return False
    def exportLiteral(self, outfile, level, name_='global-system-config-bgp-router'):
        level += 1
        self.exportLiteralAttributes(outfile, level, [], name_)
        if self.hasContent_():
            self.exportLiteralChildren(outfile, level, name_)
    def exportLiteralAttributes(self, outfile, level, already_processed, name_):
        pass
    def exportLiteralChildren(self, outfile, level, name_):
        pass
    def exportDict(self, name_='global-system-config-bgp-router'):
        obj_json = json.dumps(self, default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        obj_dict = json.loads(obj_json)
        return {name_: obj_dict}
    def build(self, node):
        self.buildAttributes(node, node.attrib, [])
        for child in node:
            nodeName_ = Tag_pattern_.match(child.tag).groups()[-1]
            self.buildChildren(child, node, nodeName_)
    def buildAttributes(self, node, attrs, already_processed):
        pass
    def buildChildren(self, child_, node, nodeName_, fromsubclass_=False):
        pass
# end class global_system_config_bgp_router


class config_root_domain(GeneratedsSuper):
    """
    config_root_domain class definition from :doc:`vnc_cfg.xsd`
    """
    subclass = None
    superclass = None
    def __init__(self, **kwargs):
        pass
    def factory(*args_, **kwargs_):
        if config_root_domain.subclass:
            return config_root_domain.subclass(*args_, **kwargs_)
        else:
            return config_root_domain(*args_, **kwargs_)
    factory = staticmethod(factory)
    @classmethod
    def populate (cls, *a, **kwa):
        obj = cls (*a, **kwa)
        return obj
    def export(self, outfile, level=1, namespace_='', name_='config-root-domain', namespacedef_='', pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        showIndent(outfile, level, pretty_print)
        outfile.write('<%s%s%s' % (namespace_, name_, namespacedef_ and ' ' + namespacedef_ or '', ))
        already_processed = []
        self.exportAttributes(outfile, level, already_processed, namespace_, name_='config-root-domain')
        if self.hasContent_():
            outfile.write('>%s' % (eol_, ))
            self.exportChildren(outfile, level + 1, namespace_, name_, pretty_print=pretty_print)
            outfile.write('</%s%s>%s' % (namespace_, name_, eol_))
        else:
            outfile.write('/>%s' % (eol_, ))
    def exportAttributes(self, outfile, level, already_processed, namespace_='', name_='config-root-domain'):
        pass
    def exportChildren(self, outfile, level, namespace_='', name_='config-root-domain', fromsubclass_=False, pretty_print=True):
        pass
    def hasContent_(self):
        if (

            ):
            return True
        else:
            return False
    def exportLiteral(self, outfile, level, name_='config-root-domain'):
        level += 1
        self.exportLiteralAttributes(outfile, level, [], name_)
        if self.hasContent_():
            self.exportLiteralChildren(outfile, level, name_)
    def exportLiteralAttributes(self, outfile, level, already_processed, name_):
        pass
    def exportLiteralChildren(self, outfile, level, name_):
        pass
    def exportDict(self, name_='config-root-domain'):
        obj_json = json.dumps(self, default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        obj_dict = json.loads(obj_json)
        return {name_: obj_dict}
    def build(self, node):
        self.buildAttributes(node, node.attrib, [])
        for child in node:
            nodeName_ = Tag_pattern_.match(child.tag).groups()[-1]
            self.buildChildren(child, node, nodeName_)
    def buildAttributes(self, node, attrs, already_processed):
        pass
    def buildChildren(self, child_, node, nodeName_, fromsubclass_=False):
        pass
# end class config_root_domain


class domain_project(GeneratedsSuper):
    """
    domain_project class definition from :doc:`vnc_cfg.xsd`
    """
    subclass = None
    superclass = None
    def __init__(self, **kwargs):
        pass
    def factory(*args_, **kwargs_):
        if domain_project.subclass:
            return domain_project.subclass(*args_, **kwargs_)
        else:
            return domain_project(*args_, **kwargs_)
    factory = staticmethod(factory)
    @classmethod
    def populate (cls, *a, **kwa):
        obj = cls (*a, **kwa)
        return obj
    def export(self, outfile, level=1, namespace_='', name_='domain-project', namespacedef_='', pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        showIndent(outfile, level, pretty_print)
        outfile.write('<%s%s%s' % (namespace_, name_, namespacedef_ and ' ' + namespacedef_ or '', ))
        already_processed = []
        self.exportAttributes(outfile, level, already_processed, namespace_, name_='domain-project')
        if self.hasContent_():
            outfile.write('>%s' % (eol_, ))
            self.exportChildren(outfile, level + 1, namespace_, name_, pretty_print=pretty_print)
            outfile.write('</%s%s>%s' % (namespace_, name_, eol_))
        else:
            outfile.write('/>%s' % (eol_, ))
    def exportAttributes(self, outfile, level, already_processed, namespace_='', name_='domain-project'):
        pass
    def exportChildren(self, outfile, level, namespace_='', name_='domain-project', fromsubclass_=False, pretty_print=True):
        pass
    def hasContent_(self):
        if (

            ):
            return True
        else:
            return False
    def exportLiteral(self, outfile, level, name_='domain-project'):
        level += 1
        self.exportLiteralAttributes(outfile, level, [], name_)
        if self.hasContent_():
            self.exportLiteralChildren(outfile, level, name_)
    def exportLiteralAttributes(self, outfile, level, already_processed, name_):
        pass
    def exportLiteralChildren(self, outfile, level, name_):
        pass
    def exportDict(self, name_='domain-project'):
        obj_json = json.dumps(self, default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        obj_dict = json.loads(obj_json)
        return {name_: obj_dict}
    def build(self, node):
        self.buildAttributes(node, node.attrib, [])
        for child in node:
            nodeName_ = Tag_pattern_.match(child.tag).groups()[-1]
            self.buildChildren(child, node, nodeName_)
    def buildAttributes(self, node, attrs, already_processed):
        pass
    def buildChildren(self, child_, node, nodeName_, fromsubclass_=False):
        pass
# end class domain_project


class domain_namespace(GeneratedsSuper):
    """
    domain_namespace class definition from :doc:`vnc_cfg.xsd`
    """
    subclass = None
    superclass = None
    def __init__(self, **kwargs):
        pass
    def factory(*args_, **kwargs_):
        if domain_namespace.subclass:
            return domain_namespace.subclass(*args_, **kwargs_)
        else:
            return domain_namespace(*args_, **kwargs_)
    factory = staticmethod(factory)
    @classmethod
    def populate (cls, *a, **kwa):
        obj = cls (*a, **kwa)
        return obj
    def export(self, outfile, level=1, namespace_='', name_='domain-namespace', namespacedef_='', pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        showIndent(outfile, level, pretty_print)
        outfile.write('<%s%s%s' % (namespace_, name_, namespacedef_ and ' ' + namespacedef_ or '', ))
        already_processed = []
        self.exportAttributes(outfile, level, already_processed, namespace_, name_='domain-namespace')
        if self.hasContent_():
            outfile.write('>%s' % (eol_, ))
            self.exportChildren(outfile, level + 1, namespace_, name_, pretty_print=pretty_print)
            outfile.write('</%s%s>%s' % (namespace_, name_, eol_))
        else:
            outfile.write('/>%s' % (eol_, ))
    def exportAttributes(self, outfile, level, already_processed, namespace_='', name_='domain-namespace'):
        pass
    def exportChildren(self, outfile, level, namespace_='', name_='domain-namespace', fromsubclass_=False, pretty_print=True):
        pass
    def hasContent_(self):
        if (

            ):
            return True
        else:
            return False
    def exportLiteral(self, outfile, level, name_='domain-namespace'):
        level += 1
        self.exportLiteralAttributes(outfile, level, [], name_)
        if self.hasContent_():
            self.exportLiteralChildren(outfile, level, name_)
    def exportLiteralAttributes(self, outfile, level, already_processed, name_):
        pass
    def exportLiteralChildren(self, outfile, level, name_):
        pass
    def exportDict(self, name_='domain-namespace'):
        obj_json = json.dumps(self, default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        obj_dict = json.loads(obj_json)
        return {name_: obj_dict}
    def build(self, node):
        self.buildAttributes(node, node.attrib, [])
        for child in node:
            nodeName_ = Tag_pattern_.match(child.tag).groups()[-1]
            self.buildChildren(child, node, nodeName_)
    def buildAttributes(self, node, attrs, already_processed):
        pass
    def buildChildren(self, child_, node, nodeName_, fromsubclass_=False):
        pass
# end class domain_namespace


class project_security_group(GeneratedsSuper):
    """
    project_security_group class definition from :doc:`vnc_cfg.xsd`
    """
    subclass = None
    superclass = None
    def __init__(self, **kwargs):
        pass
    def factory(*args_, **kwargs_):
        if project_security_group.subclass:
            return project_security_group.subclass(*args_, **kwargs_)
        else:
            return project_security_group(*args_, **kwargs_)
    factory = staticmethod(factory)
    @classmethod
    def populate (cls, *a, **kwa):
        obj = cls (*a, **kwa)
        return obj
    def export(self, outfile, level=1, namespace_='', name_='project-security-group', namespacedef_='', pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        showIndent(outfile, level, pretty_print)
        outfile.write('<%s%s%s' % (namespace_, name_, namespacedef_ and ' ' + namespacedef_ or '', ))
        already_processed = []
        self.exportAttributes(outfile, level, already_processed, namespace_, name_='project-security-group')
        if self.hasContent_():
            outfile.write('>%s' % (eol_, ))
            self.exportChildren(outfile, level + 1, namespace_, name_, pretty_print=pretty_print)
            outfile.write('</%s%s>%s' % (namespace_, name_, eol_))
        else:
            outfile.write('/>%s' % (eol_, ))
    def exportAttributes(self, outfile, level, already_processed, namespace_='', name_='project-security-group'):
        pass
    def exportChildren(self, outfile, level, namespace_='', name_='project-security-group', fromsubclass_=False, pretty_print=True):
        pass
    def hasContent_(self):
        if (

            ):
            return True
        else:
            return False
    def exportLiteral(self, outfile, level, name_='project-security-group'):
        level += 1
        self.exportLiteralAttributes(outfile, level, [], name_)
        if self.hasContent_():
            self.exportLiteralChildren(outfile, level, name_)
    def exportLiteralAttributes(self, outfile, level, already_processed, name_):
        pass
    def exportLiteralChildren(self, outfile, level, name_):
        pass
    def exportDict(self, name_='project-security-group'):
        obj_json = json.dumps(self, default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        obj_dict = json.loads(obj_json)
        return {name_: obj_dict}
    def build(self, node):
        self.buildAttributes(node, node.attrib, [])
        for child in node:
            nodeName_ = Tag_pattern_.match(child.tag).groups()[-1]
            self.buildChildren(child, node, nodeName_)
    def buildAttributes(self, node, attrs, already_processed):
        pass
    def buildChildren(self, child_, node, nodeName_, fromsubclass_=False):
        pass
# end class project_security_group


class project_virtual_network(GeneratedsSuper):
    """
    project_virtual_network class definition from :doc:`vnc_cfg.xsd`
    """
    subclass = None
    superclass = None
    def __init__(self, **kwargs):
        pass
    def factory(*args_, **kwargs_):
        if project_virtual_network.subclass:
            return project_virtual_network.subclass(*args_, **kwargs_)
        else:
            return project_virtual_network(*args_, **kwargs_)
    factory = staticmethod(factory)
    @classmethod
    def populate (cls, *a, **kwa):
        obj = cls (*a, **kwa)
        return obj
    def export(self, outfile, level=1, namespace_='', name_='project-virtual-network', namespacedef_='', pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        showIndent(outfile, level, pretty_print)
        outfile.write('<%s%s%s' % (namespace_, name_, namespacedef_ and ' ' + namespacedef_ or '', ))
        already_processed = []
        self.exportAttributes(outfile, level, already_processed, namespace_, name_='project-virtual-network')
        if self.hasContent_():
            outfile.write('>%s' % (eol_, ))
            self.exportChildren(outfile, level + 1, namespace_, name_, pretty_print=pretty_print)
            outfile.write('</%s%s>%s' % (namespace_, name_, eol_))
        else:
            outfile.write('/>%s' % (eol_, ))
    def exportAttributes(self, outfile, level, already_processed, namespace_='', name_='project-virtual-network'):
        pass
    def exportChildren(self, outfile, level, namespace_='', name_='project-virtual-network', fromsubclass_=False, pretty_print=True):
        pass
    def hasContent_(self):
        if (

            ):
            return True
        else:
            return False
    def exportLiteral(self, outfile, level, name_='project-virtual-network'):
        level += 1
        self.exportLiteralAttributes(outfile, level, [], name_)
        if self.hasContent_():
            self.exportLiteralChildren(outfile, level, name_)
    def exportLiteralAttributes(self, outfile, level, already_processed, name_):
        pass
    def exportLiteralChildren(self, outfile, level, name_):
        pass
    def exportDict(self, name_='project-virtual-network'):
        obj_json = json.dumps(self, default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        obj_dict = json.loads(obj_json)
        return {name_: obj_dict}
    def build(self, node):
        self.buildAttributes(node, node.attrib, [])
        for child in node:
            nodeName_ = Tag_pattern_.match(child.tag).groups()[-1]
            self.buildChildren(child, node, nodeName_)
    def buildAttributes(self, node, attrs, already_processed):
        pass
    def buildChildren(self, child_, node, nodeName_, fromsubclass_=False):
        pass
# end class project_virtual_network


class VirtualNetworkType(GeneratedsSuper):
    """
    VirtualNetworkType class definition from :doc:`vnc_cfg.xsd`
    """
    subclass = None
    superclass = None
    def __init__(self, extend_to_external_routers=None, network_id=None, **kwargs):
        self.extend_to_external_routers = extend_to_external_routers
        self.network_id = network_id
    def factory(*args_, **kwargs_):
        if VirtualNetworkType.subclass:
            return VirtualNetworkType.subclass(*args_, **kwargs_)
        else:
            return VirtualNetworkType(*args_, **kwargs_)
    factory = staticmethod(factory)
    def get_extend_to_external_routers(self): return self.extend_to_external_routers
    def set_extend_to_external_routers(self, extend_to_external_routers): self.extend_to_external_routers = extend_to_external_routers
    def get_network_id(self): return self.network_id
    def set_network_id(self, network_id): self.network_id = network_id
    @classmethod
    def populate (cls, *a, **kwa):
        obj = cls (*a, **kwa)
        obj.set_extend_to_external_routers (obj.populate_boolean ("extend_to_external_routers"))
        obj.set_network_id (obj.populate_integer ("network_id"))
        return obj
    def export(self, outfile, level=1, namespace_='', name_='VirtualNetworkType', namespacedef_='', pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        showIndent(outfile, level, pretty_print)
        outfile.write('<%s%s%s' % (namespace_, name_, namespacedef_ and ' ' + namespacedef_ or '', ))
        already_processed = []
        self.exportAttributes(outfile, level, already_processed, namespace_, name_='VirtualNetworkType')
        if self.hasContent_():
            outfile.write('>%s' % (eol_, ))
            self.exportChildren(outfile, level + 1, namespace_, name_, pretty_print=pretty_print)
            showIndent(outfile, level, pretty_print)
            outfile.write('</%s%s>%s' % (namespace_, name_, eol_))
        else:
            outfile.write('/>%s' % (eol_, ))
    def exportAttributes(self, outfile, level, already_processed, namespace_='', name_='VirtualNetworkType'):
        pass
    def exportChildren(self, outfile, level, namespace_='', name_='VirtualNetworkType', fromsubclass_=False, pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        if self.extend_to_external_routers is not None:
            showIndent(outfile, level, pretty_print)
            outfile.write('<%sextend-to-external-routers>%s</%sextend-to-external-routers>%s' % (namespace_, self.gds_format_boolean(self.gds_str_lower(str(self.extend_to_external_routers)), input_name='extend-to-external-routers'), namespace_, eol_))
        if self.network_id is not None:
            showIndent(outfile, level, pretty_print)
            outfile.write('<%snetwork-id>%s</%snetwork-id>%s' % (namespace_, self.gds_format_integer(self.network_id, input_name='network-id'), namespace_, eol_))
    def hasContent_(self):
        if (
            self.extend_to_external_routers is not None or
            self.network_id is not None
            ):
            return True
        else:
            return False
    def exportLiteral(self, outfile, level, name_='VirtualNetworkType'):
        level += 1
        self.exportLiteralAttributes(outfile, level, [], name_)
        if self.hasContent_():
            self.exportLiteralChildren(outfile, level, name_)
    def exportLiteralAttributes(self, outfile, level, already_processed, name_):
        pass
    def exportLiteralChildren(self, outfile, level, name_):
        if self.extend_to_external_routers is not None:
            showIndent(outfile, level)
            outfile.write('extend_to_external_routers=%s,\n' % self.extend_to_external_routers)
        if self.network_id is not None:
            showIndent(outfile, level)
            outfile.write('network_id=%d,\n' % self.network_id)
    def exportDict(self, name_='VirtualNetworkType'):
        obj_json = json.dumps(self, default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        obj_dict = json.loads(obj_json)
        return {name_: obj_dict}
    def build(self, node):
        self.buildAttributes(node, node.attrib, [])
        for child in node:
            nodeName_ = Tag_pattern_.match(child.tag).groups()[-1]
            self.buildChildren(child, node, nodeName_)
    def buildAttributes(self, node, attrs, already_processed):
        pass
    def buildChildren(self, child_, node, nodeName_, fromsubclass_=False):
        if nodeName_ == 'extend-to-external-routers':
            sval_ = child_.text
            if sval_ in ('true', '1'):
                ival_ = True
            elif sval_ in ('false', '0'):
                ival_ = False
            else:
                raise_parse_error(child_, 'requires boolean')
            ival_ = self.gds_validate_boolean(ival_, node, 'extend_to_external_routers')
            self.extend_to_external_routers = ival_
        elif nodeName_ == 'network-id':
            sval_ = child_.text
            try:
                ival_ = int(sval_)
            except (TypeError, ValueError), exp:
                raise_parse_error(child_, 'requires integer: %s' % exp)
            ival_ = self.gds_validate_integer(ival_, node, 'network_id')
            self.network_id = ival_
# end class VirtualNetworkType


class RouteTargetList(GeneratedsSuper):
    """
    RouteTargetList class definition from :doc:`vnc_cfg.xsd`
    """
    subclass = None
    superclass = None
    def __init__(self, route_target=None, **kwargs):
        if (route_target is None) or (route_target == []):
            self.route_target = []
        else:
            self.route_target = route_target
    def factory(*args_, **kwargs_):
        if RouteTargetList.subclass:
            return RouteTargetList.subclass(*args_, **kwargs_)
        else:
            return RouteTargetList(*args_, **kwargs_)
    factory = staticmethod(factory)
    def get_route_target(self): return self.route_target
    def set_route_target(self, route_target): self.route_target = route_target
    def add_route_target(self, value): self.route_target.append(value)
    def insert_route_target(self, index, value): self.route_target[index] = value
    @classmethod
    def populate (cls, *a, **kwa):
        obj = cls (*a, **kwa)
        obj.set_route_target (obj.populate_string ("route_target"))
        return obj
    def export(self, outfile, level=1, namespace_='', name_='RouteTargetList', namespacedef_='', pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        showIndent(outfile, level, pretty_print)
        outfile.write('<%s%s%s' % (namespace_, name_, namespacedef_ and ' ' + namespacedef_ or '', ))
        already_processed = []
        self.exportAttributes(outfile, level, already_processed, namespace_, name_='RouteTargetList')
        if self.hasContent_():
            outfile.write('>%s' % (eol_, ))
            self.exportChildren(outfile, level + 1, namespace_, name_, pretty_print=pretty_print)
            showIndent(outfile, level, pretty_print)
            outfile.write('</%s%s>%s' % (namespace_, name_, eol_))
        else:
            outfile.write('/>%s' % (eol_, ))
    def exportAttributes(self, outfile, level, already_processed, namespace_='', name_='RouteTargetList'):
        pass
    def exportChildren(self, outfile, level, namespace_='', name_='RouteTargetList', fromsubclass_=False, pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        for route_target_ in self.route_target:
            showIndent(outfile, level, pretty_print)
            outfile.write('<%sroute-target>%s</%sroute-target>%s' % (namespace_, self.gds_format_string(quote_xml(route_target_).encode(ExternalEncoding), input_name='route-target'), namespace_, eol_))
    def hasContent_(self):
        if (
            self.route_target
            ):
            return True
        else:
            return False
    def exportLiteral(self, outfile, level, name_='RouteTargetList'):
        level += 1
        self.exportLiteralAttributes(outfile, level, [], name_)
        if self.hasContent_():
            self.exportLiteralChildren(outfile, level, name_)
    def exportLiteralAttributes(self, outfile, level, already_processed, name_):
        pass
    def exportLiteralChildren(self, outfile, level, name_):
        showIndent(outfile, level)
        outfile.write('route_target=[\n')
        level += 1
        for route_target_ in self.route_target:
            showIndent(outfile, level)
            outfile.write('%s,\n' % quote_python(route_target_).encode(ExternalEncoding))
        level -= 1
        showIndent(outfile, level)
        outfile.write('],\n')
    def exportDict(self, name_='RouteTargetList'):
        obj_json = json.dumps(self, default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        obj_dict = json.loads(obj_json)
        return {name_: obj_dict}
    def build(self, node):
        self.buildAttributes(node, node.attrib, [])
        for child in node:
            nodeName_ = Tag_pattern_.match(child.tag).groups()[-1]
            self.buildChildren(child, node, nodeName_)
    def buildAttributes(self, node, attrs, already_processed):
        pass
    def buildChildren(self, child_, node, nodeName_, fromsubclass_=False):
        if nodeName_ == 'route-target':
            route_target_ = child_.text
            route_target_ = self.gds_validate_string(route_target_, node, 'route_target')
            self.route_target.append(route_target_)
# end class RouteTargetList


class project_network_ipam(GeneratedsSuper):
    """
    project_network_ipam class definition from :doc:`vnc_cfg.xsd`
    """
    subclass = None
    superclass = None
    def __init__(self, **kwargs):
        pass
    def factory(*args_, **kwargs_):
        if project_network_ipam.subclass:
            return project_network_ipam.subclass(*args_, **kwargs_)
        else:
            return project_network_ipam(*args_, **kwargs_)
    factory = staticmethod(factory)
    @classmethod
    def populate (cls, *a, **kwa):
        obj = cls (*a, **kwa)
        return obj
    def export(self, outfile, level=1, namespace_='', name_='project-network-ipam', namespacedef_='', pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        showIndent(outfile, level, pretty_print)
        outfile.write('<%s%s%s' % (namespace_, name_, namespacedef_ and ' ' + namespacedef_ or '', ))
        already_processed = []
        self.exportAttributes(outfile, level, already_processed, namespace_, name_='project-network-ipam')
        if self.hasContent_():
            outfile.write('>%s' % (eol_, ))
            self.exportChildren(outfile, level + 1, namespace_, name_, pretty_print=pretty_print)
            outfile.write('</%s%s>%s' % (namespace_, name_, eol_))
        else:
            outfile.write('/>%s' % (eol_, ))
    def exportAttributes(self, outfile, level, already_processed, namespace_='', name_='project-network-ipam'):
        pass
    def exportChildren(self, outfile, level, namespace_='', name_='project-network-ipam', fromsubclass_=False, pretty_print=True):
        pass
    def hasContent_(self):
        if (

            ):
            return True
        else:
            return False
    def exportLiteral(self, outfile, level, name_='project-network-ipam'):
        level += 1
        self.exportLiteralAttributes(outfile, level, [], name_)
        if self.hasContent_():
            self.exportLiteralChildren(outfile, level, name_)
    def exportLiteralAttributes(self, outfile, level, already_processed, name_):
        pass
    def exportLiteralChildren(self, outfile, level, name_):
        pass
    def exportDict(self, name_='project-network-ipam'):
        obj_json = json.dumps(self, default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        obj_dict = json.loads(obj_json)
        return {name_: obj_dict}
    def build(self, node):
        self.buildAttributes(node, node.attrib, [])
        for child in node:
            nodeName_ = Tag_pattern_.match(child.tag).groups()[-1]
            self.buildChildren(child, node, nodeName_)
    def buildAttributes(self, node, attrs, already_processed):
        pass
    def buildChildren(self, child_, node, nodeName_, fromsubclass_=False):
        pass
# end class project_network_ipam


class project_network_policy(GeneratedsSuper):
    """
    project_network_policy class definition from :doc:`vnc_cfg.xsd`
    """
    subclass = None
    superclass = None
    def __init__(self, **kwargs):
        pass
    def factory(*args_, **kwargs_):
        if project_network_policy.subclass:
            return project_network_policy.subclass(*args_, **kwargs_)
        else:
            return project_network_policy(*args_, **kwargs_)
    factory = staticmethod(factory)
    @classmethod
    def populate (cls, *a, **kwa):
        obj = cls (*a, **kwa)
        return obj
    def export(self, outfile, level=1, namespace_='', name_='project-network-policy', namespacedef_='', pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        showIndent(outfile, level, pretty_print)
        outfile.write('<%s%s%s' % (namespace_, name_, namespacedef_ and ' ' + namespacedef_ or '', ))
        already_processed = []
        self.exportAttributes(outfile, level, already_processed, namespace_, name_='project-network-policy')
        if self.hasContent_():
            outfile.write('>%s' % (eol_, ))
            self.exportChildren(outfile, level + 1, namespace_, name_, pretty_print=pretty_print)
            outfile.write('</%s%s>%s' % (namespace_, name_, eol_))
        else:
            outfile.write('/>%s' % (eol_, ))
    def exportAttributes(self, outfile, level, already_processed, namespace_='', name_='project-network-policy'):
        pass
    def exportChildren(self, outfile, level, namespace_='', name_='project-network-policy', fromsubclass_=False, pretty_print=True):
        pass
    def hasContent_(self):
        if (

            ):
            return True
        else:
            return False
    def exportLiteral(self, outfile, level, name_='project-network-policy'):
        level += 1
        self.exportLiteralAttributes(outfile, level, [], name_)
        if self.hasContent_():
            self.exportLiteralChildren(outfile, level, name_)
    def exportLiteralAttributes(self, outfile, level, already_processed, name_):
        pass
    def exportLiteralChildren(self, outfile, level, name_):
        pass
    def exportDict(self, name_='project-network-policy'):
        obj_json = json.dumps(self, default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        obj_dict = json.loads(obj_json)
        return {name_: obj_dict}
    def build(self, node):
        self.buildAttributes(node, node.attrib, [])
        for child in node:
            nodeName_ = Tag_pattern_.match(child.tag).groups()[-1]
            self.buildChildren(child, node, nodeName_)
    def buildAttributes(self, node, attrs, already_processed):
        pass
    def buildChildren(self, child_, node, nodeName_, fromsubclass_=False):
        pass
# end class project_network_policy


class access_control_list_link(GeneratedsSuper):
    """
    access_control_list_link class definition from :doc:`vnc_cfg.xsd`
    """
    subclass = None
    superclass = None
    def __init__(self, **kwargs):
        pass
    def factory(*args_, **kwargs_):
        if access_control_list_link.subclass:
            return access_control_list_link.subclass(*args_, **kwargs_)
        else:
            return access_control_list_link(*args_, **kwargs_)
    factory = staticmethod(factory)
    @classmethod
    def populate (cls, *a, **kwa):
        obj = cls (*a, **kwa)
        return obj
    def export(self, outfile, level=1, namespace_='', name_='access-control-list-link', namespacedef_='', pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        showIndent(outfile, level, pretty_print)
        outfile.write('<%s%s%s' % (namespace_, name_, namespacedef_ and ' ' + namespacedef_ or '', ))
        already_processed = []
        self.exportAttributes(outfile, level, already_processed, namespace_, name_='access-control-list-link')
        if self.hasContent_():
            outfile.write('>%s' % (eol_, ))
            self.exportChildren(outfile, level + 1, namespace_, name_, pretty_print=pretty_print)
            outfile.write('</%s%s>%s' % (namespace_, name_, eol_))
        else:
            outfile.write('/>%s' % (eol_, ))
    def exportAttributes(self, outfile, level, already_processed, namespace_='', name_='access-control-list-link'):
        pass
    def exportChildren(self, outfile, level, namespace_='', name_='access-control-list-link', fromsubclass_=False, pretty_print=True):
        pass
    def hasContent_(self):
        if (

            ):
            return True
        else:
            return False
    def exportLiteral(self, outfile, level, name_='access-control-list-link'):
        level += 1
        self.exportLiteralAttributes(outfile, level, [], name_)
        if self.hasContent_():
            self.exportLiteralChildren(outfile, level, name_)
    def exportLiteralAttributes(self, outfile, level, already_processed, name_):
        pass
    def exportLiteralChildren(self, outfile, level, name_):
        pass
    def exportDict(self, name_='access-control-list-link'):
        obj_json = json.dumps(self, default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        obj_dict = json.loads(obj_json)
        return {name_: obj_dict}
    def build(self, node):
        self.buildAttributes(node, node.attrib, [])
        for child in node:
            nodeName_ = Tag_pattern_.match(child.tag).groups()[-1]
            self.buildChildren(child, node, nodeName_)
    def buildAttributes(self, node, attrs, already_processed):
        pass
    def buildChildren(self, child_, node, nodeName_, fromsubclass_=False):
        pass
# end class access_control_list_link


class virtual_machine_security_group(GeneratedsSuper):
    """
    virtual_machine_security_group class definition from :doc:`vnc_cfg.xsd`
    """
    subclass = None
    superclass = None
    def __init__(self, **kwargs):
        pass
    def factory(*args_, **kwargs_):
        if virtual_machine_security_group.subclass:
            return virtual_machine_security_group.subclass(*args_, **kwargs_)
        else:
            return virtual_machine_security_group(*args_, **kwargs_)
    factory = staticmethod(factory)
    @classmethod
    def populate (cls, *a, **kwa):
        obj = cls (*a, **kwa)
        return obj
    def export(self, outfile, level=1, namespace_='', name_='virtual-machine-security-group', namespacedef_='', pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        showIndent(outfile, level, pretty_print)
        outfile.write('<%s%s%s' % (namespace_, name_, namespacedef_ and ' ' + namespacedef_ or '', ))
        already_processed = []
        self.exportAttributes(outfile, level, already_processed, namespace_, name_='virtual-machine-security-group')
        if self.hasContent_():
            outfile.write('>%s' % (eol_, ))
            self.exportChildren(outfile, level + 1, namespace_, name_, pretty_print=pretty_print)
            outfile.write('</%s%s>%s' % (namespace_, name_, eol_))
        else:
            outfile.write('/>%s' % (eol_, ))
    def exportAttributes(self, outfile, level, already_processed, namespace_='', name_='virtual-machine-security-group'):
        pass
    def exportChildren(self, outfile, level, namespace_='', name_='virtual-machine-security-group', fromsubclass_=False, pretty_print=True):
        pass
    def hasContent_(self):
        if (

            ):
            return True
        else:
            return False
    def exportLiteral(self, outfile, level, name_='virtual-machine-security-group'):
        level += 1
        self.exportLiteralAttributes(outfile, level, [], name_)
        if self.hasContent_():
            self.exportLiteralChildren(outfile, level, name_)
    def exportLiteralAttributes(self, outfile, level, already_processed, name_):
        pass
    def exportLiteralChildren(self, outfile, level, name_):
        pass
    def exportDict(self, name_='virtual-machine-security-group'):
        obj_json = json.dumps(self, default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        obj_dict = json.loads(obj_json)
        return {name_: obj_dict}
    def build(self, node):
        self.buildAttributes(node, node.attrib, [])
        for child in node:
            nodeName_ = Tag_pattern_.match(child.tag).groups()[-1]
            self.buildChildren(child, node, nodeName_)
    def buildAttributes(self, node, attrs, already_processed):
        pass
    def buildChildren(self, child_, node, nodeName_, fromsubclass_=False):
        pass
# end class virtual_machine_security_group


class VirtualMachineInterfacePropertiesType(GeneratedsSuper):
    """
    VirtualMachineInterfacePropertiesType class definition from :doc:`vnc_cfg.xsd`
    """
    subclass = None
    superclass = None
    def __init__(self, service_interface_type=None, dummy=None, **kwargs):
        self.service_interface_type = service_interface_type
        self.dummy = dummy
    def factory(*args_, **kwargs_):
        if VirtualMachineInterfacePropertiesType.subclass:
            return VirtualMachineInterfacePropertiesType.subclass(*args_, **kwargs_)
        else:
            return VirtualMachineInterfacePropertiesType(*args_, **kwargs_)
    factory = staticmethod(factory)
    def get_service_interface_type(self): return self.service_interface_type
    def set_service_interface_type(self, service_interface_type): self.service_interface_type = service_interface_type
    def validate_ServiceInterfaceType(self, value):
        # Validate type ServiceInterfaceType, a restriction on xsd:string.
        pass
    def get_dummy(self): return self.dummy
    def set_dummy(self, dummy): self.dummy = dummy
    @classmethod
    def populate (cls, *a, **kwa):
        obj = cls (*a, **kwa)
        obj.set_service_interface_type (obj.populate_string ("service_interface_type"))
        obj.set_dummy (obj.populate_string ("dummy"))
        return obj
    def export(self, outfile, level=1, namespace_='', name_='VirtualMachineInterfacePropertiesType', namespacedef_='', pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        showIndent(outfile, level, pretty_print)
        outfile.write('<%s%s%s' % (namespace_, name_, namespacedef_ and ' ' + namespacedef_ or '', ))
        already_processed = []
        self.exportAttributes(outfile, level, already_processed, namespace_, name_='VirtualMachineInterfacePropertiesType')
        if self.hasContent_():
            outfile.write('>%s' % (eol_, ))
            self.exportChildren(outfile, level + 1, namespace_, name_, pretty_print=pretty_print)
            showIndent(outfile, level, pretty_print)
            outfile.write('</%s%s>%s' % (namespace_, name_, eol_))
        else:
            outfile.write('/>%s' % (eol_, ))
    def exportAttributes(self, outfile, level, already_processed, namespace_='', name_='VirtualMachineInterfacePropertiesType'):
        pass
    def exportChildren(self, outfile, level, namespace_='', name_='VirtualMachineInterfacePropertiesType', fromsubclass_=False, pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        if self.service_interface_type is not None:
            showIndent(outfile, level, pretty_print)
            outfile.write('<%sservice-interface-type>%s</%sservice-interface-type>%s' % (namespace_, self.gds_format_string(quote_xml(self.service_interface_type).encode(ExternalEncoding), input_name='service-interface-type'), namespace_, eol_))
        if self.dummy is not None:
            showIndent(outfile, level, pretty_print)
            outfile.write('<%sdummy>%s</%sdummy>%s' % (namespace_, self.gds_format_string(quote_xml(self.dummy).encode(ExternalEncoding), input_name='dummy'), namespace_, eol_))
    def hasContent_(self):
        if (
            self.service_interface_type is not None or
            self.dummy is not None
            ):
            return True
        else:
            return False
    def exportLiteral(self, outfile, level, name_='VirtualMachineInterfacePropertiesType'):
        level += 1
        self.exportLiteralAttributes(outfile, level, [], name_)
        if self.hasContent_():
            self.exportLiteralChildren(outfile, level, name_)
    def exportLiteralAttributes(self, outfile, level, already_processed, name_):
        pass
    def exportLiteralChildren(self, outfile, level, name_):
        if self.service_interface_type is not None:
            showIndent(outfile, level)
            outfile.write('service_interface_type=%s,\n' % quote_python(self.service_interface_type).encode(ExternalEncoding))
        if self.dummy is not None:
            showIndent(outfile, level)
            outfile.write('dummy=%s,\n' % quote_python(self.dummy).encode(ExternalEncoding))
    def exportDict(self, name_='VirtualMachineInterfacePropertiesType'):
        obj_json = json.dumps(self, default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        obj_dict = json.loads(obj_json)
        return {name_: obj_dict}
    def build(self, node):
        self.buildAttributes(node, node.attrib, [])
        for child in node:
            nodeName_ = Tag_pattern_.match(child.tag).groups()[-1]
            self.buildChildren(child, node, nodeName_)
    def buildAttributes(self, node, attrs, already_processed):
        pass
    def buildChildren(self, child_, node, nodeName_, fromsubclass_=False):
        if nodeName_ == 'service-interface-type':
            service_interface_type_ = child_.text
            service_interface_type_ = self.gds_validate_string(service_interface_type_, node, 'service_interface_type')
            self.service_interface_type = service_interface_type_
            self.validate_ServiceInterfaceType(self.service_interface_type)    # validate type ServiceInterfaceType
        elif nodeName_ == 'dummy':
            dummy_ = child_.text
            dummy_ = self.gds_validate_string(dummy_, node, 'dummy')
            self.dummy = dummy_
# end class VirtualMachineInterfacePropertiesType


class dummy(GeneratedsSuper):
    """
    dummy class definition from :doc:`vnc_cfg.xsd`
    """
    subclass = None
    superclass = None
    def __init__(self, **kwargs):
        pass
    def factory(*args_, **kwargs_):
        if dummy.subclass:
            return dummy.subclass(*args_, **kwargs_)
        else:
            return dummy(*args_, **kwargs_)
    factory = staticmethod(factory)
    @classmethod
    def populate (cls, *a, **kwa):
        obj = cls (*a, **kwa)
        return obj
    def export(self, outfile, level=1, namespace_='', name_='dummy', namespacedef_='', pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        showIndent(outfile, level, pretty_print)
        outfile.write('<%s%s%s' % (namespace_, name_, namespacedef_ and ' ' + namespacedef_ or '', ))
        already_processed = []
        self.exportAttributes(outfile, level, already_processed, namespace_, name_='dummy')
        if self.hasContent_():
            outfile.write('>%s' % (eol_, ))
            self.exportChildren(outfile, level + 1, namespace_, name_, pretty_print=pretty_print)
            outfile.write('</%s%s>%s' % (namespace_, name_, eol_))
        else:
            outfile.write('/>%s' % (eol_, ))
    def exportAttributes(self, outfile, level, already_processed, namespace_='', name_='dummy'):
        pass
    def exportChildren(self, outfile, level, namespace_='', name_='dummy', fromsubclass_=False, pretty_print=True):
        pass
    def hasContent_(self):
        if (

            ):
            return True
        else:
            return False
    def exportLiteral(self, outfile, level, name_='dummy'):
        level += 1
        self.exportLiteralAttributes(outfile, level, [], name_)
        if self.hasContent_():
            self.exportLiteralChildren(outfile, level, name_)
    def exportLiteralAttributes(self, outfile, level, already_processed, name_):
        pass
    def exportLiteralChildren(self, outfile, level, name_):
        pass
    def exportDict(self, name_='dummy'):
        obj_json = json.dumps(self, default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        obj_dict = json.loads(obj_json)
        return {name_: obj_dict}
    def build(self, node):
        self.buildAttributes(node, node.attrib, [])
        for child in node:
            nodeName_ = Tag_pattern_.match(child.tag).groups()[-1]
            self.buildChildren(child, node, nodeName_)
    def buildAttributes(self, node, attrs, already_processed):
        pass
    def buildChildren(self, child_, node, nodeName_, fromsubclass_=False):
        pass
# end class dummy


class ServiceTemplateInterfaceType(GeneratedsSuper):
    """
    ServiceTemplateInterfaceType class definition from :doc:`vnc_cfg.xsd`
    """
    subclass = None
    superclass = None
    def __init__(self, service_interface_type=None, shared_ip=False, **kwargs):
        self.service_interface_type = service_interface_type
        self.shared_ip = shared_ip
    def factory(*args_, **kwargs_):
        if ServiceTemplateInterfaceType.subclass:
            return ServiceTemplateInterfaceType.subclass(*args_, **kwargs_)
        else:
            return ServiceTemplateInterfaceType(*args_, **kwargs_)
    factory = staticmethod(factory)
    def get_service_interface_type(self): return self.service_interface_type
    def set_service_interface_type(self, service_interface_type): self.service_interface_type = service_interface_type
    def validate_ServiceInterfaceType(self, value):
        # Validate type ServiceInterfaceType, a restriction on xsd:string.
        pass
    def get_shared_ip(self): return self.shared_ip
    def set_shared_ip(self, shared_ip): self.shared_ip = shared_ip
    @classmethod
    def populate (cls, *a, **kwa):
        obj = cls (*a, **kwa)
        obj.set_service_interface_type (obj.populate_string ("service_interface_type"))
        obj.set_shared_ip (obj.populate_boolean ("shared_ip"))
        return obj
    def export(self, outfile, level=1, namespace_='', name_='ServiceTemplateInterfaceType', namespacedef_='', pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        showIndent(outfile, level, pretty_print)
        outfile.write('<%s%s%s' % (namespace_, name_, namespacedef_ and ' ' + namespacedef_ or '', ))
        already_processed = []
        self.exportAttributes(outfile, level, already_processed, namespace_, name_='ServiceTemplateInterfaceType')
        if self.hasContent_():
            outfile.write('>%s' % (eol_, ))
            self.exportChildren(outfile, level + 1, namespace_, name_, pretty_print=pretty_print)
            showIndent(outfile, level, pretty_print)
            outfile.write('</%s%s>%s' % (namespace_, name_, eol_))
        else:
            outfile.write('/>%s' % (eol_, ))
    def exportAttributes(self, outfile, level, already_processed, namespace_='', name_='ServiceTemplateInterfaceType'):
        pass
    def exportChildren(self, outfile, level, namespace_='', name_='ServiceTemplateInterfaceType', fromsubclass_=False, pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        if self.service_interface_type is not None:
            showIndent(outfile, level, pretty_print)
            outfile.write('<%sservice-interface-type>%s</%sservice-interface-type>%s' % (namespace_, self.gds_format_string(quote_xml(self.service_interface_type).encode(ExternalEncoding), input_name='service-interface-type'), namespace_, eol_))
        if self.shared_ip is not None:
            showIndent(outfile, level, pretty_print)
            outfile.write('<%sshared-ip>%s</%sshared-ip>%s' % (namespace_, self.gds_format_boolean(self.gds_str_lower(str(self.shared_ip)), input_name='shared-ip'), namespace_, eol_))
    def hasContent_(self):
        if (
            self.service_interface_type is not None or
            self.shared_ip is not None
            ):
            return True
        else:
            return False
    def exportLiteral(self, outfile, level, name_='ServiceTemplateInterfaceType'):
        level += 1
        self.exportLiteralAttributes(outfile, level, [], name_)
        if self.hasContent_():
            self.exportLiteralChildren(outfile, level, name_)
    def exportLiteralAttributes(self, outfile, level, already_processed, name_):
        pass
    def exportLiteralChildren(self, outfile, level, name_):
        if self.service_interface_type is not None:
            showIndent(outfile, level)
            outfile.write('service_interface_type=%s,\n' % quote_python(self.service_interface_type).encode(ExternalEncoding))
        if self.shared_ip is not None:
            showIndent(outfile, level)
            outfile.write('shared_ip=%s,\n' % self.shared_ip)
    def exportDict(self, name_='ServiceTemplateInterfaceType'):
        obj_json = json.dumps(self, default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        obj_dict = json.loads(obj_json)
        return {name_: obj_dict}
    def build(self, node):
        self.buildAttributes(node, node.attrib, [])
        for child in node:
            nodeName_ = Tag_pattern_.match(child.tag).groups()[-1]
            self.buildChildren(child, node, nodeName_)
    def buildAttributes(self, node, attrs, already_processed):
        pass
    def buildChildren(self, child_, node, nodeName_, fromsubclass_=False):
        if nodeName_ == 'service-interface-type':
            service_interface_type_ = child_.text
            service_interface_type_ = self.gds_validate_string(service_interface_type_, node, 'service_interface_type')
            self.service_interface_type = service_interface_type_
            self.validate_ServiceInterfaceType(self.service_interface_type)    # validate type ServiceInterfaceType
        elif nodeName_ == 'shared-ip':
            sval_ = child_.text
            if sval_ in ('true', '1'):
                ival_ = True
            elif sval_ in ('false', '0'):
                ival_ = False
            else:
                raise_parse_error(child_, 'requires boolean')
            ival_ = self.gds_validate_boolean(ival_, node, 'shared_ip')
            self.shared_ip = ival_
# end class ServiceTemplateInterfaceType


class virtual_machine_virtual_machine_interface(GeneratedsSuper):
    """
    virtual_machine_virtual_machine_interface class definition from :doc:`vnc_cfg.xsd`
    """
    subclass = None
    superclass = None
    def __init__(self, **kwargs):
        pass
    def factory(*args_, **kwargs_):
        if virtual_machine_virtual_machine_interface.subclass:
            return virtual_machine_virtual_machine_interface.subclass(*args_, **kwargs_)
        else:
            return virtual_machine_virtual_machine_interface(*args_, **kwargs_)
    factory = staticmethod(factory)
    @classmethod
    def populate (cls, *a, **kwa):
        obj = cls (*a, **kwa)
        return obj
    def export(self, outfile, level=1, namespace_='', name_='virtual-machine-virtual-machine-interface', namespacedef_='', pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        showIndent(outfile, level, pretty_print)
        outfile.write('<%s%s%s' % (namespace_, name_, namespacedef_ and ' ' + namespacedef_ or '', ))
        already_processed = []
        self.exportAttributes(outfile, level, already_processed, namespace_, name_='virtual-machine-virtual-machine-interface')
        if self.hasContent_():
            outfile.write('>%s' % (eol_, ))
            self.exportChildren(outfile, level + 1, namespace_, name_, pretty_print=pretty_print)
            outfile.write('</%s%s>%s' % (namespace_, name_, eol_))
        else:
            outfile.write('/>%s' % (eol_, ))
    def exportAttributes(self, outfile, level, already_processed, namespace_='', name_='virtual-machine-virtual-machine-interface'):
        pass
    def exportChildren(self, outfile, level, namespace_='', name_='virtual-machine-virtual-machine-interface', fromsubclass_=False, pretty_print=True):
        pass
    def hasContent_(self):
        if (

            ):
            return True
        else:
            return False
    def exportLiteral(self, outfile, level, name_='virtual-machine-virtual-machine-interface'):
        level += 1
        self.exportLiteralAttributes(outfile, level, [], name_)
        if self.hasContent_():
            self.exportLiteralChildren(outfile, level, name_)
    def exportLiteralAttributes(self, outfile, level, already_processed, name_):
        pass
    def exportLiteralChildren(self, outfile, level, name_):
        pass
    def exportDict(self, name_='virtual-machine-virtual-machine-interface'):
        obj_json = json.dumps(self, default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        obj_dict = json.loads(obj_json)
        return {name_: obj_dict}
    def build(self, node):
        self.buildAttributes(node, node.attrib, [])
        for child in node:
            nodeName_ = Tag_pattern_.match(child.tag).groups()[-1]
            self.buildChildren(child, node, nodeName_)
    def buildAttributes(self, node, attrs, already_processed):
        pass
    def buildChildren(self, child_, node, nodeName_, fromsubclass_=False):
        pass
# end class virtual_machine_virtual_machine_interface


class virtual_machine_interface_virtual_network(GeneratedsSuper):
    """
    virtual_machine_interface_virtual_network class definition from :doc:`vnc_cfg.xsd`
    """
    subclass = None
    superclass = None
    def __init__(self, **kwargs):
        pass
    def factory(*args_, **kwargs_):
        if virtual_machine_interface_virtual_network.subclass:
            return virtual_machine_interface_virtual_network.subclass(*args_, **kwargs_)
        else:
            return virtual_machine_interface_virtual_network(*args_, **kwargs_)
    factory = staticmethod(factory)
    @classmethod
    def populate (cls, *a, **kwa):
        obj = cls (*a, **kwa)
        return obj
    def export(self, outfile, level=1, namespace_='', name_='virtual-machine-interface-virtual-network', namespacedef_='', pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        showIndent(outfile, level, pretty_print)
        outfile.write('<%s%s%s' % (namespace_, name_, namespacedef_ and ' ' + namespacedef_ or '', ))
        already_processed = []
        self.exportAttributes(outfile, level, already_processed, namespace_, name_='virtual-machine-interface-virtual-network')
        if self.hasContent_():
            outfile.write('>%s' % (eol_, ))
            self.exportChildren(outfile, level + 1, namespace_, name_, pretty_print=pretty_print)
            outfile.write('</%s%s>%s' % (namespace_, name_, eol_))
        else:
            outfile.write('/>%s' % (eol_, ))
    def exportAttributes(self, outfile, level, already_processed, namespace_='', name_='virtual-machine-interface-virtual-network'):
        pass
    def exportChildren(self, outfile, level, namespace_='', name_='virtual-machine-interface-virtual-network', fromsubclass_=False, pretty_print=True):
        pass
    def hasContent_(self):
        if (

            ):
            return True
        else:
            return False
    def exportLiteral(self, outfile, level, name_='virtual-machine-interface-virtual-network'):
        level += 1
        self.exportLiteralAttributes(outfile, level, [], name_)
        if self.hasContent_():
            self.exportLiteralChildren(outfile, level, name_)
    def exportLiteralAttributes(self, outfile, level, already_processed, name_):
        pass
    def exportLiteralChildren(self, outfile, level, name_):
        pass
    def exportDict(self, name_='virtual-machine-interface-virtual-network'):
        obj_json = json.dumps(self, default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        obj_dict = json.loads(obj_json)
        return {name_: obj_dict}
    def build(self, node):
        self.buildAttributes(node, node.attrib, [])
        for child in node:
            nodeName_ = Tag_pattern_.match(child.tag).groups()[-1]
            self.buildChildren(child, node, nodeName_)
    def buildAttributes(self, node, attrs, already_processed):
        pass
    def buildChildren(self, child_, node, nodeName_, fromsubclass_=False):
        pass
# end class virtual_machine_interface_virtual_network


class PolicyBasedForwardingRuleType(GeneratedsSuper):
    """
    PolicyBasedForwardingRuleType class definition from :doc:`vnc_cfg.xsd`
    """
    subclass = None
    superclass = None
    def __init__(self, direction=None, vlan_tag=None, mpls_label=None, service_chain_address=None, protocol=None, **kwargs):
        self.direction = direction
        self.vlan_tag = vlan_tag
        self.mpls_label = mpls_label
        self.service_chain_address = service_chain_address
        self.protocol = protocol
    def factory(*args_, **kwargs_):
        if PolicyBasedForwardingRuleType.subclass:
            return PolicyBasedForwardingRuleType.subclass(*args_, **kwargs_)
        else:
            return PolicyBasedForwardingRuleType(*args_, **kwargs_)
    factory = staticmethod(factory)
    def get_direction(self): return self.direction
    def set_direction(self, direction): self.direction = direction
    def validate_TrafficDirectionType(self, value):
        # Validate type TrafficDirectionType, a restriction on xsd:string.
        pass
    def get_vlan_tag(self): return self.vlan_tag
    def set_vlan_tag(self, vlan_tag): self.vlan_tag = vlan_tag
    def get_mpls_label(self): return self.mpls_label
    def set_mpls_label(self, mpls_label): self.mpls_label = mpls_label
    def get_service_chain_address(self): return self.service_chain_address
    def set_service_chain_address(self, service_chain_address): self.service_chain_address = service_chain_address
    def validate_IpAddress(self, value):
        # Validate type IpAddress, a restriction on xsd:string.
        pass
    def get_protocol(self): return self.protocol
    def set_protocol(self, protocol): self.protocol = protocol
    @classmethod
    def populate (cls, *a, **kwa):
        obj = cls (*a, **kwa)
        obj.set_direction (obj.populate_string ("direction"))
        obj.set_vlan_tag (obj.populate_integer ("vlan_tag"))
        obj.set_mpls_label (obj.populate_integer ("mpls_label"))
        obj.set_service_chain_address (obj.populate_string ("service_chain_address"))
        obj.set_protocol (obj.populate_string ("protocol"))
        return obj
    def export(self, outfile, level=1, namespace_='', name_='PolicyBasedForwardingRuleType', namespacedef_='', pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        showIndent(outfile, level, pretty_print)
        outfile.write('<%s%s%s' % (namespace_, name_, namespacedef_ and ' ' + namespacedef_ or '', ))
        already_processed = []
        self.exportAttributes(outfile, level, already_processed, namespace_, name_='PolicyBasedForwardingRuleType')
        if self.hasContent_():
            outfile.write('>%s' % (eol_, ))
            self.exportChildren(outfile, level + 1, namespace_, name_, pretty_print=pretty_print)
            showIndent(outfile, level, pretty_print)
            outfile.write('</%s%s>%s' % (namespace_, name_, eol_))
        else:
            outfile.write('/>%s' % (eol_, ))
    def exportAttributes(self, outfile, level, already_processed, namespace_='', name_='PolicyBasedForwardingRuleType'):
        pass
    def exportChildren(self, outfile, level, namespace_='', name_='PolicyBasedForwardingRuleType', fromsubclass_=False, pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        if self.direction is not None:
            showIndent(outfile, level, pretty_print)
            outfile.write('<%sdirection>%s</%sdirection>%s' % (namespace_, self.gds_format_string(quote_xml(self.direction).encode(ExternalEncoding), input_name='direction'), namespace_, eol_))
        if self.vlan_tag is not None:
            showIndent(outfile, level, pretty_print)
            outfile.write('<%svlan-tag>%s</%svlan-tag>%s' % (namespace_, self.gds_format_integer(self.vlan_tag, input_name='vlan-tag'), namespace_, eol_))
        if self.mpls_label is not None:
            showIndent(outfile, level, pretty_print)
            outfile.write('<%smpls-label>%s</%smpls-label>%s' % (namespace_, self.gds_format_integer(self.mpls_label, input_name='mpls-label'), namespace_, eol_))
        if self.service_chain_address is not None:
            showIndent(outfile, level, pretty_print)
            outfile.write('<%sservice-chain-address>%s</%sservice-chain-address>%s' % (namespace_, self.gds_format_string(quote_xml(self.service_chain_address).encode(ExternalEncoding), input_name='service-chain-address'), namespace_, eol_))
        if self.protocol is not None:
            showIndent(outfile, level, pretty_print)
            outfile.write('<%sprotocol>%s</%sprotocol>%s' % (namespace_, self.gds_format_string(quote_xml(self.protocol).encode(ExternalEncoding), input_name='protocol'), namespace_, eol_))
    def hasContent_(self):
        if (
            self.direction is not None or
            self.vlan_tag is not None or
            self.mpls_label is not None or
            self.service_chain_address is not None or
            self.protocol is not None
            ):
            return True
        else:
            return False
    def exportLiteral(self, outfile, level, name_='PolicyBasedForwardingRuleType'):
        level += 1
        self.exportLiteralAttributes(outfile, level, [], name_)
        if self.hasContent_():
            self.exportLiteralChildren(outfile, level, name_)
    def exportLiteralAttributes(self, outfile, level, already_processed, name_):
        pass
    def exportLiteralChildren(self, outfile, level, name_):
        if self.direction is not None:
            showIndent(outfile, level)
            outfile.write('direction=%s,\n' % quote_python(self.direction).encode(ExternalEncoding))
        if self.vlan_tag is not None:
            showIndent(outfile, level)
            outfile.write('vlan_tag=%d,\n' % self.vlan_tag)
        if self.mpls_label is not None:
            showIndent(outfile, level)
            outfile.write('mpls_label=%d,\n' % self.mpls_label)
        if self.service_chain_address is not None:
            showIndent(outfile, level)
            outfile.write('service_chain_address=%s,\n' % quote_python(self.service_chain_address).encode(ExternalEncoding))
        if self.protocol is not None:
            showIndent(outfile, level)
            outfile.write('protocol=%s,\n' % quote_python(self.protocol).encode(ExternalEncoding))
    def exportDict(self, name_='PolicyBasedForwardingRuleType'):
        obj_json = json.dumps(self, default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        obj_dict = json.loads(obj_json)
        return {name_: obj_dict}
    def build(self, node):
        self.buildAttributes(node, node.attrib, [])
        for child in node:
            nodeName_ = Tag_pattern_.match(child.tag).groups()[-1]
            self.buildChildren(child, node, nodeName_)
    def buildAttributes(self, node, attrs, already_processed):
        pass
    def buildChildren(self, child_, node, nodeName_, fromsubclass_=False):
        if nodeName_ == 'direction':
            direction_ = child_.text
            direction_ = self.gds_validate_string(direction_, node, 'direction')
            self.direction = direction_
            self.validate_TrafficDirectionType(self.direction)    # validate type TrafficDirectionType
        elif nodeName_ == 'vlan-tag':
            sval_ = child_.text
            try:
                ival_ = int(sval_)
            except (TypeError, ValueError), exp:
                raise_parse_error(child_, 'requires integer: %s' % exp)
            ival_ = self.gds_validate_integer(ival_, node, 'vlan_tag')
            self.vlan_tag = ival_
        elif nodeName_ == 'mpls-label':
            sval_ = child_.text
            try:
                ival_ = int(sval_)
            except (TypeError, ValueError), exp:
                raise_parse_error(child_, 'requires integer: %s' % exp)
            ival_ = self.gds_validate_integer(ival_, node, 'mpls_label')
            self.mpls_label = ival_
        elif nodeName_ == 'service-chain-address':
            service_chain_address_ = child_.text
            service_chain_address_ = self.gds_validate_string(service_chain_address_, node, 'service_chain_address')
            self.service_chain_address = service_chain_address_
            self.validate_IpAddress(self.service_chain_address)    # validate type IpAddress
        elif nodeName_ == 'protocol':
            protocol_ = child_.text
            protocol_ = self.gds_validate_string(protocol_, node, 'protocol')
            self.protocol = protocol_
# end class PolicyBasedForwardingRuleType


class instance_ip_virtual_network(GeneratedsSuper):
    """
    instance_ip_virtual_network class definition from :doc:`vnc_cfg.xsd`
    """
    subclass = None
    superclass = None
    def __init__(self, **kwargs):
        pass
    def factory(*args_, **kwargs_):
        if instance_ip_virtual_network.subclass:
            return instance_ip_virtual_network.subclass(*args_, **kwargs_)
        else:
            return instance_ip_virtual_network(*args_, **kwargs_)
    factory = staticmethod(factory)
    @classmethod
    def populate (cls, *a, **kwa):
        obj = cls (*a, **kwa)
        return obj
    def export(self, outfile, level=1, namespace_='', name_='instance-ip-virtual-network', namespacedef_='', pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        showIndent(outfile, level, pretty_print)
        outfile.write('<%s%s%s' % (namespace_, name_, namespacedef_ and ' ' + namespacedef_ or '', ))
        already_processed = []
        self.exportAttributes(outfile, level, already_processed, namespace_, name_='instance-ip-virtual-network')
        if self.hasContent_():
            outfile.write('>%s' % (eol_, ))
            self.exportChildren(outfile, level + 1, namespace_, name_, pretty_print=pretty_print)
            outfile.write('</%s%s>%s' % (namespace_, name_, eol_))
        else:
            outfile.write('/>%s' % (eol_, ))
    def exportAttributes(self, outfile, level, already_processed, namespace_='', name_='instance-ip-virtual-network'):
        pass
    def exportChildren(self, outfile, level, namespace_='', name_='instance-ip-virtual-network', fromsubclass_=False, pretty_print=True):
        pass
    def hasContent_(self):
        if (

            ):
            return True
        else:
            return False
    def exportLiteral(self, outfile, level, name_='instance-ip-virtual-network'):
        level += 1
        self.exportLiteralAttributes(outfile, level, [], name_)
        if self.hasContent_():
            self.exportLiteralChildren(outfile, level, name_)
    def exportLiteralAttributes(self, outfile, level, already_processed, name_):
        pass
    def exportLiteralChildren(self, outfile, level, name_):
        pass
    def exportDict(self, name_='instance-ip-virtual-network'):
        obj_json = json.dumps(self, default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        obj_dict = json.loads(obj_json)
        return {name_: obj_dict}
    def build(self, node):
        self.buildAttributes(node, node.attrib, [])
        for child in node:
            nodeName_ = Tag_pattern_.match(child.tag).groups()[-1]
            self.buildChildren(child, node, nodeName_)
    def buildAttributes(self, node, attrs, already_processed):
        pass
    def buildChildren(self, child_, node, nodeName_, fromsubclass_=False):
        pass
# end class instance_ip_virtual_network


class instance_ip_virtual_machine_interface(GeneratedsSuper):
    """
    instance_ip_virtual_machine_interface class definition from :doc:`vnc_cfg.xsd`
    """
    subclass = None
    superclass = None
    def __init__(self, **kwargs):
        pass
    def factory(*args_, **kwargs_):
        if instance_ip_virtual_machine_interface.subclass:
            return instance_ip_virtual_machine_interface.subclass(*args_, **kwargs_)
        else:
            return instance_ip_virtual_machine_interface(*args_, **kwargs_)
    factory = staticmethod(factory)
    @classmethod
    def populate (cls, *a, **kwa):
        obj = cls (*a, **kwa)
        return obj
    def export(self, outfile, level=1, namespace_='', name_='instance-ip-virtual-machine-interface', namespacedef_='', pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        showIndent(outfile, level, pretty_print)
        outfile.write('<%s%s%s' % (namespace_, name_, namespacedef_ and ' ' + namespacedef_ or '', ))
        already_processed = []
        self.exportAttributes(outfile, level, already_processed, namespace_, name_='instance-ip-virtual-machine-interface')
        if self.hasContent_():
            outfile.write('>%s' % (eol_, ))
            self.exportChildren(outfile, level + 1, namespace_, name_, pretty_print=pretty_print)
            outfile.write('</%s%s>%s' % (namespace_, name_, eol_))
        else:
            outfile.write('/>%s' % (eol_, ))
    def exportAttributes(self, outfile, level, already_processed, namespace_='', name_='instance-ip-virtual-machine-interface'):
        pass
    def exportChildren(self, outfile, level, namespace_='', name_='instance-ip-virtual-machine-interface', fromsubclass_=False, pretty_print=True):
        pass
    def hasContent_(self):
        if (

            ):
            return True
        else:
            return False
    def exportLiteral(self, outfile, level, name_='instance-ip-virtual-machine-interface'):
        level += 1
        self.exportLiteralAttributes(outfile, level, [], name_)
        if self.hasContent_():
            self.exportLiteralChildren(outfile, level, name_)
    def exportLiteralAttributes(self, outfile, level, already_processed, name_):
        pass
    def exportLiteralChildren(self, outfile, level, name_):
        pass
    def exportDict(self, name_='instance-ip-virtual-machine-interface'):
        obj_json = json.dumps(self, default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        obj_dict = json.loads(obj_json)
        return {name_: obj_dict}
    def build(self, node):
        self.buildAttributes(node, node.attrib, [])
        for child in node:
            nodeName_ = Tag_pattern_.match(child.tag).groups()[-1]
            self.buildChildren(child, node, nodeName_)
    def buildAttributes(self, node, attrs, already_processed):
        pass
    def buildChildren(self, child_, node, nodeName_, fromsubclass_=False):
        pass
# end class instance_ip_virtual_machine_interface


class virtual_network_floating_ip_pool(GeneratedsSuper):
    """
    virtual_network_floating_ip_pool class definition from :doc:`vnc_cfg.xsd`
    """
    subclass = None
    superclass = None
    def __init__(self, **kwargs):
        pass
    def factory(*args_, **kwargs_):
        if virtual_network_floating_ip_pool.subclass:
            return virtual_network_floating_ip_pool.subclass(*args_, **kwargs_)
        else:
            return virtual_network_floating_ip_pool(*args_, **kwargs_)
    factory = staticmethod(factory)
    @classmethod
    def populate (cls, *a, **kwa):
        obj = cls (*a, **kwa)
        return obj
    def export(self, outfile, level=1, namespace_='', name_='virtual-network-floating-ip-pool', namespacedef_='', pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        showIndent(outfile, level, pretty_print)
        outfile.write('<%s%s%s' % (namespace_, name_, namespacedef_ and ' ' + namespacedef_ or '', ))
        already_processed = []
        self.exportAttributes(outfile, level, already_processed, namespace_, name_='virtual-network-floating-ip-pool')
        if self.hasContent_():
            outfile.write('>%s' % (eol_, ))
            self.exportChildren(outfile, level + 1, namespace_, name_, pretty_print=pretty_print)
            outfile.write('</%s%s>%s' % (namespace_, name_, eol_))
        else:
            outfile.write('/>%s' % (eol_, ))
    def exportAttributes(self, outfile, level, already_processed, namespace_='', name_='virtual-network-floating-ip-pool'):
        pass
    def exportChildren(self, outfile, level, namespace_='', name_='virtual-network-floating-ip-pool', fromsubclass_=False, pretty_print=True):
        pass
    def hasContent_(self):
        if (

            ):
            return True
        else:
            return False
    def exportLiteral(self, outfile, level, name_='virtual-network-floating-ip-pool'):
        level += 1
        self.exportLiteralAttributes(outfile, level, [], name_)
        if self.hasContent_():
            self.exportLiteralChildren(outfile, level, name_)
    def exportLiteralAttributes(self, outfile, level, already_processed, name_):
        pass
    def exportLiteralChildren(self, outfile, level, name_):
        pass
    def exportDict(self, name_='virtual-network-floating-ip-pool'):
        obj_json = json.dumps(self, default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        obj_dict = json.loads(obj_json)
        return {name_: obj_dict}
    def build(self, node):
        self.buildAttributes(node, node.attrib, [])
        for child in node:
            nodeName_ = Tag_pattern_.match(child.tag).groups()[-1]
            self.buildChildren(child, node, nodeName_)
    def buildAttributes(self, node, attrs, already_processed):
        pass
    def buildChildren(self, child_, node, nodeName_, fromsubclass_=False):
        pass
# end class virtual_network_floating_ip_pool


class project_floating_ip_pool(GeneratedsSuper):
    """
    project_floating_ip_pool class definition from :doc:`vnc_cfg.xsd`
    """
    subclass = None
    superclass = None
    def __init__(self, **kwargs):
        pass
    def factory(*args_, **kwargs_):
        if project_floating_ip_pool.subclass:
            return project_floating_ip_pool.subclass(*args_, **kwargs_)
        else:
            return project_floating_ip_pool(*args_, **kwargs_)
    factory = staticmethod(factory)
    @classmethod
    def populate (cls, *a, **kwa):
        obj = cls (*a, **kwa)
        return obj
    def export(self, outfile, level=1, namespace_='', name_='project-floating-ip-pool', namespacedef_='', pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        showIndent(outfile, level, pretty_print)
        outfile.write('<%s%s%s' % (namespace_, name_, namespacedef_ and ' ' + namespacedef_ or '', ))
        already_processed = []
        self.exportAttributes(outfile, level, already_processed, namespace_, name_='project-floating-ip-pool')
        if self.hasContent_():
            outfile.write('>%s' % (eol_, ))
            self.exportChildren(outfile, level + 1, namespace_, name_, pretty_print=pretty_print)
            outfile.write('</%s%s>%s' % (namespace_, name_, eol_))
        else:
            outfile.write('/>%s' % (eol_, ))
    def exportAttributes(self, outfile, level, already_processed, namespace_='', name_='project-floating-ip-pool'):
        pass
    def exportChildren(self, outfile, level, namespace_='', name_='project-floating-ip-pool', fromsubclass_=False, pretty_print=True):
        pass
    def hasContent_(self):
        if (

            ):
            return True
        else:
            return False
    def exportLiteral(self, outfile, level, name_='project-floating-ip-pool'):
        level += 1
        self.exportLiteralAttributes(outfile, level, [], name_)
        if self.hasContent_():
            self.exportLiteralChildren(outfile, level, name_)
    def exportLiteralAttributes(self, outfile, level, already_processed, name_):
        pass
    def exportLiteralChildren(self, outfile, level, name_):
        pass
    def exportDict(self, name_='project-floating-ip-pool'):
        obj_json = json.dumps(self, default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        obj_dict = json.loads(obj_json)
        return {name_: obj_dict}
    def build(self, node):
        self.buildAttributes(node, node.attrib, [])
        for child in node:
            nodeName_ = Tag_pattern_.match(child.tag).groups()[-1]
            self.buildChildren(child, node, nodeName_)
    def buildAttributes(self, node, attrs, already_processed):
        pass
    def buildChildren(self, child_, node, nodeName_, fromsubclass_=False):
        pass
# end class project_floating_ip_pool


class floating_ip_project(GeneratedsSuper):
    """
    floating_ip_project class definition from :doc:`vnc_cfg.xsd`
    """
    subclass = None
    superclass = None
    def __init__(self, **kwargs):
        pass
    def factory(*args_, **kwargs_):
        if floating_ip_project.subclass:
            return floating_ip_project.subclass(*args_, **kwargs_)
        else:
            return floating_ip_project(*args_, **kwargs_)
    factory = staticmethod(factory)
    @classmethod
    def populate (cls, *a, **kwa):
        obj = cls (*a, **kwa)
        return obj
    def export(self, outfile, level=1, namespace_='', name_='floating-ip-project', namespacedef_='', pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        showIndent(outfile, level, pretty_print)
        outfile.write('<%s%s%s' % (namespace_, name_, namespacedef_ and ' ' + namespacedef_ or '', ))
        already_processed = []
        self.exportAttributes(outfile, level, already_processed, namespace_, name_='floating-ip-project')
        if self.hasContent_():
            outfile.write('>%s' % (eol_, ))
            self.exportChildren(outfile, level + 1, namespace_, name_, pretty_print=pretty_print)
            outfile.write('</%s%s>%s' % (namespace_, name_, eol_))
        else:
            outfile.write('/>%s' % (eol_, ))
    def exportAttributes(self, outfile, level, already_processed, namespace_='', name_='floating-ip-project'):
        pass
    def exportChildren(self, outfile, level, namespace_='', name_='floating-ip-project', fromsubclass_=False, pretty_print=True):
        pass
    def hasContent_(self):
        if (

            ):
            return True
        else:
            return False
    def exportLiteral(self, outfile, level, name_='floating-ip-project'):
        level += 1
        self.exportLiteralAttributes(outfile, level, [], name_)
        if self.hasContent_():
            self.exportLiteralChildren(outfile, level, name_)
    def exportLiteralAttributes(self, outfile, level, already_processed, name_):
        pass
    def exportLiteralChildren(self, outfile, level, name_):
        pass
    def exportDict(self, name_='floating-ip-project'):
        obj_json = json.dumps(self, default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        obj_dict = json.loads(obj_json)
        return {name_: obj_dict}
    def build(self, node):
        self.buildAttributes(node, node.attrib, [])
        for child in node:
            nodeName_ = Tag_pattern_.match(child.tag).groups()[-1]
            self.buildChildren(child, node, nodeName_)
    def buildAttributes(self, node, attrs, already_processed):
        pass
    def buildChildren(self, child_, node, nodeName_, fromsubclass_=False):
        pass
# end class floating_ip_project


class floating_ip_pool_floating_ip(GeneratedsSuper):
    """
    floating_ip_pool_floating_ip class definition from :doc:`vnc_cfg.xsd`
    """
    subclass = None
    superclass = None
    def __init__(self, **kwargs):
        pass
    def factory(*args_, **kwargs_):
        if floating_ip_pool_floating_ip.subclass:
            return floating_ip_pool_floating_ip.subclass(*args_, **kwargs_)
        else:
            return floating_ip_pool_floating_ip(*args_, **kwargs_)
    factory = staticmethod(factory)
    @classmethod
    def populate (cls, *a, **kwa):
        obj = cls (*a, **kwa)
        return obj
    def export(self, outfile, level=1, namespace_='', name_='floating-ip-pool-floating-ip', namespacedef_='', pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        showIndent(outfile, level, pretty_print)
        outfile.write('<%s%s%s' % (namespace_, name_, namespacedef_ and ' ' + namespacedef_ or '', ))
        already_processed = []
        self.exportAttributes(outfile, level, already_processed, namespace_, name_='floating-ip-pool-floating-ip')
        if self.hasContent_():
            outfile.write('>%s' % (eol_, ))
            self.exportChildren(outfile, level + 1, namespace_, name_, pretty_print=pretty_print)
            outfile.write('</%s%s>%s' % (namespace_, name_, eol_))
        else:
            outfile.write('/>%s' % (eol_, ))
    def exportAttributes(self, outfile, level, already_processed, namespace_='', name_='floating-ip-pool-floating-ip'):
        pass
    def exportChildren(self, outfile, level, namespace_='', name_='floating-ip-pool-floating-ip', fromsubclass_=False, pretty_print=True):
        pass
    def hasContent_(self):
        if (

            ):
            return True
        else:
            return False
    def exportLiteral(self, outfile, level, name_='floating-ip-pool-floating-ip'):
        level += 1
        self.exportLiteralAttributes(outfile, level, [], name_)
        if self.hasContent_():
            self.exportLiteralChildren(outfile, level, name_)
    def exportLiteralAttributes(self, outfile, level, already_processed, name_):
        pass
    def exportLiteralChildren(self, outfile, level, name_):
        pass
    def exportDict(self, name_='floating-ip-pool-floating-ip'):
        obj_json = json.dumps(self, default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        obj_dict = json.loads(obj_json)
        return {name_: obj_dict}
    def build(self, node):
        self.buildAttributes(node, node.attrib, [])
        for child in node:
            nodeName_ = Tag_pattern_.match(child.tag).groups()[-1]
            self.buildChildren(child, node, nodeName_)
    def buildAttributes(self, node, attrs, already_processed):
        pass
    def buildChildren(self, child_, node, nodeName_, fromsubclass_=False):
        pass
# end class floating_ip_pool_floating_ip


class floating_ip_virtual_machine_interface(GeneratedsSuper):
    """
    floating_ip_virtual_machine_interface class definition from :doc:`vnc_cfg.xsd`
    """
    subclass = None
    superclass = None
    def __init__(self, **kwargs):
        pass
    def factory(*args_, **kwargs_):
        if floating_ip_virtual_machine_interface.subclass:
            return floating_ip_virtual_machine_interface.subclass(*args_, **kwargs_)
        else:
            return floating_ip_virtual_machine_interface(*args_, **kwargs_)
    factory = staticmethod(factory)
    @classmethod
    def populate (cls, *a, **kwa):
        obj = cls (*a, **kwa)
        return obj
    def export(self, outfile, level=1, namespace_='', name_='floating-ip-virtual-machine-interface', namespacedef_='', pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        showIndent(outfile, level, pretty_print)
        outfile.write('<%s%s%s' % (namespace_, name_, namespacedef_ and ' ' + namespacedef_ or '', ))
        already_processed = []
        self.exportAttributes(outfile, level, already_processed, namespace_, name_='floating-ip-virtual-machine-interface')
        if self.hasContent_():
            outfile.write('>%s' % (eol_, ))
            self.exportChildren(outfile, level + 1, namespace_, name_, pretty_print=pretty_print)
            outfile.write('</%s%s>%s' % (namespace_, name_, eol_))
        else:
            outfile.write('/>%s' % (eol_, ))
    def exportAttributes(self, outfile, level, already_processed, namespace_='', name_='floating-ip-virtual-machine-interface'):
        pass
    def exportChildren(self, outfile, level, namespace_='', name_='floating-ip-virtual-machine-interface', fromsubclass_=False, pretty_print=True):
        pass
    def hasContent_(self):
        if (

            ):
            return True
        else:
            return False
    def exportLiteral(self, outfile, level, name_='floating-ip-virtual-machine-interface'):
        level += 1
        self.exportLiteralAttributes(outfile, level, [], name_)
        if self.hasContent_():
            self.exportLiteralChildren(outfile, level, name_)
    def exportLiteralAttributes(self, outfile, level, already_processed, name_):
        pass
    def exportLiteralChildren(self, outfile, level, name_):
        pass
    def exportDict(self, name_='floating-ip-virtual-machine-interface'):
        obj_json = json.dumps(self, default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        obj_dict = json.loads(obj_json)
        return {name_: obj_dict}
    def build(self, node):
        self.buildAttributes(node, node.attrib, [])
        for child in node:
            nodeName_ = Tag_pattern_.match(child.tag).groups()[-1]
            self.buildChildren(child, node, nodeName_)
    def buildAttributes(self, node, attrs, already_processed):
        pass
    def buildChildren(self, child_, node, nodeName_, fromsubclass_=False):
        pass
# end class floating_ip_virtual_machine_interface


class global_system_config_physical_router(GeneratedsSuper):
    """
    global_system_config_physical_router class definition from :doc:`vnc_cfg.xsd`
    """
    subclass = None
    superclass = None
    def __init__(self, **kwargs):
        pass
    def factory(*args_, **kwargs_):
        if global_system_config_physical_router.subclass:
            return global_system_config_physical_router.subclass(*args_, **kwargs_)
        else:
            return global_system_config_physical_router(*args_, **kwargs_)
    factory = staticmethod(factory)
    @classmethod
    def populate (cls, *a, **kwa):
        obj = cls (*a, **kwa)
        return obj
    def export(self, outfile, level=1, namespace_='', name_='global-system-config-physical-router', namespacedef_='', pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        showIndent(outfile, level, pretty_print)
        outfile.write('<%s%s%s' % (namespace_, name_, namespacedef_ and ' ' + namespacedef_ or '', ))
        already_processed = []
        self.exportAttributes(outfile, level, already_processed, namespace_, name_='global-system-config-physical-router')
        if self.hasContent_():
            outfile.write('>%s' % (eol_, ))
            self.exportChildren(outfile, level + 1, namespace_, name_, pretty_print=pretty_print)
            outfile.write('</%s%s>%s' % (namespace_, name_, eol_))
        else:
            outfile.write('/>%s' % (eol_, ))
    def exportAttributes(self, outfile, level, already_processed, namespace_='', name_='global-system-config-physical-router'):
        pass
    def exportChildren(self, outfile, level, namespace_='', name_='global-system-config-physical-router', fromsubclass_=False, pretty_print=True):
        pass
    def hasContent_(self):
        if (

            ):
            return True
        else:
            return False
    def exportLiteral(self, outfile, level, name_='global-system-config-physical-router'):
        level += 1
        self.exportLiteralAttributes(outfile, level, [], name_)
        if self.hasContent_():
            self.exportLiteralChildren(outfile, level, name_)
    def exportLiteralAttributes(self, outfile, level, already_processed, name_):
        pass
    def exportLiteralChildren(self, outfile, level, name_):
        pass
    def exportDict(self, name_='global-system-config-physical-router'):
        obj_json = json.dumps(self, default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        obj_dict = json.loads(obj_json)
        return {name_: obj_dict}
    def build(self, node):
        self.buildAttributes(node, node.attrib, [])
        for child in node:
            nodeName_ = Tag_pattern_.match(child.tag).groups()[-1]
            self.buildChildren(child, node, nodeName_)
    def buildAttributes(self, node, attrs, already_processed):
        pass
    def buildChildren(self, child_, node, nodeName_, fromsubclass_=False):
        pass
# end class global_system_config_physical_router


class physical_router_bgp_router(GeneratedsSuper):
    """
    physical_router_bgp_router class definition from :doc:`vnc_cfg.xsd`
    """
    subclass = None
    superclass = None
    def __init__(self, **kwargs):
        pass
    def factory(*args_, **kwargs_):
        if physical_router_bgp_router.subclass:
            return physical_router_bgp_router.subclass(*args_, **kwargs_)
        else:
            return physical_router_bgp_router(*args_, **kwargs_)
    factory = staticmethod(factory)
    @classmethod
    def populate (cls, *a, **kwa):
        obj = cls (*a, **kwa)
        return obj
    def export(self, outfile, level=1, namespace_='', name_='physical-router-bgp-router', namespacedef_='', pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        showIndent(outfile, level, pretty_print)
        outfile.write('<%s%s%s' % (namespace_, name_, namespacedef_ and ' ' + namespacedef_ or '', ))
        already_processed = []
        self.exportAttributes(outfile, level, already_processed, namespace_, name_='physical-router-bgp-router')
        if self.hasContent_():
            outfile.write('>%s' % (eol_, ))
            self.exportChildren(outfile, level + 1, namespace_, name_, pretty_print=pretty_print)
            outfile.write('</%s%s>%s' % (namespace_, name_, eol_))
        else:
            outfile.write('/>%s' % (eol_, ))
    def exportAttributes(self, outfile, level, already_processed, namespace_='', name_='physical-router-bgp-router'):
        pass
    def exportChildren(self, outfile, level, namespace_='', name_='physical-router-bgp-router', fromsubclass_=False, pretty_print=True):
        pass
    def hasContent_(self):
        if (

            ):
            return True
        else:
            return False
    def exportLiteral(self, outfile, level, name_='physical-router-bgp-router'):
        level += 1
        self.exportLiteralAttributes(outfile, level, [], name_)
        if self.hasContent_():
            self.exportLiteralChildren(outfile, level, name_)
    def exportLiteralAttributes(self, outfile, level, already_processed, name_):
        pass
    def exportLiteralChildren(self, outfile, level, name_):
        pass
    def exportDict(self, name_='physical-router-bgp-router'):
        obj_json = json.dumps(self, default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        obj_dict = json.loads(obj_json)
        return {name_: obj_dict}
    def build(self, node):
        self.buildAttributes(node, node.attrib, [])
        for child in node:
            nodeName_ = Tag_pattern_.match(child.tag).groups()[-1]
            self.buildChildren(child, node, nodeName_)
    def buildAttributes(self, node, attrs, already_processed):
        pass
    def buildChildren(self, child_, node, nodeName_, fromsubclass_=False):
        pass
# end class physical_router_bgp_router


class physical_router_physical_interface(GeneratedsSuper):
    """
    physical_router_physical_interface class definition from :doc:`vnc_cfg.xsd`
    """
    subclass = None
    superclass = None
    def __init__(self, **kwargs):
        pass
    def factory(*args_, **kwargs_):
        if physical_router_physical_interface.subclass:
            return physical_router_physical_interface.subclass(*args_, **kwargs_)
        else:
            return physical_router_physical_interface(*args_, **kwargs_)
    factory = staticmethod(factory)
    @classmethod
    def populate (cls, *a, **kwa):
        obj = cls (*a, **kwa)
        return obj
    def export(self, outfile, level=1, namespace_='', name_='physical-router-physical-interface', namespacedef_='', pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        showIndent(outfile, level, pretty_print)
        outfile.write('<%s%s%s' % (namespace_, name_, namespacedef_ and ' ' + namespacedef_ or '', ))
        already_processed = []
        self.exportAttributes(outfile, level, already_processed, namespace_, name_='physical-router-physical-interface')
        if self.hasContent_():
            outfile.write('>%s' % (eol_, ))
            self.exportChildren(outfile, level + 1, namespace_, name_, pretty_print=pretty_print)
            outfile.write('</%s%s>%s' % (namespace_, name_, eol_))
        else:
            outfile.write('/>%s' % (eol_, ))
    def exportAttributes(self, outfile, level, already_processed, namespace_='', name_='physical-router-physical-interface'):
        pass
    def exportChildren(self, outfile, level, namespace_='', name_='physical-router-physical-interface', fromsubclass_=False, pretty_print=True):
        pass
    def hasContent_(self):
        if (

            ):
            return True
        else:
            return False
    def exportLiteral(self, outfile, level, name_='physical-router-physical-interface'):
        level += 1
        self.exportLiteralAttributes(outfile, level, [], name_)
        if self.hasContent_():
            self.exportLiteralChildren(outfile, level, name_)
    def exportLiteralAttributes(self, outfile, level, already_processed, name_):
        pass
    def exportLiteralChildren(self, outfile, level, name_):
        pass
    def exportDict(self, name_='physical-router-physical-interface'):
        obj_json = json.dumps(self, default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        obj_dict = json.loads(obj_json)
        return {name_: obj_dict}
    def build(self, node):
        self.buildAttributes(node, node.attrib, [])
        for child in node:
            nodeName_ = Tag_pattern_.match(child.tag).groups()[-1]
            self.buildChildren(child, node, nodeName_)
    def buildAttributes(self, node, attrs, already_processed):
        pass
    def buildChildren(self, child_, node, nodeName_, fromsubclass_=False):
        pass
# end class physical_router_physical_interface


class physical_interface_logical_interface(GeneratedsSuper):
    """
    physical_interface_logical_interface class definition from :doc:`vnc_cfg.xsd`
    """
    subclass = None
    superclass = None
    def __init__(self, **kwargs):
        pass
    def factory(*args_, **kwargs_):
        if physical_interface_logical_interface.subclass:
            return physical_interface_logical_interface.subclass(*args_, **kwargs_)
        else:
            return physical_interface_logical_interface(*args_, **kwargs_)
    factory = staticmethod(factory)
    @classmethod
    def populate (cls, *a, **kwa):
        obj = cls (*a, **kwa)
        return obj
    def export(self, outfile, level=1, namespace_='', name_='physical-interface-logical-interface', namespacedef_='', pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        showIndent(outfile, level, pretty_print)
        outfile.write('<%s%s%s' % (namespace_, name_, namespacedef_ and ' ' + namespacedef_ or '', ))
        already_processed = []
        self.exportAttributes(outfile, level, already_processed, namespace_, name_='physical-interface-logical-interface')
        if self.hasContent_():
            outfile.write('>%s' % (eol_, ))
            self.exportChildren(outfile, level + 1, namespace_, name_, pretty_print=pretty_print)
            outfile.write('</%s%s>%s' % (namespace_, name_, eol_))
        else:
            outfile.write('/>%s' % (eol_, ))
    def exportAttributes(self, outfile, level, already_processed, namespace_='', name_='physical-interface-logical-interface'):
        pass
    def exportChildren(self, outfile, level, namespace_='', name_='physical-interface-logical-interface', fromsubclass_=False, pretty_print=True):
        pass
    def hasContent_(self):
        if (

            ):
            return True
        else:
            return False
    def exportLiteral(self, outfile, level, name_='physical-interface-logical-interface'):
        level += 1
        self.exportLiteralAttributes(outfile, level, [], name_)
        if self.hasContent_():
            self.exportLiteralChildren(outfile, level, name_)
    def exportLiteralAttributes(self, outfile, level, already_processed, name_):
        pass
    def exportLiteralChildren(self, outfile, level, name_):
        pass
    def exportDict(self, name_='physical-interface-logical-interface'):
        obj_json = json.dumps(self, default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        obj_dict = json.loads(obj_json)
        return {name_: obj_dict}
    def build(self, node):
        self.buildAttributes(node, node.attrib, [])
        for child in node:
            nodeName_ = Tag_pattern_.match(child.tag).groups()[-1]
            self.buildChildren(child, node, nodeName_)
    def buildAttributes(self, node, attrs, already_processed):
        pass
    def buildChildren(self, child_, node, nodeName_, fromsubclass_=False):
        pass
# end class physical_interface_logical_interface


class logical_interface_virtual_network(GeneratedsSuper):
    """
    logical_interface_virtual_network class definition from :doc:`vnc_cfg.xsd`
    """
    subclass = None
    superclass = None
    def __init__(self, **kwargs):
        pass
    def factory(*args_, **kwargs_):
        if logical_interface_virtual_network.subclass:
            return logical_interface_virtual_network.subclass(*args_, **kwargs_)
        else:
            return logical_interface_virtual_network(*args_, **kwargs_)
    factory = staticmethod(factory)
    @classmethod
    def populate (cls, *a, **kwa):
        obj = cls (*a, **kwa)
        return obj
    def export(self, outfile, level=1, namespace_='', name_='logical-interface-virtual-network', namespacedef_='', pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        showIndent(outfile, level, pretty_print)
        outfile.write('<%s%s%s' % (namespace_, name_, namespacedef_ and ' ' + namespacedef_ or '', ))
        already_processed = []
        self.exportAttributes(outfile, level, already_processed, namespace_, name_='logical-interface-virtual-network')
        if self.hasContent_():
            outfile.write('>%s' % (eol_, ))
            self.exportChildren(outfile, level + 1, namespace_, name_, pretty_print=pretty_print)
            outfile.write('</%s%s>%s' % (namespace_, name_, eol_))
        else:
            outfile.write('/>%s' % (eol_, ))
    def exportAttributes(self, outfile, level, already_processed, namespace_='', name_='logical-interface-virtual-network'):
        pass
    def exportChildren(self, outfile, level, namespace_='', name_='logical-interface-virtual-network', fromsubclass_=False, pretty_print=True):
        pass
    def hasContent_(self):
        if (

            ):
            return True
        else:
            return False
    def exportLiteral(self, outfile, level, name_='logical-interface-virtual-network'):
        level += 1
        self.exportLiteralAttributes(outfile, level, [], name_)
        if self.hasContent_():
            self.exportLiteralChildren(outfile, level, name_)
    def exportLiteralAttributes(self, outfile, level, already_processed, name_):
        pass
    def exportLiteralChildren(self, outfile, level, name_):
        pass
    def exportDict(self, name_='logical-interface-virtual-network'):
        obj_json = json.dumps(self, default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        obj_dict = json.loads(obj_json)
        return {name_: obj_dict}
    def build(self, node):
        self.buildAttributes(node, node.attrib, [])
        for child in node:
            nodeName_ = Tag_pattern_.match(child.tag).groups()[-1]
            self.buildChildren(child, node, nodeName_)
    def buildAttributes(self, node, attrs, already_processed):
        pass
    def buildChildren(self, child_, node, nodeName_, fromsubclass_=False):
        pass
# end class logical_interface_virtual_network


class global_system_config_virtual_router(GeneratedsSuper):
    """
    global_system_config_virtual_router class definition from :doc:`vnc_cfg.xsd`
    """
    subclass = None
    superclass = None
    def __init__(self, **kwargs):
        pass
    def factory(*args_, **kwargs_):
        if global_system_config_virtual_router.subclass:
            return global_system_config_virtual_router.subclass(*args_, **kwargs_)
        else:
            return global_system_config_virtual_router(*args_, **kwargs_)
    factory = staticmethod(factory)
    @classmethod
    def populate (cls, *a, **kwa):
        obj = cls (*a, **kwa)
        return obj
    def export(self, outfile, level=1, namespace_='', name_='global-system-config-virtual-router', namespacedef_='', pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        showIndent(outfile, level, pretty_print)
        outfile.write('<%s%s%s' % (namespace_, name_, namespacedef_ and ' ' + namespacedef_ or '', ))
        already_processed = []
        self.exportAttributes(outfile, level, already_processed, namespace_, name_='global-system-config-virtual-router')
        if self.hasContent_():
            outfile.write('>%s' % (eol_, ))
            self.exportChildren(outfile, level + 1, namespace_, name_, pretty_print=pretty_print)
            outfile.write('</%s%s>%s' % (namespace_, name_, eol_))
        else:
            outfile.write('/>%s' % (eol_, ))
    def exportAttributes(self, outfile, level, already_processed, namespace_='', name_='global-system-config-virtual-router'):
        pass
    def exportChildren(self, outfile, level, namespace_='', name_='global-system-config-virtual-router', fromsubclass_=False, pretty_print=True):
        pass
    def hasContent_(self):
        if (

            ):
            return True
        else:
            return False
    def exportLiteral(self, outfile, level, name_='global-system-config-virtual-router'):
        level += 1
        self.exportLiteralAttributes(outfile, level, [], name_)
        if self.hasContent_():
            self.exportLiteralChildren(outfile, level, name_)
    def exportLiteralAttributes(self, outfile, level, already_processed, name_):
        pass
    def exportLiteralChildren(self, outfile, level, name_):
        pass
    def exportDict(self, name_='global-system-config-virtual-router'):
        obj_json = json.dumps(self, default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        obj_dict = json.loads(obj_json)
        return {name_: obj_dict}
    def build(self, node):
        self.buildAttributes(node, node.attrib, [])
        for child in node:
            nodeName_ = Tag_pattern_.match(child.tag).groups()[-1]
            self.buildChildren(child, node, nodeName_)
    def buildAttributes(self, node, attrs, already_processed):
        pass
    def buildChildren(self, child_, node, nodeName_, fromsubclass_=False):
        pass
# end class global_system_config_virtual_router


class virtual_router_bgp_router(GeneratedsSuper):
    """
    virtual_router_bgp_router class definition from :doc:`vnc_cfg.xsd`
    """
    subclass = None
    superclass = None
    def __init__(self, **kwargs):
        pass
    def factory(*args_, **kwargs_):
        if virtual_router_bgp_router.subclass:
            return virtual_router_bgp_router.subclass(*args_, **kwargs_)
        else:
            return virtual_router_bgp_router(*args_, **kwargs_)
    factory = staticmethod(factory)
    @classmethod
    def populate (cls, *a, **kwa):
        obj = cls (*a, **kwa)
        return obj
    def export(self, outfile, level=1, namespace_='', name_='virtual-router-bgp-router', namespacedef_='', pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        showIndent(outfile, level, pretty_print)
        outfile.write('<%s%s%s' % (namespace_, name_, namespacedef_ and ' ' + namespacedef_ or '', ))
        already_processed = []
        self.exportAttributes(outfile, level, already_processed, namespace_, name_='virtual-router-bgp-router')
        if self.hasContent_():
            outfile.write('>%s' % (eol_, ))
            self.exportChildren(outfile, level + 1, namespace_, name_, pretty_print=pretty_print)
            outfile.write('</%s%s>%s' % (namespace_, name_, eol_))
        else:
            outfile.write('/>%s' % (eol_, ))
    def exportAttributes(self, outfile, level, already_processed, namespace_='', name_='virtual-router-bgp-router'):
        pass
    def exportChildren(self, outfile, level, namespace_='', name_='virtual-router-bgp-router', fromsubclass_=False, pretty_print=True):
        pass
    def hasContent_(self):
        if (

            ):
            return True
        else:
            return False
    def exportLiteral(self, outfile, level, name_='virtual-router-bgp-router'):
        level += 1
        self.exportLiteralAttributes(outfile, level, [], name_)
        if self.hasContent_():
            self.exportLiteralChildren(outfile, level, name_)
    def exportLiteralAttributes(self, outfile, level, already_processed, name_):
        pass
    def exportLiteralChildren(self, outfile, level, name_):
        pass
    def exportDict(self, name_='virtual-router-bgp-router'):
        obj_json = json.dumps(self, default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        obj_dict = json.loads(obj_json)
        return {name_: obj_dict}
    def build(self, node):
        self.buildAttributes(node, node.attrib, [])
        for child in node:
            nodeName_ = Tag_pattern_.match(child.tag).groups()[-1]
            self.buildChildren(child, node, nodeName_)
    def buildAttributes(self, node, attrs, already_processed):
        pass
    def buildChildren(self, child_, node, nodeName_, fromsubclass_=False):
        pass
# end class virtual_router_bgp_router


class virtual_router_virtual_machine(GeneratedsSuper):
    """
    virtual_router_virtual_machine class definition from :doc:`vnc_cfg.xsd`
    """
    subclass = None
    superclass = None
    def __init__(self, **kwargs):
        pass
    def factory(*args_, **kwargs_):
        if virtual_router_virtual_machine.subclass:
            return virtual_router_virtual_machine.subclass(*args_, **kwargs_)
        else:
            return virtual_router_virtual_machine(*args_, **kwargs_)
    factory = staticmethod(factory)
    @classmethod
    def populate (cls, *a, **kwa):
        obj = cls (*a, **kwa)
        return obj
    def export(self, outfile, level=1, namespace_='', name_='virtual-router-virtual-machine', namespacedef_='', pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        showIndent(outfile, level, pretty_print)
        outfile.write('<%s%s%s' % (namespace_, name_, namespacedef_ and ' ' + namespacedef_ or '', ))
        already_processed = []
        self.exportAttributes(outfile, level, already_processed, namespace_, name_='virtual-router-virtual-machine')
        if self.hasContent_():
            outfile.write('>%s' % (eol_, ))
            self.exportChildren(outfile, level + 1, namespace_, name_, pretty_print=pretty_print)
            outfile.write('</%s%s>%s' % (namespace_, name_, eol_))
        else:
            outfile.write('/>%s' % (eol_, ))
    def exportAttributes(self, outfile, level, already_processed, namespace_='', name_='virtual-router-virtual-machine'):
        pass
    def exportChildren(self, outfile, level, namespace_='', name_='virtual-router-virtual-machine', fromsubclass_=False, pretty_print=True):
        pass
    def hasContent_(self):
        if (

            ):
            return True
        else:
            return False
    def exportLiteral(self, outfile, level, name_='virtual-router-virtual-machine'):
        level += 1
        self.exportLiteralAttributes(outfile, level, [], name_)
        if self.hasContent_():
            self.exportLiteralChildren(outfile, level, name_)
    def exportLiteralAttributes(self, outfile, level, already_processed, name_):
        pass
    def exportLiteralChildren(self, outfile, level, name_):
        pass
    def exportDict(self, name_='virtual-router-virtual-machine'):
        obj_json = json.dumps(self, default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        obj_dict = json.loads(obj_json)
        return {name_: obj_dict}
    def build(self, node):
        self.buildAttributes(node, node.attrib, [])
        for child in node:
            nodeName_ = Tag_pattern_.match(child.tag).groups()[-1]
            self.buildChildren(child, node, nodeName_)
    def buildAttributes(self, node, attrs, already_processed):
        pass
    def buildChildren(self, child_, node, nodeName_, fromsubclass_=False):
        pass
# end class virtual_router_virtual_machine


class virtual_network_routing_instance(GeneratedsSuper):
    """
    virtual_network_routing_instance class definition from :doc:`vnc_cfg.xsd`
    """
    subclass = None
    superclass = None
    def __init__(self, **kwargs):
        pass
    def factory(*args_, **kwargs_):
        if virtual_network_routing_instance.subclass:
            return virtual_network_routing_instance.subclass(*args_, **kwargs_)
        else:
            return virtual_network_routing_instance(*args_, **kwargs_)
    factory = staticmethod(factory)
    @classmethod
    def populate (cls, *a, **kwa):
        obj = cls (*a, **kwa)
        return obj
    def export(self, outfile, level=1, namespace_='', name_='virtual-network-routing-instance', namespacedef_='', pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        showIndent(outfile, level, pretty_print)
        outfile.write('<%s%s%s' % (namespace_, name_, namespacedef_ and ' ' + namespacedef_ or '', ))
        already_processed = []
        self.exportAttributes(outfile, level, already_processed, namespace_, name_='virtual-network-routing-instance')
        if self.hasContent_():
            outfile.write('>%s' % (eol_, ))
            self.exportChildren(outfile, level + 1, namespace_, name_, pretty_print=pretty_print)
            outfile.write('</%s%s>%s' % (namespace_, name_, eol_))
        else:
            outfile.write('/>%s' % (eol_, ))
    def exportAttributes(self, outfile, level, already_processed, namespace_='', name_='virtual-network-routing-instance'):
        pass
    def exportChildren(self, outfile, level, namespace_='', name_='virtual-network-routing-instance', fromsubclass_=False, pretty_print=True):
        pass
    def hasContent_(self):
        if (

            ):
            return True
        else:
            return False
    def exportLiteral(self, outfile, level, name_='virtual-network-routing-instance'):
        level += 1
        self.exportLiteralAttributes(outfile, level, [], name_)
        if self.hasContent_():
            self.exportLiteralChildren(outfile, level, name_)
    def exportLiteralAttributes(self, outfile, level, already_processed, name_):
        pass
    def exportLiteralChildren(self, outfile, level, name_):
        pass
    def exportDict(self, name_='virtual-network-routing-instance'):
        obj_json = json.dumps(self, default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        obj_dict = json.loads(obj_json)
        return {name_: obj_dict}
    def build(self, node):
        self.buildAttributes(node, node.attrib, [])
        for child in node:
            nodeName_ = Tag_pattern_.match(child.tag).groups()[-1]
            self.buildChildren(child, node, nodeName_)
    def buildAttributes(self, node, attrs, already_processed):
        pass
    def buildChildren(self, child_, node, nodeName_, fromsubclass_=False):
        pass
# end class virtual_network_routing_instance


class customer_attachment_virtual_machine_interface(GeneratedsSuper):
    """
    customer_attachment_virtual_machine_interface class definition from :doc:`vnc_cfg.xsd`
    """
    subclass = None
    superclass = None
    def __init__(self, **kwargs):
        pass
    def factory(*args_, **kwargs_):
        if customer_attachment_virtual_machine_interface.subclass:
            return customer_attachment_virtual_machine_interface.subclass(*args_, **kwargs_)
        else:
            return customer_attachment_virtual_machine_interface(*args_, **kwargs_)
    factory = staticmethod(factory)
    @classmethod
    def populate (cls, *a, **kwa):
        obj = cls (*a, **kwa)
        return obj
    def export(self, outfile, level=1, namespace_='', name_='customer-attachment-virtual-machine-interface', namespacedef_='', pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        showIndent(outfile, level, pretty_print)
        outfile.write('<%s%s%s' % (namespace_, name_, namespacedef_ and ' ' + namespacedef_ or '', ))
        already_processed = []
        self.exportAttributes(outfile, level, already_processed, namespace_, name_='customer-attachment-virtual-machine-interface')
        if self.hasContent_():
            outfile.write('>%s' % (eol_, ))
            self.exportChildren(outfile, level + 1, namespace_, name_, pretty_print=pretty_print)
            outfile.write('</%s%s>%s' % (namespace_, name_, eol_))
        else:
            outfile.write('/>%s' % (eol_, ))
    def exportAttributes(self, outfile, level, already_processed, namespace_='', name_='customer-attachment-virtual-machine-interface'):
        pass
    def exportChildren(self, outfile, level, namespace_='', name_='customer-attachment-virtual-machine-interface', fromsubclass_=False, pretty_print=True):
        pass
    def hasContent_(self):
        if (

            ):
            return True
        else:
            return False
    def exportLiteral(self, outfile, level, name_='customer-attachment-virtual-machine-interface'):
        level += 1
        self.exportLiteralAttributes(outfile, level, [], name_)
        if self.hasContent_():
            self.exportLiteralChildren(outfile, level, name_)
    def exportLiteralAttributes(self, outfile, level, already_processed, name_):
        pass
    def exportLiteralChildren(self, outfile, level, name_):
        pass
    def exportDict(self, name_='customer-attachment-virtual-machine-interface'):
        obj_json = json.dumps(self, default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        obj_dict = json.loads(obj_json)
        return {name_: obj_dict}
    def build(self, node):
        self.buildAttributes(node, node.attrib, [])
        for child in node:
            nodeName_ = Tag_pattern_.match(child.tag).groups()[-1]
            self.buildChildren(child, node, nodeName_)
    def buildAttributes(self, node, attrs, already_processed):
        pass
    def buildChildren(self, child_, node, nodeName_, fromsubclass_=False):
        pass
# end class customer_attachment_virtual_machine_interface


class customer_attachment_floating_ip(GeneratedsSuper):
    """
    customer_attachment_floating_ip class definition from :doc:`vnc_cfg.xsd`
    """
    subclass = None
    superclass = None
    def __init__(self, **kwargs):
        pass
    def factory(*args_, **kwargs_):
        if customer_attachment_floating_ip.subclass:
            return customer_attachment_floating_ip.subclass(*args_, **kwargs_)
        else:
            return customer_attachment_floating_ip(*args_, **kwargs_)
    factory = staticmethod(factory)
    @classmethod
    def populate (cls, *a, **kwa):
        obj = cls (*a, **kwa)
        return obj
    def export(self, outfile, level=1, namespace_='', name_='customer-attachment-floating-ip', namespacedef_='', pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        showIndent(outfile, level, pretty_print)
        outfile.write('<%s%s%s' % (namespace_, name_, namespacedef_ and ' ' + namespacedef_ or '', ))
        already_processed = []
        self.exportAttributes(outfile, level, already_processed, namespace_, name_='customer-attachment-floating-ip')
        if self.hasContent_():
            outfile.write('>%s' % (eol_, ))
            self.exportChildren(outfile, level + 1, namespace_, name_, pretty_print=pretty_print)
            outfile.write('</%s%s>%s' % (namespace_, name_, eol_))
        else:
            outfile.write('/>%s' % (eol_, ))
    def exportAttributes(self, outfile, level, already_processed, namespace_='', name_='customer-attachment-floating-ip'):
        pass
    def exportChildren(self, outfile, level, namespace_='', name_='customer-attachment-floating-ip', fromsubclass_=False, pretty_print=True):
        pass
    def hasContent_(self):
        if (

            ):
            return True
        else:
            return False
    def exportLiteral(self, outfile, level, name_='customer-attachment-floating-ip'):
        level += 1
        self.exportLiteralAttributes(outfile, level, [], name_)
        if self.hasContent_():
            self.exportLiteralChildren(outfile, level, name_)
    def exportLiteralAttributes(self, outfile, level, already_processed, name_):
        pass
    def exportLiteralChildren(self, outfile, level, name_):
        pass
    def exportDict(self, name_='customer-attachment-floating-ip'):
        obj_json = json.dumps(self, default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        obj_dict = json.loads(obj_json)
        return {name_: obj_dict}
    def build(self, node):
        self.buildAttributes(node, node.attrib, [])
        for child in node:
            nodeName_ = Tag_pattern_.match(child.tag).groups()[-1]
            self.buildChildren(child, node, nodeName_)
    def buildAttributes(self, node, attrs, already_processed):
        pass
    def buildChildren(self, child_, node, nodeName_, fromsubclass_=False):
        pass
# end class customer_attachment_floating_ip


class provider_attachment_virtual_router(GeneratedsSuper):
    """
    provider_attachment_virtual_router class definition from :doc:`vnc_cfg.xsd`
    """
    subclass = None
    superclass = None
    def __init__(self, **kwargs):
        pass
    def factory(*args_, **kwargs_):
        if provider_attachment_virtual_router.subclass:
            return provider_attachment_virtual_router.subclass(*args_, **kwargs_)
        else:
            return provider_attachment_virtual_router(*args_, **kwargs_)
    factory = staticmethod(factory)
    @classmethod
    def populate (cls, *a, **kwa):
        obj = cls (*a, **kwa)
        return obj
    def export(self, outfile, level=1, namespace_='', name_='provider-attachment-virtual-router', namespacedef_='', pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        showIndent(outfile, level, pretty_print)
        outfile.write('<%s%s%s' % (namespace_, name_, namespacedef_ and ' ' + namespacedef_ or '', ))
        already_processed = []
        self.exportAttributes(outfile, level, already_processed, namespace_, name_='provider-attachment-virtual-router')
        if self.hasContent_():
            outfile.write('>%s' % (eol_, ))
            self.exportChildren(outfile, level + 1, namespace_, name_, pretty_print=pretty_print)
            outfile.write('</%s%s>%s' % (namespace_, name_, eol_))
        else:
            outfile.write('/>%s' % (eol_, ))
    def exportAttributes(self, outfile, level, already_processed, namespace_='', name_='provider-attachment-virtual-router'):
        pass
    def exportChildren(self, outfile, level, namespace_='', name_='provider-attachment-virtual-router', fromsubclass_=False, pretty_print=True):
        pass
    def hasContent_(self):
        if (

            ):
            return True
        else:
            return False
    def exportLiteral(self, outfile, level, name_='provider-attachment-virtual-router'):
        level += 1
        self.exportLiteralAttributes(outfile, level, [], name_)
        if self.hasContent_():
            self.exportLiteralChildren(outfile, level, name_)
    def exportLiteralAttributes(self, outfile, level, already_processed, name_):
        pass
    def exportLiteralChildren(self, outfile, level, name_):
        pass
    def exportDict(self, name_='provider-attachment-virtual-router'):
        obj_json = json.dumps(self, default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        obj_dict = json.loads(obj_json)
        return {name_: obj_dict}
    def build(self, node):
        self.buildAttributes(node, node.attrib, [])
        for child in node:
            nodeName_ = Tag_pattern_.match(child.tag).groups()[-1]
            self.buildChildren(child, node, nodeName_)
    def buildAttributes(self, node, attrs, already_processed):
        pass
    def buildChildren(self, child_, node, nodeName_, fromsubclass_=False):
        pass
# end class provider_attachment_virtual_router


class ServiceScaleOutType(GeneratedsSuper):
    """
    ServiceScaleOutType class definition from :doc:`vnc_cfg.xsd`
    """
    subclass = None
    superclass = None
    def __init__(self, max_instances=1, auto_scale=False, **kwargs):
        self.max_instances = max_instances
        self.auto_scale = auto_scale
    def factory(*args_, **kwargs_):
        if ServiceScaleOutType.subclass:
            return ServiceScaleOutType.subclass(*args_, **kwargs_)
        else:
            return ServiceScaleOutType(*args_, **kwargs_)
    factory = staticmethod(factory)
    def get_max_instances(self): return self.max_instances
    def set_max_instances(self, max_instances): self.max_instances = max_instances
    def get_auto_scale(self): return self.auto_scale
    def set_auto_scale(self, auto_scale): self.auto_scale = auto_scale
    @classmethod
    def populate (cls, *a, **kwa):
        obj = cls (*a, **kwa)
        obj.set_max_instances (obj.populate_integer ("max_instances"))
        obj.set_auto_scale (obj.populate_boolean ("auto_scale"))
        return obj
    def export(self, outfile, level=1, namespace_='', name_='ServiceScaleOutType', namespacedef_='', pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        showIndent(outfile, level, pretty_print)
        outfile.write('<%s%s%s' % (namespace_, name_, namespacedef_ and ' ' + namespacedef_ or '', ))
        already_processed = []
        self.exportAttributes(outfile, level, already_processed, namespace_, name_='ServiceScaleOutType')
        if self.hasContent_():
            outfile.write('>%s' % (eol_, ))
            self.exportChildren(outfile, level + 1, namespace_, name_, pretty_print=pretty_print)
            showIndent(outfile, level, pretty_print)
            outfile.write('</%s%s>%s' % (namespace_, name_, eol_))
        else:
            outfile.write('/>%s' % (eol_, ))
    def exportAttributes(self, outfile, level, already_processed, namespace_='', name_='ServiceScaleOutType'):
        pass
    def exportChildren(self, outfile, level, namespace_='', name_='ServiceScaleOutType', fromsubclass_=False, pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        if self.max_instances is not None:
            showIndent(outfile, level, pretty_print)
            outfile.write('<%smax-instances>%s</%smax-instances>%s' % (namespace_, self.gds_format_integer(self.max_instances, input_name='max-instances'), namespace_, eol_))
        if self.auto_scale is not None:
            showIndent(outfile, level, pretty_print)
            outfile.write('<%sauto-scale>%s</%sauto-scale>%s' % (namespace_, self.gds_format_boolean(self.gds_str_lower(str(self.auto_scale)), input_name='auto-scale'), namespace_, eol_))
    def hasContent_(self):
        if (
            self.max_instances is not None or
            self.auto_scale is not None
            ):
            return True
        else:
            return False
    def exportLiteral(self, outfile, level, name_='ServiceScaleOutType'):
        level += 1
        self.exportLiteralAttributes(outfile, level, [], name_)
        if self.hasContent_():
            self.exportLiteralChildren(outfile, level, name_)
    def exportLiteralAttributes(self, outfile, level, already_processed, name_):
        pass
    def exportLiteralChildren(self, outfile, level, name_):
        if self.max_instances is not None:
            showIndent(outfile, level)
            outfile.write('max_instances=%d,\n' % self.max_instances)
        if self.auto_scale is not None:
            showIndent(outfile, level)
            outfile.write('auto_scale=%s,\n' % self.auto_scale)
    def exportDict(self, name_='ServiceScaleOutType'):
        obj_json = json.dumps(self, default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        obj_dict = json.loads(obj_json)
        return {name_: obj_dict}
    def build(self, node):
        self.buildAttributes(node, node.attrib, [])
        for child in node:
            nodeName_ = Tag_pattern_.match(child.tag).groups()[-1]
            self.buildChildren(child, node, nodeName_)
    def buildAttributes(self, node, attrs, already_processed):
        pass
    def buildChildren(self, child_, node, nodeName_, fromsubclass_=False):
        if nodeName_ == 'max-instances':
            sval_ = child_.text
            try:
                ival_ = int(sval_)
            except (TypeError, ValueError), exp:
                raise_parse_error(child_, 'requires integer: %s' % exp)
            ival_ = self.gds_validate_integer(ival_, node, 'max_instances')
            self.max_instances = ival_
        elif nodeName_ == 'auto-scale':
            sval_ = child_.text
            if sval_ in ('true', '1'):
                ival_ = True
            elif sval_ in ('false', '0'):
                ival_ = False
            else:
                raise_parse_error(child_, 'requires boolean')
            ival_ = self.gds_validate_boolean(ival_, node, 'auto_scale')
            self.auto_scale = ival_
# end class ServiceScaleOutType


class ServiceTemplateType(GeneratedsSuper):
    """
    ServiceTemplateType class definition from :doc:`vnc_cfg.xsd`
    """
    subclass = None
    superclass = None
    def __init__(self, service_type=None, image_name=None, service_scaling=False, interface_type=None, **kwargs):
        self.service_type = service_type
        self.image_name = image_name
        self.service_scaling = service_scaling
        if (interface_type is None) or (interface_type == []):
            self.interface_type = []
        else:
            if isinstance(interface_type[0], dict):
                objs = [ServiceTemplateInterfaceType(**elem) for elem in interface_type]
                self.interface_type = objs
            else:
                self.interface_type = interface_type
    def factory(*args_, **kwargs_):
        if ServiceTemplateType.subclass:
            return ServiceTemplateType.subclass(*args_, **kwargs_)
        else:
            return ServiceTemplateType(*args_, **kwargs_)
    factory = staticmethod(factory)
    def get_service_type(self): return self.service_type
    def set_service_type(self, service_type): self.service_type = service_type
    def validate_ServiceType(self, value):
        # Validate type ServiceType, a restriction on xsd:string.
        pass
    def get_image_name(self): return self.image_name
    def set_image_name(self, image_name): self.image_name = image_name
    def get_service_scaling(self): return self.service_scaling
    def set_service_scaling(self, service_scaling): self.service_scaling = service_scaling
    def get_interface_type(self): return self.interface_type
    def set_interface_type(self, interface_type): self.interface_type = interface_type
    def add_interface_type(self, value): self.interface_type.append(value)
    def insert_interface_type(self, index, value): self.interface_type[index] = value
    @classmethod
    def populate (cls, *a, **kwa):
        obj = cls (*a, **kwa)
        obj.set_service_type (obj.populate_string ("service_type"))
        obj.set_image_name (obj.populate_string ("image_name"))
        obj.set_service_scaling (obj.populate_boolean ("service_scaling"))
        obj.set_interface_type (ServiceTemplateInterfaceType.populate ())
        return obj
    def export(self, outfile, level=1, namespace_='', name_='ServiceTemplateType', namespacedef_='', pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        showIndent(outfile, level, pretty_print)
        outfile.write('<%s%s%s' % (namespace_, name_, namespacedef_ and ' ' + namespacedef_ or '', ))
        already_processed = []
        self.exportAttributes(outfile, level, already_processed, namespace_, name_='ServiceTemplateType')
        if self.hasContent_():
            outfile.write('>%s' % (eol_, ))
            self.exportChildren(outfile, level + 1, namespace_, name_, pretty_print=pretty_print)
            showIndent(outfile, level, pretty_print)
            outfile.write('</%s%s>%s' % (namespace_, name_, eol_))
        else:
            outfile.write('/>%s' % (eol_, ))
    def exportAttributes(self, outfile, level, already_processed, namespace_='', name_='ServiceTemplateType'):
        pass
    def exportChildren(self, outfile, level, namespace_='', name_='ServiceTemplateType', fromsubclass_=False, pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        if self.service_type is not None:
            showIndent(outfile, level, pretty_print)
            outfile.write('<%sservice-type>%s</%sservice-type>%s' % (namespace_, self.gds_format_string(quote_xml(self.service_type).encode(ExternalEncoding), input_name='service-type'), namespace_, eol_))
        if self.image_name is not None:
            showIndent(outfile, level, pretty_print)
            outfile.write('<%simage-name>%s</%simage-name>%s' % (namespace_, self.gds_format_string(quote_xml(self.image_name).encode(ExternalEncoding), input_name='image-name'), namespace_, eol_))
        if self.service_scaling is not None:
            showIndent(outfile, level, pretty_print)
            outfile.write('<%sservice-scaling>%s</%sservice-scaling>%s' % (namespace_, self.gds_format_boolean(self.gds_str_lower(str(self.service_scaling)), input_name='service-scaling'), namespace_, eol_))
        for interface_type_ in self.interface_type:
            if isinstance(interface_type_, dict):
                interface_type_ = ServiceTemplateInterfaceType(**interface_type_)
            interface_type_.export(outfile, level, namespace_, name_='interface-type', pretty_print=pretty_print)
    def hasContent_(self):
        if (
            self.service_type is not None or
            self.image_name is not None or
            self.service_scaling is not None or
            self.interface_type
            ):
            return True
        else:
            return False
    def exportLiteral(self, outfile, level, name_='ServiceTemplateType'):
        level += 1
        self.exportLiteralAttributes(outfile, level, [], name_)
        if self.hasContent_():
            self.exportLiteralChildren(outfile, level, name_)
    def exportLiteralAttributes(self, outfile, level, already_processed, name_):
        pass
    def exportLiteralChildren(self, outfile, level, name_):
        if self.service_type is not None:
            showIndent(outfile, level)
            outfile.write('service_type=%s,\n' % quote_python(self.service_type).encode(ExternalEncoding))
        if self.image_name is not None:
            showIndent(outfile, level)
            outfile.write('image_name=%s,\n' % quote_python(self.image_name).encode(ExternalEncoding))
        if self.service_scaling is not None:
            showIndent(outfile, level)
            outfile.write('service_scaling=%s,\n' % self.service_scaling)
        showIndent(outfile, level)
        outfile.write('interface_type=[\n')
        level += 1
        for interface_type_ in self.interface_type:
            showIndent(outfile, level)
            outfile.write('model_.ServiceTemplateInterfaceType(\n')
            interface_type_.exportLiteral(outfile, level, name_='ServiceTemplateInterfaceType')
            showIndent(outfile, level)
            outfile.write('),\n')
        level -= 1
        showIndent(outfile, level)
        outfile.write('],\n')
    def exportDict(self, name_='ServiceTemplateType'):
        obj_json = json.dumps(self, default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        obj_dict = json.loads(obj_json)
        return {name_: obj_dict}
    def build(self, node):
        self.buildAttributes(node, node.attrib, [])
        for child in node:
            nodeName_ = Tag_pattern_.match(child.tag).groups()[-1]
            self.buildChildren(child, node, nodeName_)
    def buildAttributes(self, node, attrs, already_processed):
        pass
    def buildChildren(self, child_, node, nodeName_, fromsubclass_=False):
        if nodeName_ == 'service-type':
            service_type_ = child_.text
            service_type_ = self.gds_validate_string(service_type_, node, 'service_type')
            self.service_type = service_type_
            self.validate_ServiceType(self.service_type)    # validate type ServiceType
        elif nodeName_ == 'image-name':
            image_name_ = child_.text
            image_name_ = self.gds_validate_string(image_name_, node, 'image_name')
            self.image_name = image_name_
        elif nodeName_ == 'service-scaling':
            sval_ = child_.text
            if sval_ in ('true', '1'):
                ival_ = True
            elif sval_ in ('false', '0'):
                ival_ = False
            else:
                raise_parse_error(child_, 'requires boolean')
            ival_ = self.gds_validate_boolean(ival_, node, 'service_scaling')
            self.service_scaling = ival_
        elif nodeName_ == 'interface-type':
            obj_ = ServiceTemplateInterfaceType.factory()
            obj_.build(child_)
            self.interface_type.append(obj_)
# end class ServiceTemplateType


class ServiceInstanceType(GeneratedsSuper):
    """
    ServiceInstanceType class definition from :doc:`vnc_cfg.xsd`
    """
    subclass = None
    superclass = None
    def __init__(self, auto_policy=False, management_virtual_network=None, left_virtual_network=None, right_virtual_network=None, scale_out=None, **kwargs):
        self.auto_policy = auto_policy
        self.management_virtual_network = management_virtual_network
        self.left_virtual_network = left_virtual_network
        self.right_virtual_network = right_virtual_network
        if isinstance(scale_out, dict):
            obj = ServiceScaleOutType(**scale_out)
            self.scale_out = obj
        else:
            self.scale_out = scale_out
    def factory(*args_, **kwargs_):
        if ServiceInstanceType.subclass:
            return ServiceInstanceType.subclass(*args_, **kwargs_)
        else:
            return ServiceInstanceType(*args_, **kwargs_)
    factory = staticmethod(factory)
    def get_auto_policy(self): return self.auto_policy
    def set_auto_policy(self, auto_policy): self.auto_policy = auto_policy
    def get_management_virtual_network(self): return self.management_virtual_network
    def set_management_virtual_network(self, management_virtual_network): self.management_virtual_network = management_virtual_network
    def get_left_virtual_network(self): return self.left_virtual_network
    def set_left_virtual_network(self, left_virtual_network): self.left_virtual_network = left_virtual_network
    def get_right_virtual_network(self): return self.right_virtual_network
    def set_right_virtual_network(self, right_virtual_network): self.right_virtual_network = right_virtual_network
    def get_scale_out(self): return self.scale_out
    def set_scale_out(self, scale_out): self.scale_out = scale_out
    @classmethod
    def populate (cls, *a, **kwa):
        obj = cls (*a, **kwa)
        obj.set_auto_policy (obj.populate_boolean ("auto_policy"))
        obj.set_management_virtual_network (obj.populate_string ("management_virtual_network"))
        obj.set_left_virtual_network (obj.populate_string ("left_virtual_network"))
        obj.set_right_virtual_network (obj.populate_string ("right_virtual_network"))
        obj.set_scale_out (ServiceScaleOutType.populate ())
        return obj
    def export(self, outfile, level=1, namespace_='', name_='ServiceInstanceType', namespacedef_='', pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        showIndent(outfile, level, pretty_print)
        outfile.write('<%s%s%s' % (namespace_, name_, namespacedef_ and ' ' + namespacedef_ or '', ))
        already_processed = []
        self.exportAttributes(outfile, level, already_processed, namespace_, name_='ServiceInstanceType')
        if self.hasContent_():
            outfile.write('>%s' % (eol_, ))
            self.exportChildren(outfile, level + 1, namespace_, name_, pretty_print=pretty_print)
            showIndent(outfile, level, pretty_print)
            outfile.write('</%s%s>%s' % (namespace_, name_, eol_))
        else:
            outfile.write('/>%s' % (eol_, ))
    def exportAttributes(self, outfile, level, already_processed, namespace_='', name_='ServiceInstanceType'):
        pass
    def exportChildren(self, outfile, level, namespace_='', name_='ServiceInstanceType', fromsubclass_=False, pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        if self.auto_policy is not None:
            showIndent(outfile, level, pretty_print)
            outfile.write('<%sauto-policy>%s</%sauto-policy>%s' % (namespace_, self.gds_format_boolean(self.gds_str_lower(str(self.auto_policy)), input_name='auto-policy'), namespace_, eol_))
        if self.management_virtual_network is not None:
            showIndent(outfile, level, pretty_print)
            outfile.write('<%smanagement-virtual-network>%s</%smanagement-virtual-network>%s' % (namespace_, self.gds_format_string(quote_xml(self.management_virtual_network).encode(ExternalEncoding), input_name='management-virtual-network'), namespace_, eol_))
        if self.left_virtual_network is not None:
            showIndent(outfile, level, pretty_print)
            outfile.write('<%sleft-virtual-network>%s</%sleft-virtual-network>%s' % (namespace_, self.gds_format_string(quote_xml(self.left_virtual_network).encode(ExternalEncoding), input_name='left-virtual-network'), namespace_, eol_))
        if self.right_virtual_network is not None:
            showIndent(outfile, level, pretty_print)
            outfile.write('<%sright-virtual-network>%s</%sright-virtual-network>%s' % (namespace_, self.gds_format_string(quote_xml(self.right_virtual_network).encode(ExternalEncoding), input_name='right-virtual-network'), namespace_, eol_))
        if self.scale_out is not None:
            self.scale_out.export(outfile, level, namespace_, name_='scale-out', pretty_print=pretty_print)
    def hasContent_(self):
        if (
            self.auto_policy is not None or
            self.management_virtual_network is not None or
            self.left_virtual_network is not None or
            self.right_virtual_network is not None or
            self.scale_out is not None
            ):
            return True
        else:
            return False
    def exportLiteral(self, outfile, level, name_='ServiceInstanceType'):
        level += 1
        self.exportLiteralAttributes(outfile, level, [], name_)
        if self.hasContent_():
            self.exportLiteralChildren(outfile, level, name_)
    def exportLiteralAttributes(self, outfile, level, already_processed, name_):
        pass
    def exportLiteralChildren(self, outfile, level, name_):
        if self.auto_policy is not None:
            showIndent(outfile, level)
            outfile.write('auto_policy=%s,\n' % self.auto_policy)
        if self.management_virtual_network is not None:
            showIndent(outfile, level)
            outfile.write('management_virtual_network=%s,\n' % quote_python(self.management_virtual_network).encode(ExternalEncoding))
        if self.left_virtual_network is not None:
            showIndent(outfile, level)
            outfile.write('left_virtual_network=%s,\n' % quote_python(self.left_virtual_network).encode(ExternalEncoding))
        if self.right_virtual_network is not None:
            showIndent(outfile, level)
            outfile.write('right_virtual_network=%s,\n' % quote_python(self.right_virtual_network).encode(ExternalEncoding))
        if self.scale_out is not None:
            showIndent(outfile, level)
            outfile.write('scale_out=model_.ServiceScaleOutType(\n')
            self.scale_out.exportLiteral(outfile, level, name_='scale_out')
            showIndent(outfile, level)
            outfile.write('),\n')
    def exportDict(self, name_='ServiceInstanceType'):
        obj_json = json.dumps(self, default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        obj_dict = json.loads(obj_json)
        return {name_: obj_dict}
    def build(self, node):
        self.buildAttributes(node, node.attrib, [])
        for child in node:
            nodeName_ = Tag_pattern_.match(child.tag).groups()[-1]
            self.buildChildren(child, node, nodeName_)
    def buildAttributes(self, node, attrs, already_processed):
        pass
    def buildChildren(self, child_, node, nodeName_, fromsubclass_=False):
        if nodeName_ == 'auto-policy':
            sval_ = child_.text
            if sval_ in ('true', '1'):
                ival_ = True
            elif sval_ in ('false', '0'):
                ival_ = False
            else:
                raise_parse_error(child_, 'requires boolean')
            ival_ = self.gds_validate_boolean(ival_, node, 'auto_policy')
            self.auto_policy = ival_
        elif nodeName_ == 'management-virtual-network':
            management_virtual_network_ = child_.text
            management_virtual_network_ = self.gds_validate_string(management_virtual_network_, node, 'management_virtual_network')
            self.management_virtual_network = management_virtual_network_
        elif nodeName_ == 'left-virtual-network':
            left_virtual_network_ = child_.text
            left_virtual_network_ = self.gds_validate_string(left_virtual_network_, node, 'left_virtual_network')
            self.left_virtual_network = left_virtual_network_
        elif nodeName_ == 'right-virtual-network':
            right_virtual_network_ = child_.text
            right_virtual_network_ = self.gds_validate_string(right_virtual_network_, node, 'right_virtual_network')
            self.right_virtual_network = right_virtual_network_
        elif nodeName_ == 'scale-out':
            obj_ = ServiceScaleOutType.factory()
            obj_.build(child_)
            self.set_scale_out(obj_)
# end class ServiceInstanceType


class project_service_instance(GeneratedsSuper):
    """
    project_service_instance class definition from :doc:`vnc_cfg.xsd`
    """
    subclass = None
    superclass = None
    def __init__(self, **kwargs):
        pass
    def factory(*args_, **kwargs_):
        if project_service_instance.subclass:
            return project_service_instance.subclass(*args_, **kwargs_)
        else:
            return project_service_instance(*args_, **kwargs_)
    factory = staticmethod(factory)
    @classmethod
    def populate (cls, *a, **kwa):
        obj = cls (*a, **kwa)
        return obj
    def export(self, outfile, level=1, namespace_='', name_='project-service-instance', namespacedef_='', pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        showIndent(outfile, level, pretty_print)
        outfile.write('<%s%s%s' % (namespace_, name_, namespacedef_ and ' ' + namespacedef_ or '', ))
        already_processed = []
        self.exportAttributes(outfile, level, already_processed, namespace_, name_='project-service-instance')
        if self.hasContent_():
            outfile.write('>%s' % (eol_, ))
            self.exportChildren(outfile, level + 1, namespace_, name_, pretty_print=pretty_print)
            outfile.write('</%s%s>%s' % (namespace_, name_, eol_))
        else:
            outfile.write('/>%s' % (eol_, ))
    def exportAttributes(self, outfile, level, already_processed, namespace_='', name_='project-service-instance'):
        pass
    def exportChildren(self, outfile, level, namespace_='', name_='project-service-instance', fromsubclass_=False, pretty_print=True):
        pass
    def hasContent_(self):
        if (

            ):
            return True
        else:
            return False
    def exportLiteral(self, outfile, level, name_='project-service-instance'):
        level += 1
        self.exportLiteralAttributes(outfile, level, [], name_)
        if self.hasContent_():
            self.exportLiteralChildren(outfile, level, name_)
    def exportLiteralAttributes(self, outfile, level, already_processed, name_):
        pass
    def exportLiteralChildren(self, outfile, level, name_):
        pass
    def exportDict(self, name_='project-service-instance'):
        obj_json = json.dumps(self, default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        obj_dict = json.loads(obj_json)
        return {name_: obj_dict}
    def build(self, node):
        self.buildAttributes(node, node.attrib, [])
        for child in node:
            nodeName_ = Tag_pattern_.match(child.tag).groups()[-1]
            self.buildChildren(child, node, nodeName_)
    def buildAttributes(self, node, attrs, already_processed):
        pass
    def buildChildren(self, child_, node, nodeName_, fromsubclass_=False):
        pass
# end class project_service_instance


class domain_service_template(GeneratedsSuper):
    """
    domain_service_template class definition from :doc:`vnc_cfg.xsd`
    """
    subclass = None
    superclass = None
    def __init__(self, **kwargs):
        pass
    def factory(*args_, **kwargs_):
        if domain_service_template.subclass:
            return domain_service_template.subclass(*args_, **kwargs_)
        else:
            return domain_service_template(*args_, **kwargs_)
    factory = staticmethod(factory)
    @classmethod
    def populate (cls, *a, **kwa):
        obj = cls (*a, **kwa)
        return obj
    def export(self, outfile, level=1, namespace_='', name_='domain-service-template', namespacedef_='', pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        showIndent(outfile, level, pretty_print)
        outfile.write('<%s%s%s' % (namespace_, name_, namespacedef_ and ' ' + namespacedef_ or '', ))
        already_processed = []
        self.exportAttributes(outfile, level, already_processed, namespace_, name_='domain-service-template')
        if self.hasContent_():
            outfile.write('>%s' % (eol_, ))
            self.exportChildren(outfile, level + 1, namespace_, name_, pretty_print=pretty_print)
            outfile.write('</%s%s>%s' % (namespace_, name_, eol_))
        else:
            outfile.write('/>%s' % (eol_, ))
    def exportAttributes(self, outfile, level, already_processed, namespace_='', name_='domain-service-template'):
        pass
    def exportChildren(self, outfile, level, namespace_='', name_='domain-service-template', fromsubclass_=False, pretty_print=True):
        pass
    def hasContent_(self):
        if (

            ):
            return True
        else:
            return False
    def exportLiteral(self, outfile, level, name_='domain-service-template'):
        level += 1
        self.exportLiteralAttributes(outfile, level, [], name_)
        if self.hasContent_():
            self.exportLiteralChildren(outfile, level, name_)
    def exportLiteralAttributes(self, outfile, level, already_processed, name_):
        pass
    def exportLiteralChildren(self, outfile, level, name_):
        pass
    def exportDict(self, name_='domain-service-template'):
        obj_json = json.dumps(self, default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        obj_dict = json.loads(obj_json)
        return {name_: obj_dict}
    def build(self, node):
        self.buildAttributes(node, node.attrib, [])
        for child in node:
            nodeName_ = Tag_pattern_.match(child.tag).groups()[-1]
            self.buildChildren(child, node, nodeName_)
    def buildAttributes(self, node, attrs, already_processed):
        pass
    def buildChildren(self, child_, node, nodeName_, fromsubclass_=False):
        pass
# end class domain_service_template


class service_instance_service_template(GeneratedsSuper):
    """
    service_instance_service_template class definition from :doc:`vnc_cfg.xsd`
    """
    subclass = None
    superclass = None
    def __init__(self, **kwargs):
        pass
    def factory(*args_, **kwargs_):
        if service_instance_service_template.subclass:
            return service_instance_service_template.subclass(*args_, **kwargs_)
        else:
            return service_instance_service_template(*args_, **kwargs_)
    factory = staticmethod(factory)
    @classmethod
    def populate (cls, *a, **kwa):
        obj = cls (*a, **kwa)
        return obj
    def export(self, outfile, level=1, namespace_='', name_='service-instance-service-template', namespacedef_='', pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        showIndent(outfile, level, pretty_print)
        outfile.write('<%s%s%s' % (namespace_, name_, namespacedef_ and ' ' + namespacedef_ or '', ))
        already_processed = []
        self.exportAttributes(outfile, level, already_processed, namespace_, name_='service-instance-service-template')
        if self.hasContent_():
            outfile.write('>%s' % (eol_, ))
            self.exportChildren(outfile, level + 1, namespace_, name_, pretty_print=pretty_print)
            outfile.write('</%s%s>%s' % (namespace_, name_, eol_))
        else:
            outfile.write('/>%s' % (eol_, ))
    def exportAttributes(self, outfile, level, already_processed, namespace_='', name_='service-instance-service-template'):
        pass
    def exportChildren(self, outfile, level, namespace_='', name_='service-instance-service-template', fromsubclass_=False, pretty_print=True):
        pass
    def hasContent_(self):
        if (

            ):
            return True
        else:
            return False
    def exportLiteral(self, outfile, level, name_='service-instance-service-template'):
        level += 1
        self.exportLiteralAttributes(outfile, level, [], name_)
        if self.hasContent_():
            self.exportLiteralChildren(outfile, level, name_)
    def exportLiteralAttributes(self, outfile, level, already_processed, name_):
        pass
    def exportLiteralChildren(self, outfile, level, name_):
        pass
    def exportDict(self, name_='service-instance-service-template'):
        obj_json = json.dumps(self, default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        obj_dict = json.loads(obj_json)
        return {name_: obj_dict}
    def build(self, node):
        self.buildAttributes(node, node.attrib, [])
        for child in node:
            nodeName_ = Tag_pattern_.match(child.tag).groups()[-1]
            self.buildChildren(child, node, nodeName_)
    def buildAttributes(self, node, attrs, already_processed):
        pass
    def buildChildren(self, child_, node, nodeName_, fromsubclass_=False):
        pass
# end class service_instance_service_template


class virtual_machine_service_instance(GeneratedsSuper):
    """
    virtual_machine_service_instance class definition from :doc:`vnc_cfg.xsd`
    """
    subclass = None
    superclass = None
    def __init__(self, **kwargs):
        pass
    def factory(*args_, **kwargs_):
        if virtual_machine_service_instance.subclass:
            return virtual_machine_service_instance.subclass(*args_, **kwargs_)
        else:
            return virtual_machine_service_instance(*args_, **kwargs_)
    factory = staticmethod(factory)
    @classmethod
    def populate (cls, *a, **kwa):
        obj = cls (*a, **kwa)
        return obj
    def export(self, outfile, level=1, namespace_='', name_='virtual-machine-service-instance', namespacedef_='', pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        showIndent(outfile, level, pretty_print)
        outfile.write('<%s%s%s' % (namespace_, name_, namespacedef_ and ' ' + namespacedef_ or '', ))
        already_processed = []
        self.exportAttributes(outfile, level, already_processed, namespace_, name_='virtual-machine-service-instance')
        if self.hasContent_():
            outfile.write('>%s' % (eol_, ))
            self.exportChildren(outfile, level + 1, namespace_, name_, pretty_print=pretty_print)
            outfile.write('</%s%s>%s' % (namespace_, name_, eol_))
        else:
            outfile.write('/>%s' % (eol_, ))
    def exportAttributes(self, outfile, level, already_processed, namespace_='', name_='virtual-machine-service-instance'):
        pass
    def exportChildren(self, outfile, level, namespace_='', name_='virtual-machine-service-instance', fromsubclass_=False, pretty_print=True):
        pass
    def hasContent_(self):
        if (

            ):
            return True
        else:
            return False
    def exportLiteral(self, outfile, level, name_='virtual-machine-service-instance'):
        level += 1
        self.exportLiteralAttributes(outfile, level, [], name_)
        if self.hasContent_():
            self.exportLiteralChildren(outfile, level, name_)
    def exportLiteralAttributes(self, outfile, level, already_processed, name_):
        pass
    def exportLiteralChildren(self, outfile, level, name_):
        pass
    def exportDict(self, name_='virtual-machine-service-instance'):
        obj_json = json.dumps(self, default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        obj_dict = json.loads(obj_json)
        return {name_: obj_dict}
    def build(self, node):
        self.buildAttributes(node, node.attrib, [])
        for child in node:
            nodeName_ = Tag_pattern_.match(child.tag).groups()[-1]
            self.buildChildren(child, node, nodeName_)
    def buildAttributes(self, node, attrs, already_processed):
        pass
    def buildChildren(self, child_, node, nodeName_, fromsubclass_=False):
        pass
# end class virtual_machine_service_instance


class domain_virtual_DNS(GeneratedsSuper):
    """
    domain_virtual_DNS class definition from :doc:`vnc_cfg.xsd`
    """
    subclass = None
    superclass = None
    def __init__(self, **kwargs):
        pass
    def factory(*args_, **kwargs_):
        if domain_virtual_DNS.subclass:
            return domain_virtual_DNS.subclass(*args_, **kwargs_)
        else:
            return domain_virtual_DNS(*args_, **kwargs_)
    factory = staticmethod(factory)
    @classmethod
    def populate (cls, *a, **kwa):
        obj = cls (*a, **kwa)
        return obj
    def export(self, outfile, level=1, namespace_='', name_='domain-virtual-DNS', namespacedef_='', pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        showIndent(outfile, level, pretty_print)
        outfile.write('<%s%s%s' % (namespace_, name_, namespacedef_ and ' ' + namespacedef_ or '', ))
        already_processed = []
        self.exportAttributes(outfile, level, already_processed, namespace_, name_='domain-virtual-DNS')
        if self.hasContent_():
            outfile.write('>%s' % (eol_, ))
            self.exportChildren(outfile, level + 1, namespace_, name_, pretty_print=pretty_print)
            outfile.write('</%s%s>%s' % (namespace_, name_, eol_))
        else:
            outfile.write('/>%s' % (eol_, ))
    def exportAttributes(self, outfile, level, already_processed, namespace_='', name_='domain-virtual-DNS'):
        pass
    def exportChildren(self, outfile, level, namespace_='', name_='domain-virtual-DNS', fromsubclass_=False, pretty_print=True):
        pass
    def hasContent_(self):
        if (

            ):
            return True
        else:
            return False
    def exportLiteral(self, outfile, level, name_='domain-virtual-DNS'):
        level += 1
        self.exportLiteralAttributes(outfile, level, [], name_)
        if self.hasContent_():
            self.exportLiteralChildren(outfile, level, name_)
    def exportLiteralAttributes(self, outfile, level, already_processed, name_):
        pass
    def exportLiteralChildren(self, outfile, level, name_):
        pass
    def exportDict(self, name_='domain-virtual-DNS'):
        obj_json = json.dumps(self, default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        obj_dict = json.loads(obj_json)
        return {name_: obj_dict}
    def build(self, node):
        self.buildAttributes(node, node.attrib, [])
        for child in node:
            nodeName_ = Tag_pattern_.match(child.tag).groups()[-1]
            self.buildChildren(child, node, nodeName_)
    def buildAttributes(self, node, attrs, already_processed):
        pass
    def buildChildren(self, child_, node, nodeName_, fromsubclass_=False):
        pass
# end class domain_virtual_DNS


class virtual_DNS_virtual_DNS_record(GeneratedsSuper):
    """
    virtual_DNS_virtual_DNS_record class definition from :doc:`vnc_cfg.xsd`
    """
    subclass = None
    superclass = None
    def __init__(self, **kwargs):
        pass
    def factory(*args_, **kwargs_):
        if virtual_DNS_virtual_DNS_record.subclass:
            return virtual_DNS_virtual_DNS_record.subclass(*args_, **kwargs_)
        else:
            return virtual_DNS_virtual_DNS_record(*args_, **kwargs_)
    factory = staticmethod(factory)
    @classmethod
    def populate (cls, *a, **kwa):
        obj = cls (*a, **kwa)
        return obj
    def export(self, outfile, level=1, namespace_='', name_='virtual-DNS-virtual-DNS-record', namespacedef_='', pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        showIndent(outfile, level, pretty_print)
        outfile.write('<%s%s%s' % (namespace_, name_, namespacedef_ and ' ' + namespacedef_ or '', ))
        already_processed = []
        self.exportAttributes(outfile, level, already_processed, namespace_, name_='virtual-DNS-virtual-DNS-record')
        if self.hasContent_():
            outfile.write('>%s' % (eol_, ))
            self.exportChildren(outfile, level + 1, namespace_, name_, pretty_print=pretty_print)
            outfile.write('</%s%s>%s' % (namespace_, name_, eol_))
        else:
            outfile.write('/>%s' % (eol_, ))
    def exportAttributes(self, outfile, level, already_processed, namespace_='', name_='virtual-DNS-virtual-DNS-record'):
        pass
    def exportChildren(self, outfile, level, namespace_='', name_='virtual-DNS-virtual-DNS-record', fromsubclass_=False, pretty_print=True):
        pass
    def hasContent_(self):
        if (

            ):
            return True
        else:
            return False
    def exportLiteral(self, outfile, level, name_='virtual-DNS-virtual-DNS-record'):
        level += 1
        self.exportLiteralAttributes(outfile, level, [], name_)
        if self.hasContent_():
            self.exportLiteralChildren(outfile, level, name_)
    def exportLiteralAttributes(self, outfile, level, already_processed, name_):
        pass
    def exportLiteralChildren(self, outfile, level, name_):
        pass
    def exportDict(self, name_='virtual-DNS-virtual-DNS-record'):
        obj_json = json.dumps(self, default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        obj_dict = json.loads(obj_json)
        return {name_: obj_dict}
    def build(self, node):
        self.buildAttributes(node, node.attrib, [])
        for child in node:
            nodeName_ = Tag_pattern_.match(child.tag).groups()[-1]
            self.buildChildren(child, node, nodeName_)
    def buildAttributes(self, node, attrs, already_processed):
        pass
    def buildChildren(self, child_, node, nodeName_, fromsubclass_=False):
        pass
# end class virtual_DNS_virtual_DNS_record


class network_ipam_virtual_DNS(GeneratedsSuper):
    """
    network_ipam_virtual_DNS class definition from :doc:`vnc_cfg.xsd`
    """
    subclass = None
    superclass = None
    def __init__(self, **kwargs):
        pass
    def factory(*args_, **kwargs_):
        if network_ipam_virtual_DNS.subclass:
            return network_ipam_virtual_DNS.subclass(*args_, **kwargs_)
        else:
            return network_ipam_virtual_DNS(*args_, **kwargs_)
    factory = staticmethod(factory)
    @classmethod
    def populate (cls, *a, **kwa):
        obj = cls (*a, **kwa)
        return obj
    def export(self, outfile, level=1, namespace_='', name_='network-ipam-virtual-DNS', namespacedef_='', pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        showIndent(outfile, level, pretty_print)
        outfile.write('<%s%s%s' % (namespace_, name_, namespacedef_ and ' ' + namespacedef_ or '', ))
        already_processed = []
        self.exportAttributes(outfile, level, already_processed, namespace_, name_='network-ipam-virtual-DNS')
        if self.hasContent_():
            outfile.write('>%s' % (eol_, ))
            self.exportChildren(outfile, level + 1, namespace_, name_, pretty_print=pretty_print)
            outfile.write('</%s%s>%s' % (namespace_, name_, eol_))
        else:
            outfile.write('/>%s' % (eol_, ))
    def exportAttributes(self, outfile, level, already_processed, namespace_='', name_='network-ipam-virtual-DNS'):
        pass
    def exportChildren(self, outfile, level, namespace_='', name_='network-ipam-virtual-DNS', fromsubclass_=False, pretty_print=True):
        pass
    def hasContent_(self):
        if (

            ):
            return True
        else:
            return False
    def exportLiteral(self, outfile, level, name_='network-ipam-virtual-DNS'):
        level += 1
        self.exportLiteralAttributes(outfile, level, [], name_)
        if self.hasContent_():
            self.exportLiteralChildren(outfile, level, name_)
    def exportLiteralAttributes(self, outfile, level, already_processed, name_):
        pass
    def exportLiteralChildren(self, outfile, level, name_):
        pass
    def exportDict(self, name_='network-ipam-virtual-DNS'):
        obj_json = json.dumps(self, default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        obj_dict = json.loads(obj_json)
        return {name_: obj_dict}
    def build(self, node):
        self.buildAttributes(node, node.attrib, [])
        for child in node:
            nodeName_ = Tag_pattern_.match(child.tag).groups()[-1]
            self.buildChildren(child, node, nodeName_)
    def buildAttributes(self, node, attrs, already_processed):
        pass
    def buildChildren(self, child_, node, nodeName_, fromsubclass_=False):
        pass
# end class network_ipam_virtual_DNS


class RouteType(GeneratedsSuper):
    """
    RouteType class definition from :doc:`vnc_cfg.xsd`
    """
    subclass = None
    superclass = None
    def __init__(self, prefix=None, next_hop=None, **kwargs):
        self.prefix = prefix
        self.next_hop = next_hop
    def factory(*args_, **kwargs_):
        if RouteType.subclass:
            return RouteType.subclass(*args_, **kwargs_)
        else:
            return RouteType(*args_, **kwargs_)
    factory = staticmethod(factory)
    def get_prefix(self): return self.prefix
    def set_prefix(self, prefix): self.prefix = prefix
    def get_next_hop(self): return self.next_hop
    def set_next_hop(self, next_hop): self.next_hop = next_hop
    @classmethod
    def populate (cls, *a, **kwa):
        obj = cls (*a, **kwa)
        obj.set_prefix (obj.populate_string ("prefix"))
        obj.set_next_hop (obj.populate_string ("next_hop"))
        return obj
    def export(self, outfile, level=1, namespace_='', name_='RouteType', namespacedef_='', pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        showIndent(outfile, level, pretty_print)
        outfile.write('<%s%s%s' % (namespace_, name_, namespacedef_ and ' ' + namespacedef_ or '', ))
        already_processed = []
        self.exportAttributes(outfile, level, already_processed, namespace_, name_='RouteType')
        if self.hasContent_():
            outfile.write('>%s' % (eol_, ))
            self.exportChildren(outfile, level + 1, namespace_, name_, pretty_print=pretty_print)
            showIndent(outfile, level, pretty_print)
            outfile.write('</%s%s>%s' % (namespace_, name_, eol_))
        else:
            outfile.write('/>%s' % (eol_, ))
    def exportAttributes(self, outfile, level, already_processed, namespace_='', name_='RouteType'):
        pass
    def exportChildren(self, outfile, level, namespace_='', name_='RouteType', fromsubclass_=False, pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        if self.prefix is not None:
            showIndent(outfile, level, pretty_print)
            outfile.write('<%sprefix>%s</%sprefix>%s' % (namespace_, self.gds_format_string(quote_xml(self.prefix).encode(ExternalEncoding), input_name='prefix'), namespace_, eol_))
        if self.next_hop is not None:
            showIndent(outfile, level, pretty_print)
            outfile.write('<%snext-hop>%s</%snext-hop>%s' % (namespace_, self.gds_format_string(quote_xml(self.next_hop).encode(ExternalEncoding), input_name='next-hop'), namespace_, eol_))
    def hasContent_(self):
        if (
            self.prefix is not None or
            self.next_hop is not None
            ):
            return True
        else:
            return False
    def exportLiteral(self, outfile, level, name_='RouteType'):
        level += 1
        self.exportLiteralAttributes(outfile, level, [], name_)
        if self.hasContent_():
            self.exportLiteralChildren(outfile, level, name_)
    def exportLiteralAttributes(self, outfile, level, already_processed, name_):
        pass
    def exportLiteralChildren(self, outfile, level, name_):
        if self.prefix is not None:
            showIndent(outfile, level)
            outfile.write('prefix=%s,\n' % quote_python(self.prefix).encode(ExternalEncoding))
        if self.next_hop is not None:
            showIndent(outfile, level)
            outfile.write('next_hop=%s,\n' % quote_python(self.next_hop).encode(ExternalEncoding))
    def exportDict(self, name_='RouteType'):
        obj_json = json.dumps(self, default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        obj_dict = json.loads(obj_json)
        return {name_: obj_dict}
    def build(self, node):
        self.buildAttributes(node, node.attrib, [])
        for child in node:
            nodeName_ = Tag_pattern_.match(child.tag).groups()[-1]
            self.buildChildren(child, node, nodeName_)
    def buildAttributes(self, node, attrs, already_processed):
        pass
    def buildChildren(self, child_, node, nodeName_, fromsubclass_=False):
        if nodeName_ == 'prefix':
            prefix_ = child_.text
            prefix_ = self.gds_validate_string(prefix_, node, 'prefix')
            self.prefix = prefix_
        elif nodeName_ == 'next-hop':
            next_hop_ = child_.text
            next_hop_ = self.gds_validate_string(next_hop_, node, 'next_hop')
            self.next_hop = next_hop_
# end class RouteType


class RouteTableType(GeneratedsSuper):
    """
    RouteTableType class definition from :doc:`vnc_cfg.xsd`
    """
    subclass = None
    superclass = None
    def __init__(self, route=None, **kwargs):
        if (route is None) or (route == []):
            self.route = []
        else:
            if isinstance(route[0], dict):
                objs = [RouteType(**elem) for elem in route]
                self.route = objs
            else:
                self.route = route
    def factory(*args_, **kwargs_):
        if RouteTableType.subclass:
            return RouteTableType.subclass(*args_, **kwargs_)
        else:
            return RouteTableType(*args_, **kwargs_)
    factory = staticmethod(factory)
    def get_route(self): return self.route
    def set_route(self, route): self.route = route
    def add_route(self, value): self.route.append(value)
    def insert_route(self, index, value): self.route[index] = value
    @classmethod
    def populate (cls, *a, **kwa):
        obj = cls (*a, **kwa)
        obj.set_route (RouteType.populate ())
        return obj
    def export(self, outfile, level=1, namespace_='', name_='RouteTableType', namespacedef_='', pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        showIndent(outfile, level, pretty_print)
        outfile.write('<%s%s%s' % (namespace_, name_, namespacedef_ and ' ' + namespacedef_ or '', ))
        already_processed = []
        self.exportAttributes(outfile, level, already_processed, namespace_, name_='RouteTableType')
        if self.hasContent_():
            outfile.write('>%s' % (eol_, ))
            self.exportChildren(outfile, level + 1, namespace_, name_, pretty_print=pretty_print)
            showIndent(outfile, level, pretty_print)
            outfile.write('</%s%s>%s' % (namespace_, name_, eol_))
        else:
            outfile.write('/>%s' % (eol_, ))
    def exportAttributes(self, outfile, level, already_processed, namespace_='', name_='RouteTableType'):
        pass
    def exportChildren(self, outfile, level, namespace_='', name_='RouteTableType', fromsubclass_=False, pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        for route_ in self.route:
            if isinstance(route_, dict):
                route_ = RouteType(**route_)
            route_.export(outfile, level, namespace_, name_='route', pretty_print=pretty_print)
    def hasContent_(self):
        if (
            self.route
            ):
            return True
        else:
            return False
    def exportLiteral(self, outfile, level, name_='RouteTableType'):
        level += 1
        self.exportLiteralAttributes(outfile, level, [], name_)
        if self.hasContent_():
            self.exportLiteralChildren(outfile, level, name_)
    def exportLiteralAttributes(self, outfile, level, already_processed, name_):
        pass
    def exportLiteralChildren(self, outfile, level, name_):
        showIndent(outfile, level)
        outfile.write('route=[\n')
        level += 1
        for route_ in self.route:
            showIndent(outfile, level)
            outfile.write('model_.RouteType(\n')
            route_.exportLiteral(outfile, level, name_='RouteType')
            showIndent(outfile, level)
            outfile.write('),\n')
        level -= 1
        showIndent(outfile, level)
        outfile.write('],\n')
    def exportDict(self, name_='RouteTableType'):
        obj_json = json.dumps(self, default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        obj_dict = json.loads(obj_json)
        return {name_: obj_dict}
    def build(self, node):
        self.buildAttributes(node, node.attrib, [])
        for child in node:
            nodeName_ = Tag_pattern_.match(child.tag).groups()[-1]
            self.buildChildren(child, node, nodeName_)
    def buildAttributes(self, node, attrs, already_processed):
        pass
    def buildChildren(self, child_, node, nodeName_, fromsubclass_=False):
        if nodeName_ == 'route':
            obj_ = RouteType.factory()
            obj_.build(child_)
            self.route.append(obj_)
# end class RouteTableType


class StaticRouteType(GeneratedsSuper):
    """
    StaticRouteType class definition from :doc:`vnc_cfg.xsd`
    """
    subclass = None
    superclass = None
    def __init__(self, prefix=None, next_hop=None, route_target=None, **kwargs):
        self.prefix = prefix
        self.next_hop = next_hop
        if (route_target is None) or (route_target == []):
            self.route_target = []
        else:
            self.route_target = route_target
    def factory(*args_, **kwargs_):
        if StaticRouteType.subclass:
            return StaticRouteType.subclass(*args_, **kwargs_)
        else:
            return StaticRouteType(*args_, **kwargs_)
    factory = staticmethod(factory)
    def get_prefix(self): return self.prefix
    def set_prefix(self, prefix): self.prefix = prefix
    def get_next_hop(self): return self.next_hop
    def set_next_hop(self, next_hop): self.next_hop = next_hop
    def get_route_target(self): return self.route_target
    def set_route_target(self, route_target): self.route_target = route_target
    def add_route_target(self, value): self.route_target.append(value)
    def insert_route_target(self, index, value): self.route_target[index] = value
    @classmethod
    def populate (cls, *a, **kwa):
        obj = cls (*a, **kwa)
        obj.set_prefix (obj.populate_string ("prefix"))
        obj.set_next_hop (obj.populate_string ("next_hop"))
        obj.set_route_target (obj.populate_string ("route_target"))
        return obj
    def export(self, outfile, level=1, namespace_='', name_='StaticRouteType', namespacedef_='', pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        showIndent(outfile, level, pretty_print)
        outfile.write('<%s%s%s' % (namespace_, name_, namespacedef_ and ' ' + namespacedef_ or '', ))
        already_processed = []
        self.exportAttributes(outfile, level, already_processed, namespace_, name_='StaticRouteType')
        if self.hasContent_():
            outfile.write('>%s' % (eol_, ))
            self.exportChildren(outfile, level + 1, namespace_, name_, pretty_print=pretty_print)
            showIndent(outfile, level, pretty_print)
            outfile.write('</%s%s>%s' % (namespace_, name_, eol_))
        else:
            outfile.write('/>%s' % (eol_, ))
    def exportAttributes(self, outfile, level, already_processed, namespace_='', name_='StaticRouteType'):
        pass
    def exportChildren(self, outfile, level, namespace_='', name_='StaticRouteType', fromsubclass_=False, pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        if self.prefix is not None:
            showIndent(outfile, level, pretty_print)
            outfile.write('<%sprefix>%s</%sprefix>%s' % (namespace_, self.gds_format_string(quote_xml(self.prefix).encode(ExternalEncoding), input_name='prefix'), namespace_, eol_))
        if self.next_hop is not None:
            showIndent(outfile, level, pretty_print)
            outfile.write('<%snext-hop>%s</%snext-hop>%s' % (namespace_, self.gds_format_string(quote_xml(self.next_hop).encode(ExternalEncoding), input_name='next-hop'), namespace_, eol_))
        for route_target_ in self.route_target:
            showIndent(outfile, level, pretty_print)
            outfile.write('<%sroute-target>%s</%sroute-target>%s' % (namespace_, self.gds_format_string(quote_xml(route_target_).encode(ExternalEncoding), input_name='route-target'), namespace_, eol_))
    def hasContent_(self):
        if (
            self.prefix is not None or
            self.next_hop is not None or
            self.route_target
            ):
            return True
        else:
            return False
    def exportLiteral(self, outfile, level, name_='StaticRouteType'):
        level += 1
        self.exportLiteralAttributes(outfile, level, [], name_)
        if self.hasContent_():
            self.exportLiteralChildren(outfile, level, name_)
    def exportLiteralAttributes(self, outfile, level, already_processed, name_):
        pass
    def exportLiteralChildren(self, outfile, level, name_):
        if self.prefix is not None:
            showIndent(outfile, level)
            outfile.write('prefix=%s,\n' % quote_python(self.prefix).encode(ExternalEncoding))
        if self.next_hop is not None:
            showIndent(outfile, level)
            outfile.write('next_hop=%s,\n' % quote_python(self.next_hop).encode(ExternalEncoding))
        showIndent(outfile, level)
        outfile.write('route_target=[\n')
        level += 1
        for route_target_ in self.route_target:
            showIndent(outfile, level)
            outfile.write('%s,\n' % quote_python(route_target_).encode(ExternalEncoding))
        level -= 1
        showIndent(outfile, level)
        outfile.write('],\n')
    def exportDict(self, name_='StaticRouteType'):
        obj_json = json.dumps(self, default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        obj_dict = json.loads(obj_json)
        return {name_: obj_dict}
    def build(self, node):
        self.buildAttributes(node, node.attrib, [])
        for child in node:
            nodeName_ = Tag_pattern_.match(child.tag).groups()[-1]
            self.buildChildren(child, node, nodeName_)
    def buildAttributes(self, node, attrs, already_processed):
        pass
    def buildChildren(self, child_, node, nodeName_, fromsubclass_=False):
        if nodeName_ == 'prefix':
            prefix_ = child_.text
            prefix_ = self.gds_validate_string(prefix_, node, 'prefix')
            self.prefix = prefix_
        elif nodeName_ == 'next-hop':
            next_hop_ = child_.text
            next_hop_ = self.gds_validate_string(next_hop_, node, 'next_hop')
            self.next_hop = next_hop_
        elif nodeName_ == 'route-target':
            route_target_ = child_.text
            route_target_ = self.gds_validate_string(route_target_, node, 'route_target')
            self.route_target.append(route_target_)
# end class StaticRouteType


class StaticRouteEntriesType(GeneratedsSuper):
    """
    StaticRouteEntriesType class definition from :doc:`vnc_cfg.xsd`
    """
    subclass = None
    superclass = None
    def __init__(self, route=None, **kwargs):
        if (route is None) or (route == []):
            self.route = []
        else:
            if isinstance(route[0], dict):
                objs = [StaticRouteType(**elem) for elem in route]
                self.route = objs
            else:
                self.route = route
    def factory(*args_, **kwargs_):
        if StaticRouteEntriesType.subclass:
            return StaticRouteEntriesType.subclass(*args_, **kwargs_)
        else:
            return StaticRouteEntriesType(*args_, **kwargs_)
    factory = staticmethod(factory)
    def get_route(self): return self.route
    def set_route(self, route): self.route = route
    def add_route(self, value): self.route.append(value)
    def insert_route(self, index, value): self.route[index] = value
    @classmethod
    def populate (cls, *a, **kwa):
        obj = cls (*a, **kwa)
        obj.set_route (StaticRouteType.populate ())
        return obj
    def export(self, outfile, level=1, namespace_='', name_='StaticRouteEntriesType', namespacedef_='', pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        showIndent(outfile, level, pretty_print)
        outfile.write('<%s%s%s' % (namespace_, name_, namespacedef_ and ' ' + namespacedef_ or '', ))
        already_processed = []
        self.exportAttributes(outfile, level, already_processed, namespace_, name_='StaticRouteEntriesType')
        if self.hasContent_():
            outfile.write('>%s' % (eol_, ))
            self.exportChildren(outfile, level + 1, namespace_, name_, pretty_print=pretty_print)
            showIndent(outfile, level, pretty_print)
            outfile.write('</%s%s>%s' % (namespace_, name_, eol_))
        else:
            outfile.write('/>%s' % (eol_, ))
    def exportAttributes(self, outfile, level, already_processed, namespace_='', name_='StaticRouteEntriesType'):
        pass
    def exportChildren(self, outfile, level, namespace_='', name_='StaticRouteEntriesType', fromsubclass_=False, pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        for route_ in self.route:
            if isinstance(route_, dict):
                route_ = StaticRouteType(**route_)
            route_.export(outfile, level, namespace_, name_='route', pretty_print=pretty_print)
    def hasContent_(self):
        if (
            self.route
            ):
            return True
        else:
            return False
    def exportLiteral(self, outfile, level, name_='StaticRouteEntriesType'):
        level += 1
        self.exportLiteralAttributes(outfile, level, [], name_)
        if self.hasContent_():
            self.exportLiteralChildren(outfile, level, name_)
    def exportLiteralAttributes(self, outfile, level, already_processed, name_):
        pass
    def exportLiteralChildren(self, outfile, level, name_):
        showIndent(outfile, level)
        outfile.write('route=[\n')
        level += 1
        for route_ in self.route:
            showIndent(outfile, level)
            outfile.write('model_.StaticRouteType(\n')
            route_.exportLiteral(outfile, level, name_='StaticRouteType')
            showIndent(outfile, level)
            outfile.write('),\n')
        level -= 1
        showIndent(outfile, level)
        outfile.write('],\n')
    def exportDict(self, name_='StaticRouteEntriesType'):
        obj_json = json.dumps(self, default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        obj_dict = json.loads(obj_json)
        return {name_: obj_dict}
    def build(self, node):
        self.buildAttributes(node, node.attrib, [])
        for child in node:
            nodeName_ = Tag_pattern_.match(child.tag).groups()[-1]
            self.buildChildren(child, node, nodeName_)
    def buildAttributes(self, node, attrs, already_processed):
        pass
    def buildChildren(self, child_, node, nodeName_, fromsubclass_=False):
        if nodeName_ == 'route':
            obj_ = StaticRouteType.factory()
            obj_.build(child_)
            self.route.append(obj_)
# end class StaticRouteEntriesType


class BgpRouterParams(GeneratedsSuper):
    """
    BgpRouterParams class definition from :doc:`vnc_cfg.xsd`
    """
    subclass = None
    superclass = None
    def __init__(self, vendor=None, vnc_managed=None, autonomous_system=None, identifier=None, address=None, port=None, address_families=None, **kwargs):
        self.vendor = vendor
        self.vnc_managed = vnc_managed
        self.autonomous_system = autonomous_system
        self.identifier = identifier
        self.address = address
        self.port = port
        if isinstance(address_families, dict):
            obj = AddressFamilies(**address_families)
            self.address_families = obj
        else:
            self.address_families = address_families
    def factory(*args_, **kwargs_):
        if BgpRouterParams.subclass:
            return BgpRouterParams.subclass(*args_, **kwargs_)
        else:
            return BgpRouterParams(*args_, **kwargs_)
    factory = staticmethod(factory)
    def get_vendor(self): return self.vendor
    def set_vendor(self, vendor): self.vendor = vendor
    def get_vnc_managed(self): return self.vnc_managed
    def set_vnc_managed(self, vnc_managed): self.vnc_managed = vnc_managed
    def get_autonomous_system(self): return self.autonomous_system
    def set_autonomous_system(self, autonomous_system): self.autonomous_system = autonomous_system
    def get_identifier(self): return self.identifier
    def set_identifier(self, identifier): self.identifier = identifier
    def validate_IpAddress(self, value):
        # Validate type IpAddress, a restriction on xsd:string.
        pass
    def get_address(self): return self.address
    def set_address(self, address): self.address = address
    def get_port(self): return self.port
    def set_port(self, port): self.port = port
    def get_address_families(self): return self.address_families
    def set_address_families(self, address_families): self.address_families = address_families
    @classmethod
    def populate (cls, *a, **kwa):
        obj = cls (*a, **kwa)
        obj.set_vendor (obj.populate_string ("vendor"))
        obj.set_vnc_managed (obj.populate_boolean ("vnc_managed"))
        obj.set_autonomous_system (obj.populate_integer ("autonomous_system"))
        obj.set_identifier (obj.populate_string ("identifier"))
        obj.set_address (obj.populate_string ("address"))
        obj.set_port (obj.populate_integer ("port"))
        obj.set_address_families (AddressFamilies.populate ())
        return obj
    def export(self, outfile, level=1, namespace_='', name_='BgpRouterParams', namespacedef_='', pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        showIndent(outfile, level, pretty_print)
        outfile.write('<%s%s%s' % (namespace_, name_, namespacedef_ and ' ' + namespacedef_ or '', ))
        already_processed = []
        self.exportAttributes(outfile, level, already_processed, namespace_, name_='BgpRouterParams')
        if self.hasContent_():
            outfile.write('>%s' % (eol_, ))
            self.exportChildren(outfile, level + 1, namespace_, name_, pretty_print=pretty_print)
            showIndent(outfile, level, pretty_print)
            outfile.write('</%s%s>%s' % (namespace_, name_, eol_))
        else:
            outfile.write('/>%s' % (eol_, ))
    def exportAttributes(self, outfile, level, already_processed, namespace_='', name_='BgpRouterParams'):
        pass
    def exportChildren(self, outfile, level, namespace_='', name_='BgpRouterParams', fromsubclass_=False, pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        if self.vendor is not None:
            showIndent(outfile, level, pretty_print)
            outfile.write('<%svendor>%s</%svendor>%s' % (namespace_, self.gds_format_string(quote_xml(self.vendor).encode(ExternalEncoding), input_name='vendor'), namespace_, eol_))
        if self.vnc_managed is not None:
            showIndent(outfile, level, pretty_print)
            outfile.write('<%svnc-managed>%s</%svnc-managed>%s' % (namespace_, self.gds_format_boolean(self.gds_str_lower(str(self.vnc_managed)), input_name='vnc-managed'), namespace_, eol_))
        if self.autonomous_system is not None:
            showIndent(outfile, level, pretty_print)
            outfile.write('<%sautonomous-system>%s</%sautonomous-system>%s' % (namespace_, self.gds_format_integer(self.autonomous_system, input_name='autonomous-system'), namespace_, eol_))
        if self.identifier is not None:
            showIndent(outfile, level, pretty_print)
            outfile.write('<%sidentifier>%s</%sidentifier>%s' % (namespace_, self.gds_format_string(quote_xml(self.identifier).encode(ExternalEncoding), input_name='identifier'), namespace_, eol_))
        if self.address is not None:
            showIndent(outfile, level, pretty_print)
            outfile.write('<%saddress>%s</%saddress>%s' % (namespace_, self.gds_format_string(quote_xml(self.address).encode(ExternalEncoding), input_name='address'), namespace_, eol_))
        if self.port is not None:
            showIndent(outfile, level, pretty_print)
            outfile.write('<%sport>%s</%sport>%s' % (namespace_, self.gds_format_integer(self.port, input_name='port'), namespace_, eol_))
        if self.address_families is not None:
            self.address_families.export(outfile, level, namespace_, name_='address-families', pretty_print=pretty_print)
    def hasContent_(self):
        if (
            self.vendor is not None or
            self.vnc_managed is not None or
            self.autonomous_system is not None or
            self.identifier is not None or
            self.address is not None or
            self.port is not None or
            self.address_families is not None
            ):
            return True
        else:
            return False
    def exportLiteral(self, outfile, level, name_='BgpRouterParams'):
        level += 1
        self.exportLiteralAttributes(outfile, level, [], name_)
        if self.hasContent_():
            self.exportLiteralChildren(outfile, level, name_)
    def exportLiteralAttributes(self, outfile, level, already_processed, name_):
        pass
    def exportLiteralChildren(self, outfile, level, name_):
        if self.vendor is not None:
            showIndent(outfile, level)
            outfile.write('vendor=%s,\n' % quote_python(self.vendor).encode(ExternalEncoding))
        if self.vnc_managed is not None:
            showIndent(outfile, level)
            outfile.write('vnc_managed=%s,\n' % self.vnc_managed)
        if self.autonomous_system is not None:
            showIndent(outfile, level)
            outfile.write('autonomous_system=%d,\n' % self.autonomous_system)
        if self.identifier is not None:
            showIndent(outfile, level)
            outfile.write('identifier=%s,\n' % quote_python(self.identifier).encode(ExternalEncoding))
        if self.address is not None:
            showIndent(outfile, level)
            outfile.write('address=%s,\n' % quote_python(self.address).encode(ExternalEncoding))
        if self.port is not None:
            showIndent(outfile, level)
            outfile.write('port=%d,\n' % self.port)
        if self.address_families is not None:
            showIndent(outfile, level)
            outfile.write('address_families=model_.AddressFamilies(\n')
            self.address_families.exportLiteral(outfile, level, name_='address_families')
            showIndent(outfile, level)
            outfile.write('),\n')
    def exportDict(self, name_='BgpRouterParams'):
        obj_json = json.dumps(self, default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        obj_dict = json.loads(obj_json)
        return {name_: obj_dict}
    def build(self, node):
        self.buildAttributes(node, node.attrib, [])
        for child in node:
            nodeName_ = Tag_pattern_.match(child.tag).groups()[-1]
            self.buildChildren(child, node, nodeName_)
    def buildAttributes(self, node, attrs, already_processed):
        pass
    def buildChildren(self, child_, node, nodeName_, fromsubclass_=False):
        if nodeName_ == 'vendor':
            vendor_ = child_.text
            vendor_ = self.gds_validate_string(vendor_, node, 'vendor')
            self.vendor = vendor_
        elif nodeName_ == 'vnc-managed':
            sval_ = child_.text
            if sval_ in ('true', '1'):
                ival_ = True
            elif sval_ in ('false', '0'):
                ival_ = False
            else:
                raise_parse_error(child_, 'requires boolean')
            ival_ = self.gds_validate_boolean(ival_, node, 'vnc_managed')
            self.vnc_managed = ival_
        elif nodeName_ == 'autonomous-system':
            sval_ = child_.text
            try:
                ival_ = int(sval_)
            except (TypeError, ValueError), exp:
                raise_parse_error(child_, 'requires integer: %s' % exp)
            ival_ = self.gds_validate_integer(ival_, node, 'autonomous_system')
            self.autonomous_system = ival_
        elif nodeName_ == 'identifier':
            identifier_ = child_.text
            identifier_ = self.gds_validate_string(identifier_, node, 'identifier')
            self.identifier = identifier_
            self.validate_IpAddress(self.identifier)    # validate type IpAddress
        elif nodeName_ == 'address':
            address_ = child_.text
            address_ = self.gds_validate_string(address_, node, 'address')
            self.address = address_
            self.validate_IpAddress(self.address)    # validate type IpAddress
        elif nodeName_ == 'port':
            sval_ = child_.text
            try:
                ival_ = int(sval_)
            except (TypeError, ValueError), exp:
                raise_parse_error(child_, 'requires integer: %s' % exp)
            ival_ = self.gds_validate_integer(ival_, node, 'port')
            self.port = ival_
        elif nodeName_ == 'address-families':
            obj_ = AddressFamilies.factory()
            obj_.build(child_)
            self.set_address_families(obj_)
# end class BgpRouterParams


class instance_bgp_router(GeneratedsSuper):
    """
    instance_bgp_router class definition from :doc:`vnc_cfg.xsd`
    """
    subclass = None
    superclass = None
    def __init__(self, **kwargs):
        pass
    def factory(*args_, **kwargs_):
        if instance_bgp_router.subclass:
            return instance_bgp_router.subclass(*args_, **kwargs_)
        else:
            return instance_bgp_router(*args_, **kwargs_)
    factory = staticmethod(factory)
    @classmethod
    def populate (cls, *a, **kwa):
        obj = cls (*a, **kwa)
        return obj
    def export(self, outfile, level=1, namespace_='', name_='instance-bgp-router', namespacedef_='', pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        showIndent(outfile, level, pretty_print)
        outfile.write('<%s%s%s' % (namespace_, name_, namespacedef_ and ' ' + namespacedef_ or '', ))
        already_processed = []
        self.exportAttributes(outfile, level, already_processed, namespace_, name_='instance-bgp-router')
        if self.hasContent_():
            outfile.write('>%s' % (eol_, ))
            self.exportChildren(outfile, level + 1, namespace_, name_, pretty_print=pretty_print)
            outfile.write('</%s%s>%s' % (namespace_, name_, eol_))
        else:
            outfile.write('/>%s' % (eol_, ))
    def exportAttributes(self, outfile, level, already_processed, namespace_='', name_='instance-bgp-router'):
        pass
    def exportChildren(self, outfile, level, namespace_='', name_='instance-bgp-router', fromsubclass_=False, pretty_print=True):
        pass
    def hasContent_(self):
        if (

            ):
            return True
        else:
            return False
    def exportLiteral(self, outfile, level, name_='instance-bgp-router'):
        level += 1
        self.exportLiteralAttributes(outfile, level, [], name_)
        if self.hasContent_():
            self.exportLiteralChildren(outfile, level, name_)
    def exportLiteralAttributes(self, outfile, level, already_processed, name_):
        pass
    def exportLiteralChildren(self, outfile, level, name_):
        pass
    def exportDict(self, name_='instance-bgp-router'):
        obj_json = json.dumps(self, default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        obj_dict = json.loads(obj_json)
        return {name_: obj_dict}
    def build(self, node):
        self.buildAttributes(node, node.attrib, [])
        for child in node:
            nodeName_ = Tag_pattern_.match(child.tag).groups()[-1]
            self.buildChildren(child, node, nodeName_)
    def buildAttributes(self, node, attrs, already_processed):
        pass
    def buildChildren(self, child_, node, nodeName_, fromsubclass_=False):
        pass
# end class instance_bgp_router


class BgpPeeringAttributes(GeneratedsSuper):
    """
    BgpPeeringAttributes class definition from :doc:`vnc_cfg.xsd`
    """
    subclass = None
    superclass = None
    def __init__(self, session=None, **kwargs):
        if (session is None) or (session == []):
            self.session = []
        else:
            if isinstance(session[0], dict):
                objs = [BgpSession(**elem) for elem in session]
                self.session = objs
            else:
                self.session = session
    def factory(*args_, **kwargs_):
        if BgpPeeringAttributes.subclass:
            return BgpPeeringAttributes.subclass(*args_, **kwargs_)
        else:
            return BgpPeeringAttributes(*args_, **kwargs_)
    factory = staticmethod(factory)
    def get_session(self): return self.session
    def set_session(self, session): self.session = session
    def add_session(self, value): self.session.append(value)
    def insert_session(self, index, value): self.session[index] = value
    @classmethod
    def populate (cls, *a, **kwa):
        obj = cls (*a, **kwa)
        obj.set_session (BgpSession.populate ())
        return obj
    def export(self, outfile, level=1, namespace_='', name_='BgpPeeringAttributes', namespacedef_='', pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        showIndent(outfile, level, pretty_print)
        outfile.write('<%s%s%s' % (namespace_, name_, namespacedef_ and ' ' + namespacedef_ or '', ))
        already_processed = []
        self.exportAttributes(outfile, level, already_processed, namespace_, name_='BgpPeeringAttributes')
        if self.hasContent_():
            outfile.write('>%s' % (eol_, ))
            self.exportChildren(outfile, level + 1, namespace_, name_, pretty_print=pretty_print)
            showIndent(outfile, level, pretty_print)
            outfile.write('</%s%s>%s' % (namespace_, name_, eol_))
        else:
            outfile.write('/>%s' % (eol_, ))
    def exportAttributes(self, outfile, level, already_processed, namespace_='', name_='BgpPeeringAttributes'):
        pass
    def exportChildren(self, outfile, level, namespace_='', name_='BgpPeeringAttributes', fromsubclass_=False, pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        for session_ in self.session:
            if isinstance(session_, dict):
                session_ = BgpSession(**session_)
            session_.export(outfile, level, namespace_, name_='session', pretty_print=pretty_print)
    def hasContent_(self):
        if (
            self.session
            ):
            return True
        else:
            return False
    def exportLiteral(self, outfile, level, name_='BgpPeeringAttributes'):
        level += 1
        self.exportLiteralAttributes(outfile, level, [], name_)
        if self.hasContent_():
            self.exportLiteralChildren(outfile, level, name_)
    def exportLiteralAttributes(self, outfile, level, already_processed, name_):
        pass
    def exportLiteralChildren(self, outfile, level, name_):
        showIndent(outfile, level)
        outfile.write('session=[\n')
        level += 1
        for session_ in self.session:
            showIndent(outfile, level)
            outfile.write('model_.BgpSession(\n')
            session_.exportLiteral(outfile, level, name_='BgpSession')
            showIndent(outfile, level)
            outfile.write('),\n')
        level -= 1
        showIndent(outfile, level)
        outfile.write('],\n')
    def exportDict(self, name_='BgpPeeringAttributes'):
        obj_json = json.dumps(self, default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        obj_dict = json.loads(obj_json)
        return {name_: obj_dict}
    def build(self, node):
        self.buildAttributes(node, node.attrib, [])
        for child in node:
            nodeName_ = Tag_pattern_.match(child.tag).groups()[-1]
            self.buildChildren(child, node, nodeName_)
    def buildAttributes(self, node, attrs, already_processed):
        pass
    def buildChildren(self, child_, node, nodeName_, fromsubclass_=False):
        if nodeName_ == 'session':
            obj_ = BgpSession.factory()
            obj_.build(child_)
            self.session.append(obj_)
# end class BgpPeeringAttributes


class BgpSession(GeneratedsSuper):
    """
    BgpSession class definition from :doc:`vnc_cfg.xsd`
    """
    subclass = None
    superclass = None
    def __init__(self, uuid=None, attributes=None, **kwargs):
        self.uuid = uuid
        if (attributes is None) or (attributes == []):
            self.attributes = []
        else:
            if isinstance(attributes[0], dict):
                objs = [BgpSessionAttributes(**elem) for elem in attributes]
                self.attributes = objs
            else:
                self.attributes = attributes
    def factory(*args_, **kwargs_):
        if BgpSession.subclass:
            return BgpSession.subclass(*args_, **kwargs_)
        else:
            return BgpSession(*args_, **kwargs_)
    factory = staticmethod(factory)
    def get_uuid(self): return self.uuid
    def set_uuid(self, uuid): self.uuid = uuid
    def get_attributes(self): return self.attributes
    def set_attributes(self, attributes): self.attributes = attributes
    def add_attributes(self, value): self.attributes.append(value)
    def insert_attributes(self, index, value): self.attributes[index] = value
    @classmethod
    def populate (cls, *a, **kwa):
        obj = cls (*a, **kwa)
        obj.set_uuid (obj.populate_string ("uuid"))
        obj.set_attributes (BgpSessionAttributes.populate ())
        return obj
    def export(self, outfile, level=1, namespace_='', name_='BgpSession', namespacedef_='', pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        showIndent(outfile, level, pretty_print)
        outfile.write('<%s%s%s' % (namespace_, name_, namespacedef_ and ' ' + namespacedef_ or '', ))
        already_processed = []
        self.exportAttributes(outfile, level, already_processed, namespace_, name_='BgpSession')
        if self.hasContent_():
            outfile.write('>%s' % (eol_, ))
            self.exportChildren(outfile, level + 1, namespace_, name_, pretty_print=pretty_print)
            showIndent(outfile, level, pretty_print)
            outfile.write('</%s%s>%s' % (namespace_, name_, eol_))
        else:
            outfile.write('/>%s' % (eol_, ))
    def exportAttributes(self, outfile, level, already_processed, namespace_='', name_='BgpSession'):
        pass
    def exportChildren(self, outfile, level, namespace_='', name_='BgpSession', fromsubclass_=False, pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        if self.uuid is not None:
            showIndent(outfile, level, pretty_print)
            outfile.write('<%suuid>%s</%suuid>%s' % (namespace_, self.gds_format_string(quote_xml(self.uuid).encode(ExternalEncoding), input_name='uuid'), namespace_, eol_))
        for attributes_ in self.attributes:
            if isinstance(attributes_, dict):
                attributes_ = BgpSessionAttributes(**attributes_)
            attributes_.export(outfile, level, namespace_, name_='attributes', pretty_print=pretty_print)
    def hasContent_(self):
        if (
            self.uuid is not None or
            self.attributes
            ):
            return True
        else:
            return False
    def exportLiteral(self, outfile, level, name_='BgpSession'):
        level += 1
        self.exportLiteralAttributes(outfile, level, [], name_)
        if self.hasContent_():
            self.exportLiteralChildren(outfile, level, name_)
    def exportLiteralAttributes(self, outfile, level, already_processed, name_):
        pass
    def exportLiteralChildren(self, outfile, level, name_):
        if self.uuid is not None:
            showIndent(outfile, level)
            outfile.write('uuid=%s,\n' % quote_python(self.uuid).encode(ExternalEncoding))
        showIndent(outfile, level)
        outfile.write('attributes=[\n')
        level += 1
        for attributes_ in self.attributes:
            showIndent(outfile, level)
            outfile.write('model_.BgpSessionAttributes(\n')
            attributes_.exportLiteral(outfile, level, name_='BgpSessionAttributes')
            showIndent(outfile, level)
            outfile.write('),\n')
        level -= 1
        showIndent(outfile, level)
        outfile.write('],\n')
    def exportDict(self, name_='BgpSession'):
        obj_json = json.dumps(self, default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        obj_dict = json.loads(obj_json)
        return {name_: obj_dict}
    def build(self, node):
        self.buildAttributes(node, node.attrib, [])
        for child in node:
            nodeName_ = Tag_pattern_.match(child.tag).groups()[-1]
            self.buildChildren(child, node, nodeName_)
    def buildAttributes(self, node, attrs, already_processed):
        pass
    def buildChildren(self, child_, node, nodeName_, fromsubclass_=False):
        if nodeName_ == 'uuid':
            uuid_ = child_.text
            uuid_ = self.gds_validate_string(uuid_, node, 'uuid')
            self.uuid = uuid_
        elif nodeName_ == 'attributes':
            obj_ = BgpSessionAttributes.factory()
            obj_.build(child_)
            self.attributes.append(obj_)
# end class BgpSession


class BgpSessionAttributes(GeneratedsSuper):
    """
    BgpSessionAttributes class definition from :doc:`vnc_cfg.xsd`
    """
    subclass = None
    superclass = None
    def __init__(self, bgp_router=None, address_families=None, **kwargs):
        self.bgp_router = bgp_router
        if isinstance(address_families, dict):
            obj = AddressFamilies(**address_families)
            self.address_families = obj
        else:
            self.address_families = address_families
    def factory(*args_, **kwargs_):
        if BgpSessionAttributes.subclass:
            return BgpSessionAttributes.subclass(*args_, **kwargs_)
        else:
            return BgpSessionAttributes(*args_, **kwargs_)
    factory = staticmethod(factory)
    def get_bgp_router(self): return self.bgp_router
    def set_bgp_router(self, bgp_router): self.bgp_router = bgp_router
    def get_address_families(self): return self.address_families
    def set_address_families(self, address_families): self.address_families = address_families
    @classmethod
    def populate (cls, *a, **kwa):
        obj = cls (*a, **kwa)
        obj.set_bgp_router (obj.populate_string ("bgp_router"))
        obj.set_address_families (AddressFamilies.populate ())
        return obj
    def export(self, outfile, level=1, namespace_='', name_='BgpSessionAttributes', namespacedef_='', pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        showIndent(outfile, level, pretty_print)
        outfile.write('<%s%s%s' % (namespace_, name_, namespacedef_ and ' ' + namespacedef_ or '', ))
        already_processed = []
        self.exportAttributes(outfile, level, already_processed, namespace_, name_='BgpSessionAttributes')
        if self.hasContent_():
            outfile.write('>%s' % (eol_, ))
            self.exportChildren(outfile, level + 1, namespace_, name_, pretty_print=pretty_print)
            showIndent(outfile, level, pretty_print)
            outfile.write('</%s%s>%s' % (namespace_, name_, eol_))
        else:
            outfile.write('/>%s' % (eol_, ))
    def exportAttributes(self, outfile, level, already_processed, namespace_='', name_='BgpSessionAttributes'):
        pass
    def exportChildren(self, outfile, level, namespace_='', name_='BgpSessionAttributes', fromsubclass_=False, pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        if self.bgp_router is not None:
            showIndent(outfile, level, pretty_print)
            outfile.write('<%sbgp-router>%s</%sbgp-router>%s' % (namespace_, self.gds_format_string(quote_xml(self.bgp_router).encode(ExternalEncoding), input_name='bgp-router'), namespace_, eol_))
        if self.address_families is not None:
            self.address_families.export(outfile, level, namespace_, name_='address-families', pretty_print=pretty_print)
    def hasContent_(self):
        if (
            self.bgp_router is not None or
            self.address_families is not None
            ):
            return True
        else:
            return False
    def exportLiteral(self, outfile, level, name_='BgpSessionAttributes'):
        level += 1
        self.exportLiteralAttributes(outfile, level, [], name_)
        if self.hasContent_():
            self.exportLiteralChildren(outfile, level, name_)
    def exportLiteralAttributes(self, outfile, level, already_processed, name_):
        pass
    def exportLiteralChildren(self, outfile, level, name_):
        if self.bgp_router is not None:
            showIndent(outfile, level)
            outfile.write('bgp_router=%s,\n' % quote_python(self.bgp_router).encode(ExternalEncoding))
        if self.address_families is not None:
            showIndent(outfile, level)
            outfile.write('address_families=model_.AddressFamilies(\n')
            self.address_families.exportLiteral(outfile, level, name_='address_families')
            showIndent(outfile, level)
            outfile.write('),\n')
    def exportDict(self, name_='BgpSessionAttributes'):
        obj_json = json.dumps(self, default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        obj_dict = json.loads(obj_json)
        return {name_: obj_dict}
    def build(self, node):
        self.buildAttributes(node, node.attrib, [])
        for child in node:
            nodeName_ = Tag_pattern_.match(child.tag).groups()[-1]
            self.buildChildren(child, node, nodeName_)
    def buildAttributes(self, node, attrs, already_processed):
        pass
    def buildChildren(self, child_, node, nodeName_, fromsubclass_=False):
        if nodeName_ == 'bgp-router':
            bgp_router_ = child_.text
            bgp_router_ = self.gds_validate_string(bgp_router_, node, 'bgp_router')
            self.bgp_router = bgp_router_
        elif nodeName_ == 'address-families':
            obj_ = AddressFamilies.factory()
            obj_.build(child_)
            self.set_address_families(obj_)
# end class BgpSessionAttributes


class AddressFamilies(GeneratedsSuper):
    """
    AddressFamilies class definition from :doc:`vnc_cfg.xsd`
    """
    subclass = None
    superclass = None
    def __init__(self, family=None, **kwargs):
        if (family is None) or (family == []):
            self.family = []
        else:
            self.family = family
    def factory(*args_, **kwargs_):
        if AddressFamilies.subclass:
            return AddressFamilies.subclass(*args_, **kwargs_)
        else:
            return AddressFamilies(*args_, **kwargs_)
    factory = staticmethod(factory)
    def get_family(self): return self.family
    def set_family(self, family): self.family = family
    def add_family(self, value): self.family.append(value)
    def insert_family(self, index, value): self.family[index] = value
    @classmethod
    def populate (cls, *a, **kwa):
        obj = cls (*a, **kwa)
        obj.set_family (obj.populate_string ("family"))
        return obj
    def export(self, outfile, level=1, namespace_='', name_='AddressFamilies', namespacedef_='', pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        showIndent(outfile, level, pretty_print)
        outfile.write('<%s%s%s' % (namespace_, name_, namespacedef_ and ' ' + namespacedef_ or '', ))
        already_processed = []
        self.exportAttributes(outfile, level, already_processed, namespace_, name_='AddressFamilies')
        if self.hasContent_():
            outfile.write('>%s' % (eol_, ))
            self.exportChildren(outfile, level + 1, namespace_, name_, pretty_print=pretty_print)
            showIndent(outfile, level, pretty_print)
            outfile.write('</%s%s>%s' % (namespace_, name_, eol_))
        else:
            outfile.write('/>%s' % (eol_, ))
    def exportAttributes(self, outfile, level, already_processed, namespace_='', name_='AddressFamilies'):
        pass
    def exportChildren(self, outfile, level, namespace_='', name_='AddressFamilies', fromsubclass_=False, pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        for family_ in self.family:
            showIndent(outfile, level, pretty_print)
            outfile.write('<%sfamily>%s</%sfamily>%s' % (namespace_, self.gds_format_string(quote_xml(family_).encode(ExternalEncoding), input_name='family'), namespace_, eol_))
    def hasContent_(self):
        if (
            self.family
            ):
            return True
        else:
            return False
    def exportLiteral(self, outfile, level, name_='AddressFamilies'):
        level += 1
        self.exportLiteralAttributes(outfile, level, [], name_)
        if self.hasContent_():
            self.exportLiteralChildren(outfile, level, name_)
    def exportLiteralAttributes(self, outfile, level, already_processed, name_):
        pass
    def exportLiteralChildren(self, outfile, level, name_):
        showIndent(outfile, level)
        outfile.write('family=[\n')
        level += 1
        for family_ in self.family:
            showIndent(outfile, level)
            outfile.write('%s,\n' % quote_python(family_).encode(ExternalEncoding))
        level -= 1
        showIndent(outfile, level)
        outfile.write('],\n')
    def exportDict(self, name_='AddressFamilies'):
        obj_json = json.dumps(self, default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        obj_dict = json.loads(obj_json)
        return {name_: obj_dict}
    def build(self, node):
        self.buildAttributes(node, node.attrib, [])
        for child in node:
            nodeName_ = Tag_pattern_.match(child.tag).groups()[-1]
            self.buildChildren(child, node, nodeName_)
    def buildAttributes(self, node, attrs, already_processed):
        pass
    def buildChildren(self, child_, node, nodeName_, fromsubclass_=False):
        if nodeName_ == 'family':
            family_ = child_.text
            family_ = self.gds_validate_string(family_, node, 'family')
            self.family.append(family_)
# end class AddressFamilies


class ServiceChainInfo(GeneratedsSuper):
    """
    ServiceChainInfo class definition from :doc:`vnc_cfg.xsd`
    """
    subclass = None
    superclass = None
    def __init__(self, routing_instance=None, prefix=None, service_chain_address=None, **kwargs):
        self.routing_instance = routing_instance
        if (prefix is None) or (prefix == []):
            self.prefix = []
        else:
            self.prefix = prefix
        self.service_chain_address = service_chain_address
    def factory(*args_, **kwargs_):
        if ServiceChainInfo.subclass:
            return ServiceChainInfo.subclass(*args_, **kwargs_)
        else:
            return ServiceChainInfo(*args_, **kwargs_)
    factory = staticmethod(factory)
    def get_routing_instance(self): return self.routing_instance
    def set_routing_instance(self, routing_instance): self.routing_instance = routing_instance
    def get_prefix(self): return self.prefix
    def set_prefix(self, prefix): self.prefix = prefix
    def add_prefix(self, value): self.prefix.append(value)
    def insert_prefix(self, index, value): self.prefix[index] = value
    def get_service_chain_address(self): return self.service_chain_address
    def set_service_chain_address(self, service_chain_address): self.service_chain_address = service_chain_address
    def validate_IpAddress(self, value):
        # Validate type IpAddress, a restriction on xsd:string.
        pass
    @classmethod
    def populate (cls, *a, **kwa):
        obj = cls (*a, **kwa)
        obj.set_routing_instance (obj.populate_string ("routing_instance"))
        obj.set_prefix (obj.populate_string ("prefix"))
        obj.set_service_chain_address (obj.populate_string ("service_chain_address"))
        return obj
    def export(self, outfile, level=1, namespace_='', name_='ServiceChainInfo', namespacedef_='', pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        showIndent(outfile, level, pretty_print)
        outfile.write('<%s%s%s' % (namespace_, name_, namespacedef_ and ' ' + namespacedef_ or '', ))
        already_processed = []
        self.exportAttributes(outfile, level, already_processed, namespace_, name_='ServiceChainInfo')
        if self.hasContent_():
            outfile.write('>%s' % (eol_, ))
            self.exportChildren(outfile, level + 1, namespace_, name_, pretty_print=pretty_print)
            showIndent(outfile, level, pretty_print)
            outfile.write('</%s%s>%s' % (namespace_, name_, eol_))
        else:
            outfile.write('/>%s' % (eol_, ))
    def exportAttributes(self, outfile, level, already_processed, namespace_='', name_='ServiceChainInfo'):
        pass
    def exportChildren(self, outfile, level, namespace_='', name_='ServiceChainInfo', fromsubclass_=False, pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        if self.routing_instance is not None:
            showIndent(outfile, level, pretty_print)
            outfile.write('<%srouting-instance>%s</%srouting-instance>%s' % (namespace_, self.gds_format_string(quote_xml(self.routing_instance).encode(ExternalEncoding), input_name='routing-instance'), namespace_, eol_))
        for prefix_ in self.prefix:
            showIndent(outfile, level, pretty_print)
            outfile.write('<%sprefix>%s</%sprefix>%s' % (namespace_, self.gds_format_string(quote_xml(prefix_).encode(ExternalEncoding), input_name='prefix'), namespace_, eol_))
        if self.service_chain_address is not None:
            showIndent(outfile, level, pretty_print)
            outfile.write('<%sservice-chain-address>%s</%sservice-chain-address>%s' % (namespace_, self.gds_format_string(quote_xml(self.service_chain_address).encode(ExternalEncoding), input_name='service-chain-address'), namespace_, eol_))
    def hasContent_(self):
        if (
            self.routing_instance is not None or
            self.prefix or
            self.service_chain_address is not None
            ):
            return True
        else:
            return False
    def exportLiteral(self, outfile, level, name_='ServiceChainInfo'):
        level += 1
        self.exportLiteralAttributes(outfile, level, [], name_)
        if self.hasContent_():
            self.exportLiteralChildren(outfile, level, name_)
    def exportLiteralAttributes(self, outfile, level, already_processed, name_):
        pass
    def exportLiteralChildren(self, outfile, level, name_):
        if self.routing_instance is not None:
            showIndent(outfile, level)
            outfile.write('routing_instance=%s,\n' % quote_python(self.routing_instance).encode(ExternalEncoding))
        showIndent(outfile, level)
        outfile.write('prefix=[\n')
        level += 1
        for prefix_ in self.prefix:
            showIndent(outfile, level)
            outfile.write('%s,\n' % quote_python(prefix_).encode(ExternalEncoding))
        level -= 1
        showIndent(outfile, level)
        outfile.write('],\n')
        if self.service_chain_address is not None:
            showIndent(outfile, level)
            outfile.write('service_chain_address=%s,\n' % quote_python(self.service_chain_address).encode(ExternalEncoding))
    def exportDict(self, name_='ServiceChainInfo'):
        obj_json = json.dumps(self, default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        obj_dict = json.loads(obj_json)
        return {name_: obj_dict}
    def build(self, node):
        self.buildAttributes(node, node.attrib, [])
        for child in node:
            nodeName_ = Tag_pattern_.match(child.tag).groups()[-1]
            self.buildChildren(child, node, nodeName_)
    def buildAttributes(self, node, attrs, already_processed):
        pass
    def buildChildren(self, child_, node, nodeName_, fromsubclass_=False):
        if nodeName_ == 'routing-instance':
            routing_instance_ = child_.text
            routing_instance_ = self.gds_validate_string(routing_instance_, node, 'routing_instance')
            self.routing_instance = routing_instance_
        elif nodeName_ == 'prefix':
            prefix_ = child_.text
            prefix_ = self.gds_validate_string(prefix_, node, 'prefix')
            self.prefix.append(prefix_)
        elif nodeName_ == 'service-chain-address':
            service_chain_address_ = child_.text
            service_chain_address_ = self.gds_validate_string(service_chain_address_, node, 'service_chain_address')
            self.service_chain_address = service_chain_address_
            self.validate_IpAddress(self.service_chain_address)    # validate type IpAddress
# end class ServiceChainInfo


class ProtocolBgpType(GeneratedsSuper):
    """
    ProtocolBgpType class definition from :doc:`vnc_cfg.xsd`
    """
    subclass = None
    superclass = None
    def __init__(self, **kwargs):
        pass
    def factory(*args_, **kwargs_):
        if ProtocolBgpType.subclass:
            return ProtocolBgpType.subclass(*args_, **kwargs_)
        else:
            return ProtocolBgpType(*args_, **kwargs_)
    factory = staticmethod(factory)
    @classmethod
    def populate (cls, *a, **kwa):
        obj = cls (*a, **kwa)
        return obj
    def export(self, outfile, level=1, namespace_='', name_='ProtocolBgpType', namespacedef_='', pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        showIndent(outfile, level, pretty_print)
        outfile.write('<%s%s%s' % (namespace_, name_, namespacedef_ and ' ' + namespacedef_ or '', ))
        already_processed = []
        self.exportAttributes(outfile, level, already_processed, namespace_, name_='ProtocolBgpType')
        if self.hasContent_():
            outfile.write('>%s' % (eol_, ))
            self.exportChildren(outfile, level + 1, namespace_, name_, pretty_print=pretty_print)
            outfile.write('</%s%s>%s' % (namespace_, name_, eol_))
        else:
            outfile.write('/>%s' % (eol_, ))
    def exportAttributes(self, outfile, level, already_processed, namespace_='', name_='ProtocolBgpType'):
        pass
    def exportChildren(self, outfile, level, namespace_='', name_='ProtocolBgpType', fromsubclass_=False, pretty_print=True):
        pass
    def hasContent_(self):
        if (

            ):
            return True
        else:
            return False
    def exportLiteral(self, outfile, level, name_='ProtocolBgpType'):
        level += 1
        self.exportLiteralAttributes(outfile, level, [], name_)
        if self.hasContent_():
            self.exportLiteralChildren(outfile, level, name_)
    def exportLiteralAttributes(self, outfile, level, already_processed, name_):
        pass
    def exportLiteralChildren(self, outfile, level, name_):
        pass
    def exportDict(self, name_='ProtocolBgpType'):
        obj_json = json.dumps(self, default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        obj_dict = json.loads(obj_json)
        return {name_: obj_dict}
    def build(self, node):
        self.buildAttributes(node, node.attrib, [])
        for child in node:
            nodeName_ = Tag_pattern_.match(child.tag).groups()[-1]
            self.buildChildren(child, node, nodeName_)
    def buildAttributes(self, node, attrs, already_processed):
        pass
    def buildChildren(self, child_, node, nodeName_, fromsubclass_=False):
        pass
# end class ProtocolBgpType


class ProtocolOspfType(GeneratedsSuper):
    """
    ProtocolOspfType class definition from :doc:`vnc_cfg.xsd`
    """
    subclass = None
    superclass = None
    def __init__(self, area=None, **kwargs):
        self.area = area
    def factory(*args_, **kwargs_):
        if ProtocolOspfType.subclass:
            return ProtocolOspfType.subclass(*args_, **kwargs_)
        else:
            return ProtocolOspfType(*args_, **kwargs_)
    factory = staticmethod(factory)
    def get_area(self): return self.area
    def set_area(self, area): self.area = area
    @classmethod
    def populate (cls, *a, **kwa):
        obj = cls (*a, **kwa)
        obj.set_area (obj.populate_integer ("area"))
        return obj
    def export(self, outfile, level=1, namespace_='', name_='ProtocolOspfType', namespacedef_='', pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        showIndent(outfile, level, pretty_print)
        outfile.write('<%s%s%s' % (namespace_, name_, namespacedef_ and ' ' + namespacedef_ or '', ))
        already_processed = []
        self.exportAttributes(outfile, level, already_processed, namespace_, name_='ProtocolOspfType')
        if self.hasContent_():
            outfile.write('>%s' % (eol_, ))
            self.exportChildren(outfile, level + 1, namespace_, name_, pretty_print=pretty_print)
            showIndent(outfile, level, pretty_print)
            outfile.write('</%s%s>%s' % (namespace_, name_, eol_))
        else:
            outfile.write('/>%s' % (eol_, ))
    def exportAttributes(self, outfile, level, already_processed, namespace_='', name_='ProtocolOspfType'):
        pass
    def exportChildren(self, outfile, level, namespace_='', name_='ProtocolOspfType', fromsubclass_=False, pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        if self.area is not None:
            showIndent(outfile, level, pretty_print)
            outfile.write('<%sarea>%s</%sarea>%s' % (namespace_, self.gds_format_integer(self.area, input_name='area'), namespace_, eol_))
    def hasContent_(self):
        if (
            self.area is not None
            ):
            return True
        else:
            return False
    def exportLiteral(self, outfile, level, name_='ProtocolOspfType'):
        level += 1
        self.exportLiteralAttributes(outfile, level, [], name_)
        if self.hasContent_():
            self.exportLiteralChildren(outfile, level, name_)
    def exportLiteralAttributes(self, outfile, level, already_processed, name_):
        pass
    def exportLiteralChildren(self, outfile, level, name_):
        if self.area is not None:
            showIndent(outfile, level)
            outfile.write('area=%d,\n' % self.area)
    def exportDict(self, name_='ProtocolOspfType'):
        obj_json = json.dumps(self, default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        obj_dict = json.loads(obj_json)
        return {name_: obj_dict}
    def build(self, node):
        self.buildAttributes(node, node.attrib, [])
        for child in node:
            nodeName_ = Tag_pattern_.match(child.tag).groups()[-1]
            self.buildChildren(child, node, nodeName_)
    def buildAttributes(self, node, attrs, already_processed):
        pass
    def buildChildren(self, child_, node, nodeName_, fromsubclass_=False):
        if nodeName_ == 'area':
            sval_ = child_.text
            try:
                ival_ = int(sval_)
            except (TypeError, ValueError), exp:
                raise_parse_error(child_, 'requires integer: %s' % exp)
            ival_ = self.gds_validate_integer(ival_, node, 'area')
            self.area = ival_
# end class ProtocolOspfType


class ProtocolStaticType(GeneratedsSuper):
    """
    ProtocolStaticType class definition from :doc:`vnc_cfg.xsd`
    """
    subclass = None
    superclass = None
    def __init__(self, route=None, **kwargs):
        if (route is None) or (route == []):
            self.route = []
        else:
            self.route = route
    def factory(*args_, **kwargs_):
        if ProtocolStaticType.subclass:
            return ProtocolStaticType.subclass(*args_, **kwargs_)
        else:
            return ProtocolStaticType(*args_, **kwargs_)
    factory = staticmethod(factory)
    def get_route(self): return self.route
    def set_route(self, route): self.route = route
    def add_route(self, value): self.route.append(value)
    def insert_route(self, index, value): self.route[index] = value
    @classmethod
    def populate (cls, *a, **kwa):
        obj = cls (*a, **kwa)
        obj.set_route (obj.populate_string ("route"))
        return obj
    def export(self, outfile, level=1, namespace_='', name_='ProtocolStaticType', namespacedef_='', pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        showIndent(outfile, level, pretty_print)
        outfile.write('<%s%s%s' % (namespace_, name_, namespacedef_ and ' ' + namespacedef_ or '', ))
        already_processed = []
        self.exportAttributes(outfile, level, already_processed, namespace_, name_='ProtocolStaticType')
        if self.hasContent_():
            outfile.write('>%s' % (eol_, ))
            self.exportChildren(outfile, level + 1, namespace_, name_, pretty_print=pretty_print)
            showIndent(outfile, level, pretty_print)
            outfile.write('</%s%s>%s' % (namespace_, name_, eol_))
        else:
            outfile.write('/>%s' % (eol_, ))
    def exportAttributes(self, outfile, level, already_processed, namespace_='', name_='ProtocolStaticType'):
        pass
    def exportChildren(self, outfile, level, namespace_='', name_='ProtocolStaticType', fromsubclass_=False, pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        for route_ in self.route:
            showIndent(outfile, level, pretty_print)
            outfile.write('<%sroute>%s</%sroute>%s' % (namespace_, self.gds_format_string(quote_xml(route_).encode(ExternalEncoding), input_name='route'), namespace_, eol_))
    def hasContent_(self):
        if (
            self.route
            ):
            return True
        else:
            return False
    def exportLiteral(self, outfile, level, name_='ProtocolStaticType'):
        level += 1
        self.exportLiteralAttributes(outfile, level, [], name_)
        if self.hasContent_():
            self.exportLiteralChildren(outfile, level, name_)
    def exportLiteralAttributes(self, outfile, level, already_processed, name_):
        pass
    def exportLiteralChildren(self, outfile, level, name_):
        showIndent(outfile, level)
        outfile.write('route=[\n')
        level += 1
        for route_ in self.route:
            showIndent(outfile, level)
            outfile.write('%s,\n' % quote_python(route_).encode(ExternalEncoding))
        level -= 1
        showIndent(outfile, level)
        outfile.write('],\n')
    def exportDict(self, name_='ProtocolStaticType'):
        obj_json = json.dumps(self, default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        obj_dict = json.loads(obj_json)
        return {name_: obj_dict}
    def build(self, node):
        self.buildAttributes(node, node.attrib, [])
        for child in node:
            nodeName_ = Tag_pattern_.match(child.tag).groups()[-1]
            self.buildChildren(child, node, nodeName_)
    def buildAttributes(self, node, attrs, already_processed):
        pass
    def buildChildren(self, child_, node, nodeName_, fromsubclass_=False):
        if nodeName_ == 'route':
            route_ = child_.text
            route_ = self.gds_validate_string(route_, node, 'route')
            self.route.append(route_)
# end class ProtocolStaticType


class ConnectionType(GeneratedsSuper):
    """
    ConnectionType class definition from :doc:`vnc_cfg.xsd`
    """
    subclass = None
    superclass = None
    def __init__(self, **kwargs):
        pass
    def factory(*args_, **kwargs_):
        if ConnectionType.subclass:
            return ConnectionType.subclass(*args_, **kwargs_)
        else:
            return ConnectionType(*args_, **kwargs_)
    factory = staticmethod(factory)
    @classmethod
    def populate (cls, *a, **kwa):
        obj = cls (*a, **kwa)
        return obj
    def export(self, outfile, level=1, namespace_='', name_='ConnectionType', namespacedef_='', pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        showIndent(outfile, level, pretty_print)
        outfile.write('<%s%s%s' % (namespace_, name_, namespacedef_ and ' ' + namespacedef_ or '', ))
        already_processed = []
        self.exportAttributes(outfile, level, already_processed, namespace_, name_='ConnectionType')
        if self.hasContent_():
            outfile.write('>%s' % (eol_, ))
            self.exportChildren(outfile, level + 1, namespace_, name_, pretty_print=pretty_print)
            outfile.write('</%s%s>%s' % (namespace_, name_, eol_))
        else:
            outfile.write('/>%s' % (eol_, ))
    def exportAttributes(self, outfile, level, already_processed, namespace_='', name_='ConnectionType'):
        pass
    def exportChildren(self, outfile, level, namespace_='', name_='ConnectionType', fromsubclass_=False, pretty_print=True):
        pass
    def hasContent_(self):
        if (

            ):
            return True
        else:
            return False
    def exportLiteral(self, outfile, level, name_='ConnectionType'):
        level += 1
        self.exportLiteralAttributes(outfile, level, [], name_)
        if self.hasContent_():
            self.exportLiteralChildren(outfile, level, name_)
    def exportLiteralAttributes(self, outfile, level, already_processed, name_):
        pass
    def exportLiteralChildren(self, outfile, level, name_):
        pass
    def exportDict(self, name_='ConnectionType'):
        obj_json = json.dumps(self, default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        obj_dict = json.loads(obj_json)
        return {name_: obj_dict}
    def build(self, node):
        self.buildAttributes(node, node.attrib, [])
        for child in node:
            nodeName_ = Tag_pattern_.match(child.tag).groups()[-1]
            self.buildChildren(child, node, nodeName_)
    def buildAttributes(self, node, attrs, already_processed):
        pass
    def buildChildren(self, child_, node, nodeName_, fromsubclass_=False):
        pass
# end class ConnectionType


class InstanceTargetType(GeneratedsSuper):
    """
    InstanceTargetType class definition from :doc:`vnc_cfg.xsd`
    """
    subclass = None
    superclass = None
    def __init__(self, import_export=None, **kwargs):
        self.import_export = import_export
    def factory(*args_, **kwargs_):
        if InstanceTargetType.subclass:
            return InstanceTargetType.subclass(*args_, **kwargs_)
        else:
            return InstanceTargetType(*args_, **kwargs_)
    factory = staticmethod(factory)
    def get_import_export(self): return self.import_export
    def set_import_export(self, import_export): self.import_export = import_export
    def validate_ImportExportType(self, value):
        # Validate type ImportExportType, a restriction on xsd:string.
        pass
    @classmethod
    def populate (cls, *a, **kwa):
        obj = cls (*a, **kwa)
        obj.set_import_export (obj.populate_string ("import_export"))
        return obj
    def export(self, outfile, level=1, namespace_='', name_='InstanceTargetType', namespacedef_='', pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        showIndent(outfile, level, pretty_print)
        outfile.write('<%s%s%s' % (namespace_, name_, namespacedef_ and ' ' + namespacedef_ or '', ))
        already_processed = []
        self.exportAttributes(outfile, level, already_processed, namespace_, name_='InstanceTargetType')
        if self.hasContent_():
            outfile.write('>%s' % (eol_, ))
            self.exportChildren(outfile, level + 1, namespace_, name_, pretty_print=pretty_print)
            showIndent(outfile, level, pretty_print)
            outfile.write('</%s%s>%s' % (namespace_, name_, eol_))
        else:
            outfile.write('/>%s' % (eol_, ))
    def exportAttributes(self, outfile, level, already_processed, namespace_='', name_='InstanceTargetType'):
        pass
    def exportChildren(self, outfile, level, namespace_='', name_='InstanceTargetType', fromsubclass_=False, pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        if self.import_export is not None:
            showIndent(outfile, level, pretty_print)
            outfile.write('<%simport-export>%s</%simport-export>%s' % (namespace_, self.gds_format_string(quote_xml(self.import_export).encode(ExternalEncoding), input_name='import-export'), namespace_, eol_))
    def hasContent_(self):
        if (
            self.import_export is not None
            ):
            return True
        else:
            return False
    def exportLiteral(self, outfile, level, name_='InstanceTargetType'):
        level += 1
        self.exportLiteralAttributes(outfile, level, [], name_)
        if self.hasContent_():
            self.exportLiteralChildren(outfile, level, name_)
    def exportLiteralAttributes(self, outfile, level, already_processed, name_):
        pass
    def exportLiteralChildren(self, outfile, level, name_):
        if self.import_export is not None:
            showIndent(outfile, level)
            outfile.write('import_export=%s,\n' % quote_python(self.import_export).encode(ExternalEncoding))
    def exportDict(self, name_='InstanceTargetType'):
        obj_json = json.dumps(self, default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        obj_dict = json.loads(obj_json)
        return {name_: obj_dict}
    def build(self, node):
        self.buildAttributes(node, node.attrib, [])
        for child in node:
            nodeName_ = Tag_pattern_.match(child.tag).groups()[-1]
            self.buildChildren(child, node, nodeName_)
    def buildAttributes(self, node, attrs, already_processed):
        pass
    def buildChildren(self, child_, node, nodeName_, fromsubclass_=False):
        if nodeName_ == 'import-export':
            import_export_ = child_.text
            import_export_ = self.gds_validate_string(import_export_, node, 'import_export')
            self.import_export = import_export_
            self.validate_ImportExportType(self.import_export)    # validate type ImportExportType
# end class InstanceTargetType


class DefaultProtocolType(GeneratedsSuper):
    """
    DefaultProtocolType class definition from :doc:`vnc_cfg.xsd`
    """
    subclass = None
    superclass = None
    def __init__(self, bgp=None, ospf=None, **kwargs):
        if isinstance(bgp, dict):
            obj = ProtocolBgpType(**bgp)
            self.bgp = obj
        else:
            self.bgp = bgp
        if isinstance(ospf, dict):
            obj = ProtocolOspfType(**ospf)
            self.ospf = obj
        else:
            self.ospf = ospf
    def factory(*args_, **kwargs_):
        if DefaultProtocolType.subclass:
            return DefaultProtocolType.subclass(*args_, **kwargs_)
        else:
            return DefaultProtocolType(*args_, **kwargs_)
    factory = staticmethod(factory)
    def get_bgp(self): return self.bgp
    def set_bgp(self, bgp): self.bgp = bgp
    def get_ospf(self): return self.ospf
    def set_ospf(self, ospf): self.ospf = ospf
    @classmethod
    def populate (cls, *a, **kwa):
        obj = cls (*a, **kwa)
        obj.set_bgp (ProtocolBgpType.populate ())
        obj.set_ospf (ProtocolOspfType.populate ())
        return obj
    def export(self, outfile, level=1, namespace_='', name_='DefaultProtocolType', namespacedef_='', pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        showIndent(outfile, level, pretty_print)
        outfile.write('<%s%s%s' % (namespace_, name_, namespacedef_ and ' ' + namespacedef_ or '', ))
        already_processed = []
        self.exportAttributes(outfile, level, already_processed, namespace_, name_='DefaultProtocolType')
        if self.hasContent_():
            outfile.write('>%s' % (eol_, ))
            self.exportChildren(outfile, level + 1, namespace_, name_, pretty_print=pretty_print)
            showIndent(outfile, level, pretty_print)
            outfile.write('</%s%s>%s' % (namespace_, name_, eol_))
        else:
            outfile.write('/>%s' % (eol_, ))
    def exportAttributes(self, outfile, level, already_processed, namespace_='', name_='DefaultProtocolType'):
        pass
    def exportChildren(self, outfile, level, namespace_='', name_='DefaultProtocolType', fromsubclass_=False, pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        if self.bgp is not None:
            self.bgp.export(outfile, level, namespace_, name_='bgp', pretty_print=pretty_print)
        if self.ospf is not None:
            self.ospf.export(outfile, level, namespace_, name_='ospf', pretty_print=pretty_print)
    def hasContent_(self):
        if (
            self.bgp is not None or
            self.ospf is not None
            ):
            return True
        else:
            return False
    def exportLiteral(self, outfile, level, name_='DefaultProtocolType'):
        level += 1
        self.exportLiteralAttributes(outfile, level, [], name_)
        if self.hasContent_():
            self.exportLiteralChildren(outfile, level, name_)
    def exportLiteralAttributes(self, outfile, level, already_processed, name_):
        pass
    def exportLiteralChildren(self, outfile, level, name_):
        if self.bgp is not None:
            showIndent(outfile, level)
            outfile.write('bgp=model_.ProtocolBgpType(\n')
            self.bgp.exportLiteral(outfile, level, name_='bgp')
            showIndent(outfile, level)
            outfile.write('),\n')
        if self.ospf is not None:
            showIndent(outfile, level)
            outfile.write('ospf=model_.ProtocolOspfType(\n')
            self.ospf.exportLiteral(outfile, level, name_='ospf')
            showIndent(outfile, level)
            outfile.write('),\n')
    def exportDict(self, name_='DefaultProtocolType'):
        obj_json = json.dumps(self, default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        obj_dict = json.loads(obj_json)
        return {name_: obj_dict}
    def build(self, node):
        self.buildAttributes(node, node.attrib, [])
        for child in node:
            nodeName_ = Tag_pattern_.match(child.tag).groups()[-1]
            self.buildChildren(child, node, nodeName_)
    def buildAttributes(self, node, attrs, already_processed):
        pass
    def buildChildren(self, child_, node, nodeName_, fromsubclass_=False):
        if nodeName_ == 'bgp':
            obj_ = ProtocolBgpType.factory()
            obj_.build(child_)
            self.set_bgp(obj_)
        elif nodeName_ == 'ospf':
            obj_ = ProtocolOspfType.factory()
            obj_.build(child_)
            self.set_ospf(obj_)
# end class DefaultProtocolType


class BindingType(GeneratedsSuper):
    """
    BindingType class definition from :doc:`vnc_cfg.xsd`
    """
    subclass = None
    superclass = None
    def __init__(self, **kwargs):
        pass
    def factory(*args_, **kwargs_):
        if BindingType.subclass:
            return BindingType.subclass(*args_, **kwargs_)
        else:
            return BindingType(*args_, **kwargs_)
    factory = staticmethod(factory)
    @classmethod
    def populate (cls, *a, **kwa):
        obj = cls (*a, **kwa)
        return obj
    def export(self, outfile, level=1, namespace_='', name_='BindingType', namespacedef_='', pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        showIndent(outfile, level, pretty_print)
        outfile.write('<%s%s%s' % (namespace_, name_, namespacedef_ and ' ' + namespacedef_ or '', ))
        already_processed = []
        self.exportAttributes(outfile, level, already_processed, namespace_, name_='BindingType')
        if self.hasContent_():
            outfile.write('>%s' % (eol_, ))
            self.exportChildren(outfile, level + 1, namespace_, name_, pretty_print=pretty_print)
            outfile.write('</%s%s>%s' % (namespace_, name_, eol_))
        else:
            outfile.write('/>%s' % (eol_, ))
    def exportAttributes(self, outfile, level, already_processed, namespace_='', name_='BindingType'):
        pass
    def exportChildren(self, outfile, level, namespace_='', name_='BindingType', fromsubclass_=False, pretty_print=True):
        pass
    def hasContent_(self):
        if (

            ):
            return True
        else:
            return False
    def exportLiteral(self, outfile, level, name_='BindingType'):
        level += 1
        self.exportLiteralAttributes(outfile, level, [], name_)
        if self.hasContent_():
            self.exportLiteralChildren(outfile, level, name_)
    def exportLiteralAttributes(self, outfile, level, already_processed, name_):
        pass
    def exportLiteralChildren(self, outfile, level, name_):
        pass
    def exportDict(self, name_='BindingType'):
        obj_json = json.dumps(self, default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        obj_dict = json.loads(obj_json)
        return {name_: obj_dict}
    def build(self, node):
        self.buildAttributes(node, node.attrib, [])
        for child in node:
            nodeName_ = Tag_pattern_.match(child.tag).groups()[-1]
            self.buildChildren(child, node, nodeName_)
    def buildAttributes(self, node, attrs, already_processed):
        pass
    def buildChildren(self, child_, node, nodeName_, fromsubclass_=False):
        pass
# end class BindingType


class AttachmentAddressType(GeneratedsSuper):
    """
    AttachmentAddressType class definition from :doc:`vnc_cfg.xsd`
    """
    subclass = None
    superclass = None
    def __init__(self, **kwargs):
        pass
    def factory(*args_, **kwargs_):
        if AttachmentAddressType.subclass:
            return AttachmentAddressType.subclass(*args_, **kwargs_)
        else:
            return AttachmentAddressType(*args_, **kwargs_)
    factory = staticmethod(factory)
    @classmethod
    def populate (cls, *a, **kwa):
        obj = cls (*a, **kwa)
        return obj
    def export(self, outfile, level=1, namespace_='', name_='AttachmentAddressType', namespacedef_='', pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        showIndent(outfile, level, pretty_print)
        outfile.write('<%s%s%s' % (namespace_, name_, namespacedef_ and ' ' + namespacedef_ or '', ))
        already_processed = []
        self.exportAttributes(outfile, level, already_processed, namespace_, name_='AttachmentAddressType')
        if self.hasContent_():
            outfile.write('>%s' % (eol_, ))
            self.exportChildren(outfile, level + 1, namespace_, name_, pretty_print=pretty_print)
            outfile.write('</%s%s>%s' % (namespace_, name_, eol_))
        else:
            outfile.write('/>%s' % (eol_, ))
    def exportAttributes(self, outfile, level, already_processed, namespace_='', name_='AttachmentAddressType'):
        pass
    def exportChildren(self, outfile, level, namespace_='', name_='AttachmentAddressType', fromsubclass_=False, pretty_print=True):
        pass
    def hasContent_(self):
        if (

            ):
            return True
        else:
            return False
    def exportLiteral(self, outfile, level, name_='AttachmentAddressType'):
        level += 1
        self.exportLiteralAttributes(outfile, level, [], name_)
        if self.hasContent_():
            self.exportLiteralChildren(outfile, level, name_)
    def exportLiteralAttributes(self, outfile, level, already_processed, name_):
        pass
    def exportLiteralChildren(self, outfile, level, name_):
        pass
    def exportDict(self, name_='AttachmentAddressType'):
        obj_json = json.dumps(self, default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        obj_dict = json.loads(obj_json)
        return {name_: obj_dict}
    def build(self, node):
        self.buildAttributes(node, node.attrib, [])
        for child in node:
            nodeName_ = Tag_pattern_.match(child.tag).groups()[-1]
            self.buildChildren(child, node, nodeName_)
    def buildAttributes(self, node, attrs, already_processed):
        pass
    def buildChildren(self, child_, node, nodeName_, fromsubclass_=False):
        pass
# end class AttachmentAddressType


class AttachmentInfoType(GeneratedsSuper):
    """
    AttachmentInfoType class definition from :doc:`vnc_cfg.xsd`
    """
    subclass = None
    superclass = None
    def __init__(self, static=None, bgp=None, ospf=None, state=None, **kwargs):
        if isinstance(static, dict):
            obj = ProtocolStaticType(**static)
            self.static = obj
        else:
            self.static = static
        if isinstance(bgp, dict):
            obj = ProtocolBgpType(**bgp)
            self.bgp = obj
        else:
            self.bgp = bgp
        if isinstance(ospf, dict):
            obj = ProtocolOspfType(**ospf)
            self.ospf = obj
        else:
            self.ospf = ospf
        self.state = state
    def factory(*args_, **kwargs_):
        if AttachmentInfoType.subclass:
            return AttachmentInfoType.subclass(*args_, **kwargs_)
        else:
            return AttachmentInfoType(*args_, **kwargs_)
    factory = staticmethod(factory)
    def get_static(self): return self.static
    def set_static(self, static): self.static = static
    def get_bgp(self): return self.bgp
    def set_bgp(self, bgp): self.bgp = bgp
    def get_ospf(self): return self.ospf
    def set_ospf(self, ospf): self.ospf = ospf
    def get_state(self): return self.state
    def set_state(self, state): self.state = state
    @classmethod
    def populate (cls, *a, **kwa):
        obj = cls (*a, **kwa)
        obj.set_static (ProtocolStaticType.populate ())
        obj.set_bgp (ProtocolBgpType.populate ())
        obj.set_ospf (ProtocolOspfType.populate ())
        obj.set_state (obj.populate_string ("state"))
        return obj
    def export(self, outfile, level=1, namespace_='', name_='AttachmentInfoType', namespacedef_='', pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        showIndent(outfile, level, pretty_print)
        outfile.write('<%s%s%s' % (namespace_, name_, namespacedef_ and ' ' + namespacedef_ or '', ))
        already_processed = []
        self.exportAttributes(outfile, level, already_processed, namespace_, name_='AttachmentInfoType')
        if self.hasContent_():
            outfile.write('>%s' % (eol_, ))
            self.exportChildren(outfile, level + 1, namespace_, name_, pretty_print=pretty_print)
            showIndent(outfile, level, pretty_print)
            outfile.write('</%s%s>%s' % (namespace_, name_, eol_))
        else:
            outfile.write('/>%s' % (eol_, ))
    def exportAttributes(self, outfile, level, already_processed, namespace_='', name_='AttachmentInfoType'):
        pass
    def exportChildren(self, outfile, level, namespace_='', name_='AttachmentInfoType', fromsubclass_=False, pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        if self.static is not None:
            self.static.export(outfile, level, namespace_, name_='static', pretty_print=pretty_print)
        if self.bgp is not None:
            self.bgp.export(outfile, level, namespace_, name_='bgp', pretty_print=pretty_print)
        if self.ospf is not None:
            self.ospf.export(outfile, level, namespace_, name_='ospf', pretty_print=pretty_print)
        if self.state is not None:
            showIndent(outfile, level, pretty_print)
            outfile.write('<%sstate>%s</%sstate>%s' % (namespace_, self.gds_format_string(quote_xml(self.state).encode(ExternalEncoding), input_name='state'), namespace_, eol_))
    def hasContent_(self):
        if (
            self.static is not None or
            self.bgp is not None or
            self.ospf is not None or
            self.state is not None
            ):
            return True
        else:
            return False
    def exportLiteral(self, outfile, level, name_='AttachmentInfoType'):
        level += 1
        self.exportLiteralAttributes(outfile, level, [], name_)
        if self.hasContent_():
            self.exportLiteralChildren(outfile, level, name_)
    def exportLiteralAttributes(self, outfile, level, already_processed, name_):
        pass
    def exportLiteralChildren(self, outfile, level, name_):
        if self.static is not None:
            showIndent(outfile, level)
            outfile.write('static=model_.ProtocolStaticType(\n')
            self.static.exportLiteral(outfile, level, name_='static')
            showIndent(outfile, level)
            outfile.write('),\n')
        if self.bgp is not None:
            showIndent(outfile, level)
            outfile.write('bgp=model_.ProtocolBgpType(\n')
            self.bgp.exportLiteral(outfile, level, name_='bgp')
            showIndent(outfile, level)
            outfile.write('),\n')
        if self.ospf is not None:
            showIndent(outfile, level)
            outfile.write('ospf=model_.ProtocolOspfType(\n')
            self.ospf.exportLiteral(outfile, level, name_='ospf')
            showIndent(outfile, level)
            outfile.write('),\n')
        if self.state is not None:
            showIndent(outfile, level)
            outfile.write('state=%s,\n' % quote_python(self.state).encode(ExternalEncoding))
    def exportDict(self, name_='AttachmentInfoType'):
        obj_json = json.dumps(self, default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        obj_dict = json.loads(obj_json)
        return {name_: obj_dict}
    def build(self, node):
        self.buildAttributes(node, node.attrib, [])
        for child in node:
            nodeName_ = Tag_pattern_.match(child.tag).groups()[-1]
            self.buildChildren(child, node, nodeName_)
    def buildAttributes(self, node, attrs, already_processed):
        pass
    def buildChildren(self, child_, node, nodeName_, fromsubclass_=False):
        if nodeName_ == 'static':
            obj_ = ProtocolStaticType.factory()
            obj_.build(child_)
            self.set_static(obj_)
        elif nodeName_ == 'bgp':
            obj_ = ProtocolBgpType.factory()
            obj_.build(child_)
            self.set_bgp(obj_)
        elif nodeName_ == 'ospf':
            obj_ = ProtocolOspfType.factory()
            obj_.build(child_)
            self.set_ospf(obj_)
        elif nodeName_ == 'state':
            state_ = child_.text
            state_ = self.gds_validate_string(state_, node, 'state')
            self.state = state_
# end class AttachmentInfoType


class state(GeneratedsSuper):
    """
    state class definition from :doc:`vnc_cfg.xsd`
    """
    subclass = None
    superclass = None
    def __init__(self, **kwargs):
        pass
    def factory(*args_, **kwargs_):
        if state.subclass:
            return state.subclass(*args_, **kwargs_)
        else:
            return state(*args_, **kwargs_)
    factory = staticmethod(factory)
    @classmethod
    def populate (cls, *a, **kwa):
        obj = cls (*a, **kwa)
        return obj
    def export(self, outfile, level=1, namespace_='', name_='state', namespacedef_='', pretty_print=True):
        if pretty_print:
            eol_ = '\n'
        else:
            eol_ = ''
        showIndent(outfile, level, pretty_print)
        outfile.write('<%s%s%s' % (namespace_, name_, namespacedef_ and ' ' + namespacedef_ or '', ))
        already_processed = []
        self.exportAttributes(outfile, level, already_processed, namespace_, name_='state')
        if self.hasContent_():
            outfile.write('>%s' % (eol_, ))
            self.exportChildren(outfile, level + 1, namespace_, name_, pretty_print=pretty_print)
            outfile.write('</%s%s>%s' % (namespace_, name_, eol_))
        else:
            outfile.write('/>%s' % (eol_, ))
    def exportAttributes(self, outfile, level, already_processed, namespace_='', name_='state'):
        pass
    def exportChildren(self, outfile, level, namespace_='', name_='state', fromsubclass_=False, pretty_print=True):
        pass
    def hasContent_(self):
        if (

            ):
            return True
        else:
            return False
    def exportLiteral(self, outfile, level, name_='state'):
        level += 1
        self.exportLiteralAttributes(outfile, level, [], name_)
        if self.hasContent_():
            self.exportLiteralChildren(outfile, level, name_)
    def exportLiteralAttributes(self, outfile, level, already_processed, name_):
        pass
    def exportLiteralChildren(self, outfile, level, name_):
        pass
    def exportDict(self, name_='state'):
        obj_json = json.dumps(self, default=lambda o: dict((k, v) for k, v in o.__dict__.iteritems()))
        obj_dict = json.loads(obj_json)
        return {name_: obj_dict}
    def build(self, node):
        self.buildAttributes(node, node.attrib, [])
        for child in node:
            nodeName_ = Tag_pattern_.match(child.tag).groups()[-1]
            self.buildChildren(child, node, nodeName_)
    def buildAttributes(self, node, attrs, already_processed):
        pass
    def buildChildren(self, child_, node, nodeName_, fromsubclass_=False):
        pass
# end class state



__all__ = [
    "AclEntriesType",
    "AclRuleType",
    "ActionListType",
    "AddressFamilies",
    "AddressType",
    "ApiAccessListType",
    "ApiAccessType",
    "AttachmentAddressType",
    "AttachmentInfoType",
    "BgpPeeringAttributes",
    "BgpRouterParams",
    "BgpSession",
    "BgpSessionAttributes",
    "BindingType",
    "ConnectionType",
    "DefaultProtocolType",
    "DhcpOptionType",
    "DhcpOptionsListType",
    "DomainLimitsType",
    "FloatingIpPoolType",
    "IdPermsType",
    "InstanceTargetType",
    "IpAddressesType",
    "IpamDnsAddressType",
    "IpamSubnetType",
    "IpamType",
    "MacAddressesType",
    "MatchConditionType",
    "MirrorActionType",
    "PermType",
    "PolicyBasedForwardingRuleType",
    "PolicyEntriesType",
    "PolicyRuleType",
    "PortType",
    "ProtocolBgpType",
    "ProtocolOspfType",
    "ProtocolStaticType",
    "RouteTableType",
    "RouteTargetList",
    "RouteType",
    "SequenceType",
    "ServiceChainInfo",
    "ServiceInstanceType",
    "ServiceScaleOutType",
    "ServiceTemplateInterfaceType",
    "ServiceTemplateType",
    "StaticRouteEntriesType",
    "StaticRouteType",
    "SubnetType",
    "TimerType",
    "UuidType",
    "VirtualDnsRecordType",
    "VirtualDnsType",
    "VirtualMachineInterfacePropertiesType",
    "VirtualNetworkPolicyType",
    "VirtualNetworkType",
    "VnSubnetsType",
    "access_control_list_link",
    "config_root_domain",
    "config_root_global_system_config",
    "customer_attachment_floating_ip",
    "customer_attachment_virtual_machine_interface",
    "domain_namespace",
    "domain_project",
    "domain_service_template",
    "domain_virtual_DNS",
    "dummy",
    "floating_ip_pool_floating_ip",
    "floating_ip_project",
    "floating_ip_virtual_machine_interface",
    "global_system_config_bgp_router",
    "global_system_config_physical_router",
    "global_system_config_virtual_router",
    "instance_bgp_router",
    "instance_ip_virtual_machine_interface",
    "instance_ip_virtual_network",
    "logical_interface_virtual_network",
    "mac_address",
    "network_ipam_virtual_DNS",
    "physical_interface_logical_interface",
    "physical_router_bgp_router",
    "physical_router_physical_interface",
    "project_floating_ip_pool",
    "project_network_ipam",
    "project_network_policy",
    "project_security_group",
    "project_service_instance",
    "project_virtual_network",
    "provider_attachment_virtual_router",
    "service_instance_service_template",
    "state",
    "virtual_DNS_virtual_DNS_record",
    "virtual_machine_interface_virtual_network",
    "virtual_machine_security_group",
    "virtual_machine_service_instance",
    "virtual_machine_virtual_machine_interface",
    "virtual_network_floating_ip_pool",
    "virtual_network_routing_instance",
    "virtual_router_bgp_router",
    "virtual_router_virtual_machine"
    ]
